# Luraph v15.2 notes

What was added to this tool for v15.2, what it found, and what is still open.
Two test scripts are in `samples/`:

- `luraph_v15_2_sample.luau`: the v15.2 sample from the luraph-v15.2-deobf repo.
- `luraph_v15_1_script.lua`: your v15.1 script, recovered from `studio/instrumented.luau`
  by removing the hooks (re-instrumenting it reproduces that file byte for byte).

## What changed

| File | Change |
|---|---|
| `src/vmmap.js`, `core/obfuscators/luraph_v15/driver.py` | The instrumentation records the inner maker's arguments (`__m1`..`__mN`, `__mn`) for three-level closure makers. |
| `core/obfuscators/luraph_v15/devirt.py` | `VMModel.maker_args` uses those numbers instead of binding every inner-maker parameter to the upvalue list. Closures that were never created at run time fall back to the numbers at their creation site (`dump.maker_site`). |
| `runtime/envlog.luau` | `cfg.cstack_pcall`: a `pcall`/`ypcall` that refuses to run its function at the C-call limit, like Roblox. `IsA`, `IsDescendantOf`, `IsAncestorOf` answer correctly for `game`, `workspace` and services. |
| `src/driver.js`, `core/obfuscators/luraph_v15/driver.py` | `cstack_pcall` is on for a v15.2+ header. For other scripts it is tried once when an anti-tamper trap is reached, and kept only if the trace gets longer. The "run stopped before the script's own code" note is no longer written when statements follow Luraph's probe block. Byte strings repeated in the lifted output are written once (`luraphData`). |
| `src/optrace.js` | New. Records every VM instruction and prints the last ones before a stall or error. |

`--cfg-json '{"cstack_pcall":false}'` (or `true`) overrides the automatic choice.

## The v15.2 closure maker

```
[83] = function(t, W, m, a, X, V, E, E, c, k, _, R, Y, F)      -- per proto: VM object, frame size W, entry pc m, arrays
    local C, y, A, ... = t[7], t.ZQ, ...
    return function(Z, Z, Z, J, i, U)                          -- per closure: seeds Z (3rd) and J, upvalues i
        local U, S, z, ... = C, y, A, ...
        return function(...)                                   -- the interpreter
            ...
            W, Q, Wh, mh = m, J, Z, E                          -- pc, key state, key state, mode
```

The two seeds feed the handlers that decrypt operands as they run, so without them the
lifter could not follow a single function (`value <UpList> in an expression`). The chunk
has four VMs of this shape (`[125]`, `[22]`, `[56]`, `[83]`); the sample's script runs in
the last one, and its main function (proto 1) contains Luraph's startup checks followed by
the script's own code.

Closures can also be plain Lua functions made by small helpers on the VM object
(`[53]`, `[28]`, `[47]`, `[75]`, `[113]`, ...). They show up as `luraph_runtime<N>` in the output.

## The depth probe (why v15.2 looped forever)

Luraph recurses through an `__index` metamethod. At depth 198 it expects, as in Roblox:

1. `pcall(A)` runs `A`,
2. one more `__index` call inside `A` fails with "C stack overflow",
3. `pcall(function() pcall(B) end)` does not run `B`.

The bundled Luau never limits nested `pcall`, so `B` ran, the check failed and the script
entered its crash routine (function #6: scrambles its bytecode buffer in an endless loop).
The old behaviour of disabling that function only hid the failure.
Your v15.1 script has the same probe: its traps #8 and #7 are the same thing.

`cstack_pcall` checks the limit with two nested coroutine resumes, which fail exactly when
one more C call is not allowed. `xpcall` is not changed: no script tested its behaviour there.

## Finding the next divergence

```
node src/optrace.js <script> --last 400                       # last 400 VM instructions before the failure
node src/optrace.js <script> --before-function 6 --last 3000  # what ran before function #6 was first entered
```

Lines are `P<function> L<loop> op<opcode> pc<pc>`. Match them with
`python core/obfuscators/luraph_v15/devirt.py <script> <protos.json> --chunk <chunk> --raw <function>`
(set `PYTHONPATH=core`), or read the lifted function with `--lift <function>`.
`--cfg-json '{"ptrace":true}'` on `deob.js` prints proxy-level events.

## Status (bundled Linux Luau, same results as the Windows build for the old tool)

| Script | Before | Now |
|---|---|---|
| v15.2 sample | endless loop after the first Path2D block; 1 function, nothing lifted | passes Luraph's startup and the script's own PC-R01 and PC-R02 checks; stops at `PC-E01`; 38 functions lifted, 24 unlifted blocks |
| v15.1 script | traps #8 and #7 disabled, run "finished" without reaching the script; 35 functions, 7 unlifted blocks | passes the probe without disabling anything; stops later with a decode error (`Script:3: buffer access out of bounds`); 35 functions, 5 unlifted blocks |

## Open

- **`PC-E01` / `PC-E02` (the v15.2 sample's own executor check).** It calls
  `getrawmetatable(setmetatable({}, { __metatable = "locked" }))` and `setrawmetatable`. The
  runtime cannot read a protected metatable: Luau has no raw `getmetatable`, and wrapping
  `setmetatable` to remember metatables is the kind of wrapper the depth probes punish.
  The clean fix is a raw-metatable function added in `build_luau.py`.
- **v15.1 script, after the instance-tree probe.** The last thing it does is `debug.info(f, "sl")`
  on about 100 of its functions (answer: `Script`, `3`), then a buffer is created with a bad
  size: a wrong key from an earlier answer. Not found yet.
- **Lifter, v15.2.** 74 "symbolic value store into proto array" (handlers that decrypt
  operands with a key that depends on run-time values) and 49 "symbolic next pc/mode"
  (computed jumps of the flattened control flow). Where constants are not decoded the VM's
  own decrypt code is inlined into the output, which is why it is large (5 MB) and noisy.
  The new numeric `for` state tables (`{ index, step, limit, previous, ... }`) are not
  turned back into loops.
- **Upvalues of closures made by the v15.2 closure instruction** (descriptor triples in
  `ah[-2]`) are not bound to the parent's registers: they print as `upv<N>`.
- The repo's line that strips a leading `getgenv().SCRIPT_KEY = ...` was not ported: this
  tool runs the script with the line in place, which keeps the key visible to the script.

## Final state (Nov 24 20:27 EST)
- All 15 lift holes filled and trace-pinned: 13 return holes (shared t92 tail, Mn=3017039603 at pc 625, +3633704100 mod 2^32), t82 compare (v41==144012123, +171833604 vs 315845727), and line 79 n = Mn - g = 2019976274 - 1312148884 = 707827390 (ot8 watch at idx 7435 fired once: r3=1312148884, r4=2019976274; dispatch Mn match confirmed).
- Six ENCFUNC stubs (luraph_runtime1..6) documented at definition and all five call sites. Findings: runtime5 returns the tamper-path abort fn (never tripped); runtime1-4 top-level calls discard return values; closures LTable#112/#200/#141 created but never invoked; runtime6 sits in a dead (nil-condition) fn12 branch. Encrypted nested bodies never executed; no live code depends on them.
- Deliverable: output/input_v152.lifted_annotated.luau (7,580 lines, header explains holes/nil-branches/stubs, AST-valid via bin/luau-ast).
- Script identity: Roblox GUI payload (Folder, ScreenGui, Frame, Path2D, ScreenGui:Destroy at end).
