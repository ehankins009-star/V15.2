'use strict';
// PC-keyed watch probes: at each dispatch head `while true do X=Y[Z];`, inject a
// guarded recorder that captures the packed instruction word, the decoded field
// arrays and the watched registers, into the runtime ring (__r), encoded as
// negative probe values (tag*2^40 + payload), capped at 40 firings per pc.
const fs = require('fs');
const path = require('path');

const B = '1099511627776';
const headRe = /while true do (?:local )?([A-Za-z_]+)(?:,[A-Za-z_]+)*=([A-Za-z_]+)\[([A-Za-z_]+)\];/g;

const WATCH_MAIN = { 9408: [84, 85, 86, 87] };
const WATCH_CHUNK = { 625: [], 626: [], 168: [], 196: [], 18: [2, 4], 88: [0, 1, 2, 3, 4, 5], 666: [3, 17, 18], 1949: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 17: [], 50: [], 7435: [3, 4], 7434: [4] };

function typecode(v) {
  return "((type(" + v + ")=='number' and 0) or (type(" + v + ")=='nil' and 1) or (" + v + "==false and 2) or (" + v + "==true and 3) or (type(" + v + ")=='string' and 4) or (type(" + v + ")=='table' and 5) or (type(" + v + ")=='function' and 6) or 7)";
}

function injectWatch(src, watch, label) {
  const watchLit = '{' + Object.keys(watch).map(k => '[' + k + ']=' + JSON.stringify(watch[k])).join(',') + '}';
  let out = src;
  let count = 0;
  const re = new RegExp(headRe.source, 'g');
  const edits = [];
  let m;
  while ((m = re.exec(src))) {
    const names = m[1].split(',');
    const arr = m[2], idx = m[3];
    const at = m.index + m[0].length;
    const window = src.slice(at, at + 5000);
    const regarr = window.includes('G[') ? 'G' : (window.includes('i[') ? 'i' : null);
    if (!regarr) continue;
    const keyOk = !names.includes('Mn');
    let probe = 'if __wp and __wp[' + idx + '] then local __ck=__wpk[' + idx + '] or 0;if __ck<40 then __wpk[' + idx + ']=__ck+1;'
      + 'pcall(function()'
      + '__r[#__r+1]=-((910*' + B + ')+((' + idx + ' or -1)+1));'
      + '__r[#__r+1]=-((911*' + B + ')+((type(' + arr + '[' + idx + '])==' + "'number'" + ' and (math.floor(' + arr + '[' + idx + '])%4294967296) or 0)));'
      + '__r[#__r+1]=-((912*' + B + ')+((type(X[' + idx + '])==' + "'number'" + ' and (X[' + idx + ']%4294967296) or 0)));'
      + '__r[#__r+1]=-((913*' + B + ')+((type(V[' + idx + '])==' + "'number'" + ' and (V[' + idx + ']%4294967296) or 0)));'
      + '__r[#__r+1]=-((914*' + B + ')+((type(z[' + idx + '])==' + "'number'" + ' and (z[' + idx + ']%4294967296) or 0)));';
    if (keyOk) probe += '__r[#__r+1]=-((915*' + B + ')+((type(Mn)==' + "'number'" + ' and (math.floor(Mn)%4294967296) or 4294967295)));';
    probe += 'local __wl=__wp[' + idx + '];for __wi=1,#__wl do local __rg=__wl[__wi];local __rv=' + regarr + '[__rg];'
      + '__r[#__r+1]=-(((920+__rg)*' + B + ')+(' + typecode('__rv') + '));'
      + '__r[#__r+1]=-(((960+__rg)*' + B + ')+((type(__rv)==' + "'number'" + ' and (math.floor(__rv)%' + B + ') or 0)));'
      + 'end;end);end;end;';
    edits.push([m[0], m[0] + probe]);
    count++;
  }
  for (const [a, b] of edits) out = out.split(a).join(b);
  process.stderr.write(`[*] ${label} watch probes: ${count} heads\n`);
  return out;
}

const RUNTIME_SETUP = `
env.__wpk = {}
env.__wp = __WATCH__
`;

function luaWatch(watch) {
  return '{' + Object.keys(watch).map(k => '[' + k + ']={' + (watch[k] || []).join(',') + '}').join(',') + '}';
}

function pluginRt(otraceSrc, watch) {
  const dm = /const dumpRuntime = `([\s\S]*?)`;\n/.exec(otraceSrc);
  const base = dm ? dm[1] : '';
  return base + RUNTIME_SETUP.replace('__WATCH__', luaWatch(watch));
}

module.exports = { B, headRe, WATCH_MAIN, WATCH_CHUNK, typecode, injectWatch, pluginRt, luaWatch };
