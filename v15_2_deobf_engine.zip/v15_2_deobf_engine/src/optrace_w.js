#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const harness = require('./harness');
const vmmap = require('./vmmap');

const B = '1099511627776';
const headRe = /while true do (?:local )?([A-Za-z_]+)(?:,[A-Za-z_]+)*=([A-Za-z_]+)\[([A-Za-z_]+)\];/g;

const WATCH_MAIN = { 9408: [84, 85, 86, 87] };
const WATCH_CHUNK = { 625: [], 626: [], 168: [], 196: [], 18: [2, 4], 88: [0, 1, 2, 3, 4, 5], 666: [3, 17, 18], 1949: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 17: [], 50: [] };

const dumpRuntime = `
local a = ...
local real, env, cfg = a.real, a.env, a.cfg
env.__r = {}
env.__wpk = {}
__WATCH__
env.__opdump = function()
	real.print("[wp] ring=" .. #env.__r)
	for i = 1, #env.__r do real.print("[wp] " .. real.tostring(env.__r[i])) end
end
`;


const optraceSrc = fs.readFileSync(path.join(__dirname, 'optrace.js'), 'utf8');
const dm = /const dumpRuntime = `([\s\S]*?)`;/g.exec(optraceSrc);
const OTRACE_RT = dm ? dm[1] : '';

function pluginRt() {
  const watch = `\nenv.__wpk = {}\nenv.__wp = __WATCH__\n`;
  return OTRACE_RT + watch;
}

function typecode(v) {
  return "((type(" + v + ")=='number' and 0) or (type(" + v + ")=='nil' and 1) or (" + v + "==false and 2) or (" + v + "==true and 3) or (type(" + v + ")=='string' and 4) or (type(" + v + ")=='table' and 5) or (type(" + v + ")=='function' and 6) or 7)";
}

function injectWatch(src, watch, label) {
  const watchLit = '{' + Object.keys(watch).map(k => '[' + k + ']=' + JSON.stringify(watch[k])).join(',') + '}';
  let out = src;
  let count = 0;
  const re = new RegExp(headRe.source, 'g');
  const edits = [];
  let m;
  while ((m = re.exec(src))) {
    const names = m[1].split(',');
    const arr = m[2], idx = m[3];
    const at = m.index + m[0].length;
    const window = src.slice(at, at + 5000);
    const regarr = window.includes('G[') ? 'G' : (window.includes('i[') ? 'i' : null);
    if (!regarr) continue;
    const keyOk = !names.includes('Mn');
    let probe = 'if __wp and __wp[' + idx + '] then local __ck=__wpk[' + idx + '] or 0;if __ck<40 then __wpk[' + idx + ']=__ck+1;'
      + '__r[#__r+1]=-((910*' + B + ')+((' + idx + ' or -1)+1));'
      + '__r[#__r+1]=-((911*' + B + ')+((type(' + arr + '[' + idx + '])==' + "'number'" + ' and (math.floor(' + arr + '[' + idx + '])%4294967296) or 0)));'
      + '__r[#__r+1]=-((912*' + B + ')+((type(X[' + idx + '])==' + "'number'" + ' and (X[' + idx + ']%4294967296) or 0)));'
      + '__r[#__r+1]=-((913*' + B + ')+((type(V[' + idx + '])==' + "'number'" + ' and (V[' + idx + ']%4294967296) or 0)));'
      + '__r[#__r+1]=-((914*' + B + ')+((type(z[' + idx + '])==' + "'number'" + ' and (z[' + idx + ']%4294967296) or 0)));';
    if (keyOk) probe += '__r[#__r+1]=-((915*' + B + ')+((type(Mn)==' + "'number'" + ' and (math.floor(Mn)%4294967296) or 4294967295)));';
    probe += 'local __wl=__wp[' + idx + '];for __wi=1,#__wl do local __rg=__wl[__wi];local __rv=' + regarr + '[__rg];'
      + '__r[#__r+1]=-(((920+__rg)*' + B + ')+(' + typecode('__rv') + '));'
      + '__r[#__r+1]=-(((960+__rg)*' + B + ')+((type(__rv)==' + "'number'" + ' and (math.floor(__rv)%' + B + ') or 0)));'
      + 'end;end;end;';
    edits.push([m[0], m[0] + probe]);
    count++;
  }
  for (const [a, b] of edits) out = out.split(a).join(b);
  process.stderr.write(`[*] ${label} watch probes: ${count} heads\n`);
  return out;
}

function instrument(src, filePath, key) {
  let out = vmmap.patchEntries(src, filePath, key);
  const isChunk = filePath && filePath.indexOf('.optrace.chunk_') >= 0;
  out = injectWatch(out, isChunk ? WATCH_CHUNK : WATCH_MAIN, isChunk ? 'chunk' : 'main');
  return { source: out, heads: 0 };
}

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--cfg-json') args.cfg = JSON.parse(argv[++i]);
    else if (a === '--timeout') args.timeout = parseInt(argv[++i], 10);
    else if (!args.input) args.input = a;
  }
  return args;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.input) { console.error('Usage: node src/optrace_w.js <script.lua> [--timeout S]'); process.exit(2); }
  const input = path.resolve(args.input);
  const source = fs.readFileSync(input, 'latin1');
  const luau = harness.findLuau();
  const main0 = instrument(source, input, harness.chunkKey(source));
  const hpath = input + '.optrace_w.harness.luau';
  const cfg = Object.assign({
    time_budget: 60, executor: 'Wave', devirt: true, spin: 24, stall_dump: true, skip_protos: [],
    inline_probe: true, plugin_rt: pluginRt(),
  }, args.cfg);
  const version = require('./detect').luraphVersion(source);
  if (version && (version[0] > 15 || (version[0] === 15 && version[1] >= 2)) && !('cstack_pcall' in cfg)) cfg.cstack_pcall = true;

  const chunks = {};
  let heads = main0.heads;
  let body = null;
  let cstack = !!cfg.cstack_pcall;
  const skip = Array.isArray(cfg.skip_protos) ? cfg.skip_protos.slice() : [];
  const spin0 = cfg.spin;
  for (let attempt = 1; attempt <= 8; attempt++) {
    cfg.skip_protos = skip.slice();
    cfg.spin = spin0;
    const res = await harness.runOnce(luau, main0.source, cfg, hpath, args.timeout, false, chunks);
    body = res.body;
    if (body) { const sm = /-- run status: ([^\r\n]*)/.exec(body); process.stderr.write(`[*] attempt ${attempt} status: ${sm ? sm[1] : 'none'}\n`); fs.writeFileSync(input + `.optrace_w.raw.at${attempt}.txt`, harness.getLastRaw() || ''); }
    if (!body) { process.stderr.write(`[!] run failed: ${String(res.err || '').trim().split('\n').pop()}\n`); break; }
    const found = harness.takeChunks(body).chunks;
    let added = 0;
    for (const [key, src] of found) {
      if (chunks[key]) continue;
      try { fs.writeFileSync(input + `.optrace.chunk_${key}.luau`, src, 'latin1'); } catch (e) {}
      const patched = process.env.RAW_CHILD ? { source: src, heads: 0 } : instrument(src, input + `.optrace.chunk_${key}.luau`, key);
      chunks[key] = patched.source;
      heads += patched.heads;
      added += 1;
    }
    if (added) { process.stderr.write(`[*] ${added} chunk(s) instrumented; re-running\n`); continue; }
    const trigM = new RegExp(harness.mark('TRIGGER ') + '(\\d+)').exec(body);
    if (!trigM) break;
    const pid = parseInt(trigM[1], 10);
    if (!cstack && skip.length === 0) { cstack = true; cfg.cstack_pcall = true; continue; }
    if (skip.includes(pid)) { process.stderr.write(`[!] anti-tamper trigger ${pid} fired again; giving up\n`); break; }
    process.stderr.write(`[*] anti-tamper trap through function #${pid}; disabling and re-running\n`);
    skip.push(pid);
  }
  const raw = harness.getLastRaw() || '';
  try { fs.writeFileSync(input + '.optrace_w.raw.txt', raw); } catch (e) {}
  const status = /-- run status: ([^\r\n]*)/.exec(raw);
  process.stderr.write(`[*] run status: ${status ? status[1] : '?'}\n`);
  let shown = 0;
  for (const line of raw.split('\n')) {
    if (/^\[wp\] /.test(line)) { process.stdout.write(line.replace(/\r$/, '') + '\n'); shown++; }
  }
  if (!shown) process.stderr.write('[!] no watch ring in the output\n');
}
main();
