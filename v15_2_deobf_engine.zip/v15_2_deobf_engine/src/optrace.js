#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const harness = require('./harness');
const vmmap = require('./vmmap');
const watchlib = require('./watchlib');

const headRe = /while true do (?:local )?([A-Za-z_]+)(?:,[A-Za-z_]+)*=([A-Za-z_]+)\[([A-Za-z_]+)\];/g;

const dumpRuntime = `
local a = ...
local real, env, cfg = a.real, a.env, a.cfg
env.__opdump = function()
	local ring = env.__r
	local stop = cfg.optrace_stop
	local last = #ring
	if stop then
		for i = 1, #ring do
			local e = ring[i]
			if real.type(e) == "number" and math.floor(e / 268435456) == stop then last = i + 40 break end
		end
	end
	last = math.min(last, #ring)
	local probes = 0
	local countPos = 0
	real.print("[optrace] " .. #ring .. " instructions recorded")
	local dsk = { [422]=true, [423]=true, [424]=true, [425]=true, [430]=true, [431]=true }
	local db, dn = {}, 0
	for i = 1, last do
		local e = ring[i]
		if real.type(e) == "number" then
			if e < 0 and -e >= 1099511627776 then
				probes = probes + 1
				local tag = math.floor(-e / 1099511627776)
				if dsk[tag] then
					dn = dn + 1
					db[(dn % 600) + 1] = tag .. "," .. (-e) % 1099511627776
				else
					real.print("OPD " .. (-e))
				end
			elseif e >= 0 and e < 1099511627776 then
				countPos += 1
			end
		end
	end
	real.print("[optrace] LAST=" .. last .. " COUNTPOS=" .. countPos .. " probes=" .. probes .. " dn=" .. dn)
	local kept = {}
	local need = 24000
	local i = last
	while i >= 1 and #kept < need do
		local e = ring[i]
		if real.type(e) == "number" and e >= 0 and e < 1099511627776 then
			local d = e % 65536
			local op = math.floor(e / 65536) % 256
			local p16 = math.floor(e / 16777216)
			local pid = math.floor(p16 / 16)
			local ph = p16 % 16
			kept[#kept + 1] = i .. "|" .. pid .. "|" .. ph .. "|" .. op .. "|" .. d
		end
		i -= 1
	end
	real.print("[optrace] BACKINS n=" .. #kept)
	for j = #kept, 1, -1 do
		real.print("[optrace] INSMARK " .. kept[j])
	end
	local start = 1
	if dn > 600 then start = dn - 599 end
	for j = start, dn do
		real.print("[optrace] DEC " .. db[(j - 1) % 600 + 1])
	end
end
`;


const op78Target = "O,K,S=f[D],V[D],X[D];T,P,j=O+S-1,O+K,E(G[O](u(G,O+1,O+K)));_(j,1,S,O,G);";
const op78Replacement = "O,K,S=f[D],V[D],X[D];"
  + "__r[#__r+1]=-((1*1099511627776)+((O or -1)+1));"
  + "__r[#__r+1]=-((2*1099511627776)+((K or -1)+1));"
  + "__r[#__r+1]=-((3*1099511627776)+((S or -1)+1));"
  + "local __ct=type(G[O]);__r[#__r+1]=-((4*1099511627776)+((__ct=='function' and 4) or ((__ct=='table' and 3) or ((__ct=='nil' and 0) or 2))));"
  + "local __prev=G[O];__r[#__r+1]=-((148*1099511627776)+((type(G[11])=='function' and 1) or ((type(G[11])=='nil' and 0) or 2)));__r[#__r+1]=-((147*1099511627776)+((G[O]==G[11]) and 1 or 0));local __di3,__a3,__b3,__c3=pcall(debug.info,__prev);__r[#__r+1]=-((152*1099511627776)+(__di3 and 1 or 0));if __di3 then __r[#__r+1]=-((153*1099511627776)+((type(__a3)=='string' and #__a3) or -1)+1);__r[#__r+1]=-((160*1099511627776)+((type(__b3)=='number' and __b3) or -1)+1);end;"
  + "local __okd,__ds,__dl=pcall(debug.info,__prev);if __okd then __r[#__r+1]=-((50*1099511627776)+((type(__ds)=='string' and #__ds) or -1)+1);__r[#__r+1]=-((51*1099511627776)+((type(__dl)=='number' and __dl) or -1)+1);else __r[#__r+1]=-((50*1099511627776)+0);end;"
  + "local __oks=__ds;if type(__ds)=='string' then __r[#__r+1]=-((52*1099511627776)+((string.find(__ds,'Luraph',1,true) and 1) or 0)+1);end;"
  + "local __cy=(coroutine and coroutine.yield) or nil;local __rok,__rm=pcall(function()local __c2,__m2=coroutine.running();return __m2 end);if __rok then __r[#__r+1]=-((84*1099511627776)+((__rm and 1) or 0)+1);else __r[#__r+1]=-((84*1099511627776)+0);end;\n"
  + "local __nl=0;local function __pid2(x)if type(x)=='function' then __nl=__nl+1;local s=(__prev==x) and 1 or 0;__r[#__r+1]=-(((__nl+89)*1099511627776)+s+1);end;end;"
  + "__pid2(E);__pid2(u);__pid2(A);__pid2(_);__pid2(l);__pid2(h);__pid2(C);__pid2(I);__pid2(y);__pid2(R);__pid2(x);__pid2(W);__pid2(q);__pid2(c);__pid2(v);__pid2(Y);__pid2(t);__pid2(Z);__pid2(N);__pid2(kn);"
  + "local __mt=(type(M)=='function' and 1) or ((type(M)=='table' and 2) or ((type(M)=='nil' and 0) or 3));__r[#__r+1]=-((128*1099511627776)+__mt);"
  + "for __mk,__mv in l,k,nil do if __mv==M and type(__mk)=='number' then __r[#__r+1]=-((130*1099511627776)+(__mk+1)); end; end;"
  + "local __nms=\'Z5,K5,T5,w5,G5,I5,z5,x5,j5,O5,o5,Y5,H5,a5,M5,fC,b5,wC,n5,A5,V5,HC,BC,qC,jC,U,g5,p5,hC,W,r,P5\' ;local __i2=0;for __nm in string.gmatch(__nms,\'[^,]+\') do __i2=__i2+1;if k[__nm]==M then __r[#__r+1]=-((132*1099511627776)+__i2);end;end;"
  + "local __t1=type(G[1]);local __c1=(__t1=='function' and 4) or ((__t1=='table' and 3) or ((__t1=='nil' and 0) or ((__t1=='string' and 2) or 1)));__r[#__r+1]=-((133*1099511627776)+__c1);"
  + "local __id1=(G[1]==k and 1) or ((G[1]==M and 2) or 0);__r[#__r+1]=-((134*1099511627776)+__id1);"
  + "if __t1=='table' then local __mx=0;for __kk in l,G[1],nil do if type(__kk)=='number' and __kk>__mx then __mx=__kk end end;__r[#__r+1]=-((135*1099511627776)+__mx+1);local __v64=G[1][64];__r[#__r+1]=-((136*1099511627776)+((type(__v64)=='function' and (__v64==G[11] and 2 or 1)) or 0));end;"
  + "local __g2=G[2];if type(__g2)=='function' then __r[#__r+1]=-((110*1099511627776)+((__prev==__g2) and 2 or 1));else __r[#__r+1]=-((110*1099511627776)+0);end;"
  + "G[O]=function(...)local __b5=#__r;local __rs=table.pack(__prev(...));__r[#__r+1]=-((180*1099511627776)+(#__r-__b5+1));__r[#__r+1]=-((6*1099511627776)+(( __rs.n or 0)+1));if __rs.n>=1 then __r[#__r+1]=-((145*1099511627776)+((type(__rs[1])=='function' and 1) or ((type(__rs[1])=='table' and 2) or ((type(__rs[1])=='nil' and 0) or 3))));else local __r0=table.pack(__prev());__r[#__r+1]=-((161*1099511627776)+((__r0.n or 0)+1));if __r0.n>=1 then __r[#__r+1]=-((162*1099511627776)+((type(__r0[1])=='function' and 1) or ((type(__r0[1])=='table' and 2) or ((type(__r0[1])=='nil' and 0) or 3))));end;end;return table.unpack(__rs,1,__rs.n) end;"
  + "local __ok,__e=pcall(function()T,P,j=O+S-1,O+K,E(G[O](u(G,O+1,O+K)));end);G[O]=__prev;"
  + "if __ok then __r[#__r+1]=-((9*1099511627776)+1);__r[#__r+1]=-((8*1099511627776)+(((j and #j) or 0)+1));_(j,1,S,O,G);else __r[#__r+1]=-((9*1099511627776)+0);__r[#__r+1]=-((11*1099511627776)+0);end;";

function patchClosure(src) {
  const target = "A=F[-1];F[A]=d;local d=I(u(F,1,F[0]));F[A]=nil;G[H]=d;";
  const B = 1099511627776;
  const repl2 = "A=F[-1];F[A]=d;local __b4=#__r;local d=I(u(F,1,F[0]));__r[#__r+1]=-((179*1099511627776)+(#__r-__b4+1));F[A]=nil;__r[#__r+1]=-((122*" + B + "+((type(d)=='function' and 1) or ((type(d)=='table' and 2) or ((type(d)=='nil' and 0) or 3)))));__r[#__r+1]=-((123*" + B + "+((type(I)=='function' and 1) or 0)));__r[#__r+1]=-((127*" + B + "+((F[0] or -1)+1)));local __nu,__nv=0,nil;if type(d)=='function' and debug.getupvalue then for __i=1,40 do local __n2,__v2=debug.getupvalue(d,__i);if not __n2 then break end;__nu=__nu+1;if __i==1 then __nv=type(__v2) end;end;end;__r[#__r+1]=-((163*1099511627776)+(__nu+1));__r[#__r+1]=-((164*1099511627776)+((__nv=='function' and 1) or ((__nv=='number' and 2) or ((__nv=='table' and 3) or ((__nv=='string' and 4) or 0)))));local __mu,__mv=0,nil;if type(I)=='function' and debug.getupvalue then for __i=1,40 do local __n2,__v2=debug.getupvalue(I,__i);if not __n2 then break end;__mu=__mu+1;if __i==1 then __mv=type(__v2) end;end;end;__r[#__r+1]=-((165*1099511627776)+(__mu+1));__r[#__r+1]=-((166*1099511627776)+((__mv=='function' and 1) or ((__mv=='number' and 2) or ((__mv=='table' and 3) or ((__mv=='string' and 4) or 0)))));G[H]=d;";
  const n = src.split(target).length - 1;
  if (n === 0) return { source: src, hits: 0 };
  return { source: src.split(target).join(repl2), hits: n };
}

function patchMode(src) {
  const target = "local r,G=d==184,C(U);";
  const repl = "local r,G=d==184,C(U);__r[#__r+1]=-((120*1099511627776)+((type(d)=='number' and d) or -1)+1);__r[#__r+1]=-((121*1099511627776)+((type(U)=='number' and U) or -1)+1);";
  const n = src.split(target).length - 1;
  if (n === 0) return { source: src, hits: 0 };
  return { source: src.split(target).join(repl), hits: n };
}

function patchOp78(src) {
  const n = src.split(op78Target).length - 1;
  if (n === 0) return { source: src, hits: 0 };
  const out = src.split(op78Target).join(op78Replacement);
  return { source: out, hits: n };
}

function patchFactory(src) {
  const target = "k[88],k[12],k[69],k[126],k[33],k[52],k[110],k[119],k[27],k[87],k[86],k[60],k[74],k[48],k[120],k.P5,k[8],k.b5,k[96];";
  const add = "k[88],k[12],k[69],k[126],k[33],k[52],k[110],k[119],k[27],k[87],k[86],k[60],k[74],k[48],k[120],k.P5,k[8],k.b5,k[96];__r[#__r+1]=-((140*1099511627776)+((type(d)=='number' and d) or -2)+2);__r[#__r+1]=-((141*1099511627776)+((type(U)=='number' and U) or -1)+1);local __okl,__l=pcall(debug.info,2,'l');__r[#__r+1]=-((142*1099511627776)+((__okl and __l) or -1)+1);local __tm=type(M);__r[#__r+1]=-((143*1099511627776)+((__tm=='table' and 3) or ((__tm=='nil' and 0) or ((__tm=='function' and 4) or 2))));";
  const n = src.split(target).length - 1;
  process.stderr.write('[factory patch hits: ' + n + ']\n');
  if (n === 0) return src;
  return src.split(target).join(add);
}
function patchHeads(src) {
  let count = 0;
  const out = src.replace(headRe, (m0, op, arr, pc) => {
    count += 1;
    let extra = '';
    if (count % 16 === 2) extra = `
      local t2=G[2];
      local c2=(t2==nil and 0) or ((type(t2)=='number' and 1) or ((type(t2)=='string' and 2) or ((type(t2)=='table' and 3) or ((type(t2)=='function' and 4) or 5))));
      __r[#__r+1]=-((D*262144+c2)*8+7);
      __r[#__r+1]=-(((D*262144+((f[D] or 0)))*512+((X[D] or 0)))*8+2);
      __r[#__r+1]=-(((V[D] or 0))*16+6);
      if type(G[4])=='function' then __r[#__r+1]=-((60*1099511627776)+(D+1)) end;
      if r==21 and G[X[D]]==nil then __r[#__r+1]=-(((D*262144+f[D])*512+X[D])*8+1) end;

      if D==64 and r==78 then
        local tgt=G[f[D]]
        local tc=type(tgt)
        local tcode=(tc=='function' and 1) or ((tc=='table' and 2) or ((tc=='nil' and 0) or 3))
        __r[#__r+1]=-((64*262144+tcode)*8+6)
        local tx=G[X[D]]
        local cx=(tx==nil and 0) or ((type(tx)=='number' and 1) or ((type(tx)=='string' and 2) or ((type(tx)=='table' and 3) or ((type(tx)=='function' and 4) or 5))))
        __r[#__r+1]=-((64*262144+cx)*8+8)
        local zv=z[D]
        if type(zv)=='number' then __r[#__r+1]=-((zv*8+9)*2) else __r[#__r+1]=-14 end
        local gz=G[z[D]]
        local cz=(gz==nil and 0) or ((type(gz)=='number' and 1) or ((type(gz)=='string' and 2) or ((type(gz)=='table' and 3) or ((type(gz)=='function' and 4) or 5))))
        __r[#__r+1]=-((64*262144+cz)*8+10)
        local wv=w[D]
        if type(wv)=='number' then __r[#__r+1]=-((wv*8+11)*2) else __r[#__r+1]=-16 end
        local gw=G[w[D]]
        local cw=(gw==nil and 0) or ((type(gw)=='number' and 1) or ((type(gw)=='string' and 2) or ((type(gw)=='table' and 3) or ((type(gw)=='function' and 4) or 5))))
        __r[#__r+1]=-((64*262144+cw)*8+12)
        if tc=='function' and not __sp then
          __sp=true
          local orig=tgt
          G[f[D]]=function(...)
            local rs=table.pack(orig(...))
            __r[#__r+1]=-((64*262144+rs.n)*8+5)
            print('[SPY] nested call returned ' .. rs.n .. ' results')
            return table.unpack(rs,1,rs.n)
          end
        end
      end;
      if r==21 and G[X[D]]==nil then __r[#__r+1]=-(((D*262144+f[D])*512+X[D])*8+1) end;
      if D==64 then
        local gt={}
        for gi=1,10 do local gv=G[gi];local gty=(gv==nil and 0) or ((type(gv)=='number' and 1) or ((type(gv)=='string' and 2) or ((type(gv)=='table' and 3) or ((type(gv)=='function' and 4) or 5))));gt[gi]=gty end
        __r[#__r+1]=-((53*1099511627776)+((gt[1]*6+gt[2])*6+gt[3])*6+gt[4]);
        __r[#__r+1]=-((54*1099511627776)+(((gt[5]*6+gt[6])*6+gt[7])*6+gt[8])*6+gt[9]);
        __r[#__r+1]=-((55*1099511627776)+gt[10]);
      end;
      if D==64 or D==65 or D==66 then
        local g11=G[11]
        local t11=(g11==nil and 0) or ((type(g11)=='number' and 1) or ((type(g11)=='string' and 2) or ((type(g11)=='table' and 3) or ((type(g11)=='function' and 4) or 5))))
        __r[#__r+1]=-(((D*512+t11)*8+11))
        __r[#__r+1]=-(((D*262144+f[D])*512+X[D])*8+2);
        __r[#__r+1]=-((V[D]*8+3)*2);
        local t=G[2];
        local tid=(t==nil and 0) or ((type(t)=='number' and 1) or ((type(t)=='string' and 2) or ((type(t)=='table' and 3) or ((type(t)=='function' and 4) or 5))));
        __r[#__r+1]=-((D*262144+tid)*8+4);
      end;`;


    return m0 + `__r[#__r+1]=(((__pid[__pv] or 0)*16+${count % 16})*256+${op}%256)*65536+${pc};` + extra;
  });
  return { source: out, heads: count };
}



function patchCmpSites(src) {
  const B = 1099511627776;
  let total = 0;
  const wl = (L, pc, tag) => `((__crL and __crL(` + L + `,` + pc + `,` + tag + `) or ` + L + `))`;
  const wr = (R, tag) => `((__crR and __crR(` + R + `,` + tag + `) or ` + R + `))`;
  const jpat = "t=if j<=0 then Q>=b else Q<=b;";
  const jrep = "local __tj,__tq,__tb=type(j),type(Q),type(b);if __tj~='number' or __tq~='number' or __tb~='number' then __lA=(__lA or 0)+1;if __lA<=30 and __r then __r[#__r+1]=-((300*" + B + ")+__tj*64+__tq*8+__tb);__r[#__r+1]=-((301*" + B + ")+((T or -1)+1));end;end;" + jpat;
  total += src.split(jpat).length - 1;
  src = src.split(jpat).join(jrep);
  const dpat = "O=if U<=0 then Q>=m else Q<=m;";
  const drep = "local __tu2,__tq2,__tm2=type(U),type(Q),type(m);if __tu2~='number' or __tq2~='number' or __tm2~='number' then __lB=(__lB or 0)+1;if __lB<=30 and __r then __r[#__r+1]=-((310*" + B + ")+__tu2*64+__tq2*8+__tm2);__r[#__r+1]=-((311*" + B + ")+((D or -1)+1));end;end;" + dpat;
  total += src.split(dpat).length - 1;
  src = src.split(dpat).join(drep);
  const cpat = "U,m=G[O+2]+0,G[O+1]+0;Q=G[O]-U;D=V[D];";
  const crep = "local __t0,__t1,__t2=type(G[O]),type(G[O+1]),type(G[O+2]);if __t0~='number' or __t1~='number' or __t2~='number' then __lC=(__lC or 0)+1;if __lC<=30 and __r then __r[#__r+1]=-((315*" + B + ")+__t0*64+__t1*8+__t2);__r[#__r+1]=-((316*" + B + ")+((D or -1)+1));end;end;" + cpat;
  total += src.split(cpat).length - 1;
  src = src.split(cpat).join(crep);
  const tpat = "j=i[t+2]+0;b=i[t+1]+0;Q=i[t]-j;";
  const trep = "local __t0b,__t1b,__t2b=type(i[t]),type(i[t+1]),type(i[t+2]);if __t0b~='number' or __t1b~='number' or __t2b~='number' then __lD=(__lD or 0)+1;if __lD<=30 and __r then __r[#__r+1]=-((317*" + B + ")+__t0b*64+__t1b*8+__t2b);__r[#__r+1]=-((318*" + B + ")+((T or -1)+1));end;end;" + tpat;
  total += src.split(tpat).length - 1;
  src = src.split(tpat).join(trep);
  let e3 = 0;
  src = src.replace(/local (\w+),(\w+),(\w+)=(\w+)\[(\d+)\],(\w+)\[(\d+)\],(\w+)\[(\d+)\];local (\w+),(\w+)=(\w+)\+(\w+),(\w+)<=0;/g, (m) => {
    const tag = 410 + 2 * (e3++);
    const first = m.slice(6, m.indexOf(';'));
    const vals = first.slice(first.indexOf('=') + 1);
    return "do local __s1,__s2,__s3=" + vals + ";__s1,__s2,__s3=type(__s1),type(__s2),type(__s3);if __s1~='number' or __s2~='number' or __s3~='number' then __lE=(__lE or 0)+1;if __lE<=40 and __r then __r[#__r+1]=-(((" + tag + ")*" + B + ")+__s1*64+__s2*8+__s3);end;end;end;" + m;
  });
  total += e3;
  let e2 = 0;
  src = src.replace(/=([A-Za-z_][\w\[\]]*)>=([A-Za-z_][\w\[\]]*),([A-Za-z_][\w\[\]]*)<=([A-Za-z_][\w\[\]]*);/g, (m, a, b, c, d) => {
    const tag = 460 + 4 * (e2++);
    return "=" + wl(a, 0, tag) + ">=" + wr(b, tag + 2) + "," + wl(c, 0, tag) + "<=" + wr(d, tag + 2) + ";";
  });
  total += e2;
  const pats = [
    ["i[B[T]]<=H[T]", "T"], ["i[B[T]]<=e[T]", "T"], ["i[B[T]]<=f[T]", "T"],
    ["i[B[T]]<=i[f[T]]", "T"], ["i[B[T]]<=i[z[T]]", "T"], ["i[B[T]]<=z[T]", "T"],
    ["i[B[T]]>=e[T]", "T"], ["i[B[T]]>=i[f[T]]", "T"], ["i[B[T]]>=z[T]", "T"],
    ["i[e[T]]<=B[T]", "T"], ["i[e[T]]<=a[T]", "T"], ["i[e[T]]>=d[T]", "T"],
    ["i[e[T]]>=i[z[T]]", "T"], ["i[f[T]]<=H[T]", "T"], ["i[f[T]]<=a[T]", "T"],
    ["i[f[T]]<=d[T]", "T"], ["i[f[T]]<=e[T]", "T"], ["i[f[T]]<=i[e[T]]", "T"],
    ["i[f[T]]>=i[B[T]]", "T"], ["i[z[T]]<=B[T]", "T"], ["i[z[T]]<=H[T]", "T"],
    ["i[z[T]]<=d[T]", "T"], ["i[z[T]]<=i[B[T]]", "T"], ["i[z[T]]<=i[e[T]]", "T"],
    ["i[z[T]]>=B[T]", "T"], ["i[z[T]]>=d[T]", "T"], ["i[z[T]]>=i[B[T]]", "T"],
    ["G[V[D]]<=X[D]", "D"], ["G[z[D]]>=G[f[D]]", "D"],
    ["G[X[D]]<=V[D]", "D"], ["G[f[D]]<=V[D]", "D"], ["V[D]<=G[f[D]]", "D"],
    ["a[D]<=G[f[D]]", "D"], ["G[z[D]]<=V[D]", "D"], ["G[z[D]]<=X[D]", "D"],
    ["G[f[D]]=G[z[D]]<=V[D]", "D"], ["G[z[D]]=G[V[D]]<=G[f[D]]", "D"],
    ["G[f[D+4]]=G[z[D+4]]<=V[D+4]", "D"],
  ];
  pats.sort((x, y) => y[0].length - x[0].length);
  for (let pi = 0; pi < pats.length; pi++) {
    const [pat, pcvar] = pats[pi];
    const tag = 500 + 4 * pi;
    const opIdx = pat.indexOf('>=') >= 0 ? pat.indexOf('>=') : pat.indexOf('<=');
    let L = pat.slice(0, opIdx);
    const R = pat.slice(opIdx + 2);
    const op = pat.slice(opIdx, opIdx + 2);
    let prefix = '';
    const eq = L.lastIndexOf('=');
    if (eq >= 0) { prefix = L.slice(0, eq + 1); L = L.slice(eq + 1); }
    const wrapped = prefix + wl(L, pcvar, tag) + op + wr(R, tag + 2);
    const n = src.split(pat).length - 1;
    if (n > 0) { src = src.split(pat).join(wrapped); total += n; }
  }
  // H5 runner dispatch compares + handler-return type checks
  const h5edits = [
    ["while H do if P<=15 then if P<=7 then if P<=3 then P,K,S,j,m=k:u(m,P,j,n,K,S,p);",
     "while H do if " + wl("P", 0, 700) + "<=15 then if " + wl("P", 0, 703) + "<=7 then if " + wl("P", 0, 706) + "<=3 then P,K,S,j,m=k:u(m,P,j,n,K,S,p);if type(P)~='number' and __r then __r[#__r+1]=-((730*" + B + ")+tc(P)*8);end;", 1],
    ["else P,K,T,Q,p=k:v(r,j,o,Q,T,n,S,p,P,K,b);end;",
     "else P,K,T,Q,p=k:v(r,j,o,Q,T,n,S,p,P,K,b);if type(P)~='number' and __r then __r[#__r+1]=-((733*" + B + ")+tc(P)*8);end;end;", 1],
    ["elseif P<=11 then P,S,Q,b,j=k:d(p,S,o,P,b,Q,j);",
     "elseif " + wl("P", 0, 709) + "<=11 then P,S,Q,b,j=k:d(p,S,o,P,b,Q,j);if type(P)~='number' and __r then __r[#__r+1]=-((736*" + B + ")+tc(P)*8);end;", 1],
    ["else P,K,i,T,S,b,p=k:f(j,o,T,p,i,S,P,n,b,Q,K);end;",
     "else P,K,i,T,S,b,p=k:f(j,o,T,p,i,S,P,n,b,Q,K);if type(P)~='number' and __r then __r[#__r+1]=-((739*" + B + ")+tc(P)*8);end;end;", 1],
    ["elseif P<=23 then if P<=19 then M,a,O,z,V,L,B,d,w,e=k:tC(G,r,j,m,T,K,p,n,P,b,S);if M==2 then P,K,T,j,p,n,m,r,G=a,O,z,V,L,B,d,w,e;",
     "elseif " + wl("P", 0, 712) + "<=23 then if " + wl("P", 0, 715) + "<=19 then M,a,O,z,V,L,B,d,w,e=k:tC(G,r,j,m,T,K,p,n,P,b,S);if type(M)~='number' and __r then __r[#__r+1]=-((757*" + B + ")+tc(M)*8);end;if type(a)~='number' and __r then __r[#__r+1]=-((760*" + B + ")+tc(a)*8);end;if M==2 then P,K,T,j,p,n,m,r,G=a,O,z,V,L,B,d,w,e;if type(P)~='number' and __r then __r[#__r+1]=-((742*" + B + ")+tc(P)*8);end;", 1],
    ["elseif P<=21 then P,S,b,j=k:XC(P,S,b,p,j,m,n);",
     "elseif " + wl("P", 0, 718) + "<=21 then P,S,b,j=k:XC(P,S,b,p,j,m,n);if type(P)~='number' and __r then __r[#__r+1]=-((745*" + B + ")+tc(P)*8);end;", 1],
    ["else P,S,b=k:pC(b,p,P,j,S);end;",
     "else P,S,b=k:pC(b,p,P,j,S);if type(P)~='number' and __r then __r[#__r+1]=-((748*" + B + ")+tc(P)*8);end;end;", 1],
    ["elseif P<=27 then P,o,Q,b,j=k:lC(o,i,Q,T,K,b,P,p,j);",
     "elseif " + wl("P", 0, 721) + "<=27 then P,o,Q,b,j=k:lC(o,i,Q,T,K,b,P,p,j);if type(P)~='number' and __r then __r[#__r+1]=-((751*" + B + ")+tc(P)*8);end;", 1],
    ["else P,T,S,Q,b,j=k:cC(T,p,G,j,Q,b,o,S,m,P,n);end;end;end;",
     "else P,T,S,Q,b,j=k:cC(T,p,G,j,Q,b,o,S,m,P,n);if type(P)~='number' and __r then __r[#__r+1]=-((754*" + B + ")+tc(P)*8);end;end;end;end;", 1],
  ];
  let h5n = 0;
  for (const [t, r] of h5edits) {
    const n = src.split(t).length - 1;
    if (n > 0) { src = src.split(t).join(r); h5n += n; total += n; }
  }
  process.stderr.write(`[*] h5 dispatch probes applied: ${h5n}\n`);
  const heads = [
    ["if S==3 then while true do local Mn=f[T];", 395],
    ["if S==68 then while true do local Mn,Xn,Bn,Hn=f[T];", 396],
    ["if S==93 then while true do local Mn=e[T];", 397],
    ["if S==48 then while true do local a=z[T];", 398],
    ["while H do if P<=15 then", 399],
  ];
  for (const [h, tag] of heads) {
    const rep = h + (h.endsWith(";") ? "" : " ") + "__sc=(__sc or 0)+1;if __sc<=8 and __r then __r[#__r+1]=-(((" + tag + ")*" + B + ")+1);end;";
    const n = src.split(h).length - 1;
    if (n > 0) { src = src.split(h).join(rep); total += n; }
  }
  process.stderr.write(`[*] cmp-site probes applied: ${total}\n`);
  return src;
}

function patchSecondVm(src) {
  const B = 1099511627776;
  const tc = "(function(v)local t=type(v);return (t=='nil' and 0) or ((t=='number' and 1) or ((t=='string' and 2) or ((t=='table' and 3) or ((t=='function' and 4) or 5)))) end)";
  const mT = "local function C(y,y,y,R,R,x,W)";
  const mR = mT + "__r[#__r+1]=-((170*1099511627776)+(" + tc + "(y)*64+" + tc + "(R)*16+" + tc + "(x)*4+" + tc + "(W)));";
  let n1 = src.split(mT).length - 1;
  src = src.split(mT).join(mR);
  const rT = "local function L(...)local s,P,K=R,y,W;";
  const rR = "local function L(...)__r[#__r+1]=-((171*1099511627776)+(" + tc + "(R)*64+" + tc + "(y)*16+" + tc + "(W))*16+select('#',...));local s,P,K=R,y,W;__r[#__r+1]=-((174*1099511627776)+(" + tc + "(K)+1));";
  let n2 = src.split(rT).length - 1;
  src = src.split(rT).join(rR);
  const sT = "local i,T,S,o,Q,b,j,p,n,m=K(V),U,O;";
  const sR = sT + "__r[#__r+1]=-((172*1099511627776)+((type(S)=='number' and S) or -1)+1);";
  let n3 = src.split(sT).length - 1;
  src = src.split(sT).join(sR);
  // decrypt-loop body probes: K-family (child chunk) and N-family (outer chunk)
  const dclPat = 'K=R(x(K,(W(K,13))),536870911);K=x(K,(y(K,13)));K=R(x(K,(W(K,14))),536870911);';
  const dclProbe = dclPat + "__p.dcl=(__p.dcl or 0)+1;if __p.dcl<=2000000 then __r[#__r+1]=-((422*1099511627776)+((type(K)=='number' and (K%4294967296)) or 0));__r[#__r+1]=-((423*1099511627776)+((type(O)=='number' and (O%4294967296)) or 0));end;";
  const ndcl = src.split(dclPat).length - 1;
  src = src.split(dclPat).join(dclProbe);
  const dnlPat = 'N=g(J(N,(I(N,13))),536870911);N=J(N,(r(N,13)));N=g(J(N,(I(N,14))),536870911);';
  const dnlProbe = dnlPat + "__p.dnl=(__p.dnl or 0)+1;if __p.dnl<=2000000 then __r[#__r+1]=-((430*1099511627776)+((type(N)=='number' and (N%4294967296)) or 0));__r[#__r+1]=-((431*1099511627776)+((type(t)=='number' and (t%4294967296)) or 0));end;";
  const ndnl = src.split(dnlPat).length - 1;
  src = src.split(dnlPat).join(dnlProbe);
  // loop-entry probes: record the count bound of each K/N decrypt loop
  let siteId = 0;
  let kSites = 0;
  src = src.replace(/for (\w+)=1,([\w\[\]]+),1 do (?=K=R\(x\(K)/g, (m, lv, cnt) => {
    kSites++;
    return `for ${lv}=1,${cnt},1 do if ${lv}==1 then __r[#__r+1]=-((424*1099511627776)+((type(${cnt})=='number' and (${cnt}%4294967296)) or 0));__r[#__r+1]=-((425*1099511627776)+${kSites});end;`;
  });
  src = src.replace(/for (\w+)=1,([\w\[\]]+),1 do (?=N=g\(J\(N)/g, (m, lv, cnt) => {
    siteId++;
    return `for ${lv}=1,${cnt},1 do if ${lv}==1 then __r[#__r+1]=-((432*1099511627776)+((type(${cnt})=='number' and (${cnt}%4294967296)) or 0));__r[#__r+1]=-((433*1099511627776)+${siteId});end;`;
  });
const nSites = siteId - kSites;
  process.stderr.write(`[*] second-vm probes: maker=${n1} runner=${n2} mode=${n3} dcl=${ndcl} dnl=${ndnl}\n`);
  return src;
}


function patchMaker(src) {
  const t = "return __mk end)(function(J,I,F,F)";
  const r = t + "__r[#__r+1]=-((178*1099511627776)+2);";
  const n = src.split(t).length - 1;
  src = src.split(t).join(r);
  process.stderr.write(`[*] maker-entry probe hits: ${n}\n`);
  return src;
}



function patchMode203(src) {
  const h = "if Xn==203 then while true do r=z[D];";
  const rh = h + "__r[#__r+1]=-((189*1099511627776)+((type(r)=='number' and (r+1)) or 0));__r[#__r+1]=-((190*1099511627776)+((type(D)=='number' and (D%1048576) or 0)+1));__r[#__r+1]=-((202*1099511627776)+((type(V[D])=='number' and (V[D]+1)) or 0));__r[#__r+1]=-((250*1099511627776)+((type(z[D])=='number' and (z[D]+1)) or 0));__r[#__r+1]=-((251*1099511627776)+((type(f[D])=='number' and (f[D]+1)) or 0));__r[#__r+1]=-((252*1099511627776)+((type(X[D])=='number' and (X[D]+1)) or 0));";
  const n = src.split(h).length - 1;
  src = src.split(h).join(rh);
  const a = "if r==58 then G[X[D]]=x(G[V[D]],B[D]);";
  const a23 = 'else G[f[D]]=x(G[V[D]],G[X[D]]);';
const ra = "__r[#__r+1]=-((191*1099511627776)+((type(G[V[D]])=='number' and 1) or ((type(G[V[D]])=='nil' and 0) or 2))+1);__r[#__r+1]=-((192*1099511627776)+((type(B[D])=='number' and 1) or ((type(B[D])=='nil' and 0) or 2))+1);" + a;
  const ra23 = "__r[#__r+1]=-((200*1099511627776)+((V[D] or -1)+1));__r[#__r+1]=-((201*1099511627776)+((X[D] or -1)+1));__r[#__r+1]=-((203*1099511627776)+((f[D] or -1)+1));__r[#__r+1]=-((204*1099511627776)+((type(G[V[D]])=='number' and 1) or ((type(G[V[D]])=='nil' and 0) or 2))+1);" + 'else G[f[D]]=x(G[V[D]],G[X[D]]);';
  const afl = 'Q+=U;O=if U<=0 then Q>=m else Q<=m;';
  const rprobe = "if type(U)~='number' then __r[#__r+1]=-((220*1099511627776)+((type(U)=='nil' and 0) or 2));__r[#__r+1]=-((221*1099511627776)+((D or -1)+1));__r[#__r+1]=-((222*1099511627776)+((type(Q)=='nil' and 0) or (type(Q)=='userdata' and 2) or 3));end;";
  const rfl = rprobe + afl;
  const nfl = src.split(afl).length - 1;
  src = src.split(afl).join(rfl);
  process.stderr.write(`[*] forloop probes: ${nfl}\n`);
  const cmpPats = [
    ['D=if G[X[D]]<=V[D]then D else f[D];', 'G[X[D]]'],
    ['D=if G[f[D]]<=V[D]then D else z[D];', 'G[f[D]]'],
    ['D=if V[D]<=G[f[D]]then D else z[D];', 'G[f[D]]'],
    ['D=if a[D]<=G[f[D]]then D else V[D];', 'G[f[D]]'],
    ['G[f[D]]=G[z[D]]<=V[D];', 'G[z[D]]'],
    ['G[z[D]]=G[V[D]]<=G[f[D]];', 'G[V[D]]'],
    ['G[f[D+4]]=G[z[D+4]]<=V[D+4];', 'G[z[D+4]]'],
  ];
  for (const [pat, operand] of cmpPats) {
    const pre = `if type(${operand})~='number' then __r[#__r+1]=-((230*1099511627776)+((type(${operand})=='nil' and 0) or 2));__r[#__r+1]=-((231*1099511627776)+((D or -1)+1));end;`;
    const cnt = src.split(pat).length - 1;
    if (cnt > 0) src = src.split(pat).join(pre + pat);
    process.stderr.write(`[*] cmpprobe ${cnt} ${pat.slice(0, 28)}\n`);
  }

  const na23 = src.split(a23).length - 1;
  src = src.split(a23).join(ra23);
  process.stderr.write(`[*] op23 probes: ${na23}\n`);
  const a23b = ');else G[f[D]]=x(G[V[D]],G[X[D]]);end;';
  const r23b = ');else if G[V[D]]==nil then __p.c23=(__p.c23 or 0)+1;if __p.c23<=20 then __r[#__r+1]=-((210*1099511627776)+((D or -1)+1));__r[#__r+1]=-((211*1099511627776)+((V[D] or -1)+1));__r[#__r+1]=-((212*1099511627776)+((f[D] or -1)+1));__r[#__r+1]=-((213*1099511627776)+((X[D] or -1)+1));local __nz=0;for __i=1,260,1 do if G[__i]~=nil then __nz=__nz+1 end end;__r[#__r+1]=-((214*1099511627776)+__nz+1);local __bm=0;for __i=130,170,1 do __bm=__bm*2+(G[__i]~=nil and 1 or 0) end;__r[#__r+1]=-((215*1099511627776)+__bm);__r[#__r+1]=-((216*1099511627776)+((G[2]==nil and 0) or 1));end;end;G[f[D]]=x(G[V[D]],G[X[D]]);end;';
  const n23b = src.split(a23b).length - 1;
  src = src.split(a23b).join(r23b);
  process.stderr.write(`[*] op23-nil probes: ${n23b}\n`);
  const a23c = 'end;G[f[D]]=x(G[V[D]],G[X[D]]);end;';
  const a24b = 'else G[f[D]]=W(G[V[D]],X[D]);end;';
  const r24b = "else __r[#__r+1]=-((276*1099511627776)+((type(G[V[D]])=='number' and 1) or ((type(G[V[D]])=='nil' and 0) or 2)));local __wi1,__wi2,__wi3=pcall(debug.info,W,'s','l','n');__r[#__r+1]=-((277*1099511627776)+(__wi1 and 1 or 0));__r[#__r+1]=-((278*1099511627776)+((type(__wi2)=='string' and #__wi2) or -1)+1);__r[#__r+1]=-((279*1099511627776)+((type(__wi3)=='number' and __wi3) or -1)+1);G[f[D]]=W(G[V[D]],X[D]);end;";
  const n24b = src.split(a24b).length - 1;
  src = src.split(a24b).join(r24b);
  process.stderr.write(`[*] op24-id probes: ${n24b}\n`);
  const a13 = 'D=if G[z[D]]<=X[D]then D else f[D];';
  const r13 = "if type(G[z[D]])~='number' then __r[#__r+1]=-((280*1099511627776)+((type(G[z[D]])=='nil' and 0) or 2));__r[#__r+1]=-((281*1099511627776)+((D or -1)+1));end;" + a13;
  const n13 = src.split(a13).length - 1;
  src = src.split(a13).join(r13);
  process.stderr.write(`[*] op13 probes: ${n13}\n`);
  const r23c = "end;local __ok23,__v23,__e23=pcall(function() return x(G[V[D]],G[X[D]]) end);if not __ok23 then __r[#__r+1]=-((260*1099511627776)+((type(G[V[D]])=='number' and 1) or ((type(G[V[D]])=='nil' and 0) or 2)));__r[#__r+1]=-((261*1099511627776)+((type(G[X[D]])=='number' and 1) or ((type(G[X[D]])=='nil' and 0) or 2)));__r[#__r+1]=-((262*1099511627776)+((type(x)=='function' and 1) or 2));local __xok,__xsl,__xsn=pcall(debug.info,x,'l','n');__r[#__r+1]=-((263*1099511627776)+(__xok and 1 or 0));if __xok then __r[#__r+1]=-((264*1099511627776)+((type(__xsl)=='number' and __xsl) or -1)+1);__r[#__r+1]=-((265*1099511627776)+((type(__xsn)=='string' and #__xsn) or -1)+1);end;__r[#__r+1]=-((266*1099511627776)+1);error(__e23,0);end;G[f[D]]=__v23;end;";
  const n23c = src.split(a23c).length - 1;
  src = src.split(a23c).join(r23c);
  process.stderr.write(`[*] op23-pcall probes: ${n23c}\n`);
  const a23d = 'local __ok23,__v23,__e23=pcall(function() return x(G[V[D]],G[X[D]]) end);';
  const r23d = "local __xi1,__xi2,__xi3=pcall(debug.info,x,'s','l','n');__r[#__r+1]=-((270*1099511627776)+((D or -1)+1));__r[#__r+1]=-((271*1099511627776)+(__xi1 and 1 or 0));__r[#__r+1]=-((272*1099511627776)+((type(__xi2)=='string' and #__xi2) or -1)+1);__r[#__r+1]=-((273*1099511627776)+((type(__xi3)=='number' and __xi3) or -1)+1);__r[#__r+1]=-((274*1099511627776)+((type(G[V[D]])=='number' and 1) or ((type(G[V[D]])=='nil' and 0) or 2)));__r[#__r+1]=-((275*1099511627776)+((type(G[X[D]])=='number' and 1) or ((type(G[X[D]])=='nil' and 0) or 2)));local __ok23,__v23,__e23=pcall(function() return x(G[V[D]],G[X[D]]) end);";
  const n23d = src.split(a23d).length - 1;
  src = src.split(a23d).join(r23d);
  process.stderr.write(`[*] op23-id probes: ${n23d}\n`);
  const a23e = 'G[f[D]]=__v23;end;';
  const r23e = 'G[f[D]]=__v23;__r[#__r+1]=-((283*1099511627776)+((D or -1)+1));end;';
  const n23e = src.split(a23e).length - 1;
  src = src.split(a23e).join(r23e);
  process.stderr.write(`[*] op23-done probes: ${n23e}\n`);

  // op64 stream-decrypt probe: key material + first dword before decrypt
  const a64 = 'local F=x(I[H],116283512);I[H]=F;';
  const r64 = '__p.c64=(__p.c64 or 0)+1;if __p.c64<=48 then __r[#__r+1]=-((220*1099511627776)+((D or -1)+1));__r[#__r+1]=-((221*1099511627776)+((f[D] or -1)+1));__r[#__r+1]=-((222*1099511627776)+(((type(g)==\'table\') and 1 or 0)+(((type(g)==\'table\') and g[14]~=nil) and 2 or 0)+(((type(g)==\'table\') and g[28]~=nil) and 4 or 0)+(((type(g)==\'table\') and g[29]~=nil) and 8 or 0)));local __ti=type(I);__r[#__r+1]=-((224*1099511627776)+((type(I)==\'table\' and 1) or ((type(I)==\'userdata\' and 2) or ((type(I)==\'number\' and 3) or 4))));if __ti==\'table\' then local __b1=I[H];__r[#__r+1]=-((223*1099511627776)+((type(__b1)==\'number\' and (__b1%4294967296)) or 4294967295));end;__r[#__r+1]=-((243*1099511627776)+((type(g)==\'number\' and (g%4294967296)) or 4294967295));__r[#__r+1]=-((245*1099511627776)+((type(d)==\'number\' and (d%4294967296)) or 4294967295));end;' + a64;
  const n64 = src.split(a64).length - 1;
  src = src.split(a64).join(r64);
  process.stderr.write(`[*] op64-decrypt probes: ${n64}\n`);
  const a64b = 'I[H]=F;H,I=M[7],F+1;';
  const r64b = "I[H]=F;__p.c64b=(__p.c64b or 0)+1;if __p.c64b<=48 then __r[#__r+1]=-((244*1099511627776)+((type(F)=='number' and (F%4294967296)) or 4294967295));end;H,I=M[7],F+1;";
  const n64b = src.split(a64b).length - 1;
  src = src.split(a64b).join(r64b);
  process.stderr.write(`[*] op64-post probes: ${n64b}\n`);
  // op85 field-patch probe: fields after patch
  const a85 = 'V[D]=x(O,68,(R(y(K,14),127)));D=D-1;';
  const r85 = 'V[D]=x(O,68,(R(y(K,14),127)));__p.c85=(__p.c85 or 0)+1;if __p.c85<=40 then __r[#__r+1]=-((233*1099511627776)+((D-1 or -1)+1));__r[#__r+1]=-((234*1099511627776)+((z[D] or -1)+1));__r[#__r+1]=-((235*1099511627776)+((X[D] or -1)+1));__r[#__r+1]=-((236*1099511627776)+((f[D] or -1)+1));__r[#__r+1]=-((237*1099511627776)+((V[D] or -1)+1));end;D=D-1;';
  const n85 = src.split(a85).length - 1;
  src = src.split(a85).join(r85);
  process.stderr.write(`[*] op85-patch probes: ${n85}\n`);
  // op85 patch input probe: r, O, S, T, K, j, i, P
  const a85i = 'j,i=R(T,W(1,P)-1),y(T,P);z[D]=x(i,102,';
  const r85i = '__p.c85i=(__p.c85i or 0)+1;if __p.c85i<=40 then __r[#__r+1]=-((256*1099511627776)+((type(r)==\'number\' and (r+1)) or 0));__r[#__r+1]=-((246*1099511627776)+((type(O)==\'number\' and (O%4294967296)) or 4294967295));__r[#__r+1]=-((247*1099511627776)+((type(S)==\'number\' and (S%4294967296)) or 4294967295));__r[#__r+1]=-((248*1099511627776)+((type(T)==\'number\' and (T%4294967296)) or 4294967295));__r[#__r+1]=-((259*1099511627776)+((type(K)==\'number\' and (K%4294967296)) or 4294967295));__r[#__r+1]=-((253*1099511627776)+((type(j)==\'number\' and (j%4294967296)) or 4294967295));__r[#__r+1]=-((254*1099511627776)+((type(i)==\'number\' and (i%4294967296)) or 4294967295));__r[#__r+1]=-((255*1099511627776)+((type(P)==\'number\' and (P+1)) or 0));end;j,i=R(T,W(1,P)-1),y(T,P);z[D]=x(i,102,';
  const n85i = src.split(a85i).length - 1;
  src = src.split(a85i).join(r85i);
  process.stderr.write(`[*] op85-input probes: ${n85i}\n`);
  // op84 call probe: X[D], callee type, function bitmap of G[1..80]
  const a84 = 'D=D-1;end;else G[X[D]](G[V[D]]);end;';
  const r84 = 'D=D-1;end;else __p.c84=(__p.c84 or 0)+1;if __p.c84<=30 then __r[#__r+1]=-((238*1099511627776)+((D or -1)+1));__r[#__r+1]=-((239*1099511627776)+((X[D] or -1)+1));__r[#__r+1]=-((240*1099511627776)+((type(G[X[D]])==\'function\' and 1) or ((type(G[X[D]])==\'nil\' and 0) or 2)));local __bh1,__bh2=0,0;for __i=1,40,1 do __bh1=__bh1*2+((type(G[__i])==\'function\') and 1 or 0) end;for __i=41,80,1 do __bh2=__bh2*2+((type(G[__i])==\'function\') and 1 or 0) end;__r[#__r+1]=-((241*1099511627776)+__bh1);__r[#__r+1]=-((242*1099511627776)+__bh2);end;G[X[D]](G[V[D]]);end;';
  const n84 = src.split(a84).length - 1;
  src = src.split(a84).join(r84);
  process.stderr.write(`[*] op84-call probes: ${n84}\n`);
  // --- child-VM decoder/handoff probes ---
  const enc = (tag, expr) => `__r[#__r+1]=-((${tag}*1099511627776)+${expr});`;
  const num = (e) => `((type(${e})=='number' and (${e}%4294967296)) or 0)`;
  const a26 = 'if Bn==26 then K,O=(x(z[D],(R(x(g,(R(y(g,29),7))),536870911)))),X[D]+1;';
  const r26 = a26 + "__p.c26=(__p.c26 or 0)+1;if __p.c26<=5000 then " + enc(300,"((D or -1)+1)") + enc(301,"((z[D] or -1)+1)") + enc(302,"((X[D] or -1)+1)") + enc(303,"((V[D] or -1)+1)") + enc(304,num("g")) + enc(305,num("K")) + "end;";
  const n26 = src.split(a26).length - 1;
  src = src.split(a26).join(r26);
  process.stderr.write(`[*] bn26 probes: ${n26}\n`);
  const a19 = 'if Bn==19 then K,O=(x(z[D],(R(x(Mn,(R(y(Mn,29),7))),536870911)))),X[D]+1;';
  const r19 = a19 + "__p.c19=(__p.c19 or 0)+1;if __p.c19<=30 then " + enc(310,"((D or -1)+1)") + enc(311,"((z[D] or -1)+1)") + enc(312,"((X[D] or -1)+1)") + enc(313,"((V[D] or -1)+1)") + enc(314,num("Mn")) + enc(315,num("K")) + "end;";
  const n19 = src.split(a19).length - 1;
  src = src.split(a19).join(r19);
  process.stderr.write(`[*] bn19 probes: ${n19}\n`);
  const abrk = 'Xn=V[Hn];D=X[Hn]+1;break;';
  const rbrk = "__p.cbrk=(__p.cbrk or 0)+1;if __p.cbrk<=30 then " + enc(320,"((Hn or -1)+1)") + enc(321,num("V[Hn]")) + enc(322,num("X[Hn]")) + "end;" + abrk;
  const nbrk = src.split(abrk).length - 1;
  src = src.split(abrk).join(rbrk);
  process.stderr.write(`[*] break probes: ${nbrk}\n`);
  const a52 = 'X[D]=x(O,76,(R(S,127)));D=D-1;';
  const r52 = 'X[D]=x(O,76,(R(S,127)));' + "__p.c52=(__p.c52 or 0)+1;if __p.c52<=30 then " + enc(330,"((D or -1)+1)") + enc(331,"((z[D] or -1)+1)") + enc(332,"((f[D] or -1)+1)") + enc(333,"((V[D] or -1)+1)") + enc(334,"((X[D] or -1)+1)") + enc(335,num("O")) + enc(336,num("T")) + enc(337,num("S")) + enc(338,num("K")) + "end;D=D-1;";
  const n52 = src.split(a52).length - 1;
  src = src.split(a52).join(r52);
  process.stderr.write(`[*] bn52dec probes: ${n52}\n`);
  const aent = 'if Xn==203 then while true do r=z[D];';
  const flds = [];
  for (const arr of ['z','f','X','V']) for (let rr=64; rr<=67; rr++) flds.push(enc(349+((flds.length)+1), num(`${arr}[${rr}]`)));
  const rent = 'if Xn==203 then ' + "__p.cent=(__p.cent or 0)+1;if __p.cent<=10 then " + enc(340,"((Xn or -1)+1)") + enc(341,num("I")) + enc(342,"((H or -1)+1)") + enc(343,"((d or -1)+1)") + enc(344,"((D or -1)+1)") + enc(345,num("g")) + enc(346,num("Mn")) + flds.join('') + "end; while true do r=z[D];";
  const nent = src.split(aent).length - 1;
  src = src.split(aent).join(rent);
  process.stderr.write(`[*] outer-entry probes: ${nent}\n`);
  const a54 = 'O,K,S=z[Hn],V[Hn],X[Hn];';
  const r54 = a54 + "__p.c54=(__p.c54 or 0)+1;if __p.c54<=30 then " + enc(360,"((Hn or -1)+1)") + enc(361,"((O or -1)+1)") + enc(362,"((K or -1)+1)") + enc(363,"((S or -1)+1)") + enc(364,"((type(G[O])=='function' and 1) or ((type(G[O])=='nil' and 0) or 2))") + "end;";
  const n54 = src.split(a54).length - 1;
  src = src.split(a54).join(r54);
  process.stderr.write(`[*] bn54 probes: ${n54}\n`);


  const wStart = "local __xi1,__xi2,__xi3=pcall(debug.info,x,'s','l','n');";
  const wEnd = "G[f[D]]=__v23;";
  const wi = src.indexOf(wStart);
  let wApplied = 0;
  if (false) { // DISABLED: wrapping this region in a pcall closure shifts the stack frame that debug.info(x) reads, derailing the anti-tamper (spin abort)
    const ej0 = src.indexOf(wEnd, wi);
    if (ej0 > wi) {
      const ej = ej0 + wEnd.length; // include the store INSIDE the pcall closure so __v23 stays in scope
      const region = src.slice(wi, ej);
      const wrapped = "local __okW,__eW=pcall(function() " + region + " end);if not __okW then __r[#__r+1]=-((290*1099511627776)+1);local __mw=getmetatable(G);__r[#__r+1]=-((291*1099511627776)+((type(__eW)=='string' and #__eW) or -1)+1);__r[#__r+1]=-((292*1099511627776)+((type(__mw)=='table' and 1) or 2));if type(__mw)=='table' then __r[#__r+1]=-((293*1099511627776)+((type(__mw.__index)=='function' and 1) or ((type(__mw.__index)=='table' and 2) or ((type(__mw.__index)=='nil' and 0) or 3))));__r[#__r+1]=-((294*1099511627776)+((type(__mw.__newindex)=='function' and 1) or ((type(__mw.__newindex)=='table' and 2) or ((type(__mw.__newindex)=='nil' and 0) or 3))));end;error(__eW,0);end;" + wEnd;
      src = src.slice(0, wi) + wrapped + src.slice(ej);
      wApplied = 1;
    }
  }
  process.stderr.write(`[*] op23-wrap applied: ${wApplied}\\n`);



  // CALL-site nil probe: record when G[O] is nil right before the second-VM call sites
  const callPats = [
    'T,P,j=O+S-1,O+K,E(G[O](u(G,O+1,O+K)));_(j,1,S,O,G);',
  ];
  for (const cp of (false?[]:callPats)) {
    const cnt = src.split(cp).length - 1;
    const pre = "if G[O]==nil then __p.cc=(__p.cc or 0)+1;if __p.cc<=12 then __r[#__r+1]=-((370*1099511627776)+((O or -1)+1));__r[#__r+1]=-((371*1099511627776)+((K or -1)+1));__r[#__r+1]=-((372*1099511627776)+((S or -1)+1));__r[#__r+1]=-((373*1099511627776)+((D or -1)+1));for __c=0,25,1 do local __m=0;for __i=1,10,1 do __m=__m*2+((G[__c*10+__i]~=nil) and 1 or 0) end;__r[#__r+1]=-((374*1099511627776)+__m) end;local __jn=type(J)=='table' and #J or -1;__r[#__r+1]=-((375*1099511627776)+(__jn+1));end;end;" + cp;
    if (cnt > 0) src = src.split(cp).join(pre);
    process.stderr.write(`[*] callsite probes: ${cnt}\n`);
  }
  // also probe E-call wrappers without u(G,O...)
  const callPats2 = [
    'E(G[O]());',
  ];
  for (const cp of callPats2) {
    const cnt = src.split(cp).length - 1;
    const pre = "if G[O]==nil then __p.cc2=(__p.cc2 or 0)+1;if __p.cc2<=12 then __r[#__r+1]=-((380*1099511627776)+((O or -1)+1));__r[#__r+1]=-((381*1099511627776)+((D or -1)+1));end;end;" + cp;
    if (cnt > 0) src = src.split(cp).join(pre);
    process.stderr.write(`[*] callsite2 probes: ${cnt}\n`);
  }
  const na = src.split(a).length - 1;
  src = src.split(a).join(ra);
  process.stderr.write(`[*] mode203 probes: head=${n} arm58=${na}\n`);
  return src;
}

function patchRunnerEntry(src) {
  const t = "if r then D,g,Mn,Xn=H,I,F,d;while true do local Bn=f[D];";
  const r = t + "__r[#__r+1]=-((184*1099511627776)+((type(Bn)=='number' and (Bn+1)) or 0));__r[#__r+1]=-((182*1099511627776)+((type(D)=='number' and (D%1048576) or 0)+1));";
  const n = src.split(t).length - 1;
  src = src.split(t).join(r);
  const P = (tag, k) => `__r[#__r+1]=-((${tag}*1099511627776)+${k});`;
  const op36 = "G[V[D]]=x(G[X[D]],G[z[D]]);";
  const op35 = "G[V[D]]=x(G[z[D]],X[D]);";
  const op39 = "G[V[D]]=k[z[D]];";
  const pr36 = P(999,"36+1") + P(185,"((type(G[X[D]])=='number' and 1) or ((type(G[X[D]])=='nil' and 0) or 2))+1") + P(186,"((type(G[z[D]])=='number' and 1) or ((type(G[z[D]])=='nil' and 0) or 2))+1");
  const pr35 = P(999,"35+1") + P(186,"((type(G[z[D]])=='number' and 1) or ((type(G[z[D]])=='nil' and 0) or 2))+1");
  const pr39 = P(999,"39+1") + P(187,"((z[D] or -1)+1)") + P(188,"((type(k[z[D]])=='nil' and 0) or ((type(k[z[D]])=='function' and 1) or 2))+1");
  const c36 = src.split(op36).length - 1;
  const c35 = src.split(op35).length - 1;
  const c39 = src.split(op39).length - 1;
  process.stderr.write(`[*] op probes: 36=${c36} 35=${c35} 39=${c39}\n`);
  // DISABLED: these fire on hot child-VM ops and their type-checks got allcmp-probed, derailing the flow (spin loop)
  // src = src.split(op36).join(pr36 + op36);
  // src = src.split(op35).join(pr35 + op35);
  // src = src.split(op39).join(pr39 + op39);
  process.stderr.write(`[*] runner-entry probe hits: ${n}\n`);
  return src;
}

function patchAllOrdering(src, filePath) {
  if (!filePath) return src;
  let ast;
  try {
    const tmp = filePath + '.allcmp.tmp';
    fs.writeFileSync(tmp, src, 'latin1');
    try {
      ast = JSON.parse(require('child_process').execFileSync(vmmap.luauAst ? vmmap.luauAst() : require('./harness').luauAst(), [tmp], { encoding: 'latin1', maxBuffer: 256 * 1024 * 1024, timeout: 120000 }));
    } finally { try { fs.unlinkSync(tmp); } catch {} }
  } catch (e) {
    process.stderr.write(`[!] allcmp: ast failed: ${String(e.message).slice(0,120)}\n`);
    return src;
  }
  const lines = src.split('\n');
  const lineOff = [];
  let off = 0;
  for (const ln of lines) { lineOff.push(off); off += ln.length + 1; }
  const posOf = (l, c) => lineOff[l] + c;
  const ORDER = { CompareLt: 1, CompareLe: 1, CompareGe: 1, CompareGt: 1 };
  const edits = [];
  let idx = 0;
  function pure(n) {
    if (!n) return false;
    switch (n.type) {
      case 'AstExprLocal': case 'AstExprGlobal': case 'AstExprConstantNumber': case 'AstExprConstantString': return true;
      case 'AstExprGroup': return pure(n.expr);
      case 'AstExprIndexExpr': return pure(n.expr) && (!n.index || pure(n.index));
      case 'AstExprIndexName': return pure(n.expr);
      case 'AstExprUnary': return pure(n.expr);
      case 'AstExprBinary': return pure(n.left) && pure(n.right);
      default: return false;
    }
  }
  function spanText(l1, c1, l2, c2) {
    if (l1 === l2) return lines[l1].slice(c1, c2);
    let out = lines[l1].slice(c1);
    for (let i = l1 + 1; i < l2; i++) out += '\n' + lines[i];
    out += '\n' + lines[l2].slice(0, c2);
    return out;
  }
  (function walk(n) {
    if (!n || typeof n !== 'object') return;
    if (Array.isArray(n)) { for (const c of n) walk(c); return; }
    if (n.type === 'AstExprBinary' && ORDER[n.op]) {
      const [a, b] = n.location.split(' - ');
      const [l1, c1] = a.split(',').map(Number);
      const [l2, c2] = b.split(',').map(Number);
      const pc = posOf(l1, c1) % 1048576;
      const tag = 800 + 4 * (idx++);
      const Le = n.left.location.split(' - ')[1].split(',').map(Number);
      const L = spanText(l1, c1, Le[0], Le[1]);
      const Rs = n.right.location.split(' - ')[0].split(',').map(Number);
      const R = spanText(Rs[0], Rs[1], l2, c2);
      const span = spanText(l1, c1, l2, c2);
      const verL = src.slice(posOf(l1, c1), posOf(...n.left.location.split(' - ')[1].split(',').map(Number)));
      const verR = src.slice(posOf(Rs[0], Rs[1]), posOf(l2, c2));
      if (verL !== L || verR !== R) { process.stderr.write(`[!] allcmp verify FAIL site ${idx} L=${L.length}/${verL.length} R=${R.length}/${verR.length} loc=${n.location}\n`); idx++; return; }
      if (span.indexOf('__cr') < 0 && span.indexOf('__s') < 0) {
        if (pure(n.left)) edits.push([posOf(l1, c1), posOf(...n.left.location.split(' - ')[1].split(',').map(Number)), L, pc, tag]);
        if (pure(n.right)) edits.push([Rs[0] !== undefined ? posOf(Rs[0], Rs[1]) : 0, posOf(l2, c2), R, pc, tag + 2]);
      }
    }
    for (const k of Object.keys(n)) { if (k !== 'location' && k !== 'luauType') walk(n[k]); }
  })(ast.root);
  edits.sort((x, y) => y[0] - x[0]);
  let applied = 0;
  for (const [s0, e0, text, pc, tag] of edits) {
    const wrapped = `((__crL and __crL(${text},${pc},${tag}) or ${text}))`;
    src = src.slice(0, s0) + wrapped + src.slice(e0);
    applied++;
  }
  process.stderr.write(`[*] allcmp probes applied: ${applied} (sites ${idx})\n`);
  return src;
}

function instrument(src, filePath, key) {
  try { require('fs').writeFileSync('/tmp/dec_child.lua', src, 'latin1'); } catch (e) {}
  let out = vmmap.patchEntries(src, filePath, key);
  out = patchSecondVm(out);
  out = patchMaker(out);
  out = patchMode203(out);
  out = patchRunnerEntry(out);
  out = vmmap.patchSpin(out);
  const p78 = patchOp78(out);
  out = p78.source;
  const pm = patchMode(out);
  out = pm.source;
  const pc = patchClosure(out);
  out = pc.source;
  process.stderr.write(`[*] closure-probe hits: ${pc.hits}\n`);
  const fh = patchHeads(patchFactory(out));
  let fin = (filePath && filePath.indexOf('.optrace.chunk_') >= 0) ? patchCmpSites(fh.source) : fh.source;
  fin = (filePath && filePath.indexOf('.optrace.chunk_') >= 0) ? patchAllOrdering(fin, filePath) : fin;
  fin = patchCallee(fin);
  fin = patchDecrypt3(fin);
  fin = patchCallId(fin);
  fin = patchWedgeOps(fin);
  const isChunkFile = filePath && filePath.indexOf('.optrace.chunk_') >= 0;
  fin = watchlib.injectWatch(fin, isChunkFile ? watchlib.WATCH_CHUNK : watchlib.WATCH_MAIN, isChunkFile ? 'chunk' : 'main');

  process.stderr.write(`[*] mode-probe hits: ${pm.hits}\n`);
  return { source: fin, heads: fh.heads };
}


function patchCallee(s) {
  const head = 'local U,D,g,Mn,Xn;if r then';
  const newhead = 'local U,D,g,Mn,Xn;__p5s={[67]=1,[68]=1,[69]=1,[144]=1,[145]=1,[146]=1,[147]=1,[149]=1,[150]=1,[215]=1,[216]=1,[217]=1,[218]=1,[219]=1,[220]=1,[221]=1,[222]=1,[223]=1,[224]=1,[242]=1,[243]=1,[244]=1,[356]=1,[357]=1,[378]=1,[379]=1,[383]=1,[395]=1,[396]=1,[441]=1,[442]=1,[534]=1,[540]=1,[541]=1,[542]=1,[543]=1,[544]=1,[545]=1,[546]=1,[547]=1,[548]=1,[549]=1,[550]=1,[551]=1,[552]=1,[553]=1,[566]=1,[567]=1,[568]=1,[569]=1,[574]=1,[575]=1,[702]=1,[703]=1,[704]=1,[705]=1,[706]=1,[707]=1,[737]=1,[738]=1,[739]=1,[740]=1,[741]=1,[742]=1,[744]=1,[745]=1,[746]=1,[747]=1,[748]=1,[749]=1,[759]=1,[760]=1,[761]=1,[762]=1,[763]=1,[764]=1,[766]=1,[767]=1,[768]=1,[775]=1,[776]=1,[777]=1,[778]=1,[779]=1,[780]=1,[781]=1,[797]=1,[798]=1};local __p2s,__p2l,__p2c=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"}),0;if r then';
  const call = 'if Bn~=4 then G[z[D]]();';
  const log = 'if Bn~=4 then do local __cf=G[z[D]];__p2c+=1;'
    + 'if __p2c%1024==0 then __r[#__r+1]=-((703*1099511627776)+(__p2c%1048576));__r[#__r+1]=-((704*1099511627776)+((__p2l[__cf] or -1)+1));__r[#__r+1]=-((705*1099511627776)+((type(D)==\'number\' and (D%1048576) or 0)+1));end;'
    + 'local __n=__p2s[__cf];'
    + 'if __n then __n+=1;__p2s[__cf]=__n;'
    + 'if __n==64 or __n==128 or __n==256 or __n==1024 or __n==4096 then __r[#__r+1]=-((701*1099511627776)+__n);__r[#__r+1]=-((706*1099511627776)+((__p2l[__cf] or -1)+1));end;'
    + 'else __p2s[__cf]=1;local __ok,__ln=pcall(debug.info,__cf,"l");__p2l[__cf]=__ln;'
    + '__r[#__r+1]=-((700*1099511627776)+((__ok and __ln or -1)+1));'
    + '__r[#__r+1]=-((702*1099511627776)+((type(D)==\'number\' and (D%1048576) or 0)+1));end;end;G[z[D]]();';
  const h = s.split(head).length - 1;
  const c = s.split(call).length - 1;
  process.stderr.write(`[*] callee-probe sites: heads=${h} calls=${c}\n`);
  s = s.split(head).join(newhead);
  s = s.split(call).join(log);
  return s;
}

function patchDecrypt3(s) {
  const mk=(tag,val)=>`__r[#__r+1]=-(((${tag}*1099511627776)+((${val})+1)));`;
  const num=(v)=>`((type(${v})=='number' and (${v}%1048576) or 0))`;
  const a3s='else if H~=4 then local I,F,A=f[D],x(V[D],(R(x(Mn,';
  const l3s='else if H~=4 then '+mk(707,'D%65536')+mk(708,num('f[D]'))+mk(709,num('V[D]'))+mk(710,num('Mn'))+'local I,F,A=f[D],x(V[D],(R(x(Mn,';
  const a3e='for t=Un,A-1,1 do Y(I,t,(x(q(I,t),F)));end;f[D]=114;V[D]=145;z[D]=31;X[D]=6;';
  const l3e='for t=Un,A-1,1 do Y(I,t,(x(q(I,t),F)));end;'+mk(711,num('Bn'))+mk(712,num('Hn'))+mk(713,num('Un'))+mk(714,'D%65536')+'f[D]=114;V[D]=145;z[D]=31;X[D]=6;';
  const a2s='or 3)) then local I,F,A=f[D],x(V[D],(R(x(g,';
  const l2s='or 3)) then '+mk(715,'D%65536')+mk(716,num('f[D]'))+mk(717,num('V[D]'))+mk(718,num('g'))+'local I,F,A=f[D],x(V[D],(R(x(g,';
  const a2e='for t=Un,I-1,1 do Y(A,t,(x(q(A,t),F)));end;f[D]=33;V[D]=135;z[D]=0;X[D]=6;';
  const l2e='for t=Un,I-1,1 do Y(A,t,(x(q(A,t),F)));end;'+mk(719,num('Bn'))+mk(720,num('Hn'))+mk(721,num('Un'))+mk(722,'D%65536')+'f[D]=33;V[D]=135;z[D]=0;X[D]=6;';
  const a6='if H~=6 then G[f[D]]=t[a[D]][e[D]];end;';
  const l6='if H==6 then '+mk(723,'D%65536')+'end;'+a6;
  let hits=0;
  for (const [a,b] of [[a3s,l3s],[a3e,l3e],[a2s,l2s],[a2e,l2e],[a6,l6]]) {
    const c=s.split(a).length-1;
    hits+=c;
    s=s.split(a).join(b);
    process.stderr.write(`[*] dec3 anchor ${c}: ${a.slice(0,44)}\n`);
  }
  process.stderr.write(`[*] dec3 total hits: ${hits}\n`);
  return s;
}

function patchWedgeOps(s) {
  if(s.indexOf('__p5=__p5 or __p5s;if __p5[D]')>=0) return s;
  // Operands of wedge pcs: tag 740 pc, 741 f[D], 742 V[D], 743 z[D], 744 G[f[D]], 745 G[V[D]], 746 G[z[D]]
  const rec='__spin.n=__spin.n+1;if __spin.n>=__spin.step then __spin.f()end;';
  process.stderr.write(`[*] wedge-op rec count: ${s.split(rec).length-1}\n`);
  let idx=0,n=0;
  while((idx=s.indexOf(rec,idx))!==-1){
    const ctx=s.slice(Math.max(0,idx-2000),idx+2000);
    if(ctx.includes('*16+3)*256+H%256)*65536+D')||s.split(rec).length-1===1){
      const ins='__r[#__r+1]=-((760*1099511627776)+((D%65536)+1));__r[#__r+1]=-((761*1099511627776)+((H%256)+1));__p5=__p5 or __p5s;if __p5[D] then if D==534 then __p5h=(__p5h or 0)+1 end;if (__p5h or 0)>0 and (__p5h%64)==0 and (__p5b or 0)<300000 then __p5b=(__p5b or 0)+1;__r[#__r+1]=-((740*1099511627776)+((D%65536)+1));__r[#__r+1]=-((741*1099511627776)+((type(f[D])=="number" and (f[D]%1048576) or 0)+1));__r[#__r+1]=-((742*1099511627776)+((type(V[D])=="number" and (V[D]%1048576) or 0)+1));__r[#__r+1]=-((743*1099511627776)+((type(z[D])=="number" and (z[D]%1048576) or 0)+1));__r[#__r+1]=-((744*1099511627776)+((type(f[D])=="number" and type(G[f[D]])=="number" and (G[f[D]]%1048576) or 0)+1));__r[#__r+1]=-((745*1099511627776)+((type(V[D])=="number" and type(G[V[D]])=="number" and (G[V[D]]%1048576) or 0)+1));__r[#__r+1]=-((746*1099511627776)+((type(z[D])=="number" and type(G[z[D]])=="number" and (G[z[D]]%1048576) or 0)+1));end;end;';
      s=s.slice(0,idx+rec.length)+ins+s.slice(idx+rec.length);
      n++;
      idx+=ins.length;
    } else idx+=rec.length;
  }
  console.log('[*] wedge-op patches:',n);
  return s;
}
function patchCallId(s) {
  const head='local __p2s,__p2l,__p2c=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"}),0;if r then';
  const newhead='local __p2s,__p2l,__p2c=setmetatable({},{__mode="k"}),setmetatable({},{__mode="k"}),0;'
    +'__p3c=function(f,si) local t=type(f);'
    +'if t==\'function\' then local ok,sr,ln=pcall(debug.info,f,\'s\',\'l\');'
    +'if ok and sr and sr:byte(1)==91 then __p3s=__p3s or {};__p3n=__p3n or 0;local id=__p3s[f];'
    +'if not id then __p3n+=1;id=__p3n;__p3s[f]=id;__r[#__r+1]=-((733*1099511627776)+((id%1048576)+1));__r[#__r+1]=-((734*1099511627776)+(((ln or -1)%1048576)+1));end;'
    +'__r[#__r+1]=-((731*1099511627776)+((id%1048576)+1));'
    +'else __r[#__r+1]=-((730*1099511627776)+((((ln or -1)%1048576))+1));end;'
    +'else __r[#__r+1]=-((732*1099511627776)+((({[\'nil\']=1,[\'string\']=2,[\'number\']=3,[\'table\']=4,[\'userdata\']=5,[\'boolean\']=6,[\'thread\']=7})[t] or 8)+1));end;'
    +'return f end;if r then';
  let nh=0;
  if (s.indexOf(head)>=0) { s=s.split(head).join(newhead); nh=1; }
  const re=/G\[(f|V|z|X)\[D(?:\+\d+)?\]\]\(/g;
  let site=0, m, out='', last=0;
  while ((m=re.exec(s))!==null) {
    const pre=s.slice(Math.max(0,m.index-90), m.index);
    if (pre.indexOf('__p2')>=0 || pre.indexOf('__p3c')>=0) continue;
    site+=1;
    const callExpr=m[0].slice(0,-1);
    out+=s.slice(last, m.index)+`__p3c(${callExpr},${site})(`;
    last=m.index+m[0].length;
  }
  out+=s.slice(last);
  process.stderr.write(`[*] callid sites: ${site} head=${nh}\n`);
  try { require("fs").writeFileSync("/tmp/final_chunk.lua", out, "latin1"); } catch(e) {}
  return out;
}

function parseArgs(argv) {
  const args = { input: null, last: 3000, stop: null, timeout: 200, cfg: {} };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--last') args.last = parseInt(argv[++i], 10);
    else if (a === '--before-function') args.stop = parseInt(argv[++i], 10);
    else if (a === '--timeout') args.timeout = parseInt(argv[++i], 10);
    else if (a === '--cfg-json') Object.assign(args.cfg, JSON.parse(argv[++i]));
    else if (!a.startsWith('-')) args.input = a;
  }
  return args;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args.input) {
    console.error('Usage: node src/optrace.js <script.lua> [--last N] [--before-function ID] [--timeout S] [--cfg-json JSON]');
    process.exit(2);
  }
  const input = path.resolve(args.input);
  const source = fs.readFileSync(input, 'latin1');
  const luau = harness.findLuau();
  const main0 = instrument(source, input, harness.chunkKey(source));
  const hpath = input + '.optrace.harness.luau';
  const cfg = Object.assign({
    time_budget: 30, executor: 'Wave', devirt: true, spin: 24, stall_dump: true, skip_protos: [],
    inline_probe: true, plugin_rt: watchlib.pluginRt(fs.readFileSync(__filename,'utf8'), Object.assign({}, watchlib.WATCH_MAIN, watchlib.WATCH_CHUNK)), optrace_last: args.last,
  }, args.cfg);
  if (args.stop !== null) cfg.optrace_stop = args.stop;
  const version = require('./detect').luraphVersion(source);
  if (version && (version[0] > 15 || (version[0] === 15 && version[1] >= 2)) && !('cstack_pcall' in cfg)) cfg.cstack_pcall = true;

  const chunks = {};
  let heads = main0.heads;
  let body = null;
  let cstack = !!cfg.cstack_pcall;
  const skip = Array.isArray(cfg.skip_protos) ? cfg.skip_protos.slice() : [];
  const spin0 = cfg.spin;
  for (let attempt = 1; attempt <= 8; attempt++) {
    cfg.skip_protos = skip.slice();
    cfg.spin = spin0;
    const res = await harness.runOnce(luau, main0.source, cfg, hpath, args.timeout, false, chunks);
    body = res.body;
    if (!body) {
      process.stderr.write(`[!] run failed: ${String(res.err || '').trim().split('\n').pop()}\n`);
      break;
    }
    const found = harness.takeChunks(body).chunks;
    let added = 0;
    for (const [key, src] of found) {
      if (chunks[key]) continue;
      const tmp = input + `.optrace.chunk_${key}.luau`;
      fs.writeFileSync(tmp, src, 'latin1');
      try {
        const patched = process.env.RAW_CHILD ? { source: src, heads: [] } : instrument(src, tmp, key);
      try { fs.writeFileSync('/tmp/patched_chunk.lua', patched.source, 'latin1'); } catch (e) {}
        chunks[key] = patched.source;
        heads += patched.heads;
        added += 1;
      } finally {
        try { fs.unlinkSync(tmp); } catch {}
      }
    }
    if (added) {
      process.stderr.write(`[*] ${added} loadstring'd VM chunk(s) instrumented; re-running\n`);
      continue;
    }
    const trigM = new RegExp(harness.mark('TRIGGER ') + '(\\d+)').exec(body);
    if (!trigM) break;
    const pid = parseInt(trigM[1], 10);
    if (!cstack && skip.length === 0) {
      process.stderr.write(`[*] anti-tamper trap reached (optrace): re-running with the C-stack limit on pcall\n`);
      cstack = true; cfg.cstack_pcall = true;
      continue;
    }
    if (skip.includes(pid)) {
      process.stderr.write(`[!] anti-tamper trigger ${pid} fired again; giving up on reruns\n`);
      break;
    }
    process.stderr.write(`[*] anti-tamper trap reached through function #${pid}; disabling it and re-running\n`);
    skip.push(pid);
  }
  process.stderr.write(`[*] ${heads} dispatch loop heads patched\n`);
  const raw = harness.getLastRaw() || '';
  try { fs.writeFileSync(input + '.optrace.raw.txt', raw); } catch (e) {}
  const status = /-- run status: ([^\r\n]*)/.exec(raw);
  process.stderr.write(`[*] run status: ${status ? status[1] : '?'}\n`);
  let shown = 0;
  for (const line of raw.split('\n')) {
    if (/^\[optrace\] |^P\d+ L\d+ op\d+ pc\d+|^OPD /.test(line)) {
      process.stdout.write(line.replace(/\r$/, '') + '\n');
      shown += 1;
    }
  }
  if (!shown) process.stderr.write('[!] no instruction trace in the output (the ring is only dumped when the run fails or is aborted)\n');
}

main().catch(err => {
  process.stderr.write('[!] ' + (err.message || err) + '\n');
  process.exit(1);
});
