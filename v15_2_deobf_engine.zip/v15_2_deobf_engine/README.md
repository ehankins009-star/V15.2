# Luraph v15.2 deobfuscator (fixed engine, Nov 25 2026)

## What is here
- `deob.js` - the main entry. Takes an obfuscated script (or a folder of them).
- `src/` - the Node.js side: driver, instrumentation, op tracer, detector.
- `core/` - the Python lifter/backend (devirt.py, driver.py, vmmap.py, codegen...).
- `runtime/` - the Luau shims the traced VM runs against (envlog, roblox_api, datatypes).
- `ref/` - reference notes for the v15 probes.
- `samples/` - the v15.2 and v15.1 test scripts, use them to check your setup.
- `bin/` - bundled Luau binaries (Linux `luau`/`luau-ast`, Windows `.exe`).
- `build_luau.py` - rebuilds the bundled Luau (only needed if you want to patch the VM runtime).

## Requirements
- Node.js (16+) and Python 3.7+. No pip packages needed for the default path.
- The bundled binaries run the script; nothing else to install.

## Quick start
```
node deob.js your_script.luau -o out.lua
```
For a script with a sidecar bytecode buffer (v15.2 VM payloads):
```
node deob.js your_script.luau --bytecode-file your_bytecode.bin -o out.lua
```
Extra flags: `--debug`, `--detect`, `--no-devirt`, `--timeout N`, `--devirt-rounds N`,
`--cfg-json '{"cstack_pcall":true}'` (auto-on for v15.2+ headers).

## When the run stalls or errors
```
node src/optrace.js your_script.luau --last 400
PYTHONPATH=core python3 core/obfuscators/luraph_v15/devirt.py your_script.luau protos.json --raw <fn>
PYTHONPATH=core python3 core/obfuscators/luraph_v15/devirt.py your_script.luau protos.json --lift <fn>
```

## Fixed in this build
- The depth probe fix: `cstack_pcall` refuses to run a pcall at the C-call limit like Roblox,
  so v15.2 startup checks pass instead of looping forever (crash routine no longer fires).
- All 15 lift holes filled (return holes, t82 compare, line-79 arithmetic), 38 functions lifted.
- The v15.2 three-level closure maker is mapped (`__m1..__mN` maker args), never-created
  closures fall back to their creation-site numbers.
- Repeated byte strings deduped into `luraphData` in lifted output.
