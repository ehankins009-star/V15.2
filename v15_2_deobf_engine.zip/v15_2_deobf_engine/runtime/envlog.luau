local cfg = __config or {}
local maxStmts = cfg.max_stmts or 250000
local maxBlock = cfg.max_block or 25000
local maxWaits = cfg.max_waits or 50
local maxDepth = cfg.max_depth or 24
local timeBudget = cfg.time_budget or 30

local real = {
        type = type, typeof = typeof, tostring = tostring, tonumber = tonumber,
        pairs = pairs, ipairs = ipairs, next = next, select = select,
        rawget = rawget, rawset = rawset, rawequal = rawequal, rawlen = rawlen,
        setmetatable = setmetatable, getmetatable = getmetatable,
        pcall = pcall, xpcall = xpcall, error = error,
        getfenv = __raw.getfenv, setfenv = __raw.setfenv, loadstring = __raw.loadstring,
        newproxy = newproxy, print = print, clock = os.clock,
        unpack = table.unpack, insert = table.insert, concat = table.concat,
        pack = table.pack,
        remove = table.remove, fmt = string.format, rep = string.rep,
        gsub = string.gsub, match = string.match, byte = string.byte,
        sub = string.sub, find = string.find, sort = table.sort,
        lower = string.lower,
        floor = math.floor, huge = math.huge, max = math.max,
}
real.json = (function()
        local jsonEsc = {['"'] = '\\"', ['\\'] = '\\\\', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t', ['\b'] = '\\b', ['\f'] = '\\f'}
        local function encodeString(s)
                return '"' .. string.gsub(s, '[%c"\\]', function(c)
                        return jsonEsc[c] or string.format("\\u%04x", string.byte(c))
                end) .. '"'
        end
        local function encode(v, seen)
                local t = type(v)
                if v == nil then return "null" end
                if t == "boolean" then return v and "true" or "false" end
                if t == "number" then
                        if v ~= v or v == math.huge or v == -math.huge then return "null" end
                        if v == math.floor(v) and math.abs(v) < 2 ^ 53 then
                                return string.format("%d", v)
                        end
                        return tostring(v)
                end
                if t == "string" then return encodeString(v) end
                if t == "table" then
                        if seen[v] then error("cannot encode recursive table", 2) end
                        seen[v] = true
                        local n = 0
                        local isArr = true
                        for k in pairs(v) do
                                if type(k) ~= "number" or k % 1 ~= 0 or k < 1 then
                                        isArr = false
                                else
                                        n = n + 1
                                end
                        end
                        local parts = {}
                        if isArr and n > 0 then
                                for i = 1, n do
                                        parts[i] = encode(v[i], seen)
                                end
                                seen[v] = nil
                                return "[" .. table.concat(parts, ",") .. "]"
                        end
                        local keys = {}
                        for k in pairs(v) do
                                if type(k) == "string" or type(k) == "number" then
                                        keys[#keys + 1] = k
                                end
                        end
                        table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
                        for i, k in ipairs(keys) do
                                parts[i] = encodeString(tostring(k)) .. ":" .. encode(v[k], seen)
                        end
                        seen[v] = nil
                        return "{" .. table.concat(parts, ",") .. "}"
                end
                error("cannot encode value of type " .. t, 2)
        end
        local function decode(s, pos)
                pos = pos or 1
                local function skipWs(p)
                        while p <= #s do
                                local c = string.sub(s, p, p)
                                if c == " " or c == "\t" or c == "\n" or c == "\r" then p = p + 1 else break end
                        end
                        return p
                end
                local parseValue
                local function parseString(p)
                        p = p + 1
                        local buf = {}
                        while p <= #s do
                                local c = string.sub(s, p, p)
                                if c == '"' then
                                        return table.concat(buf), p + 1
                                elseif c == "\\" then
                                        local e = string.sub(s, p + 1, p + 1)
                                        if e == "u" then
                                                local hex = string.sub(s, p + 2, p + 5)
                                                local code = tonumber(hex, 16)
                                                p = p + 6
                                                if code < 0x80 then
                                                        buf[#buf + 1] = string.char(code)
                                                elseif code < 0x800 then
                                                        buf[#buf + 1] = string.char(0xC0 + math.floor(code / 64), 0x80 + code % 64)
                                                else
                                                        buf[#buf + 1] = string.char(0xE0 + math.floor(code / 4096),
                                                                0x80 + math.floor(code / 64) % 64, 0x80 + code % 64)
                                                end
                                        else
                                                local map = { n = "\n", t = "\t", r = "\r", b = "\b", f = "\f", ['"'] = '"', ["\\"] = "\\", ["/"] = "/" }
                                                buf[#buf + 1] = map[e] or e
                                                p = p + 2
                                        end
                                else
                                        buf[#buf + 1] = c
                                        p = p + 1
                                end
                        end
                        error("unterminated string", 0)
                end
                parseValue = function(p)
                        p = skipWs(p)
                        local c = string.sub(s, p, p)
                        if c == '"' then
                                return parseString(p)
                        elseif c == "{" then
                                local obj = {}
                                p = skipWs(p + 1)
                                if string.sub(s, p, p) == "}" then return obj, p + 1 end
                                while true do
                                        p = skipWs(p)
                                        local k
                                        k, p = parseString(p)
                                        p = skipWs(p)
                                        if string.sub(s, p, p) ~= ":" then error("expected :", 0) end
                                        local v
                                        v, p = parseValue(p + 1)
                                        obj[k] = v
                                        p = skipWs(p)
                                        local d = string.sub(s, p, p)
                                        if d == "," then p = p + 1
                                        elseif d == "}" then return obj, p + 1
                                        else error("expected , or }", 0) end
                                end
                        elseif c == "[" then
                                local arr = {}
                                p = skipWs(p + 1)
                                if string.sub(s, p, p) == "]" then return arr, p + 1 end
                                while true do
                                        local v
                                        v, p = parseValue(p)
                                        arr[#arr + 1] = v
                                        p = skipWs(p)
                                        local d = string.sub(s, p, p)
                                        if d == "," then p = p + 1
                                        elseif d == "]" then return arr, p + 1
                                        else error("expected , or ]", 0) end
                                end
                        elseif string.sub(s, p, p + 3) == "true" then
                                return true, p + 4
                        elseif string.sub(s, p, p + 4) == "false" then
                                return false, p + 5
                        elseif string.sub(s, p, p + 3) == "null" then
                                return nil, p + 4
                        else
                                local num = string.match(s, "^%-?%d+%.?%d*[eE]?%+?%-?%d*", p)
                                if not num or num == "" then
                                        num = string.match(s, "^%-?%d+", p)
                                end
                                if num and num ~= "" then
                                        return tonumber(num), p + #num
                                end
                                error("unexpected character at " .. p .. ": " .. string.sub(s, p, p + 10), 0)
                        end
                end
                return parseValue(pos)
        end
        local function jd(s)
                if type(s) == "buffer" then s = buffer.tostring(s) end
                return decode(tostring(s))
        end
        return { encode = function(v) return encode(v, {}) end, decode = jd }
end)()
local realGlobals = real.getfenv(0)
local harnessSrc0 = debug.info(1, "s")

local markPrefix = "\0" .. (__mark or "")
real.__ls_src = {}
real.reportErrLine = function(err)
        local sn, sl = real.match(real.tostring(err), '%[string "(.-)"%]:(%d+)')
        if not (sn and sl and real.__ls_src[sn]) then return end
        local src = real.__ls_src[sn]
        local target = real.tonumber(sl)
        local pos, ln = 1, 0
        while pos <= #src do
                local e = real.find(src, "\n", pos, true)
                local le = e and (e - 1) or #src
                ln = ln + 1
                if ln == target then
                        real.print(markPrefix .. "ERRLINE " .. sn .. ":" .. sl .. " => " .. real.sub(src, pos, le))
                        return
                end
                pos = e and (e + 1) or (#src + 1)
        end
end

local protocol = { hash_mult = 31, hash_mod = 2147483648, hash_stride = 4096, chunk_min = 4096 }

local native = cfg.native and real.typeof(realGlobals.game) == "Instance"
local outBuf = {}
if native then
        real.print = function(...)
                local t = table.pack(...)
                for i = 1, t.n do t[i] = real.tostring(t[i]) end
                real.insert(outBuf, real.concat(t, "\t", 1, t.n))
                if cfg.print_tail and #outBuf > 2 * cfg.print_tail then
                        outBuf = table.move(outBuf, #outBuf - cfg.print_tail + 1, #outBuf, 1, {})
                end
        end
end
local startClock = real.clock()

local loopMark = real.setmetatable({}, { __tostring = function() return "<envlog: loop truncated>" end })
local abort = real.setmetatable({}, { __tostring = function() return "<envlog: budget exhausted>" end })
local tamper = real.setmetatable({}, { __tostring = function() return "<envlog: anti-tamper suppressed>" end })
local abortReason = nil
local tamperCount = 0
local trigger, noteTrigger = nil, nil

local rootTrace = { lines = {}, waits = {} }
local traceStack = { rootTrace }
local stmtCount = 0

local hub = { pf = nil, pid = nil, plast = nil }
function hub.get()
        local pf, pid, plast = hub.pf, hub.pid, hub.plast
        local parts = {}
        local lvl = 3
        local inner = nil
        while true do
                local f = debug.info(lvl, "f")
                if f == nil then break end
                local proto = pf[f]
                local id = proto and pid[proto]
                if id then
                        if id == 1 and #parts > 0 then inner = parts[1] end
                        real.insert(parts, 1, id .. ":" .. real.tostring(plast[id]))
                end
                lvl += 1
        end
        hub.seen = hub.seen or {}
        if inner and parts[1] == "1:" .. real.tostring(plast[1]) then
                local c = real.tonumber(real.match(inner, "^(%d+):"))
                hub.rootCallee = c
                hub.seen[c] = hub.seen[c] or "ok"
        elseif #parts == 1 and real.match(parts[1], "^1:") then
                for c in real.next, hub.seen do hub.seen[c] = "probe" end
                hub.rootCallee = nil
        elseif #parts >= 1 and not real.match(parts[1], "^1:") and (not hub.rootCallee or hub.seen[hub.rootCallee] == "probe") then
                local c = real.tonumber(real.match(parts[1], "^(%d+):"))
                if c and hub.seen[c] ~= "probe" then
                        hub.rootCallee = c
                        hub.seen[c] = "ok"
                end
        end
        return real.concat(parts, ",")
end

local function curBlock()
        return traceStack[#traceStack]
end

local abortHits = 0
local function checkBudget()
        if hub.unlimited then return end
        if abortReason then
                abortHits += 1
                if abortHits > 1 and coroutine.isyieldable() then coroutine.yield(abort) end
                real.error(abort, 0)
        end
        if stmtCount > maxStmts then
                abortReason = "statement limit reached"
                real.error(abort, 0)
        end
        local now = real.clock()
        if now - startClock > timeBudget then
                abortReason = "time budget exhausted"
                real.error(abort, 0)
        end
        if cfg.heartbeat and now - (cfg._hb or startClock) > cfg.heartbeat then
                cfg._hb = now
                real.print(markPrefix .. "HB t=" .. real.fmt("%.1f", real.clock() - startClock) .. " stmts=" .. stmtCount)
        end
end

local function emit(stmt)
        checkBudget()
        if hub.syncGenv and not hub.syncing then hub.syncGenv() end
        local b = curBlock()
        if b.stopped then
                b.stopped += 1
                if b.stopped > 200 then
                        abortReason = "a stopped loop kept running (its error was caught by the script)"
                        real.error(abort, 0)
                end
                real.error(loopMark, 0)
        end
        stmtCount += 1
        if hub.pf then stmt.chain = hub.get() end
        real.insert(b.lines, stmt)
        for i = #traceStack, 1, -1 do
                local rb = traceStack[i]
                if rb.isRoot or i == 1 then
                        rb.tape = rb.tape or {}
                        real.insert(rb.tape, { stmt = stmt, block = b })
                        break
                end
        end
        if #b.lines > maxBlock then
                real.insert(b.lines, { text = "-- [envlog] block truncated after " .. maxBlock .. " statements" })
                b.stopped = 0
                real.error(loopMark, 0)
        end
        return stmt
end

local function comment(s)
        return emit({ text = "-- " .. s })
end

local infoOf = real.setmetatable({}, { __mode = "k" })
local byId = {}

real.auditState = {
    events = {},
    dropped = 0,
    max_events = cfg.audit_max_events or 10000,
    max_value = cfg.audit_max_value or 512,
}

real.auditSecretKeys = {
    token = true,
    accesstoken = true,
    refreshtoken = true,
    authorization = true,
    cookie = true,
    password = true,
    passwd = true,
    apikey = true,
    secret = true,
    sessionid = true,
}

real.auditRedactKey = function(k)
    if real.type(k) ~= "string" then return false end
    local key = real.gsub(real.lower(k), "[^%w]", "")
    return real.auditSecretKeys[key] == true
        or real.find(key, "token", 1, true) ~= nil
        or real.find(key, "password", 1, true) ~= nil
        or real.find(key, "secret", 1, true) ~= nil
end

real.auditValue = function(v, depth, seen)
    local t = real.type(v)

    if t == "nil" then return { type = "nil" } end
    if t == "boolean" or t == "number" then
        return { type = t, value = v }
    end

    if t == "string" then
        if #v > real.auditState.max_value then
            return { type = t, truncated = true, length = #v }
        end
        return { type = t, value = v }
    end

    if t == "function" then return { type = "function" } end

    if t == "userdata" and infoOf[v] then
        local info = infoOf[v]
        return {
            type = "proxy",
            id = info.id,
            kind = info.kind,
            name = info.name or info.hint or info.key,
            className = info.className,
        }
    end

    if t ~= "table" then return { type = t } end

    depth = depth or 0
    seen = seen or {}

    if seen[v] then return { type = "table", circular = true } end
    if depth >= 3 then return { type = "table", truncated = true } end

    seen[v] = true
    local out = { type = "table", entries = {}, truncated = false }
    local count = 0

    for k, value in real.next, v do
        count += 1
        if count > 30 then
            out.truncated = true
            break
        end

        local key = real.type(k) == "string" and k or real.tostring(k)

        if real.auditRedactKey(key) then
            out.entries[key] = "[REDACTED]"
        else
            out.entries[key] = real.auditValue(value, depth + 1, seen)
        end
    end

    seen[v] = nil
    return out
end

real.audit = function(kind, fields)
    if cfg.audit == false then return end

    local state = real.auditState
    if #state.events >= state.max_events then
        state.dropped += 1
        return
    end

    fields = fields or {}
    fields.event = kind
    fields.seq = #state.events + 1
    fields.time = real.clock() - startClock

    state.events[#state.events + 1] = fields
end

local nextId = 0
local proxyMeta = {}
local isMethodName, methodFn
local methodProxyRef

local function isP(v)
        return real.type(v) == "userdata" and infoOf[v] ~= nil
end

local function newP(info)
        nextId += 1
        info.id = nextId
        info.children = {}
        info.props = {}
        local p = real.newproxy(true)
        local mt = real.getmetatable(p)
        for k, f in proxyMeta do
                mt[k] = f
        end
        infoOf[p] = info
        byId[nextId] = p
        return p
end

local function tok(p)
        return "\1" .. infoOf[p].id .. "\2"
end

local function isIdent(s)
        return real.type(s) == "string" and real.match(s, "^[%a_][%w_]*$") ~= nil and not ({
                ["and"] = 1, ["break"] = 1, ["do"] = 1, ["else"] = 1, ["elseif"] = 1, ["end"] = 1,
                ["false"] = 1, ["for"] = 1, ["function"] = 1, ["if"] = 1, ["in"] = 1, ["local"] = 1,
                ["nil"] = 1, ["not"] = 1, ["or"] = 1, ["repeat"] = 1, ["return"] = 1, ["then"] = 1,
                ["true"] = 1, ["until"] = 1, ["while"] = 1, ["continue"] = 1,
        })[s]
end

local function quote(s)
        local out = real.gsub(s, '[%c"\\\128-\255]', function(c)
                if c == "\n" then return "\\n" end
                if c == "\t" then return "\\t" end
                if c == "\r" then return "\\r" end
                if c == '"' then return '\\"' end
                if c == "\\" then return "\\\\" end
                local b = real.byte(c)
                return "\\" .. b
        end)
        return '"' .. out .. '"'
end

local function fmtNumber(n)
        if n ~= n then return "0/0" end
        if n == real.huge then return "math.huge" end
        if n == -real.huge then return "-math.huge" end
        if n == real.floor(n) and n > -1e15 and n < 1e15 then
                return real.fmt("%d", n)
        end
        local s = real.fmt("%.14g", n)
        if real.tonumber(s) ~= n then s = real.fmt("%.17g", n) end
        return s
end

local fmt
local genvTable
local genvName = real.setmetatable({}, { __mode = "k" })
local captureFunction
local fnText = real.setmetatable({}, { __mode = "k" })
local cfuncs = real.setmetatable({}, { __mode = "k" })
local cnames = real.setmetatable({}, { __mode = "k" })
local threadProxy = real.setmetatable({}, { __mode = "k" })

local makeTramp = real.loadstring("local impl = ... return function(...) return impl(...) end", "=" .. harnessSrc0)
local tramps = {}
local trampEnv = nil
local function tramp(impl)
        local t = makeTramp(impl)
        if trampEnv then real.setfenv(t, trampEnv) else real.insert(tramps, t) end
        return t
end

local function keySuffix(k)
        if isIdent(k) then
                return "." .. k
        end
        return "[" .. fmt(k) .. "]"
end

local scriptEnv

function fmt(v, depth, seen)
        local t = real.type(v)
        if t == "nil" then return "nil" end
        if t == "boolean" then return real.tostring(v) end
        if t == "number" then return fmtNumber(v) end
        if t == "string" then return quote(v) end
        if t == "userdata" then
                if infoOf[v] then return tok(v) end
                return "nil --[[userdata]]"
        end
        if t == "function" then
                if fnText[v] then return fnText[v] end
                if methodProxyRef and methodProxyRef[v] then return tok(methodProxyRef[v]) end
                return captureFunction(v)
        end
        if t == "table" then
                if v == scriptEnv then return "getfenv()" end
                if genvName[v] then return genvName[v] end
                depth = depth or 0
                seen = seen or {}
                if seen[v] then return "{ --[[cycle]] }" end
                if depth > 6 then return "{ --[[...]] }" end
                seen[v] = true
                local parts = {}
                local n = 0
                for i = 1, 1e9 do
                        local x = real.rawget(v, i)
                        if x == nil then break end
                        n = i
                        real.insert(parts, fmt(x, depth + 1, seen))
                end
                local keys = {}
                for k in real.next, v do
                        if not (real.type(k) == "number" and k >= 1 and k <= n and k % 1 == 0) then
                                real.insert(keys, k)
                        end
                end
                local function rank(k)
                        local x = real.rawget(v, k)
                        if real.type(x) == "function" then return 4 end
                        if k == "Title" or k == "Name" or k == "Text" then return 1 end
                        if k == "Desc" or k == "Description" or k == "Content" then return 2 end
                        return 3
                end
                real.sort(keys, function(a, b)
                        local ta, tb = real.type(a), real.type(b)
                        if ta ~= tb then return ta < tb end
                        if ta == "string" then
                                local ra, rb = rank(a), rank(b)
                                if ra ~= rb then return ra < rb end
                                return a < b
                        end
                        if ta == "number" then return a < b end
                        return false
                end)
                for _, k in keys do
                        local key = isIdent(k) and k or ("[" .. fmt(k, depth + 1, seen) .. "]")
                        local x = real.rawget(v, k)
                        if k == "Callback" and real.type(x) == "function" then cfg._cbtry = true end
                        real.insert(parts, key .. " = " .. fmt(x, depth + 1, seen))
                        cfg._cbtry = nil
                end
                seen[v] = nil
                if #parts == 0 then return "{}" end
                local flat = "{ " .. real.concat(parts, ", ") .. " }"
                if #flat <= 100 and not real.find(flat, "\3", 1, true) then return flat end
                local ind = real.rep("\t", depth + 1)
                return "{\n" .. ind .. real.concat(parts, ",\n" .. ind) .. "\n" .. real.rep("\t", depth) .. "}"
        end
        if t == "vector" then
                return "Vector3.new(" .. fmtNumber(v.x) .. ", " .. fmtNumber(v.y) .. ", " .. fmtNumber(v.z) .. ")"
        end
        if t == "buffer" then return "buffer.create(" .. buffer.len(v) .. ")" end
        if t == "thread" and threadProxy[v] then return tok(threadProxy[v]) end
        return "nil --[[" .. t .. "]]"
end

local function fmtArgs(...)
        local n = real.select("#", ...)
        local parts = {}
        for i = 1, n do
                parts[i] = fmt((real.select(i, ...)))
        end
        return real.concat(parts, ", ")
end

local function globalP(name, tname)
        return newP({ kind = "name", name = name, tname = tname or "Instance" })
end

local function exprP(text, tname, hint)
        return newP({ kind = "expr", text = text, tname = tname or "Instance", hint = hint })
end

local api = { enums = {}, classes = {} }
do
        local src = __roblox or { enums = "", classes = "" }
        for ename, items in string.gmatch(src.enums, "([%w_]+):([^;]*)") do
                local e = { name = ename, items = {}, byName = {}, byValue = {} }
                for iname, v in string.gmatch(items, "([%w_]+)=(%-?%d+)") do
                        local item = { Name = iname, Value = real.tonumber(v) }
                        real.insert(e.items, item)
                        e.byName[iname] = item
                        if e.byValue[item.Value] == nil then e.byValue[item.Value] = item end
                end
                api.enums[ename] = e
        end
        for cname, super, fns, evs, props in string.gmatch(src.classes, "([%w_]+)<([%w_]*)|([^|]*)|([^|]*)|([^;]*)") do
                local c = { super = super ~= "" and super or nil, m = {}, e = {}, p = {} }
                for x in string.gmatch(fns, "[^,]+") do c.m[x] = true end
                for x in string.gmatch(evs, "[^,]+") do c.e[x] = true end
                for x in string.gmatch(props, "[^,]+") do
                        local name, vt = real.match(x, "^([^:]+):?(.*)$")
                        c.p[name] = vt ~= "" and vt or true
                end
                api.classes[cname] = c
        end
end

local function memberKind(cls, k)
        local guard = 0
        while cls and guard < 32 do
                guard += 1
                local c = api.classes[cls]
                if not c then return nil end
                if c.m[k] then return "method" end
                if c.e[k] then return "event" end
                if c.p[k] then return "prop" end
                cls = c.super
        end
        return nil
end

local function propType(cls, k)
        local guard = 0
        while cls and guard < 32 do
                guard += 1
                local c = api.classes[cls]
                if not c then return nil end
                local v = c.p[k]
                if v then return v ~= true and v or nil end
                cls = c.super
        end
        return nil
end

local numericT = { float = true, double = true, int = true, int64 = true, int32 = true, int16 = true, number = true }
local numDefault = { Health = 100, MaxHealth = 100, WalkSpeed = 16, JumpPower = 50, JumpHeight = 7.2,
        HipHeight = 2, Gravity = 196.2, FieldOfView = 70, MaxSlopeAngle = 89, TimePosition = 0, Volume = 0.5,
        TimeLength = 1, Speed = 1, Brightness = 1, Range = 16, Size = 1 }
local dtMembers = {
        Vector3 = { X = "n", Y = "n", Z = "n", Magnitude = "n", Unit = "Vector3" },
        Vector2 = { X = "n", Y = "n", Magnitude = "n", Unit = "Vector2" },
        CFrame = { X = "n", Y = "n", Z = "n", Position = "Vector3", p = "Vector3", LookVector = "Vector3",
                RightVector = "Vector3", UpVector = "Vector3", XVector = "Vector3", YVector = "Vector3", ZVector = "Vector3",
                Rotation = "CFrame" },
        UDim2 = { X = "UDim", Y = "UDim", Width = "UDim", Height = "UDim" },
        UDim = { Scale = "n", Offset = "n" },
        Color3 = { R = "n", G = "n", B = "n" },
        NumberRange = { Min = "n", Max = "n" },
        Rect = { Width = "n", Height = "n", Min = "Vector2", Max = "Vector2" },
}

local propClass = {
        LocalPlayer = "Player", Character = "Model", CurrentCamera = "Camera", PlayerGui = "PlayerGui",
        Backpack = "Backpack", PrimaryPart = "Part", HumanoidRootPart = "Part", Head = "Part", Torso = "Part",
        UpperTorso = "MeshPart", LowerTorso = "MeshPart", PlayerScripts = "PlayerScripts", Terrain = "Terrain",
        leaderstats = "Folder", Animator = "Animator",
}

local function childClass(pi, key)
        if real.type(key) ~= "string" then return nil end
        if propClass[key] then return propClass[key] end
        if pi.className and memberKind(pi.className, key) == "prop" then return nil end
        if api.classes[key] and not api.enums[key] then return key end
        return nil
end

local function indexP(parent, key)
        local pi = infoOf[parent]
        local c = pi.children[key]
        if c then return c end
        c = newP({ kind = "index", parent = parent, key = key,
                tname = pi.childT or "Instance",
                hint = real.type(key) == "string" and key or nil, ns = pi.ns,
                className = pi.tname == "Instance" and childClass(pi, key) or nil })
        pi.children[key] = c
        return c
end

local enumRoot
local function enumType(name)
        local c = infoOf[enumRoot].children[name]
        if c then return c end
        c = indexP(enumRoot, name)
        infoOf[c].tname = "Enum"
        infoOf[c].enumName = name
        infoOf[c].className = nil
        return c
end
local function enumItem(ename, iname)
        local et = enumType(ename)
        local c = infoOf[et].children[iname]
        if c then return c end
        local item = api.enums[ename].byName[iname]
        c = indexP(et, iname)
        local info = infoOf[c]
        info.tname = "EnumItem"
        info.enumName = ename
        info.className = nil
        info.props.Name = iname
        info.props.Value = item.Value
        info.props.EnumType = et
        return c
end

local realValues = real.setmetatable({}, { __mode = "k" })
hub.dtUnsupported = __roblox and __roblox.datatypes and __roblox.datatypes.unsupported
local noReal = real.setmetatable({}, { __tostring = function() return "<envlog: no native twin>" end })

local function unwrap(v, depth)
        if isP(v) then
                local r = realValues[v]
                if r ~= nil then return r end
                if infoOf[v] and infoOf[v].tname == "EnumItem" then return v end
                real.error(noReal, 0)
        elseif real.type(v) == "table" and depth < 3 then
                local t = {}
                for k, x in real.pairs(v) do t[unwrap(k, depth + 1)] = unwrap(x, depth + 1) end
                return t
        elseif real.type(v) == "function" or real.type(v) == "thread" then
                real.error(noReal, 0)
        end
        return v
end
local function unwrapArgs(args)
        local ok, out = real.pcall(function()
                local o = { n = args.n }
                for i = 1, args.n do o[i] = unwrap(args[i], 0) end
                return o
        end)
        if ok then return out end
        if out ~= noReal then real.error(out, 0) end
        return nil
end
local function realOf(v)
        if isP(v) then return realValues[v], realValues[v] ~= nil end
        if real.type(v) == "table" or real.type(v) == "function" then return nil, false end
        return v, true
end

local plainT = { number = true, string = true, boolean = true, ["nil"] = true, vector = true }
local function nativeClass(inst)
        return inst:IsA("GuiBase") or inst:IsA("UIBase")
end
local function wrapReal(r, text, hint, depth)
        if isP(r) then return r, true end
        local t = real.type(r)
        if plainT[t] then return r, true end
        local tt = real.typeof(r)
        if tt == "userdata" and not native then tt = __roblox.datatypes.typeOf(r) or tt end
        if tt == "EnumItem" then
                local ename = real.tostring(r.EnumType)
                if api.enums[ename] and api.enums[ename].byName[r.Name] then return enumItem(ename, r.Name), true end
                return nil, false
        end
        if tt == "Instance" or tt == "RBXScriptSignal" or tt == "RBXScriptConnection" or t == "function" or t == "thread" then
                return nil, false
        end
        if t == "table" then
                if (depth or 0) > 2 then return nil, false end
                local out = {}
                for k, x in real.pairs(r) do
                        local w, ok = wrapReal(x, text .. "[" .. fmt(k) .. "]", hint, (depth or 0) + 1)
                        if not ok then return nil, false end
                        out[k] = w
                end
                return out, true
        end
        local p = exprP(text, tt, hint)
        realValues[p] = r
        return p, true
end
local function attachReal(p, libName, k, call, ...)
        local lib
        if native then
                lib = realGlobals[libName]
        else
                lib = __roblox and __roblox.datatypes and __roblox.datatypes[libName]
                if real.type(lib) ~= "table" then return end
        end
        if lib == nil then return end
        local u = unwrapArgs(table.pack(...))
        if not u then return end
        local ok, r = real.pcall(function()
                local f = lib[k]
                if call then return f(real.unpack(u, 1, u.n)) end
                return f
        end)
        if ok and r ~= nil and real.type(r) ~= "table" then realValues[p] = r end
end

local p2dLog = {}
local p2dMiss = false
local function p2dKey(name, args)
        local parts = { name }
        for i = 1, args.n do
                local a = args[i]
                parts[#parts + 1] = real.type(a) == "number" and real.fmt("%.17g", a) or real.tostring(real.typeof(a))
        end
        return real.concat(parts, "|")
end
__p2d_data = "GetLength|\tn:192.38052368164062\nGetBoundingRect|\tr:0,3.949615478515625,109.5,76.5\nGetPositionOnCurve|0.32727050995916795\tu:0.44611179828643799,0,0.25362586975097656,0\nGetPositionOnCurveArcLength|0.1794026245540169\tu:0.45542722940444946,0,0.26568529009819031,0\nGetTangentOnCurve|0.99087240828359835\tv:327.7689208984375,459.25076293945312\nGetTangentOnCurveArcLength|0.74903444093601801\tv:290.40972900390625,399.41049194335938\nGetPositionOnCurve|0\tu:0.49543377757072449,0,0.54316544532775879,0\nGetPositionOnCurveArcLength|0\tu:0.49543377757072449,0,0.54316544532775879,0\nGetTangentOnCurve|0\tv:-73.125,-43.125\nGetTangentOnCurveArcLength|0\tv:-73.125,-43.125\nGetPositionOnCurve|1\tu:0.0045662098564207554,0,0.31025180220603943,0\nGetPositionOnCurveArcLength|1\tu:0.004575999453663826,0,0.3102475106716156,0\nGetTangentOnCurve|1\tv:-185.625,51.5\nGetTangentOnCurveArcLength|1\tv:-185.62283325195312,51.499691009521484\nGetPositionOnCurve|0.5\tu:0.42380136251449585,0,0.035971224308013916,0\nGetPositionOnCurveArcLength|0.5\tu:0.41360744833946228,0,0.068031363189220428,0\nGetTangentOnCurve|0.5\tv:2,24.75\nGetTangentOnCurveArcLength|0.5\tv:-29.012641906738281,29.17152214050293\nGetPositionOnCurve|0.3333333432674408\tu:0.35193639993667603,0,0.13808952271938324,0\nGetPositionOnCurveArcLength|0.3333333432674408\tu:0.35194626450538635,0,0.15681014955043793,0\nGetTangentOnCurve|0.3333333432674408\tv:3.4583358764648438,-79.625\nGetTangentOnCurveArcLength|0.3333333432674408\tv:-3.5385284423828125,-84.169059753417969\nGetPositionOnCurve|0.66666668653488159\tu:0.37924909591674805,0,0.10601519793272018,0\nGetPositionOnCurveArcLength|0.66666668653488159\tu:0.28388795256614685,0,0.17227084934711456,0\nGetTangentOnCurve|0.66666668653488159\tv:-60.541675567626953,33.666667938232422\nGetTangentOnCurveArcLength|0.66666668653488159\tv:-107.24761199951172,40.325607299804688\nGetPositionOnCurve|0.25\tu:0.36244291067123413,0,0.24539119005203247,0\nGetPositionOnCurveArcLength|0.25\tu:0.36745178699493408,0,0.26909562945365906,0\nGetTangentOnCurve|0.25\tv:-29.53125,-96.46875\nGetTangentOnCurveArcLength|0.25\tv:-35.112537384033203,-97.776092529296875\nGetPositionOnCurve|0.75\tu:0.32127568125724792,0,0.14905574917793274,0\nGetPositionOnCurveArcLength|0.75\tu:0.21485593914985657,0,0.21062980592250824,0\nGetTangentOnCurve|0.75\tv:-91.8125,38.125\nGetTangentOnCurveArcLength|0.75\tv:-131.05374145507812,43.719688415527344\nGetPositionOnCurve|0.20000000298023224\tu:0.37956163287162781,0,0.31581291556358337,0\nGetPositionOnCurveArcLength|0.20000000298023224\tu:0.38465449213981628,0,0.33272948861122131,0\nGetTangentOnCurve|0.20000000298023224\tv:-44.894996643066406,-98.264999389648438\nGetTangentOnCurveArcLength|0.20000000298023224\tv:-48.085639953613281,-97.769195556640625\nGetPositionOnCurve|0.40000000596046448\tu:0.36379906535148621,0,0.073266170918941498,0\nGetPositionOnCurveArcLength|0.40000000596046448\tu:0.36574310064315796,0,0.069048158824443817,0\nGetTangentOnCurve|0.40000000596046448\tv:36.495010375976562,-53.68499755859375\nGetTangentOnCurveArcLength|0.40000000596046448\tv:39.538925170898438,-51.001655578613281\nGetPositionOnCurve|0.60000002384185791\tu:0.40849316120147705,0,0.075431667268276215,0\nGetPositionOnCurveArcLength|0.60000002384185791\tu:0.33817091584205627,0,0.13767582178115845,0\nGetTangentOnCurve|0.60000002384185791\tv:-35.525009155273438,30.100002288818359\nGetTangentOnCurveArcLength|0.60000002384185791\tv:-83.91119384765625,36.998497009277344\nGetPositionOnCurve|0.80000001192092896\tu:0.2750684916973114,0,0.17744605243206024,0\nGetPositionOnCurveArcLength|0.80000001192092896\tu:0.17308399081230164,0,0.23201291263103485,0\nGetTangentOnCurve|0.80000001192092896\tv:-110.57500457763672,40.800003051757812\nGetTangentOnCurveArcLength|0.80000001192092896\tv:-143.55448913574219,45.501937866210938\nGetPositionOnCurve|0.1666666716337204\tu:0.39454379677772522,0,0.36250996589660645,0\nGetPositionOnCurveArcLength|0.1666666716337204\tu:0.39846432209014893,0,0.37340077757835388,0\nGetTangentOnCurve|0.1666666716337204\tv:-53.291664123535156,-96\nGetTangentOnCurveArcLength|0.1666666716337204\tv:-55.070137023925781,-95.05426025390625\nGetPositionOnCurve|0.83333331346511841\tu:0.23950408399105072,0,0.19744202494621277,0\nGetPositionOnCurveArcLength|0.83333331346511841\tu:0.14513473212718964,0,0.24576771259307861,0\nGetTangentOnCurve|0.83333331346511841\tv:-123.08332824707031,42.583332061767578\nGetTangentOnCurveArcLength|0.83333331346511841\tv:-151.34317016601562,46.612380981445312\nGetPositionOnCurve|0.1428571492433548\tu:0.40669888257980347,0,0.39487066864967346,0\nGetPositionOnCurveArcLength|0.1428571492433548\tu:0.40938481688499451,0,0.40150171518325806,0\nGetTangentOnCurve|0.1428571492433548\tv:-58.385200500488281,-92.686225891113281\nGetTangentOnCurveArcLength|0.1428571492433548\tv:-59.358264923095703,-91.811599731445312\nGetPositionOnCurve|0.28571429848670959\tu:0.35488638281822205,0,0.19699223339557648,0\nGetPositionOnCurveArcLength|0.28571429848670959\tu:0.35828816890716553,0,0.22184313833713531,0\nGetTangentOnCurve|0.28571429848670959\tv:-16.52294921875,-91.369888305664062\nGetTangentOnCurveArcLength|0.28571429848670959\tv:-23.501251220703125,-94.419097900390625\nGetPositionOnCurve|0.4285714328289032\tu:0.37538105249404907,0,0.054108928889036179,0\nGetPositionOnCurveArcLength|0.4285714328289032\tu:0.3853175938129425,0,0.044944927096366882,0\nGetTangentOnCurve|0.4285714328289032\tv:52.46173095703125,-39.176017761230469\nGetTangentOnCurveArcLength|0.4285714328289032\tv:63.542373657226562,-28.535900115966797\nGetPositionOnCurve|0.57142859697341919\tu:0.41636377573013306,0,0.063371762633323669,0\nGetPositionOnCurveArcLength|0.57142859697341919\tu:0.36093717813491821,0,0.12103556841611862,0\nGetTangentOnCurve|0.57142859697341919\tv:-24.803581237792969,28.571430206298828\nGetTangentOnCurveArcLength|0.57142859697341919\tv:-71.903846740722656,35.286590576171875\nGetPositionOnCurve|0.71428573131561279\tu:0.34903550148010254,0,0.1299552321434021,0\nGetPositionOnCurveArcLength|0.71428573131561279\tu:0.24455054104328156,0,0.19468003511428833,0\nGetTangentOnCurve|0.71428573131561279\tv:-78.410720825195312,36.214286804199219\nGetTangentOnCurveArcLength|0.71428573131561279\tv:-121.38694000244141,42.341476440429688\nGetPositionOnCurve|0.8571428656578064\tu:0.21176964044570923,0,0.21224859356880188,0\nGetPositionOnCurveArcLength|0.8571428656578064\tu:0.12513032555580139,0,0.25538459420204163,0\nGetTangentOnCurve|0.8571428656578064\tv:-132.01785278320312,43.857143402099609\nGetTangentOnCurveArcLength|0.8571428656578064\tv:-156.68028259277344,47.373306274414062\nGetPositionOnCurve|0.125\tu:0.41649723052978516,0,0.41826382279396057,0\nGetPositionOnCurveArcLength|0.125\tu:0.4181482195854187,0,0.42199835181236267,0\nGetTangentOnCurve|0.125\tv:-61.7109375,-89.2734375\nGetTangentOnCurveArcLength|0.125\tv:-62.214046478271484,-88.640274047851562\nGetPositionOnCurve|0.375\tu:0.35697594285011292,0,0.094607129693031311,0\nGetPositionOnCurveArcLength|0.375\tu:0.35588163137435913,0,0.099754579365253448,0\nGetTangentOnCurve|0.375\tv:23.4140625,-64.7109375\nGetTangentOnCurveArcLength|0.375\tv:20.679756164550781,-66.902137756347656\nGetPositionOnCurve|0.625\tu:0.39931151270866394,0,0.086499549448490143,0\nGetPositionOnCurveArcLength|0.625\tu:0.31796097755432129,0,0.15121306478977203,0\nGetTangentOnCurve|0.625\tv:-44.90625,31.4375\nGetTangentOnCurveArcLength|0.625\tv:-93.2841796875,38.334819793701172\nGetPositionOnCurve|0.875\tu:0.18969392776489258,0,0.2236398309469223,0\nGetPositionOnCurveArcLength|0.875\tu:0.11010735481977463,0,0.26249474287033081,0\nGetTangentOnCurve|0.875\tv:-138.71875,44.8125\nGetTangentOnCurveArcLength|0.875\tv:-160.57177734375,47.928123474121094\nGetPositionOnCurve|0.1111111119389534\tu:0.42447274923324585,0,0.43579211831092834,0\nGetPositionOnCurveArcLength|0.1111111119389534\tu:0.4253101646900177,0,0.43755963444709778,0\nGetTangentOnCurve|0.1111111119389534\tv:-64.004631042480469,-86.069442749023438\nGetTangentOnCurveArcLength|0.1111111119389534\tv:-64.226264953613281,-85.712203979492188\nGetPositionOnCurve|0.2222222238779068\tu:0.37109068036079407,0,0.28436508774757385,0\nGetPositionOnCurveArcLength|0.2222222238779068\tu:0.3764534592628479,0,0.30482208728790283,0\nGetTangentOnCurve|0.2222222238779068\tv:-38.476848602294922,-98.236114501953125\nGetTangentOnCurveArcLength|0.2222222238779068\tv:-42.726249694824219,-98.394851684570312\nGetPositionOnCurve|0.4444444477558136\tu:0.38365873694419861,0,0.046170461922883987,0\nGetPositionOnCurveArcLength|0.4444444477558136\tu:0.39857909083366394,0,0.038301263004541397,0\nGetTangentOnCurve|0.4444444477558136\tv:61.800933837890625,-30.236110687255859\nGetTangentOnCurveArcLength|0.4444444477558136\tv:76.351516723632812,-15.736154556274414\nGetPositionOnCurve|0.55555558204650879\tu:0.41952759027481079,0,0.056943345814943314,0\nGetPositionOnCurveArcLength|0.55555558204650879\tu:0.37335878610610962,0,0.11105699837207794,0\nGetTangentOnCurve|0.55555558204650879\tv:-18.847232818603516,27.722223281860352\nGetTangentOnCurveArcLength|0.55555558204650879\tv:-64.41552734375,34.218971252441406\nGetPositionOnCurve|0.77777779102325439\tu:0.29666268825531006,0,0.16459056735038757,0\nGetPositionOnCurveArcLength|0.77777779102325439\tu:0.19167429208755493,0,0.22263069450855255,0\nGetTangentOnCurve|0.77777779102325439\tv:-102.23611450195312,39.611110687255859\nGetTangentOnCurveArcLength|0.77777779102325439\tv:-138.13090515136719,44.728691101074219\nGetPositionOnCurve|0.8888888955116272\tu:0.17176841199398041,0,0.2326694130897522,0\nGetPositionOnCurveArcLength|0.8888888955116272\tu:0.098412260413169861,0,0.26796838641166687,0\nGetTangentOnCurve|0.8888888955116272\tv:-143.93055725097656,45.555557250976562\nGetTangentOnCurveArcLength|0.8888888955116272\tv:-163.53713989257812,48.350898742675781\nGetPositionOnCurve|0.10000000149011612\tu:0.43105250597000122,0,0.44932374358177185,0\nGetPositionOnCurveArcLength|0.10000000149011612\tu:0.43126386404037476,0,0.44974508881568909,0\nGetTangentOnCurve|0.10000000149011612\tv:-65.654998779296875,-83.160003662109375\nGetTangentOnCurveArcLength|0.10000000149011612\tv:-65.70465087890625,-83.062698364257812\nGetPositionOnCurve|0.30000001192092896\tu:0.35309815406799316,0,0.17850357294082642,0\nGetPositionOnCurveArcLength|0.30000001192092896\tu:0.35555267333984375,0,0.20254871249198914,0\nGetTangentOnCurve|0.30000001192092896\tv:-10.844997406005859,-88.44000244140625\nGetTangentOnCurveArcLength|0.30000001192092896\tv:-18.144001007080078,-92.136039733886719\nGetPositionOnCurve|0.69999998807907104\tu:0.3589155375957489,0,0.12258992344141006,0\nGetPositionOnCurveArcLength|0.69999998807907104\tu:0.25638660788536072,0,0.1881096214056015,0\nGetTangentOnCurve|0.69999998807907104\tv:-73.049995422363281,35.450000762939453\nGetTangentOnCurveArcLength|0.69999998807907104\tv:-117.31199645996094,41.760505676269531\nGetPositionOnCurve|0.89999997615814209\tu:0.15695209801197052,0,0.24000000953674316,0\nGetPositionOnCurveArcLength|0.89999997615814209\tu:0.089049942791461945,0,0.27231350541114807,0\nGetTangentOnCurve|0.89999997615814209\tv:-148.09999084472656,46.150001525878906\nGetTangentOnCurveArcLength|0.89999997615814209\tv:-165.872802734375,48.68389892578125\nGetPositionOnCurve|0.090909093618392944\tu:0.43655505776405334,0,0.46003302931785583,0\nGetPositionOnCurveArcLength|0.090909093618392944\tu:0.43628776073455811,0,0.45952519774436951,0\nGetTangentOnCurve|0.090909093618392944\tv:-66.883262634277344,-80.550621032714844\nGetTangentOnCurveArcLength|0.090909093618392944\tv:-66.826629638671875,-80.681015014648438\nGetPositionOnCurve|0.18181818723678589\tu:0.38741770386695862,0,0.3414212167263031,0\nGetPositionOnCurveArcLength|0.18181818723678589\tu:0.39197000861167908,0,0.35509726405143738,0\nGetTangentOnCurve|0.18181818723678589\tv:-49.658058166503906,-97.372940063476562\nGetTangentOnCurveArcLength|0.18181818723678589\tv:-52.043281555175781,-96.55023193359375\nGetPositionOnCurve|0.27272728085517883\tu:0.35714039206504822,0,0.21428011357784271,0\nGetPositionOnCurveArcLength|0.27272728085517883\tu:0.36126708984375,0,0.23919285833835602,0\nGetTangentOnCurve|0.27272728085517883\tv:-21.449375152587891,-93.591934204101562\nGetTangentOnCurveArcLength|0.27272728085517883\tv:-27.993812561035156,-96.003997802734375\nGetPositionOnCurve|0.36363637447357178\tu:0.35484185814857483,0,0.10555969923734665,0\nGetPositionOnCurveArcLength|0.36363637447357178\tu:0.35353010892868042,0,0.11502991616725922,0\nGetTangentOnCurve|0.36363637447357178\tv:17.742774963378906,-69.2076416015625\nGetTangentOnCurveArcLength|0.36363637447357178\tv:13.239753723144531,-72.640228271484375\nGetPositionOnCurve|0.45454546809196472\tu:0.38964077830314636,0,0.04221014678478241,0\nGetPositionOnCurveArcLength|0.45454546809196472\tu:0.40735262632369995,0,0.036261413246393204,0\nGetTangentOnCurve|0.45454546809196472\tv:67.91839599609375,-24.220026016235352\nGetTangentOnCurveArcLength|0.45454546809196472\tv:84.00189208984375,-7.8627128601074219\nGetPositionOnCurve|0.54545456171035767\tu:0.42109137773513794,0,0.052953511476516724,0\nGetPositionOnCurveArcLength|0.54545456171035767\tu:0.38114169239997864,0,0.10434364527463913,0\nGetTangentOnCurve|0.54545456171035767\tv:-15.05682373046875,27.181819915771484\nGetTangentOnCurveArcLength|0.54545456171035767\tv:-59.243240356445312,33.481548309326172\nGetPositionOnCurve|0.63636362552642822\tu:0.39442998170852661,0,0.091689459979534149,0\nGetPositionOnCurveArcLength|0.63636362552642822\tu:0.30870971083641052,0,0.15712098777294159,0\nGetTangentOnCurve|0.63636362552642822\tv:-49.170452117919922,32.045455932617188\nGetTangentOnCurveArcLength|0.63636362552642822\tv:-97.273849487304688,38.903633117675781\nGetPositionOnCurve|0.72727274894714355\tu:0.33944675326347351,0,0.13678728044033051,0\nGetPositionOnCurveArcLength|0.72727274894714355\tu:0.23376865684986115,0,0.20055429637432098,0\nGetTangentOnCurve|0.72727274894714355\tv:-83.284095764160156,36.909091949462891\nGetTangentOnCurveArcLength|0.72727274894714355\tv:-124.98336029052734,42.854225158691406\nGetPositionOnCurve|0.81818181276321411\tu:0.25614175200462341,0,0.18824692070484161,0\nGetPositionOnCurveArcLength|0.81818181276321411\tu:0.15784773230552673,0,0.23956005275249481,0\nGetTangentOnCurve|0.81818181276321411\tv:-117.39772796630859,41.772727966308594\nGetTangentOnCurveArcLength|0.81818181276321411\tv:-147.85128784179688,46.114540100097656\nGetPositionOnCurve|0.90909093618392944\tu:0.14451485872268677,0,0.24606844782829285,0\nGetPositionOnCurveArcLength|0.90909093618392944\tu:0.081385746598243713,0,0.27584731578826904,0\nGetTangentOnCurve|0.90909093618392944\tv:-151.51136779785156,46.636367797851562\nGetTangentOnCurveArcLength|0.90909093618392944\tv:-167.76063537597656,48.953048706054688\nGetPositionOnCurve|0.083333335816860199\tu:0.44121533632278442,0,0.46868753433227539,0\nGetPositionOnCurveArcLength|0.083333335816860199\tu:0.44058254361152649,0,0.46753433346748352,0\nGetTangentOnCurve|0.083333335816860199\tv:-67.822914123535156,-78.21875\nGetTangentOnCurveArcLength|0.083333335816860199\tv:-67.700538635253906,-78.541847229003906\nGetPositionOnCurve|0.4166666567325592\tu:0.37004798650741577,0,0.061363440006971359,0\nGetPositionOnCurveArcLength|0.4166666567325592\tu:0.37625253200531006,0,0.053106348961591721,0\nGetTangentOnCurve|0.4166666567325592\tv:45.677078247070312,-45.46875\nGetTangentOnCurveArcLength|0.4166666567325592\tv:53.504631042480469,-38.193183898925781\nGetPositionOnCurve|0.58333331346511841\tu:0.41342434287071228,0,0.068320333957672119,0\nGetPositionOnCurveArcLength|0.58333331346511841\tu:0.35150426626205444,0,0.12814836204051971,0\nGetTangentOnCurve|0.58333331346511841\tv:-29.27082633972168,29.208332061767578\nGetTangentOnCurveArcLength|0.58333331346511841\tv:-77.106147766113281,36.028289794921875\nGetPositionOnCurve|0.91666668653488159\tu:0.13393421471118927,0,0.25117409229278564,0\nGetPositionOnCurveArcLength|0.91666668653488159\tu:0.074996493756771088,0,0.27877780795097351,0\nGetTangentOnCurve|0.91666668653488159\tv:-154.35417175292969,47.041667938232422\nGetTangentOnCurveArcLength|0.91666668653488159\tv:-169.31832885742188,49.175132751464844\nGetPositionOnCurve|0.076923079788684845\tu:0.44520756602287292,0,0.4758065938949585,0\nGetPositionOnCurveArcLength|0.076923079788684845\tu:0.44429567456245422,0,0.47420418262481689,0\nGetTangentOnCurve|0.076923079788684845\tv:-68.558433532714844,-76.133880615234375\nGetTangentOnCurveArcLength|0.076923079788684845\tv:-68.395919799804688,-76.617134094238281\nGetPositionOnCurve|0.15384615957736969\tu:0.40095147490501404,0,0.38007685542106628,0\nGetPositionOnCurveArcLength|0.15384615957736969\tu:0.40423646569252014,0,0.38863649964332581,0\nGetTangentOnCurve|0.15384615957736969\tv:-56.127956390380859,-94.391273498535156\nGetTangentOnCurveArcLength|0.15384615957736969\tv:-57.448539733886719,-93.445304870605469\nGetPositionOnCurve|0.23076923191547394\tu:0.36818990111351013,0,0.27230313420295715,0\nGetPositionOnCurveArcLength|0.23076923191547394\tu:0.37352868914604187,0,0.29392746090888977,0\nGetTangentOnCurve|0.23076923191547394\tv:-35.833576202392578,-97.897186279296875\nGetTangentOnCurveArcLength|0.23076923191547394\tv:-40.498630523681641,-98.375190734863281\nGetPositionOnCurve|0.30769231915473938\tu:0.35244718194007874,0,0.1688125878572464,0\nGetPositionOnCurveArcLength|0.30769231915473938\tu:0.35434475541114807,0,0.19207417964935303,0\nGetTangentOnCurve|0.30769231915473938\tv:-7.67529296875,-86.651626586914062\nGetTangentOnCurveArcLength|0.30769231915473938\tv:-15.056552886962891,-90.648948669433594\nGetPositionOnCurve|0.38461539149284363\tu:0.35924765467643738,0,0.085932254791259766,0\nGetPositionOnCurveArcLength|0.38461539149284363\tu:0.3588489294052124,0,0.087303631007671356,0\nGetTangentOnCurve|0.38461539149284363\tv:28.346885681152344,-60.654590606689453\nGetTangentOnCurveArcLength|0.38461539149284363\tv:27.536849975585938,-61.329505920410156\nGetPositionOnCurve|0.46153846383094788\tu:0.39411568641662598,0,0.039989113807678223,0\nGetPositionOnCurveArcLength|0.46153846383094788\tu:0.41348335146903992,0,0.035677410662174225,0\nGetTangentOnCurve|0.46153846383094788\tv:72.233001708984375,-19.906070709228516\nGetTangentOnCurveArcLength|0.46153846383094788\tv:89.05645751953125,-2.574554443359375\nGetPositionOnCurve|0.53846156597137451\tu:0.42196914553642273,0,0.05023733526468277,0\nGetPositionOnCurveArcLength|0.53846156597137451\tu:0.38645732402801514,0,0.099492914974689484,0\nGetTangentOnCurve|0.53846156597137451\tv:-12.432703018188477,26.807693481445312\nGetTangentOnCurveArcLength|0.53846156597137451\tv:-55.433948516845703,32.938449859619141\nGetPositionOnCurve|0.61538463830947876\tu:0.40309637784957886,0,0.082185737788677216,0\nGetPositionOnCurveArcLength|0.61538463830947876\tu:0.32575947046279907,0,0.14610075950622559,0\nGetTangentOnCurve|0.61538463830947876\tv:-41.298084259033203,30.923078536987305\nGetTangentOnCurveArcLength|0.61538463830947876\tv:-89.783409118652344,37.835708618164062\nGetPositionOnCurve|0.69230771064758301\tu:0.36394584178924561,0,0.11868909001350403,0\nGetPositionOnCurveArcLength|0.69230771064758301\tu:0.2627483606338501,0,0.18452085554599762,0\nGetTangentOnCurve|0.69230771064758301\tv:-70.163467407226562,35.038463592529297\nGetTangentOnCurveArcLength|0.69230771064758301\tv:-115.0621337890625,41.439735412597656\nGetPositionOnCurve|0.76923078298568726\tu:0.30451756715774536,0,0.15974736213684082,0\nGetPositionOnCurveArcLength|0.76923078298568726\tu:0.19881419837474823,0,0.21897211670875549,0\nGetTangentOnCurve|0.76923078298568726\tv:-99.028854370117188,39.153846740722656\nGetTangentOnCurveArcLength|0.76923078298568726\tv:-135.99040222167969,44.423515319824219\nGetPositionOnCurve|0.8461538553237915\tu:0.22481152415275574,0,0.20536057651042938,0\nGetPositionOnCurveArcLength|0.8461538553237915\tu:0.13436692953109741,0,0.25096625089645386,0\nGetTangentOnCurve|0.8461538553237915\tv:-127.89424133300781,43.269233703613281\nGetTangentOnCurveArcLength|0.8461538553237915\tv:-154.23893737792969,47.025238037109375\nGetPositionOnCurve|0.92307692766189575\tu:0.12482776492834091,0,0.25552871823310852,0\nGetPositionOnCurveArcLength|0.92307692766189575\tu:0.069588333368301392,0,0.28124764561653137,0\nGetTangentOnCurve|0.92307692766189575\tv:-156.75961303710938,47.384613037109375\nGetTangentOnCurveArcLength|0.92307692766189575\tv:-170.625732421875,49.361530303955078\nGetPositionOnCurve|0.071428574621677399\tu:0.44866257905960083,0,0.4817521870136261,0\nGetPositionOnCurveArcLength|0.071428574621677399\tu:0.44753754138946533,0,0.47983792424201965,0\nGetTangentOnCurve|0.071428574621677399\tv:-69.145408630371094,-74.265304565429688\nGetTangentOnCurveArcLength|0.071428574621677399\tv:-68.959220886230469,-74.880279541015625\nGetPositionOnCurve|0.2142857164144516\tu:0.37396577000617981,0,0.29559326171875,0\nGetPositionOnCurveArcLength|0.2142857164144516\tu:0.37928566336631775,0,0.31485918164253235,0\nGetTangentOnCurve|0.2142857164144516\tv:-40.844387054443359,-98.38775634765625\nGetTangentOnCurveArcLength|0.2142857164144516\tv:-44.709842681884766,-98.282241821289062\nGetPositionOnCurve|0.3571428656578064\tu:0.3538837730884552,0,0.11214002221822739,0\nGetPositionOnCurveArcLength|0.3571428656578064\tu:0.35267344117164612,0,0.12391398847103119,0\nGetTangentOnCurve|0.3571428656578064\tv:14.579086303710938,-71.632659912109375\nGetTangentOnCurveArcLength|0.3571428656578064\tv:9.2932281494140625,-75.540031433105469\nGetPositionOnCurve|0.6428571343421936\tu:0.39144188165664673,0,0.094699740409851074,0\nGetPositionOnCurveArcLength|0.6428571343421936\tu:0.30340805649757385,0,0.16043747961521149,0\nGetTangentOnCurve|0.6428571343421936\tv:-51.607139587402344,32.392856597900391\nGetTangentOnCurveArcLength|0.6428571343421936\tv:-99.488151550292969,39.219329833984375\nGetPositionOnCurve|0.78571426868438721\tu:0.28914478421211243,0,0.16913814842700958,0\nGetPositionOnCurveArcLength|0.78571426868438721\tu:0.18503913283348083,0,0.22600246965885162,0\nGetTangentOnCurve|0.78571426868438721\tv:-105.21427917480469,40.035713195800781\nGetTangentOnCurveArcLength|0.78571426868438721\tv:-140.09075927734375,45.008110046386719\nGetPositionOnCurve|0.92857140302658081\tu:0.11691015958786011,0,0.25928646326065063,0\nGetPositionOnCurveArcLength|0.92857140302658081\tu:0.064951471984386444,0,0.28335762023925781,0\nGetTangentOnCurve|0.92857140302658081\tv:-158.82142639160156,47.678569793701172\nGetTangentOnCurveArcLength|0.92857140302658081\tv:-171.73873901367188,49.520210266113281\nGetPositionOnCurve|0.066666670143604279\tu:0.45168000459671021,0,0.48678335547447205,0\nGetPositionOnCurveArcLength|0.066666670143604279\tu:0.45039248466491699,0,0.48465487360954285,0\nGetTangentOnCurve|0.066666670143604279\tv:-69.621665954589844,-72.584999084472656\nGetTangentOnCurveArcLength|0.066666670143604279\tv:-69.422531127929688,-73.307487487792969\nGetPositionOnCurve|0.13333334028720856\tu:0.4118572473526001,0,0.40745642781257629,0\nGetPositionOnCurveArcLength|0.13333334028720856\tu:0.41399705410003662,0,0.41249868273735046,0\nGetTangentOnCurve|0.13333334028720856\tv:-60.211666107177734,-90.964996337890625\nGetTangentOnCurveArcLength|0.13333334028720856\tv:-60.919139862060547,-90.201263427734375\nGetPositionOnCurve|0.26666668057441711\tu:0.35838931798934937,0,0.22248119115829468,0\nGetPositionOnCurveArcLength|0.26666668057441711\tu:0.36280164122581482,0,0.24722473323345184,0\nGetTangentOnCurve|0.26666668057441711\tv:-23.671661376953125,-94.485000610351562\nGetTangentOnCurveArcLength|0.26666668057441711\tv:-29.979579925537109,-96.596275329589844\nGetPositionOnCurve|0.46666666865348816\tu:0.39757350087165833,0,0.038639482110738754,0\nGetPositionOnCurveArcLength|0.46666666865348816\tu:0.41798785328865051,0,0.035623837262392044,0\nGetTangentOnCurve|0.46666666865348816\tv:75.438339233398438,-16.664993286132812\nGetTangentOnCurveArcLength|0.46666666865348816\tv:92.641098022460938,1.2152061462402344\nGetPositionOnCurve|0.53333336114883423\tu:0.42250633239746094,0,0.048269394785165787,0\nGetPositionOnCurveArcLength|0.53333336114883423\tu:0.39030915498733521,0,0.095812469720840454,0\nGetTangentOnCurve|0.53333336114883423\tv:-10.508343696594238,26.533334732055664\nGetTangentOnCurveArcLength|0.53333336114883423\tv:-52.501247406005859,32.520332336425781\nGetPositionOnCurve|0.73333334922790527\tu:0.3347741961479187,0,0.14001999795436859,0\nGetPositionOnCurveArcLength|0.73333334922790527\tu:0.22873054444789886,0,0.20326557755470276,0\nGetTangentOnCurve|0.73333334922790527\tv:-85.558341979980469,37.233333587646484\nGetTangentOnCurveArcLength|0.73333334922790527\tv:-126.62887573242188,43.088829040527344\nGetPositionOnCurve|0.86666667461395264\tu:0.20013189315795898,0,0.21829336881637573,0\nGetPositionOnCurveArcLength|0.86666667461395264\tu:0.11712012439966202,0,0.25918710231781006,0\nGetTangentOnCurve|0.86666667461395264\tv:-135.5916748046875,44.366668701171875\nGetTangentOnCurveArcLength|0.86666667461395264\tv:-158.76708984375,47.670822143554688\nGetPositionOnCurve|0.93333333730697632\tu:0.10996448248624802,0,0.26256194710731506,0\nGetPositionOnCurveArcLength|0.93333333730697632\tu:0.060931932181119919,0,0.28518113493919373,0\nGetTangentOnCurve|0.93333333730697632\tv:-160.60833740234375,47.933334350585938\nGetTangentOnCurveArcLength|0.93333333730697632\tv:-172.69776916503906,49.656944274902344\nGetPositionOnCurve|0.0625\tu:0.45433679223060608,0,0.49108973145484924,0\nGetPositionOnCurveArcLength|0.0625\tu:0.45292586088180542,0,0.48881712555885315,0\nGetTangentOnCurve|0.0625\tv:-70.013671875,-71.068359375\nGetTangentOnCurveArcLength|0.0625\tv:-69.808639526367188,-71.878128051757812\nGetPositionOnCurve|0.1875\tu:0.38487821817398071,0,0.33344516158103943,0\nGetPositionOnCurveArcLength|0.1875\tu:0.38962718844413757,0,0.34815362095832825,0\nGetTangentOnCurve|0.1875\tv:-48.216796875,-97.740234375\nGetTangentOnCurveArcLength|0.1875\tv:-50.845672607421875,-96.998733520507812\nGetPositionOnCurve|0.3125\tu:0.35215446352958679,0,0.16285936534404755,0\nGetPositionOnCurveArcLength|0.3125\tu:0.35369414091110229,0,0.18549983203411102,0\nGetTangentOnCurve|0.3125\tv:-5.654296875,-85.458984375\nGetTangentOnCurveArcLength|0.3125\tv:-13.047595977783203,-89.6201171875\nGetPositionOnCurve|0.4375\tu:0.37987056374549866,0,0.049391932785511017,0\nGetPositionOnCurveArcLength|0.4375\tu:0.39266529679298401,0,0.040647000074386597,0\nGetTangentOnCurve|0.4375\tv:57.673828125,-34.224609375\nGetTangentOnCurveArcLength|0.4375\tv:70.856307983398438,-21.288724899291992\nGetPositionOnCurve|0.5625\tu:0.41824966669082642,0,0.059731900691986084,0\nGetPositionOnCurveArcLength|0.5625\tu:0.36794945597648621,0,0.11550011485815048,0\nGetTangentOnCurve|0.5625\tv:-21.453125,28.09375\nGetTangentOnCurveArcLength|0.5625\tv:-67.778282165527344,34.698402404785156\nGetPositionOnCurve|0.6875\tu:0.36698684096336365,0,0.11627417057752609,0\nGetPositionOnCurveArcLength|0.6875\tu:0.26672008633613586,0,0.18225868046283722,0\nGetTangentOnCurve|0.6875\tv:-68.359375,34.78125\nGetTangentOnCurveArcLength|0.6875\tv:-113.63494110107422,41.236259460449219\nGetPositionOnCurve|0.8125\tu:0.26217803359031677,0,0.18484431505203247,0\nGetPositionOnCurveArcLength|0.8125\tu:0.16261133551597595,0,0.23721346259117126,0\nGetTangentOnCurve|0.8125\tv:-115.265625,41.46875\nGetTangentOnCurveArcLength|0.8125\tv:-146.52143859863281,45.924942016601562\nGetPositionOnCurve|0.9375\tu:0.10382331162691116,0,0.26544234156608582,0\nGetPositionOnCurveArcLength|0.9375\tu:0.057414121925830841,0,0.28677284717559814,0\nGetTangentOnCurve|0.9375\tv:-162.171875,48.15625\nGetTangentOnCurveArcLength|0.9375\tv:-173.53274536132812,49.775985717773438\nGetPositionOnCurve|0.058823529630899429\tu:0.45669305324554443,0,0.49481299519538879,0\nGetPositionOnCurveArcLength|0.058823529630899429\tu:0.45518910884857178,0,0.49244695901870728,0\nGetTangentOnCurve|0.058823529630899429\tv:-70.340400695800781,-69.694198608398438\nGetTangentOnCurveArcLength|0.058823529630899429\tv:-70.134109497070312,-70.574432373046875\nGetPositionOnCurve|0.11764705926179886\tu:0.420683354139328,0,0.42762339115142822,0\nGetPositionOnCurveArcLength|0.11764705926179886\tu:0.42190161347389221,0,0.43028038740158081,0\nGetTangentOnCurve|0.11764705926179886\tv:-62.957180023193359,-87.637115478515625\nGetTangentOnCurveArcLength|0.11764705926179886\tv:-63.302032470703125,-87.141929626464844\nGetPositionOnCurve|0.17647059261798859\tu:0.38987517356872559,0,0.34889781475067139,0\nGetPositionOnCurveArcLength|0.17647059261798859\tu:0.39422133564949036,0,0.36159318685531616,0\nGetTangentOnCurve|0.17647059261798859\tv:-50.975345611572266,-96.953720092773438\nGetTangentOnCurveArcLength|0.17647059261798859\tv:-53.138931274414062,-96.072097778320312\nGetPositionOnCurve|0.23529411852359772\tu:0.36673879623413086,0,0.26593738794326782,0\nGetPositionOnCurveArcLength|0.23529411852359772\tu:0.37203460931777954,0,0.28812408447265625,0\nGetTangentOnCurve|0.23529411852359772\tv:-34.394893646240234,-97.644027709960938\nGetTangentOnCurveArcLength|0.23529411852359772\tv:-39.279220581054688,-98.304397583007812\nGetPositionOnCurve|0.29411765933036804\tu:0.35374465584754944,0,0.18604324758052826,0\nGetPositionOnCurveArcLength|0.29411765933036804\tu:0.35660535097122192,0,0.21051925420761108,0\nGetTangentOnCurve|0.29411765933036804\tv:-13.215827941894531,-89.708045959472656\nGetTangentOnCurveArcLength|0.29411765933036804\tv:-20.406444549560547,-93.148536682128906\nGetPositionOnCurve|0.35294118523597717\tu:0.35336315631866455,0,0.1165166050195694,0\nGetPositionOnCurveArcLength|0.35294118523597717\tu:0.35228589177131653,0,0.12969687581062317,0\nGetTangentOnCurve|0.35294118523597717\tv:12.561859130859375,-73.145751953125\nGetTangentOnCurveArcLength|0.35294118523597717\tv:6.84954833984375,-77.281379699707031\nGetPositionOnCurve|0.4117647111415863\tu:0.36806461215019226,0,0.064658515155315399,0\nGetPositionOnCurveArcLength|0.4117647111415863\tu:0.37285959720611572,0,0.057280562818050385,0\nGetTangentOnCurve|0.4117647111415863\tv:42.938148498535156,-47.957180023193359\nGetTangentOnCurveArcLength|0.4117647111415863\tv:49.347023010253906,-42.087043762207031\nGetPositionOnCurve|0.47058823704719543\tu:0.40031945705413818,0,0.037770166993141174,0\nGetPositionOnCurveArcLength|0.47058823704719543\tu:0.42143118381500244,0,0.035775985568761826,0\nGetTangentOnCurve|0.47058823704719543\tv:77.913070678710938,-14.142290115356445\nGetTangentOnCurveArcLength|0.47058823704719543\tv:95.315216064453125,4.0629653930664062\nGetPositionOnCurve|0.52941179275512695\tu:0.42285633087158203,0,0.046778157353401184,0\nGetPositionOnCurveArcLength|0.52941179275512695\tu:0.39322349429130554,0,0.092918574810028076,0\nGetTangentOnCurve|0.52941179275512695\tv:-9.0367755889892578,26.323530197143555\nGetTangentOnCurveArcLength|0.52941179275512695\tv:-50.168544769287109,32.187755584716797\nGetPositionOnCurve|0.58823531866073608\tu:0.4120728075504303,0,0.070389717817306519,0\nGetPositionOnCurveArcLength|0.58823531866073608\tu:0.34759664535522461,0,0.13099879026412964,0\nGetTangentOnCurve|0.58823531866073608\tv:-31.110301971435547,29.470588684082031\nGetTangentOnCurveArcLength|0.58823531866073608\tv:-79.161140441894531,36.321273803710938\nGetPositionOnCurve|0.64705884456634521\tu:0.38943132758140564,0,0.096664898097515106,0\nGetPositionOnCurveArcLength|0.64705884456634521\tu:0.29997220635414124,0,0.16256187856197357,0\nGetTangentOnCurve|0.64705884456634521\tv:-53.183830261230469,32.617649078369141\nGetTangentOnCurveArcLength|0.64705884456634521\tv:-100.897216796875,39.420223236083984\nGetPositionOnCurve|0.70588237047195435\tu:0.35493198037147522,0,0.12560367584228516,0\nGetPositionOnCurveArcLength|0.70588237047195435\tu:0.25151622295379639,0,0.19082947075366974,0\nGetTangentOnCurve|0.70588237047195435\tv:-75.257362365722656,35.764705657958984\nGetTangentOnCurveArcLength|0.70588237047195435\tv:-119.00567626953125,42.001976013183594\nGetPositionOnCurve|0.76470589637756348\tu:0.30857464671134949,0,0.15720607340335846,0\nGetPositionOnCurveArcLength|0.76470589637756348\tu:0.20259168744087219,0,0.21702329814434052,0\nGetTangentOnCurve|0.76470589637756348\tv:-97.330886840820312,38.911766052246094\nGetTangentOnCurveArcLength|0.76470589637756348\tv:-134.84419250488281,44.260097503662109\nGetPositionOnCurve|0.82352942228317261\tu:0.25035944581031799,0,0.19147208333015442,0\nGetPositionOnCurveArcLength|0.82352942228317261\tu:0.15336240828037262,0,0.24175918102264404,0\nGetTangentOnCurve|0.82352942228317261\tv:-119.4044189453125,42.058822631835938\nGetTangentOnCurveArcLength|0.82352942228317261\tv:-149.09260559082031,46.291519165039062\nGetPositionOnCurve|0.88235294818878174\tu:0.18028627336025238,0,0.22840172052383423,0\nGetPositionOnCurveArcLength|0.88235294818878174\tu:0.1039169505238533,0,0.26539850234985352,0\nGetTangentOnCurve|0.88235294818878174\tv:-141.47795104980469,45.205883026123047\nGetTangentOnCurveArcLength|0.88235294818878174\tv:-162.14814758300781,48.152866363525391\nGetPositionOnCurve|0.94117647409439087\tu:0.098355226218700409,0,0.26799494028091431,0\nGetPositionOnCurveArcLength|0.94117647409439087\tu:0.054309617727994919,0,0.28817439079284668,0\nGetTangentOnCurve|0.94117647409439087\tv:-163.55146789550781,48.352943420410156\nGetTangentOnCurveArcLength|0.94117647409439087\tv:-174.26629638671875,49.880569458007812\nGetPositionOnCurve|0.0555555559694767\tu:0.45879647135734558,0,0.49806082248687744,0\nGetPositionOnCurveArcLength|0.0555555559694767\tu:0.45722326636314392,0,0.49563845992088318,0\nGetTangentOnCurve|0.0555555559694767\tv:-70.615737915039062,-68.444442749023438\nGetTangentOnCurveArcLength|0.0555555559694767\tv:-70.411247253417969,-69.381202697753906\nGetPositionOnCurve|0.27777779102325439\tu:0.35619452595710754,0,0.20750802755355835,0\nGetPositionOnCurveArcLength|0.27777779102325439\tu:0.36005681753158569,0,0.23246784508228302,0\nGetTangentOnCurve|0.27777779102325439\tv:-19.5601806640625,-92.77777099609375\nGetTangentOnCurveArcLength|0.27777779102325439\tv:-26.286441802978516,-95.440093994140625\nGetPositionOnCurve|0.3888888955116272\tu:0.36039745807647705,0,0.0822601318359375,0\nGetPositionOnCurveArcLength|0.3888888955116272\tu:0.36048892140388489,0,0.081984154880046844,0\nGetTangentOnCurve|0.3888888955116272\tv:30.578712463378906,-58.777767181396484\nGetTangentOnCurveArcLength|0.3888888955116272\tv:30.750320434570312,-58.632427215576172\nGetPositionOnCurve|0.6111111044883728\tu:0.40467685461044312,0,0.080291323363780975,0\nGetPositionOnCurveArcLength|0.6111111044883728\tu:0.32921576499938965,0,0.14379233121871948,0\nGetTangentOnCurve|0.6111111044883728\tv:-39.694442749023438,30.69444465637207\nGetTangentOnCurveArcLength|0.6111111044883728\tv:-88.187416076660156,37.608165740966797\nGetPositionOnCurve|0.72222220897674561\tu:0.34324440360069275,0,0.13411493599414825,0\nGetPositionOnCurveArcLength|0.72222220897674561\tu:0.23796398937702179,0,0.19828048348426819,0\nGetTangentOnCurve|0.72222220897674561\tv:-81.388885498046875,36.638889312744141\nGetTangentOnCurveArcLength|0.72222220897674561\tv:-123.59639739990234,42.656478881835938\nGetPositionOnCurve|0.94444441795349121\tu:0.093455836176872253,0,0.2702726423740387,0\nGetPositionOnCurveArcLength|0.94444441795349121\tu:0.051549658179283142,0,0.28941786289215088,0\nGetTangentOnCurve|0.94444441795349121\tv:-164.77777099609375,48.527778625488281\nGetTangentOnCurveArcLength|0.94444441795349121\tv:-174.91584777832031,49.973175048828125\nGetPositionOnCurve|0.052631579339504242\tu:0.46068525314331055,0,0.50091648101806641,0\nGetPositionOnCurveArcLength|0.052631579339504242\tu:0.45906150341033936,0,0.49846500158309937,0\nGetTangentOnCurve|0.052631579339504242\tv:-70.850067138671875,-67.303672790527344\nGetTangentOnCurveArcLength|0.052631579339504242\tv:-70.64935302734375,-68.285423278808594\nGetPositionOnCurve|0.10526315867900848\tu:0.42791494727134705,0,0.44297206401824951,0\nGetPositionOnCurveArcLength|0.10526315867900848\tu:0.42841842770576477,0,0.4440036416053772,0\nGetTangentOnCurve|0.10526315867900848\tv:-64.893699645996094,-84.576522827148438\nGetTangentOnCurveArcLength|0.10526315867900848\tv:-65.018966674804688,-84.352745056152344\nGetPositionOnCurve|0.15789473056793213\tu:0.39889231324195862,0,0.37456199526786804,0\nGetPositionOnCurveArcLength|0.15789473056793213\tu:0.40238642692565918,0,0.38385096192359924,0\nGetTangentOnCurve|0.15789473056793213\tv:-55.255889892578125,-94.943557739257812\nGetTangentOnCurveArcLength|0.15789473056793213\tv:-56.715164184570312,-93.987663269042969\nGetPositionOnCurve|0.21052631735801697\tu:0.37538686394691467,0,0.30091589689254761,0\nGetPositionOnCurveArcLength|0.21052631735801697\tu:0.38066521286964417,0,0.31958648562431335,0\nGetTangentOnCurve|0.21052631735801697\tv:-41.936637878417969,-98.404777526855469\nGetTangentOnCurveArcLength|0.21052631735801697\tv:-45.621967315673828,-98.185623168945312\nGetPositionOnCurve|0.26315790414810181\tu:0.35916814208030701,0,0.22726349532604218,0\nGetPositionOnCurveArcLength|0.26315790414810181\tu:0.36372947692871094,0,0.25185573101043701,0\nGetTangentOnCurve|0.26315790414810181\tv:-24.935939788818359,-94.960174560546875\nGetTangentOnCurveArcLength|0.26315790414810181\tv:-31.099117279052734,-96.89837646484375\nGetPositionOnCurve|0.31578946113586426\tu:0.35200560092926025,0,0.1588345468044281,0\nGetPositionOnCurveArcLength|0.31578946113586426\tu:0.35329827666282654,0,0.18099001049995422,0\nGetTangentOnCurve|0.31578946113586426\tv:-4.253814697265625,-84.609771728515625\nGetTangentOnCurveArcLength|0.31578946113586426\tv:-11.635696411132812,-88.869735717773438\nGetPositionOnCurve|0.3684210479259491\tu:0.35566875338554382,0,0.10085867345333099,0\nGetPositionOnCurveArcLength|0.3684210479259491\tu:0.354379802942276,0,0.10854512453079224,0\nGetTangentOnCurve|0.3684210479259491\tv:20.109756469726562,-67.353538513183594\nGetTangentOnCurveArcLength|0.3684210479259491\tv:16.286956787109375,-70.331253051757812\nGetPositionOnCurve|0.42105263471603394\tu:0.37192708253860474,0,0.058565594255924225,0\nGetPositionOnCurveArcLength|0.42105263471603394\tu:0.37947022914886475,0,0.049769997596740723,0\nGetTangentOnCurve|0.42105263471603394\tv:48.154769897460938,-43.191482543945312\nGetTangentOnCurveArcLength|0.42105263471603394\tv:57.224273681640625,-34.655517578125\nGetPositionOnCurve|0.47368422150611877\tu:0.40255013108253479,0,0.037185065448284149,0\nGetPositionOnCurveArcLength|0.47368422150611877\tu:0.42382529377937317,0,0.036517415195703506,0\nGetTangentOnCurve|0.47368422150611877\tv:79.881240844726562,-12.123605728149414\nGetTangentOnCurveArcLength|0.47368422150611877\tv:1.4254119396209717,24.831920623779297\nGetPositionOnCurve|0.52631580829620361\tu:0.42309543490409851,0,0.045609228312969208,0\nGetPositionOnCurveArcLength|0.52631580829620361\tu:0.39550244808197021,0,0.090580247342586517,0\nGetTangentOnCurve|0.52631580829620361\tv:-7.8750066757202148,26.157896041870117\nGetTangentOnCurveArcLength|0.52631580829620361\tv:-48.265911102294922,31.916492462158203\nGetPositionOnCurve|0.57894736528396606\tu:0.41456380486488342,0,0.0664844810962677,0\nGetPositionOnCurveArcLength|0.57894736528396606\tu:0.35498949885368347,0,0.12556061148643494,0\nGetTangentOnCurve|0.57894736528396606\tv:-27.624998092651367,28.973684310913086\nGetTangentOnCurveArcLength|0.57894736528396606\tv:-75.2259521484375,35.760231018066406\nGetPositionOnCurve|0.63157892227172852\tu:0.39653930068016052,0,0.089492112398147583,0\nGetPositionOnCurveArcLength|0.63157892227172852\tu:0.31260925531387329,0,0.15465021133422852,0\nGetTangentOnCurve|0.63157892227172852\tv:-47.374992370605469,31.789472579956055\nGetTangentOnCurveArcLength|0.63157892227172852\tv:-95.612457275390625,38.666767120361328\nGetPositionOnCurve|0.68421053886413574\tu:0.36902186274528503,0,0.11463212221860886,0\nGetPositionOnCurveArcLength|0.68421053886413574\tu:0.26943555474281311,0,0.18070203065872192,0\nGetTangentOnCurve|0.68421053886413574\tv:-67.125007629394531,34.605262756347656\nGetTangentOnCurveArcLength|0.68421053886413574\tv:-112.64875793457031,41.095657348632812\nGetPositionOnCurve|0.73684209585189819\tu:0.33201152086257935,0,0.14190447330474854,0\nGetPositionOnCurveArcLength|0.73684209585189819\tu:0.22581192851066589,0,0.20482693612575531,0\nGetTangentOnCurve|0.73684209585189819\tv:-86.875,37.421051025390625\nGetTangentOnCurveArcLength|0.73684209585189819\tv:-127.57241821289062,43.223350524902344\nGetPositionOnCurve|0.78947371244430542\tu:0.28550827503204346,0,0.17130923271179199,0\nGetPositionOnCurveArcLength|0.78947371244430542\tu:0.18189455568790436,0,0.22759132087230682,0\nGetTangentOnCurve|0.78947371244430542\tv:-106.62500762939453,40.236843109130859\nGetTangentOnCurveArcLength|0.78947371244430542\tv:-141.01007080078125,45.139179229736328\nGetPositionOnCurve|0.84210526943206787\tu:0.22951212525367737,0,0.20284630358219147,0\nGetPositionOnCurveArcLength|0.84210526943206787\tu:0.13776828348636627,0,0.2493298202753067,0\nGetTangentOnCurve|0.84210526943206787\tv:-126.375,43.052631378173828\nGetTangentOnCurveArcLength|0.84210526943206787\tv:-153.33012390136719,46.895668029785156\nGetPositionOnCurve|0.89473682641983032\tu:0.16402308642864227,0,0.23651579022407532,0\nGetPositionOnCurveArcLength|0.89473682641983032\tu:0.093485340476036072,0,0.27025896310806274,0\nGetTangentOnCurve|0.89473682641983032\tv:-146.125,45.868419647216797\nGetTangentOnCurveArcLength|0.89473682641983032\tv:-164.77041625976562,48.526725769042969\nGetPositionOnCurve|0.94736844301223755\tu:0.089041061699390411,0,0.27231761813163757,0\nGetPositionOnCurveArcLength|0.94736844301223755\tu:0.049080070108175278,0,0.29052859544754028,0\nGetTangentOnCurve|0.94736844301223755\tv:-165.87501525878906,48.684211730957031\nGetTangentOnCurveArcLength|0.94736844301223755\tv:-175.49502563476562,50.055755615234375\nGetPositionOnCurve|0.05000000074505806\tu:0.46239042282104492,0,0.50344514846801758,0\nGetPositionOnCurveArcLength|0.05000000074505806\tu:0.46073082089424133,0,0.5009845495223999,0\nGetTangentOnCurve|0.05000000074505806\tv:-71.051246643066406,-66.258750915527344\nGetTangentOnCurveArcLength|0.05000000074505806\tv:-70.855567932128906,-67.275955200195312\nGetPositionOnCurve|0.15000000596046448\tu:0.40293720364570618,0,0.38528504967689514,0\nGetPositionOnCurveArcLength|0.15000000596046448\tu:0.40601727366447449,0,0.39316022396087646,0\nGetTangentOnCurve|0.15000000596046448\tv:-56.936248779296875,-93.828750610351562\nGetTangentOnCurveArcLength|0.15000000596046448\tv:-58.130317687988281,-92.900505065917969\nGetPositionOnCurve|0.34999999403953552\tu:0.35304450988769531,0,0.11963400989770889,0\nGetPositionOnCurveArcLength|0.34999999403953552\tu:0.35208681225776672,0,0.13375525176525116,0\nGetTangentOnCurve|0.34999999403953552\tv:11.163749694824219,-74.178749084472656\nGetTangentOnCurveArcLength|0.34999999403953552\tv:5.1878585815429688,-78.44061279296875\nGetPositionOnCurve|0.44999998807907104\tu:0.38687896728515625,0,0.043884001672267914,0\nGetPositionOnCurveArcLength|0.44999998807907104\tu:0.40338712930679321,0,0.036991968750953674,0\nGetTangentOnCurve|0.44999998807907104\tv:65.14874267578125,-26.958755493164062\nGetTangentOnCurveArcLength|0.44999998807907104\tv:80.61053466796875,-11.372840881347656\nGetPositionOnCurve|0.55000001192092896\tu:0.42043092846870422,0,0.05473921075463295,0\nGetPositionOnCurveArcLength|0.55000001192092896\tu:0.37765321135520935,0,0.10740429908037186,0\nGetTangentOnCurve|0.55000001192092896\tv:-16.762504577636719,27.42500114440918\nGetTangentOnCurveArcLength|0.55000001192092896\tv:-61.615299224853516,33.819736480712891\nGetPositionOnCurve|0.64999997615814209\tu:0.38798803091049194,0,0.09804854542016983,0\nGetPositionOnCurveArcLength|0.64999997615814209\tu:0.29756477475166321,0,0.16403929889202118,0\nGetTangentOnCurve|0.64999997615814209\tv:-54.287490844726562,32.774997711181641\nGetTangentOnCurveArcLength|0.64999997615814209\tv:-101.8729248046875,39.559329986572266\nGetPositionOnCurve|0.85000002384185791\tu:0.22029392421245575,0,0.20776081085205078,0\nGetPositionOnCurveArcLength|0.85000002384185791\tu:0.13113486766815186,0,0.2525164783000946,0\nGetTangentOnCurve|0.85000002384185791\tv:-129.33750915527344,43.474998474121094\nGetTangentOnCurveArcLength|0.85000002384185791\tv:-155.09757995605469,47.147655487060547\nGetPositionOnCurve|0.94999998807907104\tu:0.085042804479598999,0,0.27416366338729858,0\nGetPositionOnCurveArcLength|0.94999998807907104\tu:0.04685695469379425,0,0.29152688384056091,0\nGetTangentOnCurve|0.94999998807907104\tv:-166.86250305175781,48.824996948242188\nGetTangentOnCurveArcLength|0.94999998807907104\tv:-176.0147705078125,50.129852294921875\nGetPositionOnCurve|0.0476190485060215\tu:0.46393725275993347,0,0.50569868087768555,0\nGetPositionOnCurveArcLength|0.0476190485060215\tu:0.46225345134735107,0,0.50324374437332153,0\nGetTangentOnCurve|0.0476190485060215\tv:-71.225341796875,-65.298469543457031\nGetTangentOnCurveArcLength|0.0476190485060215\tv:-71.035453796386719,-66.343215942382812\nGetPositionOnCurve|0.095238097012042999\tu:0.43392208218574524,0,0.45497596263885498,0\nGetPositionOnCurveArcLength|0.095238097012042999\tu:0.43387803435325623,0,0.45489025115966797,0\nGetTangentOnCurve|0.095238097012042999\tv:-66.31207275390625,-81.818878173828125\nGetTangentOnCurveArcLength|0.095238097012042999\tv:-66.302253723144531,-81.839813232421875\nGetPositionOnCurve|0.190476194024086\tu:0.38357815146446228,0,0.32925611734390259,0\nGetPositionOnCurveArcLength|0.190476194024086\tu:0.38842043280601501,0,0.34449955821037292,0\nGetTangentOnCurve|0.190476194024086\tv:-47.444725036621094,-97.9005126953125\nGetTangentOnCurveArcLength|0.190476194024086\tv:-50.204338073730469,-97.209182739257812\nGetPositionOnCurve|0.2380952388048172\tu:0.36587047576904297,0,0.26200553774833679,0\nGetPositionOnCurveArcLength|0.2380952388048172\tu:0.37112906575202942,0,0.28451937437057495,0\nGetTangentOnCurve|0.2380952388048172\tv:-33.490642547607422,-97.46173095703125\nGetTangentOnCurveArcLength|0.2380952388048172\tv:-38.509979248046875,-98.2392578125\nGetPositionOnCurve|0.380952388048172\tu:0.35833114385604858,0,0.089170604944229126,0\nGetPositionOnCurveArcLength|0.380952388048172\tu:0.35760411620140076,0,0.091978028416633606,0\nGetTangentOnCurve|0.380952388048172\tv:26.453239440917969,-62.227027893066406\nGetTangentOnCurveArcLength|0.380952388048172\tv:24.863090515136719,-63.532875061035156\nGetPositionOnCurve|0.4761904776096344\tu:0.40439680218696594,0,0.036777578294277191,0\nGetPositionOnCurveArcLength|0.4761904776096344\tu:0.42379239201545715,0,0.039982806891202927,0\nGetTangentOnCurve|0.4761904776096344\tv:81.483856201171875,-10.471916198730469\nGetTangentOnCurveArcLength|0.4761904776096344\tv:-2.1768836975097656,25.345504760742188\nGetPositionOnCurve|0.52380955219268799\tu:0.42326486110687256,0,0.044668357819318771,0\nGetPositionOnCurveArcLength|0.52380955219268799\tu:0.39733156561851501,0,0.088649667799472809,0\nGetTangentOnCurve|0.52380955219268799\tv:-6.9345340728759766,26.023811340332031\nGetTangentOnCurveArcLength|0.52380955219268799\tv:-46.682788848876953,31.690784454345703\nGetPositionOnCurve|0.61904764175415039\tu:0.40169188380241394,0,0.083820715546607971,0\nGetPositionOnCurveArcLength|0.61904764175415039\tu:0.32279199361801147,0,0.14806130528450012,0\nGetTangentOnCurve|0.61904764175415039\tv:-42.672626495361328,31.119049072265625\nGetTangentOnCurveArcLength|0.61904764175415039\tv:-91.131362915039062,38.027889251708984\nGetPositionOnCurve|0.76190477609634399\tu:0.31105104088783264,0,0.15564079582691193,0\nGetPositionOnCurveArcLength|0.76190477609634399\tu:0.20492932200431824,0,0.21581259369850159,0\nGetTangentOnCurve|0.76190477609634399\tv:-96.279769897460938,38.761905670166016\nGetTangentOnCurveArcLength|0.76190477609634399\tv:-134.12997436523438,44.158271789550781\nGetPositionOnCurve|0.8095238208770752\tu:0.26529574394226074,0,0.18307191133499146,0\nGetPositionOnCurveArcLength|0.8095238208770752\tu:0.16510586440563202,0,0.23597997426986694,0\nGetTangentOnCurve|0.8095238208770752\tv:-114.14881134033203,41.309524536132812\nGetTangentOnCurveArcLength|0.8095238208770752\tv:-145.82020568847656,45.824966430664062\nGetPositionOnCurve|0.9047619104385376\tu:0.15047267079353333,0,0.24317075312137604,0\nGetPositionOnCurveArcLength|0.9047619104385376\tu:0.085035838186740875,0,0.27416688203811646,0\nGetTangentOnCurve|0.9047619104385376\tv:-149.88690185546875,46.404762268066406\nGetTangentOnCurveArcLength|0.9047619104385376\tv:-166.86421203613281,48.825244903564453\nGetPositionOnCurve|0.9523809552192688\tu:0.081404872238636017,0,0.27583849430084229,0\nGetPositionOnCurveArcLength|0.9523809552192688\tu:0.044845510274171829,0,0.2924288809299469,0\nGetTangentOnCurve|0.9523809552192688\tv:-167.75595092773438,48.952381134033203\nGetTangentOnCurveArcLength|0.9523809552192688\tv:-176.48370361328125,50.196708679199219\nGetPositionOnCurve|0.045454546809196472\tu:0.46534666419029236,0,0.50771850347518921,0\nGetPositionOnCurveArcLength|0.045454546809196472\tu:0.4636479914188385,0,0.50528013706207275,0\nGetTangentOnCurve|0.045454546809196472\tv:-71.377067565917969,-64.413223266601562\nGetTangentOnCurveArcLength|0.045454546809196472\tv:-71.193389892578125,-65.478935241699219\nGetPositionOnCurve|0.13636364042758942\tu:0.41019880771636963,0,0.40347766876220703,0\nGetPositionOnCurveArcLength|0.13636364042758942\tu:0.41251429915428162,0,0.4090154767036438,0\nGetTangentOnCurve|0.13636364042758942\tv:-59.643592834472656,-91.537185668945312\nGetTangentOnCurveArcLength|0.13636364042758942\tv:-60.431900024414062,-90.7335205078125\nGetPositionOnCurve|0.22727273404598236\tu:0.36935162544250488,0,0.27723246812820435,0\nGetPositionOnCurveArcLength|0.22727273404598236\tu:0.37470918893814087,0,0.29839497804641724,0\nGetTangentOnCurve|0.22727273404598236\tv:-36.926651000976562,-98.057846069335938\nGetTangentOnCurveArcLength|0.22727273404598236\tv:-41.421684265136719,-98.401107788085938\nGetPositionOnCurve|0.31818181276321411\tu:0.35192388296127319,0,0.1559329628944397,0\nGetPositionOnCurveArcLength|0.31818181276321411\tu:0.35303667187690735,0,0.17770473659038544,0\nGetTangentOnCurve|0.31818181276321411\tv:-3.2262420654296875,-83.975212097167969\nGetTangentOnCurveArcLength|0.31818181276321411\tv:-10.589061737060547,-88.299468994140625\nGetPositionOnCurve|0.40909090638160706\tu:0.36703422665596008,0,0.066529199481010437,0\nGetPositionOnCurveArcLength|0.40909090638160706\tu:0.3711092472076416,0,0.059747599065303802,0\nGetTangentOnCurve|0.40909090638160706\tv:41.4576416015625,-49.289253234863281\nGetTangentOnCurveArcLength|0.40909090638160706\tv:47.089332580566406,-44.173748016357422\nGetPositionOnCurve|0.59090906381607056\tu:0.4113008975982666,0,0.071526236832141876,0\nGetPositionOnCurveArcLength|0.59090906381607056\tu:0.34546008706092834,0,0.13253594934940338,0\nGetTangentOnCurve|0.59090906381607056\tv:-32.113624572753906,29.613636016845703\nGetTangentOnCurveArcLength|0.59090906381607056\tv:-80.262481689453125,36.478294372558594\nGetPositionOnCurve|0.68181818723678589\tu:0.37047860026359558,0,0.11344313621520996,0\nGetPositionOnCurveArcLength|0.68181818723678589\tu:0.27140945196151733,0,0.17956528067588806,0\nGetTangentOnCurve|0.68181818723678589\tv:-66.227272033691406,34.477272033691406\nGetTangentOnCurveArcLength|0.68181818723678589\tv:-111.92645263671875,40.992679595947266\nGetPositionOnCurve|0.77272725105285645\tu:0.30133450031280518,0,0.1617218554019928,0\nGetPositionOnCurveArcLength|0.77272725105285645\tu:0.19589409232139587,0,0.2204723060131073,0\nGetTangentOnCurve|0.77272725105285645\tv:-100.34090423583984,39.340908050537109\nGetTangentOnCurveArcLength|0.77272725105285645\tv:-136.869873046875,44.548904418945312\nGetPositionOnCurve|0.86363637447357178\tu:0.20386853814125061,0,0.21636244654655457,0\nGetPositionOnCurveArcLength|0.86363637447357178\tu:0.11966928094625473,0,0.25797984004020691,0\nGetTangentOnCurve|0.86363637447357178\tv:-134.45454406738281,44.204544067382812\nGetTangentOnCurveArcLength|0.86363637447357178\tv:-158.10597229003906,47.576568603515625\nGetPositionOnCurve|0.95454543828964233\tu:0.078080788254737854,0,0.27736485004425049,0\nGetPositionOnCurveArcLength|0.95454543828964233\tu:0.043016582727432251,0,0.29324796795845032,0\nGetTangentOnCurve|0.95454543828964233\tv:-168.56817626953125,49.068180084228516\nGetTangentOnCurveArcLength|0.95454543828964233\tv:-176.90901184082031,50.257347106933594\nGetPositionOnCurve|0.043478261679410934\tu:0.46663609147071838,0,0.50953853130340576,0\nGetPositionOnCurveArcLength|0.043478261679410934\tu:0.46492993831634521,0,0.50712466239929199,0\nGetTangentOnCurve|0.043478261679410934\tv:-71.510162353515625,-63.594757080078125\nGetTangentOnCurveArcLength|0.043478261679410934\tv:-71.3328857421875,-64.675994873046875\nGetPositionOnCurve|0.086956523358821869\tu:0.4389784038066864,0,0.46458017826080322,0\nGetPositionOnCurveArcLength|0.086956523358821869\tu:0.43851608037948608,0,0.46372053027153015,0\nGetTangentOnCurve|0.086956523358821869\tv:-67.383033752441406,-79.351844787597656\nGetTangentOnCurveArcLength|0.086956523358821869\tv:-67.289573669433594,-79.582870483398438\nGetPositionOnCurve|0.1304347813129425\tu:0.41345816850662231,0,0.4112384021282196,0\nGetPositionOnCurveArcLength|0.1304347813129425\tu:0.41542869806289673,0,0.41581621766090393,0\nGetTangentOnCurve|0.1304347813129425\tv:-60.743621826171875,-90.396263122558594\nGetTangentOnCurveArcLength|0.1304347813129425\tv:-61.377017974853516,-89.674598693847656\nGetPositionOnCurve|0.17391304671764374\tu:0.39107298851013184,0,0.35246151685714722,0\nGetPositionOnCurveArcLength|0.17391304671764374\tu:0.39531382918357849,0,0.36468616127967834,0\nGetTangentOnCurve|0.17391304671764374\tv:-51.5919189453125,-96.72802734375\nGetTangentOnCurveArcLength|0.17391304671764374\tv:-53.652305603027344,-95.824234008789062\nGetPositionOnCurve|0.21739129722118378\tu:0.37282031774520874,0,0.29119765758514404,0\nGetPositionOnCurveArcLength|0.21739129722118378\tu:0.37816432118415833,0,0.31094083189964294,0\nGetTangentOnCurve|0.21739129722118378\tv:-39.927932739257812,-98.347122192382812\nGetTangentOnCurveArcLength|0.21739129722118378\tv:-43.943153381347656,-98.341140747070312\nGetPositionOnCurve|0.26086956262588501\tu:0.35969778895378113,0,0.23039497435092926,0\nGetPositionOnCurveArcLength|0.26086956262588501\tu:0.36434969305992126,0,0.25486838817596436,0\nGetTangentOnCurve|0.26086956262588501\tv:-25.751655578613281,-95.2535400390625\nGetTangentOnCurveArcLength|0.26086956262588501\tv:-31.817752838134766,-97.079666137695312\nGetPositionOnCurve|0.30434781312942505\tu:0.35270285606384277,0,0.17300170660018921,0\nGetPositionOnCurveArcLength|0.30434781312942505\tu:0.35484549403190613,0,0.19663538038730621,0\nGetTangentOnCurve|0.30434781312942505\tv:-9.0630950927734375,-87.447311401367188\nGetTangentOnCurveArcLength|0.30434781312942505\tv:-16.417560577392578,-91.318954467773438\nGetPositionOnCurve|0.34782609343528748\tu:0.352833092212677,0,0.12196599692106247,0\nGetPositionOnCurveArcLength|0.34782609343528748\tu:0.3519759476184845,0,0.13675892353057861,0\nGetTangentOnCurve|0.34782609343528748\tv:10.137763977050781,-74.92840576171875\nGetTangentOnCurveArcLength|0.34782609343528748\tv:3.9845046997070312,-79.267105102539062\nGetPositionOnCurve|0.39130434393882751\tu:0.36108601093292236,0,0.080236092209815979,0\nGetPositionOnCurveArcLength|0.39130434393882751\tu:0.36150801181793213,0,0.079052329063415527,0\nGetTangentOnCurve|0.39130434393882751\tv:31.85089111328125,-57.696834564208984\nGetTangentOnCurveArcLength|0.39130434393882751\tv:32.609786987304688,-57.048259735107422\nGetPositionOnCurve|0.43478259444236755\tu:0.37845915555953979,0,0.05076000839471817,0\nGetPositionOnCurveArcLength|0.43478259444236755\tu:0.39039245247840881,0,0.041796457022428513,0\nGetTangentOnCurve|0.43478259444236755\tv:56.076309204101562,-35.752616882324219\nGetTangentOnCurveArcLength|0.43478259444236755\tv:68.657440185546875,-23.485183715820312\nGetPositionOnCurve|0.47826087474822998\tu:0.40595003962516785,0,0.036486070603132248,0\nGetPositionOnCurveArcLength|0.47826087474822998\tu:0.42353710532188416,0,0.04281853511929512,0\nGetTangentOnCurve|0.47826087474822998\tv:82.814041137695312,-9.0957069396972656\nGetTangentOnCurveArcLength|0.47826087474822998\tv:-5.0712170600891113,25.758155822753906\nGetPositionOnCurve|0.52173912525177002\tu:0.42338865995407104,0,0.043894749134778976,0\nGetPositionOnCurveArcLength|0.52173912525177002\tu:0.39883092045783997,0,0.087027594447135925,0\nGetTangentOnCurve|0.52173912525177002\tv:-6.1576070785522461,25.913043975830078\nGetTangentOnCurveArcLength|0.52173912525177002\tv:-45.343868255615234,31.499893188476562\nGetPositionOnCurve|0.56521737575531006\tu:0.41770464181900024,0,0.06083318218588829,0\nGetPositionOnCurveArcLength|0.56521737575531006\tu:0.36582165956497192,0,0.11720479279756546,0\nGetTangentOnCurve|0.56521737575531006\tv:-22.472820281982422,28.239130020141602\nGetTangentOnCurveArcLength|0.56521737575531006\tv:-69.056182861328125,34.880592346191406\nGetPositionOnCurve|0.6086956262588501\tu:0.40554249286651611,0,0.079226776957511902,0\nGetPositionOnCurveArcLength|0.6086956262588501\tu:0.33116650581359863,0,0.14247708022594452,0\nGetTangentOnCurve|0.6086956262588501\tv:-38.788032531738281,30.565216064453125\nGetTangentOnCurveArcLength|0.6086956262588501\tv:-87.273757934570312,37.4779052734375\nGetPositionOnCurve|0.65217393636703491\tu:0.38690212368965149,0,0.099075570702552795,0\nGetPositionOnCurveArcLength|0.65217393636703491\tu:0.29578402638435364,0,0.16512636840343475,0\nGetTangentOnCurve|0.65217393636703491\tv:-55.103271484375,32.891304016113281\nGetTangentOnCurveArcLength|0.65217393636703491\tv:-102.58866119384766,39.661373138427734\nGetPositionOnCurve|0.69565218687057495\tu:0.36178365349769592,0,0.12037950754165649,0\nGetPositionOnCurveArcLength|0.69565218687057495\tu:0.25998342037200928,0,0.18608574569225311,0\nGetTangentOnCurve|0.69565218687057495\tv:-71.418479919433594,35.217391967773438\nGetTangentOnCurveArcLength|0.69565218687057495\tv:-116.04532623291016,41.579914093017578\nGetPositionOnCurve|0.73913043737411499\tu:0.33018705248832703,0,0.14313861727714539,0\nGetPositionOnCurveArcLength|0.73913043737411499\tu:0.22390773892402649,0,0.20584201812744141,0\nGetTangentOnCurve|0.73913043737411499\tv:-87.733695983886719,37.543479919433594\nGetTangentOnCurveArcLength|0.73913043737411499\tv:-128.18428039550781,43.310585021972656\nGetPositionOnCurve|0.78260868787765503\tu:0.29211229085922241,0,0.16735288500785828,0\nGetPositionOnCurveArcLength|0.78260868787765503\tu:0.18763609230518341,0,0.22468593716621399,0\nGetTangentOnCurve|0.78260868787765503\tv:-104.04891204833984,39.869564056396484\nGetTangentOnCurveArcLength|0.78260868787765503\tv:-139.32696533203125,44.899215698242188\nGetPositionOnCurve|0.82608693838119507\tu:0.24755939841270447,0,0.19302231073379517,0\nGetPositionOnCurveArcLength|0.82608693838119507\tu:0.15121664106845856,0,0.24280773103237152,0\nGetTangentOnCurve|0.82608693838119507\tv:-120.36412048339844,42.195652008056641\nGetTangentOnCurveArcLength|0.82608693838119507\tv:-149.68281555175781,46.375663757324219\nGetPositionOnCurve|0.86956518888473511\tu:0.19652834534645081,0,0.22014692425727844,0\nGetPositionOnCurveArcLength|0.86956518888473511\tu:0.11468133330345154,0,0.2603396475315094,0\nGetTangentOnCurve|0.86956518888473511\tv:-136.67933654785156,44.521736145019531\nGetTangentOnCurveArcLength|0.86956518888473511\tv:-159.39701843261719,47.760635375976562\nGetPositionOnCurve|0.91304349899291992\tu:0.13901907205581665,0,0.24872671067714691,0\nGetPositionOnCurveArcLength|0.91304349899291992\tu:0.078052572906017303,0,0.27737781405448914,0\nGetTangentOnCurve|0.91304349899291992\tv:-152.99456787109375,46.847827911376953\nGetTangentOnCurveArcLength|0.91304349899291992\tv:-168.57505798339844,49.069160461425781\nGetPositionOnCurve|0.95652174949645996\tu:0.075031712651252747,0,0.27876168489456177,0\nGetPositionOnCurveArcLength|0.95652174949645996\tu:0.041346684098243713,0,0.29399499297142029,0\nGetTangentOnCurve|0.95652174949645996\tv:-169.30978393554688,49.173912048339844\nGetTangentOnCurveArcLength|0.95652174949645996\tv:-177.29644775390625,50.312583923339844\nGetPositionOnCurve|0.041666667908430099\tu:0.46782019734382629,0,0.51118636131286621,0\nGetPositionOnCurveArcLength|0.041666667908430099\tu:0.46611243486404419,0,0.50880259275436401,0\nGetTangentOnCurve|0.041666667908430099\tv:-71.627601623535156,-62.8359375\nGetTangentOnCurveArcLength|0.041666667908430099\tv:-71.456764221191406,-63.92816162109375\nGetPositionOnCurve|0.2083333283662796\tu:0.37623304128646851,0,0.30402085185050964,0\nGetPositionOnCurveArcLength|0.2083333283662796\tu:0.38148105144500732,0,0.32233613729476929,0\nGetTangentOnCurve|0.2083333283662796\tv:-42.565105438232422,-98.3984375\nGetTangentOnCurveArcLength|0.2083333283662796\tv:-46.146102905273438,-98.116546630859375\nGetPositionOnCurve|0.2916666567325592\tu:0.3540513813495636,0,0.18921583890914917,0\nGetPositionOnCurveArcLength|0.2916666567325592\tu:0.35707506537437439,0,0.21382975578308105,0\nGetTangentOnCurve|0.2916666567325592\tv:-14.190105438232422,-90.2109375\nGetTangentOnCurveArcLength|0.2916666567325592\tv:-21.325302124023438,-93.53997802734375\nGetPositionOnCurve|0.4583333432674408\tu:0.39203047752380371,0,0.040953163057565689,0\nGetPositionOnCurveArcLength|0.4583333432674408\tu:0.41067051887512207,0,0.035867977887392044,0\nGetTangentOnCurve|0.4583333432674408\tv:70.247406005859375,-21.8984375\nGetTangentOnCurveArcLength|0.4583333432674408\tv:86.764068603515625,-4.9811134338378906\nGetPositionOnCurve|0.54166668653488159\tu:0.42158761620521545,0,0.051477577537298203,0\nGetPositionOnCurveArcLength|0.54166668653488159\tu:0.38402929902076721,0,0.10173880308866501,0\nGetTangentOnCurve|0.54166668653488159\tv:-13.63542366027832,26.979167938232422\nGetTangentOnCurveArcLength|0.54166668653488159\tv:-57.205394744873047,33.191009521484375\nGetPositionOnCurve|0.70833331346511841\tu:0.35323721170425415,0,0.12686724960803986,0\nGetPositionOnCurveArcLength|0.70833331346511841\tu:0.24948543310165405,0,0.1919567734003067,0\nGetTangentOnCurve|0.70833331346511841\tv:-76.177078247070312,35.895832061767578\nGetTangentOnCurveArcLength|0.70833331346511841\tv:-119.70480346679688,42.101650238037109\nGetPositionOnCurve|0.79166668653488159\tu:0.28336462378501892,0,0.17258070409297943,0\nGetPositionOnCurveArcLength|0.79166668653488159\tu:0.18005961179733276,0,0.22851578891277313,0\nGetTangentOnCurve|0.79166668653488159\tv:-107.44792175292969,40.354167938232422\nGetTangentOnCurveArcLength|0.79166668653488159\tv:-141.54376220703125,45.215263366699219\nGetPositionOnCurve|0.95833331346511841\tu:0.072225041687488556,0,0.28004470467567444,0\nGetPositionOnCurveArcLength|0.95833331346511841\tu:0.039815649390220642,0,0.29467916488647461,0\nGetTangentOnCurve|0.95833331346511841\tv:-169.98957824707031,49.270832061767578\nGetTangentOnCurveArcLength|0.95833331346511841\tv:-177.65092468261719,50.363121032714844\nGetPositionOnCurve|0.039999999105930328\tu:0.46891120076179504,0,0.51268476247787476,0\nGetPositionOnCurveArcLength|0.039999999105930328\tu:0.46720659732818604,0,0.51033526659011841,0\nGetTangentOnCurve|0.039999999105930328\tv:-71.731796264648438,-62.130599975585938\nGetTangentOnCurveArcLength|0.039999999105930328\tv:-71.567314147949219,-63.230026245117188\nGetPositionOnCurve|0.079999998211860657\tu:0.44328591227531433,0,0.47241348028182983,0\nGetPositionOnCurveArcLength|0.079999998211860657\tu:0.44250419735908508,0,0.4710153341293335,0\nGetTangentOnCurve|0.079999998211860657\tv:-68.212203979492188,-77.14739990234375\nGetTangentOnCurveArcLength|0.079999998211860657\tv:-68.067222595214844,-77.554412841796875\nGetPositionOnCurve|0.11999999731779099\tu:0.41933473944664001,0,0.42464727163314819,0\nGetPositionOnCurveArcLength|0.11999999731779099\tu:0.42069122195243835,0,0.42764067649841309,0\nGetTangentOnCurve|0.11999999731779099\tv:-62.566200256347656,-88.175399780273438\nGetTangentOnCurveArcLength|0.11999999731779099\tv:-62.959434509277344,-87.633934020996094\nGetPositionOnCurve|0.15999999642372131\tu:0.39783439040184021,0,0.37168186902999878,0\nGetPositionOnCurveArcLength|0.15999999642372131\tu:0.40143433213233948,0,0.38135302066802979,0\nGetTangentOnCurve|0.15999999642372131\tv:-54.793800354003906,-95.214599609375\nGetTangentOnCurveArcLength|0.15999999642372131\tv:-56.327384948730469,-94.257148742675781\nGetPositionOnCurve|0.23999999463558197\tu:0.36529329419136047,0,0.25933629274368286,0\nGetPositionOnCurveArcLength|0.23999999463558197\tu:0.3705219030380249,0,0.282062828540802,0\nGetTangentOnCurve|0.23999999463558197\tv:-32.869800567626953,-97.326606750488281\nGetTangentOnCurveArcLength|0.23999999463558197\tv:-37.980484008789062,-98.185554504394531\nGetPositionOnCurve|0.2800000011920929\tu:0.35580611228942871,0,0.20454755425453186,0\nGetPositionOnCurveArcLength|0.2800000011920929\tu:0.35954484343528748,0,0.22949995100498199,0\nGetTangentOnCurve|0.2800000011920929\tv:-18.718196868896484,-92.399398803710938\nGetTangentOnCurveArcLength|0.2800000011920929\tv:-25.519474029541016,-95.171119689941406\nGetPositionOnCurve|0.31999999284744263\tu:0.35187679529190063,0,0.1537424772977829,0\nGetPositionOnCurveArcLength|0.31999999284744263\tu:0.35285317897796631,0,0.17520490288734436,0\nGetTangentOnCurve|0.31999999284744263\tv:-2.4402008056640625,-83.4833984375\nGetTangentOnCurveArcLength|0.31999999284744263\tv:-9.7820816040039062,-87.851837158203125\nGetPositionOnCurve|0.36000001430511475\tu:0.35428223013877869,0,0.10921678692102432,0\nGetPositionOnCurveArcLength|0.36000001430511475\tu:0.35301026701927185,0,0.11999552696943283,0\nGetTangentOnCurve|0.36000001430511475\tv:15.964210510253906,-70.578598022460938\nGetTangentOnCurveArcLength|0.36000001430511475\tv:11.003608703613281,-74.296234130859375\nGetPositionOnCurve|0.43999999761581421\tu:0.38120415806770325,0,0.048186324536800385,0\nGetPositionOnCurveArcLength|0.43999999761581421\tu:0.39477866888046265,0,0.039707046002149582,0\nGetTangentOnCurve|0.43999999761581421\tv:59.152191162109375,-32.802616119384766\nGetTangentOnCurveArcLength|0.43999999761581421\tv:72.855728149414062,-19.278768539428711\nGetPositionOnCurve|0.47999998927116394\tu:0.40727421641349792,0,0.036273051053285599,0\nGetPositionOnCurveArcLength|0.47999998927116394\tu:0.4231792688369751,0,0.045157872140407562,0\nGetTangentOnCurve|0.47999998927116394\tv:83.935791015625,-7.931427001953125\nGetTangentOnCurveArcLength|0.47999998927116394\tv:-7.424443244934082,26.093658447265625\nGetPositionOnCurve|0.51999998092651367\tu:0.423481285572052,0,0.04324747622013092,0\nGetPositionOnCurveArcLength|0.51999998092651367\tu:0.40008139610290527,0,0.085644945502281189,0\nGetTangentOnCurve|0.51999998092651367\tv:-5.5049929618835449,25.819999694824219\nGetTangentOnCurveArcLength|0.51999998092651367\tv:-44.196151733398438,31.336259841918945\nGetPositionOnCurve|0.56000000238418579\tu:0.41872876882553101,0,0.058723736554384232,0\nGetPositionOnCurveArcLength|0.56000000238418579\tu:0.36990171670913696,0,0.11391536146402359,0\nGetTangentOnCurve|0.56000000238418579\tv:-20.51500129699707,27.959999084472656\nGetTangentOnCurveArcLength|0.56000000238418579\tv:-66.584220886230469,34.528163909912109\nGetPositionOnCurve|0.63999998569488525\tu:0.39277443289756775,0,0.09337121993303299,0\nGetPositionOnCurveArcLength|0.63999998569488525\tu:0.3057420551776886,0,0.15898331999778748,0\nGetTangentOnCurve|0.63999998569488525\tv:-50.534996032714844,32.239997863769531\nGetTangentOnCurveArcLength|0.63999998569488525\tv:-98.519462585449219,39.081222534179688\nGetPositionOnCurve|0.68000000715255737\tu:0.3715725839138031,0,0.11254245042800903,0\nGetPositionOnCurveArcLength|0.68000000715255737\tu:0.27290886640548706,0,0.17869874835014343,0\nGetTangentOnCurve|0.68000000715255737\tv:-65.545005798339844,34.380001068115234\nGetTangentOnCurveArcLength|0.68000000715255737\tv:-111.3746337890625,40.914005279541016\nGetPositionOnCurve|0.72000002861022949\tu:0.34488764405250549,0,0.13294532895088196,0\nGetPositionOnCurveArcLength|0.72000002861022949\tu:0.23980899155139923,0,0.1972757875919342,0\nGetTangentOnCurve|0.72000002861022949\tv:-80.555007934570312,36.520000457763672\nGetTangentOnCurveArcLength|0.72000002861022949\tv:-122.98149108886719,42.568813323974609\nGetPositionOnCurve|0.75999999046325684\tu:0.31271964311599731,0,0.15457984805107117,0\nGetPositionOnCurveArcLength|0.75999999046325684\tu:0.20651839673519135,0,0.21498748660087585,0\nGetTangentOnCurve|0.75999999046325684\tv:-95.564994812011719,38.659999847412109\nGetTangentOnCurveArcLength|0.75999999046325684\tv:-133.64228820800781,44.088737487792969\nGetPositionOnCurve|0.8399999737739563\tu:0.23193427920341492,0,0.20154388248920441,0\nGetPositionOnCurveArcLength|0.8399999737739563\tu:0.13953660428524017,0,0.24847699701786041,0\nGetTangentOnCurve|0.8399999737739563\tv:-125.58499145507812,42.939998626708984\nGetTangentOnCurveArcLength|0.8399999737739563\tv:-152.85551452636719,46.8280029296875\nGetPositionOnCurve|0.87999999523162842\tu:0.1833169013261795,0,0.22687338292598724,0\nGetPositionOnCurveArcLength|0.87999999523162842\tu:0.10589815676212311,0,0.26447078585624695,0\nGetTangentOnCurve|0.87999999523162842\tv:-140.59500122070312,45.080001831054688\nGetTangentOnCurveArcLength|0.87999999523162842\tv:-161.64530944824219,48.0811767578125\nGetPositionOnCurve|0.92000001668930054\tu:0.12921640276908875,0,0.25343453884124756,0\nGetPositionOnCurveArcLength|0.92000001668930054\tu:0.072184346616268158,0,0.28006327152252197,0\nGetTangentOnCurve|0.92000001668930054\tv:-155.60501098632812,47.220001220703125\nGetTangentOnCurveArcLength|0.92000001668930054\tv:-169.99940490722656,49.272232055664062\nGetPositionOnCurve|0.95999997854232788\tu:0.069632925093173981,0,0.28122732043266296,0\nGetPositionOnCurveArcLength|0.95999997854232788\tu:0.03840724378824234,0,0.29530796408653259,0\nGetTangentOnCurve|0.95999997854232788\tv:-170.614990234375,49.360000610351562\nGetTangentOnCurveArcLength|0.95999997854232788\tv:-177.97637939453125,50.409523010253906\nGetPositionOnCurve|0.038461539894342422\tu:0.46991965174674988,0,0.5140528678894043,0\nGetPositionOnCurveArcLength|0.038461539894342422\tu:0.4682219922542572,0,0.51174044609069824,0\nGetTangentOnCurve|0.038461539894342422\tv:-71.82470703125,-61.473373413085938\nGetTangentOnCurveArcLength|0.038461539894342422\tv:-71.666427612304688,-62.576850891113281\nGetPositionOnCurve|0.11538461595773697\tu:0.42198798060417175,0,0.4304676353931427,0\nGetPositionOnCurveArcLength|0.11538461595773697\tu:0.42307376861572266,0,0.43280914425849915,0\nGetTangentOnCurve|0.11538461595773697\tv:-63.326183319091797,-87.10650634765625\nGetTangentOnCurveArcLength|0.11538461595773697\tv:-63.62652587890625,-86.657577514648438\nGetPositionOnCurve|0.19230769574642181\tu:0.38278859853744507,0,0.32667502760887146,0\nGetPositionOnCurveArcLength|0.19230769574642181\tu:0.38768485188484192,0,0.34224513173103333,0\nGetTangentOnCurve|0.19230769574642181\tv:-46.963760375976562,-97.9881591796875\nGetTangentOnCurveArcLength|0.19230769574642181\tv:-49.8048095703125,-97.330307006835938\nGetPositionOnCurve|0.26923078298568726\tu:0.35784590244293213,0,0.21900202333927155,0\nGetPositionOnCurveArcLength|0.26923078298568726\tu:0.36214172840118408,0,0.24383172392845154,0\nGetTangentOnCurve|0.26923078298568726\tv:-22.737422943115234,-94.11834716796875\nGetTangentOnCurveArcLength|0.26923078298568726\tv:-29.147624969482422,-96.356719970703125\nGetPositionOnCurve|0.3461538553237915\tu:0.35268425941467285,0,0.1237756758928299,0\nGetPositionOnCurveArcLength|0.3461538553237915\tu:0.35191091895103455,0,0.13907110691070557,0\nGetTangentOnCurve|0.3461538553237915\tv:9.352813720703125,-75.497039794921875\nGetTangentOnCurveArcLength|0.3461538553237915\tv:3.072845458984375,-79.885826110839844\nGetPositionOnCurve|0.42307692766189575\tu:0.37282794713973999,0,0.057323098182678223,0\nGetPositionOnCurveArcLength|0.42307692766189575\tu:0.38100668787956238,0,0.048359714448451996,0\nGetTangentOnCurve|0.42307692766189575\tv:49.306968688964844,-42.124244689941406\nGetTangentOnCurveArcLength|0.42307692766189575\tv:58.935104370117188,-33.011894226074219\nGetPositionOnCurve|0.57692307233810425\tu:0.41506749391555786,0,0.065642155706882477,0\nGetPositionOnCurveArcLength|0.57692307233810425\tu:0.35659432411193848,0,0.12435369938611984,0\nGetTangentOnCurve|0.57692307233810425\tv:-26.865383148193359,28.865385055541992\nGetTangentOnCurveArcLength|0.57692307233810425\tv:-74.344200134277344,35.634517669677734\nGetPositionOnCurve|0.6538461446762085\tu:0.38605582714080811,0,0.099868036806583405,0\nGetPositionOnCurveArcLength|0.6538461446762085\tu:0.29441365599632263,0,0.16595965623855591,0\nGetTangentOnCurve|0.6538461446762085\tv:-55.730766296386719,32.980770111083984\nGetTangentOnCurveArcLength|0.6538461446762085\tv:-103.13607025146484,39.739418029785156\nGetPositionOnCurve|0.73076921701431274\tu:0.33676645159721375,0,0.13864883780479431,0\nGetPositionOnCurveArcLength|0.73076921701431274\tu:0.23086249828338623,0,0.20212078094482422,0\nGetTangentOnCurve|0.73076921701431274\tv:-84.596145629882812,37.096153259277344\nGetTangentOnCurveArcLength|0.73076921701431274\tv:-125.93517303466797,42.989925384521484\nGetPositionOnCurve|0.80769228935241699\tu:0.26719930768013,0,0.18198457360267639,0\nGetPositionOnCurveArcLength|0.80769228935241699\tu:0.16664057970046997,0,0.23521944880485535,0\nGetTangentOnCurve|0.80769228935241699\tv:-113.46153259277344,41.211540222167969\nGetTangentOnCurveArcLength|0.80769228935241699\tv:-145.38710021972656,45.763217926025391\nGetPositionOnCurve|0.88461536169052124\tu:0.17735438048839569,0,0.22987525165081024,0\nGetPositionOnCurveArcLength|0.88461536169052124\tu:0.10201172530651093,0,0.26628926396369934,0\nGetTangentOnCurve|0.88461536169052124\tv:-142.32691955566406,45.326919555664062\nGetTangentOnCurveArcLength|0.88461536169052124\tv:-162.63023376464844,48.221599578857422\nGetPositionOnCurve|0.96153843402862549\tu:0.067231759428977966,0,0.28232085704803467,0\nGetPositionOnCurveArcLength|0.96153843402862549\tu:0.037107076495885849,0,0.29588791728019714,0\nGetTangentOnCurve|0.96153843402862549\tv:-171.19229125976562,49.442306518554688\nGetTangentOnCurveArcLength|0.96153843402862549\tv:-178.27630615234375,50.452285766601562\nGetPositionOnCurve|0.037037037312984467\tu:0.47085461020469666,0,0.51530653238296509,0\nGetPositionOnCurveArcLength|0.037037037312984467\tu:0.46916681528091431,0,0.51303309202194214,0\nGetTangentOnCurve|0.037037037312984467\tv:-71.907920837402344,-60.859565734863281\nGetTangentOnCurveArcLength|0.037037037312984467\tv:-71.755661010742188,-61.964481353759766\nGetPositionOnCurve|0.074074074625968933\tu:0.44699537754058838,0,0.47890797257423401,0\nGetPositionOnCurveArcLength|0.074074074625968933\tu:0.44596970081329346,0,0.47713524103164673,0\nGetTangentOnCurve|0.074074074625968933\tv:-68.8677978515625,-75.17437744140625\nGetTangentOnCurveArcLength|0.074074074625968933\tv:-68.691802978515625,-75.726783752441406\nGetPositionOnCurve|0.14814814925193787\tu:0.40390336513519287,0,0.38778141140937805,0\nGetPositionOnCurveArcLength|0.14814814925193787\tu:0.40688282251358032,0,0.39533036947250366,0\nGetTangentOnCurve|0.14814814925193787\tv:-57.318416595458984,-93.544754028320312\nGetTangentOnCurveArcLength|0.14814814925193787\tv:-58.45343017578125,-92.627853393554688\nGetPositionOnCurve|0.18518517911434174\tu:0.38590380549430847,0,0.33669829368591309,0\nGetPositionOnCurveArcLength|0.18518517911434174\tu:0.39057549834251404,0,0.35098767280578613,0\nGetTangentOnCurve|0.18518517911434174\tv:-48.809158325195312,-97.600311279296875\nGetTangentOnCurveArcLength|0.18518517911434174\tv:-51.337795257568359,-96.823410034179688\nGetPositionOnCurve|0.25925925374031067\tu:0.36008065938949585,0,0.23260432481765747,0\nGetPositionOnCurveArcLength|0.25925925374031067\tu:0.36479312181472778,0,0.25698474049568176,0\nGetTangentOnCurve|0.25925925374031067\tv:-26.321502685546875,-95.4521484375\nGetTangentOnCurveArcLength|0.25925925374031067\tv:-32.318111419677734,-97.19989013671875\nGetPositionOnCurve|0.29629629850387573\tu:0.35349038243293762,0,0.18323829770088196,0\nGetPositionOnCurveArcLength|0.29629629850387573\tu:0.35620298981666565,0,0.20757134258747101,0\nGetTangentOnCurve|0.29629629850387573\tv:-12.343109130859375,-89.248458862304688\nGetTangentOnCurveArcLength|0.29629629850387573\tv:-19.578075408935547,-92.785713195800781\nGetPositionOnCurve|0.37037035822868347\tu:0.35603541135787964,0,0.098980389535427094,0\nGetPositionOnCurveArcLength|0.37037035822868347\tu:0.35478308796882629,0,0.10592319071292877,0\nGetTangentOnCurve|0.37037035822868347\tv:21.082809448242188,-66.581802368164062\nGetTangentOnCurveArcLength|0.37037035822868347\tv:17.563636779785156,-69.346595764160156\nGetPositionOnCurve|0.40740740299224854\tu:0.3664039671421051,0,0.067733161151409149,0\nGetPositionOnCurveArcLength|0.40740740299224854\tu:0.37004590034484863,0,0.0613667331635952,0\nGetTangentOnCurve|0.40740740299224854\tv:40.530349731445312,-50.11883544921875\nGetTangentOnCurveArcLength|0.40740740299224854\tv:45.674247741699219,-45.471340179443359\nGetPositionOnCurve|0.48148149251937866\tu:0.40841633081436157,0,0.036114588379859924,0\nGetPositionOnCurveArcLength|0.48148149251937866\tu:0.42278268933296204,0,0.047110404819250107,0\nGetTangentOnCurve|0.48148149251937866\tv:84.894546508789062,-6.9336624145507812\nGetTangentOnCurveArcLength|0.48148149251937866\tv:-9.3656539916992188,26.370420455932617\nGetPositionOnCurve|0.51851850748062134\tu:0.423552006483078,0,0.042697936296463013,0\nGetPositionOnCurveArcLength|0.51851850748062134\tu:0.40113982558250427,0,0.084451839327812195,0\nGetTangentOnCurve|0.51851850748062134\tv:-4.9490699768066406,25.740739822387695\nGetTangentOnCurveArcLength|0.51851850748062134\tv:-43.200916290283203,31.194368362426758\nGetPositionOnCurve|0.59259259700775146\tu:0.41080230474472046,0,0.07224467396736145,0\nGetPositionOnCurveArcLength|0.59259259700775146\tu:0.34411308169364929,0,0.13349767029285431,0\nGetTangentOnCurve|0.59259259700775146\tv:-32.745372772216797,29.703704833984375\nGetTangentOnCurveArcLength|0.59259259700775146\tv:-80.949142456054688,36.576194763183594\nGetPositionOnCurve|0.62962961196899414\tu:0.39737614989280701,0,0.088601946830749512,0\nGetPositionOnCurveArcLength|0.62962961196899414\tu:0.31419625878334045,0,0.15363664925098419,0\nGetTangentOnCurve|0.62962961196899414\tv:-46.643512725830078,31.685184478759766\nGetTangentOnCurveArcLength|0.62962961196899414\tv:-94.927970886230469,38.569175720214844\nGetPositionOnCurve|0.70370370149612427\tu:0.35642120242118835,0,0.1244843602180481,0\nGetPositionOnCurveArcLength|0.70370370149612427\tu:0.25332054495811462,0,0.18982456624507904,0\nGetTangentOnCurve|0.70370370149612427\tv:-74.439811706542969,35.648147583007812\nGetTangentOnCurveArcLength|0.70370370149612427\tv:-118.38104248046875,41.912918090820312\nGetPositionOnCurve|0.74074071645736694\tu:0.32889240980148315,0,0.14400945603847504,0\nGetPositionOnCurveArcLength|0.74074071645736694\tu:0.22256755828857422,0,0.20655474066734314,0\nGetTangentOnCurve|0.74074071645736694\tv:-88.33795166015625,37.629627227783203\nGetTangentOnCurveArcLength|0.74074071645736694\tv:-128.6131591796875,43.371726989746094\nGetPositionOnCurve|0.81481480598449707\tu:0.25973218679428101,0,0.18622754514217377,0\nGetPositionOnCurveArcLength|0.81481480598449707\tu:0.16067086160182953,0,0.23817072808742523,0\nGetTangentOnCurve|0.81481480598449707\tv:-116.13425445556641,41.59259033203125\nGetTangentOnCurveArcLength|0.81481480598449707\tv:-147.06460571289062,46.00238037109375\nGetPositionOnCurve|0.85185188055038452\tu:0.21810068190097809,0,0.20892052352428436,0\nGetPositionOnCurveArcLength|0.85185188055038452\tu:0.1295783668756485,0,0.25326144695281982,0\nGetTangentOnCurve|0.85185188055038452\tv:-130.03242492675781,43.574073791503906\nGetTangentOnCurveArcLength|0.85185188055038452\tv:-155.5093994140625,47.206367492675781\nGetPositionOnCurve|0.92592591047286987\tu:0.12073523551225662,0,0.25747421383857727,0\nGetPositionOnCurveArcLength|0.92592591047286987\tu:0.067184172570705414,0,0.28234252333641052,0\nGetTangentOnCurve|0.92592591047286987\tv:-157.82870483398438,47.537036895751953\nGetTangentOnCurveArcLength|0.92592591047286987\tv:-171.20372009277344,49.443931579589844\nGetPositionOnCurve|0.96296298503875732\tu:0.065001115202903748,0,0.28333508968353271,0\nGetPositionOnCurveArcLength|0.96296298503875732\tu:0.035903025418519974,0,0.29642459750175476,0\nGetTangentOnCurve|0.96296298503875732\tv:-171.72686767578125,49.518520355224609\nGetTangentOnCurveArcLength|0.96296298503875732\tv:-178.55360412597656,50.4918212890625\nGetPositionOnCurve|0.035714287310838699\tu:0.47172367572784424,0,0.51645940542221069,0\nGetPositionOnCurveArcLength|0.035714287310838699\tu:0.4700482189655304,0,0.51422607898712158,0\nGetTangentOnCurve|0.035714287310838699\tv:-71.982780456542969,-60.285079956054688\nGetTangentOnCurveArcLength|0.035714287310838699\tv:-71.836311340332031,-61.389236450195312\nGetPositionOnCurve|0.1071428582072258\tu:0.4268033504486084,0,0.4406779408454895,0\nGetPositionOnCurveArcLength|0.1071428582072258\tu:0.42741331458091736,0,0.44193968176841736,0\nGetTangentOnCurve|0.1071428582072258\tv:-64.612884521484375,-85.065689086914062\nGetTangentOnCurveArcLength|0.1071428582072258\tv:-64.767707824707031,-84.798095703125\nGetPositionOnCurve|0.1785714328289032\tu:0.38890203833580017,0,0.34596443176269531,0\nGetPositionOnCurveArcLength|0.1785714328289032\tu:0.39333155751228333,0,0.35904577374458313,0\nGetTangentOnCurve|0.1785714328289032\tv:-50.462371826171875,-97.126907348632812\nGetTangentOnCurveArcLength|0.1785714328289032\tv:-52.712104797363281,-96.26641845703125\nGetPositionOnCurve|0.3214285671710968\tu:0.35184904932975769,0,0.15203052759170532,0\nGetPositionOnCurveArcLength|0.3214285671710968\tu:0.3527185320854187,0,0.1732390969991684,0\nGetTangentOnCurve|0.3214285671710968\tv:-1.8195114135742188,-83.0911865234375\nGetTangentOnCurveArcLength|0.3214285671710968\tv:-9.1409111022949219,-87.491348266601562\nGetPositionOnCurve|0.3928571343421936\tu:0.36154347658157349,0,0.078954793512821198,0\nGetPositionOnCurveArcLength|0.3928571343421936\tu:0.36219906806945801,0,0.077199429273605347,0\nGetTangentOnCurve|0.3928571343421936\tv:32.672836303710938,-56.994255065917969\nGetTangentOnCurveArcLength|0.3928571343421936\tv:33.821090698242188,-56.00732421875\nGetPositionOnCurve|0.46428570151329041\tu:0.39594936370849609,0,0.039236385375261307,0\nGetPositionOnCurveArcLength|0.46428570151329041\tu:0.41589635610580444,0,0.035611651837825775,0\nGetTangentOnCurve|0.46428570151329041\tv:73.945785522460938,-18.177946090698242\nGetTangentOnCurveArcLength|0.46428570151329041\tv:90.989410400390625,-0.53498458862304688\nGetPositionOnCurve|0.53571426868438721\tu:0.42226815223693848,0,0.049180544912815094,0\nGetPositionOnCurveArcLength|0.53571426868438721\tu:0.38852623105049133,0,0.097535155713558197,0\nGetTangentOnCurve|0.53571426868438721\tv:-11.401779174804688,26.660713195800781\nGetTangentOnCurveArcLength|0.53571426868438721\tv:-53.878604888916016,32.716705322265625\nGetPositionOnCurve|0.6071428656578064\tu:0.40608838200569153,0,0.078544825315475464,0\nGetPositionOnCurveArcLength|0.6071428656578064\tu:0.33241939544677734,0,0.14162746071815491,0\nGetTangentOnCurve|0.6071428656578064\tv:-38.205360412597656,30.482143402099609\nGetTangentOnCurveArcLength|0.6071428656578064\tv:-86.681861877441406,37.393516540527344\nGetPositionOnCurve|0.67857140302658081\tu:0.37242427468299866,0,0.11183653771877289,0\nGetPositionOnCurveArcLength|0.67857140302658081\tu:0.27408668398857117,0,0.17801623046398163,0\nGetTangentOnCurve|0.67857140302658081\tv:-65.008918762207031,34.303569793701172\nGetTangentOnCurveArcLength|0.67857140302658081\tv:-110.93924713134766,40.8519287109375\nGetPositionOnCurve|0.82142859697341919\tu:0.25264272093772888,0,0.19020244479179382,0\nGetPositionOnCurveArcLength|0.82142859697341919\tu:0.15512466430664062,0,0.2408963143825531,0\nGetTangentOnCurve|0.82142859697341919\tv:-118.61608123779297,41.946430206298828\nGetTangentOnCurveArcLength|0.82142859697341919\tv:-148.60614013671875,46.222160339355469\nGetPositionOnCurve|0.8928571343421936\tu:0.16652542352676392,0,0.23527656495571136,0\nGetPositionOnCurveArcLength|0.8928571343421936\tu:0.095069155097007751,0,0.26952359080314636,0\nGetTangentOnCurve|0.8928571343421936\tv:-145.41964721679688,45.767856597900391\nGetTangentOnCurveArcLength|0.8928571343421936\tv:-164.37496948242188,48.470348358154297\nGetPositionOnCurve|0.96428573131561279\tu:0.062923692166805267,0,0.28427821397781372,0\nGetPositionOnCurveArcLength|0.96428573131561279\tu:0.034784916788339615,0,0.29692253470420837,0\nGetTangentOnCurve|0.96428573131561279\tv:-172.22322082519531,49.589286804199219\nGetTangentOnCurveArcLength|0.96428573131561279\tv:-178.81072998046875,50.528476715087891\nGetPositionOnCurve|0.034482758492231369\tu:0.47253364324569702,0,0.51752287149429321,0\nGetPositionOnCurveArcLength|0.034482758492231369\tu:0.47087237238883972,0,0.51533025503158569,0\nGetTangentOnCurve|0.034482758492231369\tv:-72.050384521484375,-59.746284484863281\nGetTangentOnCurveArcLength|0.034482758492231369\tv:-71.909477233886719,-60.847858428955078\nGetPositionOnCurve|0.068965516984462738\tu:0.4502207338809967,0,0.48436892032623291,0\nGetPositionOnCurveArcLength|0.068965516984462738\tu:0.44900891184806824,0,0.48233729600906372,0\nGetTangentOnCurve|0.068965516984462738\tv:-69.3955078125,-73.403244018554688\nGetTangentOnCurveArcLength|0.068965516984462738\tv:-69.201774597167969,-74.074729919433594\nGetPositionOnCurve|0.10344827920198441\tu:0.42899268865585327,0,0.44517436623573303,0\nGetPositionOnCurveArcLength|0.10344827920198441\tu:0.42939448356628418,0,0.44598981738090515,0\nGetTangentOnCurve|0.10344827920198441\tv:-65.160369873046875,-84.095870971679688\nGetTangentOnCurveArcLength|0.10344827920198441\tv:-65.258384704589844,-83.91510009765625\nGetPositionOnCurve|0.13793103396892548\tu:0.40934717655181885,0,0.40141004323959351,0\nGetPositionOnCurveArcLength|0.13793103396892548\tu:0.41175293922424316,0,0.40720799565315247,0\nGetTangentOnCurve|0.13793103396892548\tv:-59.344978332519531,-91.824172973632812\nGetTangentOnCurveArcLength|0.13793103396892548\tv:-60.17645263671875,-91.001502990722656\nGetPositionOnCurve|0.17241379618644714\tu:0.39178180694580078,0,0.35454663634300232,0\nGetPositionOnCurveArcLength|0.17241379618644714\tu:0.39595898985862732,0,0.36649513244628906,0\nGetTangentOnCurve|0.17241379618644714\tv:-51.949317932128906,-96.588142395019531\nGetTangentOnCurveArcLength|0.17241379618644714\tv:-53.950080871582031,-95.673141479492188\nGetPositionOnCurve|0.20689655840396881\tu:0.37679421901702881,0,0.30605494976043701,0\nGetPositionOnCurveArcLength|0.20689655840396881\tu:0.38201993703842163,0,0.3241342306137085,0\nGetTangentOnCurve|0.20689655840396881\tv:-42.973388671875,-98.387779235839844\nGetTangentOnCurveArcLength|0.20689655840396881\tv:-46.486351013183594,-98.06622314453125\nGetPositionOnCurve|0.24137930572032928\tu:0.36488211154937744,0,0.25740572810173035,0\nGetPositionOnCurveArcLength|0.24137930572032928\tu:0.37008661031723022,0,0.28028124570846558,0\nGetTangentOnCurve|0.24137930572032928\tv:-32.417213439941406,-97.223098754882812\nGetTangentOnCurveArcLength|0.24137930572032928\tv:-37.593769073486328,-98.141876220703125\nGetPositionOnCurve|0.27586206793785095\tu:0.35654306411743164,0,0.21006980538368225,0\nGetPositionOnCurveArcLength|0.27586206793785095\tu:0.36050832271575928,0,0.2350221574306488,0\nGetTangentOnCurve|0.27586206793785095\tv:-20.280769348144531,-93.094085693359375\nGetTangentOnCurveArcLength|0.27586206793785095\tv:-26.939853668212891,-95.661666870117188\nGetPositionOnCurve|0.31034481525421143\tu:0.35227471590042114,0,0.16551788151264191,0\nGetPositionOnCurveArcLength|0.31034481525421143\tu:0.35397547483444214,0,0.18844950199127197,0\nGetTangentOnCurve|0.31034481525421143\tv:-6.5640640258789062,-86.000747680664062\nGetTangentOnCurveArcLength|0.31034481525421143\tv:-13.956005096435547,-90.091094970703125\nGetPositionOnCurve|0.34482759237289429\tu:0.35257473587989807,0,0.12522067129611969,0\nGetPositionOnCurveArcLength|0.34482759237289429\tu:0.35187143087387085,0,0.14090563356876373,0\nGetTangentOnCurve|0.34482759237289429\tv:8.73291015625,-75.943077087402344\nGetTangentOnCurveArcLength|0.34482759237289429\tv:2.3582916259765625,-80.366188049316406\nGetPositionOnCurve|0.37931033968925476\tu:0.35794079303741455,0,0.090649060904979706,0\nGetPositionOnCurveArcLength|0.37931033968925476\tu:0.35709258913993835,0,0.094103008508682251,0\nGetTangentOnCurve|0.37931033968925476\tv:25.610122680664062,-62.92108154296875\nGetTangentOnCurveArcLength|0.37931033968925476\tv:23.689010620117188,-64.488288879394531\nGetPositionOnCurve|0.41379311680793762\tu:0.36887046694755554,0,0.063273750245571136,0\nGetPositionOnCurveArcLength|0.41379311680793762\tu:0.3742358386516571,0,0.055497366935014725,0\nGetTangentOnCurve|0.41379311680793762\tv:44.067642211914062,-46.934730529785156\nGetTangentOnCurveArcLength|0.41379311680793762\tv:51.065780639648438,-40.485240936279297\nGetPositionOnCurve|0.4482758641242981\tu:0.38586139678955078,0,0.044565487653017044,0\nGetPositionOnCurveArcLength|0.4482758641242981\tu:0.40188953280448914,0,0.037347424775362015,0\nGetTangentOnCurve|0.4482758641242981\tv:64.105392456054688,-27.984088897705078\nGetTangentOnCurveArcLength|0.4482758641242981\tv:79.302154541015625,-12.718679428100586\nGetPositionOnCurve|0.48275861144065857\tu:0.40941128134727478,0,0.035995099693536758,0\nGetPositionOnCurveArcLength|0.48275861144065857\tu:0.42238032817840576,0,0.048760157078504562,0\nGetTangentOnCurve|0.48275861144065857\tv:85.723388671875,-6.069122314453125\nGetTangentOnCurveArcLength|0.48275861144065857\tv:-10.990095138549805,26.602018356323242\nGetPositionOnCurve|0.51724135875701904\tu:0.42360693216323853,0,0.042225547134876251,0\nGetPositionOnCurveArcLength|0.51724135875701904\tu:0.40204685926437378,0,0.083411522209644318,0\nGetTangentOnCurve|0.51724135875701904\tv:-4.4698200225830078,25.672412872314453\nGetTangentOnCurveArcLength|0.51724135875701904\tv:-42.329429626464844,31.070117950439453\nGetPositionOnCurve|0.5517241358757019\tu:0.4201619029045105,0,0.055420704185962677,0\nGetPositionOnCurveArcLength|0.5517241358757019\tu:0.3763238787651062,0,0.10854783654212952,0\nGetTangentOnCurve|0.5517241358757019\tv:-17.409481048583984,27.517240524291992\nGetTangentOnCurveArcLength|0.5517241358757019\tv:-62.495498657226562,33.945228576660156\nGetPositionOnCurve|0.58620691299438477\tu:0.41264203190803528,0,0.069531187415122986,0\nGetPositionOnCurveArcLength|0.58620691299438477\tu:0.34921509027481079,0,0.12982445955276489,0\nGetTangentOnCurve|0.58620691299438477\tv:-30.349143981933594,29.362070083618164\nGetTangentOnCurveArcLength|0.58620691299438477\tv:-78.316543579101562,36.200859069824219\nGetPositionOnCurve|0.62068963050842285\tu:0.40104734897613525,0,0.084556959569454193,0\nGetPositionOnCurveArcLength|0.62068963050842285\tu:0.32146039605140686,0,0.14893488585948944,0\nGetTangentOnCurve|0.62068963050842285\tv:-43.288784027099609,31.20689582824707\nGetTangentOnCurveArcLength|0.62068963050842285\tv:-91.72979736328125,38.113208770751953\nGetPositionOnCurve|0.65517240762710571\tu:0.38537782430648804,0,0.10049807280302048,0\nGetPositionOnCurveArcLength|0.65517240762710571\tu:0.29332628846168518,0,0.16661891341209412,0\nGetTangentOnCurve|0.65517240762710571\tv:-56.228446960449219,33.051723480224609\nGetTangentOnCurveArcLength|0.65517240762710571\tv:-103.56838226318359,39.801055908203125\nGetPositionOnCurve|0.68965518474578857\tu:0.36563342809677124,0,0.11735451966524124,0\nGetPositionOnCurveArcLength|0.68965518474578857\tu:0.26494008302688599,0,0.18327464163303375,0\nGetTangentOnCurve|0.68965518474578857\tv:-69.168106079101562,34.896553039550781\nGetTangentOnCurveArcLength|0.68965518474578857\tv:-114.27677154541016,41.327766418457031\nGetPositionOnCurve|0.72413790225982666\tu:0.34181421995162964,0,0.13512624800205231,0\nGetPositionOnCurveArcLength|0.72413790225982666\tu:0.23637300729751587,0,0.19914451241493225,0\nGetTangentOnCurve|0.72413790225982666\tv:-82.107749938964844,36.741378784179688\nGetTangentOnCurveArcLength|0.72413790225982666\tv:-124.12419128417969,42.731727600097656\nGetPositionOnCurve|0.75862067937850952\tu:0.31392017006874084,0,0.15381333231925964,0\nGetPositionOnCurveArcLength|0.75862067937850952\tu:0.2076689600944519,0,0.21438902616500854,0\nGetTangentOnCurve|0.75862067937850952\tv:-95.047409057617188,38.586204528808594\nGetTangentOnCurveArcLength|0.75862067937850952\tv:-133.28805541992188,44.038238525390625\nGetPositionOnCurve|0.79310345649719238\tu:0.28195124864578247,0,0.17341573536396027,0\nGetPositionOnCurveArcLength|0.79310345649719238\tu:0.17885734140872955,0,0.22912050783634186,0\nGetTangentOnCurve|0.79310345649719238\tv:-107.98707580566406,40.431034088134766\nGetTangentOnCurveArcLength|0.79310345649719238\tv:-141.89234924316406,45.264965057373047\nGetPositionOnCurve|0.82758623361587524\tu:0.2459074854850769,0,0.19393345713615417,0\nGetPositionOnCurveArcLength|0.82758623361587524\tu:0.149958536028862,0,0.24342148005962372,0\nGetTangentOnCurve|0.82758623361587524\tv:-120.92673492431641,42.275863647460938\nGetTangentOnCurveArcLength|0.82758623361587524\tv:-150.02778625488281,46.424846649169922\nGetPositionOnCurve|0.86206895112991333\tu:0.20578895509243011,0,0.21536645293235779,0\nGetPositionOnCurveArcLength|0.86206895112991333\tu:0.120987668633461,0,0.25735446810722351,0\nGetTangentOnCurve|0.86206895112991333\tv:-133.86637878417969,44.120689392089844\nGetTangentOnCurveArcLength|0.86206895112991333\tv:-157.76296997070312,47.527664184570312\nGetPositionOnCurve|0.89655172824859619\tu:0.16159552335739136,0,0.23771481215953827,0\nGetPositionOnCurveArcLength|0.89655172824859619\tu:0.091956011950969696,0,0.27096816897392273,0\nGetTangentOnCurve|0.89655172824859619\tv:-146.8060302734375,45.96551513671875\nGetTangentOnCurveArcLength|0.89655172824859619\tv:-165.15135192871094,48.581039428710938\nGetPositionOnCurve|0.93103450536727905\tu:0.11332723498344421,0,0.26097851991653442,0\nGetPositionOnCurveArcLength|0.93103450536727905\tu:0.062872514128684998,0,0.28430142998695374,0\nGetTangentOnCurve|0.93103450536727905\tv:-159.74569702148438,47.810348510742188\nGetTangentOnCurveArcLength|0.93103450536727905\tv:-172.23542785644531,49.591026306152344\nGetPositionOnCurve|0.96551722288131714\tu:0.060984190553426743,0,0.2851574718952179,0\nGetPositionOnCurveArcLength|0.96551722288131714\tu:0.03374394029378891,0,0.29738587141036987,0\nGetTangentOnCurve|0.96551722288131714\tv:-172.68533325195312,49.655174255371094\nGetTangentOnCurveArcLength|0.96551722288131714\tv:-179.04977416992188,50.56256103515625\nGetPositionOnCurve|0.033333335071802139\tu:0.47329029440879822,0,0.51850676536560059,0\nGetPositionOnCurveArcLength|0.033333335071802139\tu:0.47164463996887207,0,0.51635503768920898,0\nGetTangentOnCurve|0.033333335071802139\tv:-72.111663818359375,-59.240001678466797\nGetTangentOnCurveArcLength|0.033333335071802139\tv:-71.97607421875,-60.337478637695312\nGetPositionOnCurve|0.23333333432674408\tu:0.36736029386520386,0,0.26869383454322815,0\nGetPositionOnCurveArcLength|0.23333333432674408\tu:0.37267732620239258,0,0.29064187407493591,0\nGetTangentOnCurve|0.23333333432674408\tv:-35.02166748046875,-97.759994506835938\nGetTangentOnCurveArcLength|0.23333333432674408\tv:-39.811115264892578,-98.340263366699219\nGetPositionOnCurve|0.36666667461395264\tu:0.35535353422164917,0,0.10256752371788025,0\nGetPositionOnCurveArcLength|0.36666667461395264\tu:0.354045569896698,0,0.11091548204421997,0\nGetTangentOnCurve|0.36666667461395264\tv:19.23834228515625,-68.039993286132812\nGetTangentOnCurveArcLength|0.36666667461395264\tv:15.155494689941406,-71.195472717285156\nGetPositionOnCurve|0.43333333730697632\tu:0.37772259116172791,0,0.051513999700546265,0\nGetPositionOnCurveArcLength|0.43333333730697632\tu:0.38919225335121155,0,0.042465265840291977,0\nGetTangentOnCurve|0.43333333730697632\tv:55.22833251953125,-36.560016632080078\nGetTangentOnCurveArcLength|0.43333333730697632\tv:67.4744873046875,-24.660615921020508\nGetPositionOnCurve|0.56666666269302368\tu:0.41740360856056213,0,0.061422854661941528,0\nGetPositionOnCurveArcLength|0.56666666269302368\tu:0.36468446254730225,0,0.1181066483259201,0\nGetTangentOnCurve|0.56666666269302368\tv:-23.016664505004883,28.316665649414062\nGetTangentOnCurveArcLength|0.56666666269302368\tv:-69.729560852050781,34.976600646972656\nGetPositionOnCurve|0.63333332538604736\tu:0.39577499032020569,0,0.090295754373073578,0\nGetPositionOnCurveArcLength|0.63333332538604736\tu:0.31118014454841614,0,0.15555889904499054,0\nGetTangentOnCurve|0.63333332538604736\tv:-48.033329010009766,31.883333206176758\nGetTangentOnCurveArcLength|0.63333332538604736\tv:-96.224655151367188,38.754047393798828\nGetPositionOnCurve|0.76666665077209473\tu:0.30682522058486938,0,0.15830534696578979,0\nGetPositionOnCurveArcLength|0.76666665077209473\tu:0.20095503330230713,0,0.21786880493164062,0\nGetTangentOnCurve|0.76666665077209473\tv:-98.066658020019531,39.016666412353516\nGetTangentOnCurveArcLength|0.76666665077209473\tv:-135.34199523925781,44.331069946289062\nGetPositionOnCurve|0.96666663885116577\tu:0.059169262647628784,0,0.28597921133041382,0\nGetPositionOnCurveArcLength|0.96666663885116577\tu:0.032772358506917953,0,0.29781800508499146,0\nGetTangentOnCurve|0.96666663885116577\tv:-173.11665344238281,49.716667175292969\nGetTangentOnCurveArcLength|0.96666663885116577\tv:-179.27259826660156,50.594329833984375\nGetPositionOnCurve|0.032258063554763794\tu:0.47399866580963135,0,0.51941967010498047,0\nGetPositionOnCurveArcLength|0.032258063554763794\tu:0.47236984968185425,0,0.51730865240097046,0\nGetTangentOnCurve|0.032258063554763794\tv:-72.167404174804688,-58.763397216796875\nGetTangentOnCurveArcLength|0.032258063554763794\tv:-72.036880493164062,-59.855514526367188\nGetPositionOnCurve|0.064516127109527588\tu:0.45304939150810242,0,0.48901733756065369,0\nGetPositionOnCurveArcLength|0.064516127109527588\tu:0.45169588923454285,0,0.48680943250656128,0\nGetTangentOnCurve|0.064516127109527588\tv:-69.826873779296875,-71.807624816894531\nGetTangentOnCurveArcLength|0.064516127109527588\tv:-69.62408447265625,-72.5760498046875\nGetPositionOnCurve|0.096774190664291382\tu:0.43299329280853271,0,0.45316272974014282,0\nGetPositionOnCurveArcLength|0.096774190664291382\tu:0.43303057551383972,0,0.45323577523231506,0\nGetTangentOnCurve|0.096774190664291382\tv:-66.103408813476562,-82.257675170898438\nGetTangentOnCurveArcLength|0.096774190664291382\tv:-66.111846923828125,-82.240158081054688\nGetPositionOnCurve|0.12903225421905518\tu:0.41423782706260681,0,0.41305980086326599,0\nGetPositionOnCurveArcLength|0.12903225421905518\tu:0.4161260724067688,0,0.41741648316383362,0\nGetTangentOnCurve|0.12903225421905518\tv:-60.99700927734375,-90.113555908203125\nGetTangentOnCurveArcLength|0.12903225421905518\tv:-61.595706939697266,-89.413543701171875\nGetPositionOnCurve|0.16129031777381897\tu:0.3971903920173645,0,0.36991262435913086,0\nGetPositionOnCurveArcLength|0.16129031777381897\tu:0.40085417032241821,0,0.37981885671615601,0\nGetTangentOnCurve|0.16129031777381897\tv:-54.507675170898438,-95.375259399414062\nGetTangentOnCurveArcLength|0.16129031777381897\tv:-56.087539672851562,-94.4180908203125\nGetPositionOnCurve|0.19354838132858276\tu:0.38225835561752319,0,0.32492527365684509,0\nGetPositionOnCurveArcLength|0.19354838132858276\tu:0.38718962669372559,0,0.34071546792984009,0\nGetTangentOnCurve|0.19354838132858276\tv:-46.635406494140625,-98.042793273925781\nGetTangentOnCurveArcLength|0.19354838132858276\tv:-49.53204345703125,-97.408737182617188\nGetPositionOnCurve|0.22580644488334656\tu:0.36984914541244507,0,0.27930185198783875,0\nGetPositionOnCurveArcLength|0.22580644488334656\tu:0.37521088123321533,0,0.30026409029960632,0\nGetTangentOnCurve|0.22580644488334656\tv:-37.380207061767578,-98.116165161132812\nGetTangentOnCurveArcLength|0.22580644488334656\tv:-41.803901672363281,-98.404586791992188\nGetPositionOnCurve|0.25806450843811035\tu:0.36037015914916992,0,0.23424644768238068,0\nGetPositionOnCurveArcLength|0.25806450843811035\tu:0.36512583494186401,0,0.25855302810668945,0\nGetTangentOnCurve|0.25806450843811035\tv:-26.7420654296875,-95.595352172851562\nGetTangentOnCurveArcLength|0.25806450843811035\tv:-32.686538696289062,-97.285194396972656\nGetPositionOnCurve|0.29032257199287415\tu:0.35422882437705994,0,0.19096305966377258,0\nGetPositionOnCurveArcLength|0.29032257199287415\tu:0.35734015703201294,0,0.21564255654811859,0\nGetTangentOnCurve|0.29032257199287415\tv:-14.720993041992188,-90.480361938476562\nGetTangentOnCurveArcLength|0.29032257199287415\tv:-21.823440551757812,-93.747261047363281\nGetPositionOnCurve|0.32258063554763794\tu:0.35183256864547729,0,0.15065582096576691,0\nGetPositionOnCurveArcLength|0.32258063554763794\tu:0.35261619091033936,0,0.17165286839008331,0\nGetTangentOnCurve|0.32258063554763794\tv:-1.3169937133789062,-82.771202087402344\nGetTangentOnCurveArcLength|0.32258063554763794\tv:-8.6192398071289062,-87.194931030273438\nGetPositionOnCurve|0.35483869910240173\tu:0.35358867049217224,0,0.11452876776456833,0\nGetPositionOnCurveArcLength|0.35483869910240173\tu:0.35244548320770264,0,0.12708257138729095,0\nGetTangentOnCurve|0.35483869910240173\tv:13.469947814941406,-72.467880249023438\nGetTangentOnCurveArcLength|0.35483869910240173\tv:7.9428253173828125,-76.507598876953125\nGetPositionOnCurve|0.38709676265716553\tu:0.35990467667579651,0,0.083785980939865112,0\nGetPositionOnCurveArcLength|0.38709676265716553\tu:0.35977604985237122,0,0.084195695817470551,0\nGetTangentOnCurve|0.38709676265716553\tv:29.639823913574219,-59.57037353515625\nGetTangentOnCurveArcLength|0.38709676265716553\tv:29.390556335449219,-59.780059814453125\nGetPositionOnCurve|0.41935482621192932\tu:0.37118792533874512,0,0.059631567448377609,0\nGetPositionOnCurveArcLength|0.41935482621192932\tu:0.37820583581924438,0,0.051016170531511307,0\nGetTangentOnCurve|0.41935482621192932\tv:47.192634582519531,-44.078685760498047\nGetTangentOnCurveArcLength|0.41935482621192932\tv:55.78582763671875,-36.029487609863281\nGetPositionOnCurve|0.45161288976669312\tu:0.38784581422805786,0,0.043269533663988113,0\nGetPositionOnCurveArcLength|0.45161288976669312\tu:0.40479171276092529,0,0.036699090152978897,0\nGetTangentOnCurve|0.45161288976669312\tv:66.12835693359375,-25.99287223815918\nGetTangentOnCurveArcLength|0.45161288976669312\tv:81.823577880859375,-10.120891571044922\nGetPositionOnCurve|0.48387095332145691\tu:0.41028577089309692,0,0.035904038697481155,0\nGetPositionOnCurveArcLength|0.48387095332145691\tu:0.42198875546455383,0,0.050170574337244034,0\nGetTangentOnCurve|0.48387095332145691\tv:86.447052001953125,-5.312835693359375\nGetTangentOnCurveArcLength|0.48387095332145691\tv:-12.367741584777832,26.798431396484375\nGetPositionOnCurve|0.5161290168762207\tu:0.42365020513534546,0,0.041815135627985001,0\nGetPositionOnCurveArcLength|0.5161290168762207\tu:0.4028325080871582,0,0.082496188580989838,0\nGetTangentOnCurve|0.5161290168762207\tv:-4.0524134635925293,25.61290168762207\nGetTangentOnCurveArcLength|0.5161290168762207\tv:-41.559757232666016,30.960384368896484\nGetPositionOnCurve|0.54838711023330688\tu:0.42067340016365051,0,0.054103754460811615,0\nGetPositionOnCurveArcLength|0.54838711023330688\tu:0.37889379262924194,0,0.10632605105638504,0\nGetTangentOnCurve|0.54838711023330688\tv:-16.157262802124023,27.338710784912109\nGetTangentOnCurveArcLength|0.54838711023330688\tv:-60.7823486328125,33.700981140136719\nGetPositionOnCurve|0.58064514398574829\tu:0.41413053870201111,0,0.067193374037742615,0\nGetPositionOnCurveArcLength|0.58064514398574829\tu:0.35364165902137756,0,0.12656664848327637,0\nGetTangentOnCurve|0.58064514398574829\tv:-28.262090682983398,29.06451416015625\nGetTangentOnCurveArcLength|0.58064514398574829\tv:-75.958580017089844,35.864681243896484\nGetPositionOnCurve|0.61290323734283447\tu:0.40402168035507202,0,0.081084035336971283,0\nGetPositionOnCurveArcLength|0.61290323734283447\tu:0.32776707410812378,0,0.14476323127746582,0\nGetTangentOnCurve|0.61290323734283447\tv:-40.366939544677734,30.790323257446289\nGetTangentOnCurveArcLength|0.61290323734283447\tv:-88.859848022460938,37.704036712646484\nGetPositionOnCurve|0.64516127109527588\tu:0.39034682512283325,0,0.095775716006755829,0\nGetPositionOnCurveArcLength|0.64516127109527588\tu:0.30152440071105957,0,0.16160450875759125,0\nGetTangentOnCurve|0.64516127109527588\tv:-52.471767425537109,32.516128540039062\nGetTangentOnCurveArcLength|0.64516127109527588\tv:-100.26309967041016,39.329814910888672\nGetPositionOnCurve|0.67741936445236206\tu:0.37310591340065002,0,0.11126843094825745,0\nGetPositionOnCurveArcLength|0.67741936445236206\tu:0.27503621578216553,0,0.1774648129940033,0\nGetTangentOnCurve|0.67741936445236206\tv:-64.576614379882812,34.241935729980469\nGetTangentOnCurveArcLength|0.67741936445236206\tv:-110.58699035644531,40.801712036132812\nGetPositionOnCurve|0.70967739820480347\tu:0.3522990345954895,0,0.12756215035915375,0\nGetPositionOnCurveArcLength|0.70967739820480347\tu:0.24837155640125275,0,0.1925734281539917,0\nGetTangentOnCurve|0.70967739820480347\tv:-76.681442260742188,35.967742919921875\nGetTangentOnCurveArcLength|0.70967739820480347\tv:-120.08654022216797,42.156074523925781\nGetPositionOnCurve|0.74193549156188965\tu:0.32792606949806213,0,0.14465691149234772,0\nGetPositionOnCurveArcLength|0.74193549156188965\tu:0.22157299518585205,0,0.20708280801773071,0\nGetTangentOnCurve|0.74193549156188965\tv:-88.786293029785156,37.693550109863281\nGetTangentOnCurveArcLength|0.74193549156188965\tv:-128.93051147460938,43.416976928710938\nGetPositionOnCurve|0.77419352531433105\tu:0.29998719692230225,0,0.16255266964435577,0\nGetPositionOnCurveArcLength|0.77419352531433105\tu:0.19466915726661682,0,0.22110000252723694,0\nGetTangentOnCurve|0.77419352531433105\tv:-100.89112091064453,39.419353485107422\nGetTangentOnCurveArcLength|0.77419352531433105\tv:-137.23712158203125,44.601264953613281\nGetPositionOnCurve|0.80645161867141724\tu:0.26848220825195312,0,0.18124948441982269,0\nGetPositionOnCurveArcLength|0.80645161867141724\tu:0.16768006980419159,0,0.2347036749124527,0\nGetTangentOnCurve|0.80645161867141724\tv:-112.9959716796875,41.145160675048828\nGetTangentOnCurveArcLength|0.80645161867141724\tv:-145.093017578125,45.721290588378906\nGetPositionOnCurve|0.83870965242385864\tu:0.2334112823009491,0,0.2007472962141037,0\nGetPositionOnCurveArcLength|0.83870965242385864\tu:0.1406203955411911,0,0.2479536235332489,0\nGetTangentOnCurve|0.83870965242385864\tv:-125.10079956054688,42.870964050292969\nGetTangentOnCurveArcLength|0.83870965242385864\tv:-152.56388854980469,46.786422729492188\nGetPositionOnCurve|0.87096774578094482\tu:0.19477428495883942,0,0.22104616463184357,0\nGetPositionOnCurveArcLength|0.87096774578094482\tu:0.11350114643573761,0,0.26089650392532349,0\nGetTangentOnCurve|0.87096774578094482\tv:-137.20564270019531,44.596775054931641\nGetTangentOnCurveArcLength|0.87096774578094482\tv:-159.70095825195312,47.803966522216797\nGetPositionOnCurve|0.90322577953338623\tu:0.15257132053375244,0,0.24214600026607513,0\nGetPositionOnCurveArcLength|0.90322577953338623\tu:0.086330816149711609,0,0.27356958389282227,0\nGetTangentOnCurve|0.90322577953338623\tv:-149.31047058105469,46.322578430175781\nGetTangentOnCurveArcLength|0.90322577953338623\tv:-166.54502868652344,48.779739379882812\nGetPositionOnCurve|0.93548387289047241\tu:0.10680225491523743,0,0.26404693722724915,0\nGetPositionOnCurveArcLength|0.93548387289047241\tu:0.059116344898939133,0,0.28600314259529114,0\nGetTangentOnCurve|0.93548387289047241\tv:-161.41532897949219,48.048385620117188\nGetTangentOnCurveArcLength|0.93548387289047241\tv:-173.12921142578125,49.718456268310547\nGetPositionOnCurve|0.96774190664291382\tu:0.057467281818389893,0,0.28674885630607605,0\nGetPositionOnCurveArcLength|0.96774190664291382\tu:0.031863279640674591,0,0.29822209477424622,0\nGetTangentOnCurve|0.96774190664291382\tv:-173.52015686035156,49.774192810058594\nGetTangentOnCurveArcLength|0.96774190664291382\tv:-179.48085021972656,50.624015808105469\nGetPositionOnCurve|0.03125\tu:0.47466331720352173,0,0.52026873826980591,0\nGetPositionOnCurveArcLength|0.03125\tu:0.47305211424827576,0,0.51819807291030884,0\nGetTangentOnCurve|0.03125\tv:-72.21826171875,-58.31396484375\nGetTangentOnCurveArcLength|0.03125\tv:-72.092575073242188,-59.399681091308594\nGetPositionOnCurve|0.09375\tu:0.4348246157169342,0,0.45672321319580078,0\nGetPositionOnCurveArcLength|0.09375\tu:0.43470275402069092,0,0.45648813247680664,0\nGetTangentOnCurve|0.09375\tv:-66.51123046875,-81.38818359375\nGetTangentOnCurveArcLength|0.09375\tv:-66.484542846679688,-81.446586608886719\nGetPositionOnCurve|0.15625\tu:0.39972496032714844,0,0.37680625915527344,0\nGetPositionOnCurveArcLength|0.15625\tu:0.40313497185707092,0,0.38579800724983215,0\nGetTangentOnCurve|0.15625\tv:-55.61279296875,-94.72412109375\nGetTangentOnCurveArcLength|0.15625\tv:-57.015052795410156,-93.771163940429688\nGetPositionOnCurve|0.21875\tu:0.37232741713523865,0,0.28927525877952576,0\nGetPositionOnCurveArcLength|0.21875\tu:0.37767899036407471,0,0.30922278761863708,0\nGetTangentOnCurve|0.21875\tv:-39.52294921875,-98.32177734375\nGetTangentOnCurveArcLength|0.21875\tv:-43.603904724121094,-98.360931396484375\nGetPositionOnCurve|0.28125\tu:0.35559514164924622,0,0.20288766920566559,0\nGetPositionOnCurveArcLength|0.28125\tu:0.35926246643066406,0,0.22782802581787109,0\nGetTangentOnCurve|0.28125\tv:-18.24169921875,-92.18115234375\nGetTangentOnCurveArcLength|0.28125\tv:-25.083694458007812,-95.01409912109375\nGetPositionOnCurve|0.34375\tu:0.35249125957489014,0,0.12640094757080078,0\nGetPositionOnCurveArcLength|0.34375\tu:0.35184711217880249,0,0.14239652454853058,0\nGetTangentOnCurve|0.34375\tv:8.23095703125,-76.30224609375\nGetTangentOnCurveArcLength|0.34375\tv:1.7831573486328125,-80.7498779296875\nGetPositionOnCurve|0.40625\tu:0.36597892642021179,0,0.068572558462619781,0\nGetPositionOnCurveArcLength|0.40625\tu:0.36933267116546631,0,0.062508396804332733,0\nGetTangentOnCurve|0.40625\tv:39.89501953125,-50.68505859375\nGetTangentOnCurveArcLength|0.40625\tv:44.705001831054688,-46.355449676513672\nGetPositionOnCurve|0.46875\tu:0.39902123808860779,0,0.038159925490617752,0\nGetPositionOnCurveArcLength|0.46875\tu:0.41981741786003113,0,0.035684764385223389,0\nGetTangentOnCurve|0.46875\tv:76.75048828125,-15.32958984375\nGetTangentOnCurveArcLength|0.46875\tv:94.068771362304688,2.7334213256835938\nGetPositionOnCurve|0.53125\tu:0.42269882559776306,0,0.047475691884756088,0\nGetPositionOnCurveArcLength|0.53125\tu:0.39186102151870728,0,0.09428415447473526,0\nGetTangentOnCurve|0.53125\tv:-9.7265625,26.421875\nGetTangentOnCurveArcLength|0.53125\tv:-51.272293090820312,32.345115661621094\nGetPositionOnCurve|0.59375\tu:0.4104539155960083,0,0.072739854454994202,0\nGetPositionOnCurveArcLength|0.59375\tu:0.34318622946739197,0,0.13415618240833282,0\nGetTangentOnCurve|0.59375\tv:-33.1796875,29.765625\nGetTangentOnCurveArcLength|0.59375\tv:-81.418258666992188,36.643074035644531\nGetPositionOnCurve|0.65625\tu:0.38482248783111572,0,0.10101098567247391,0\nGetPositionOnCurveArcLength|0.65625\tu:0.29244256019592285,0,0.16715341806411743,0\nGetTangentOnCurve|0.65625\tv:-56.6328125,33.109375\nGetTangentOnCurveArcLength|0.65625\tv:-103.91840362548828,39.850959777832031\nGetPositionOnCurve|0.71875\tu:0.34580457210540771,0,0.1322890967130661,0\nGetPositionOnCurveArcLength|0.71875\tu:0.24084655940532684,0,0.19670946896076202,0\nGetTangentOnCurve|0.71875\tv:-80.0859375,36.453125\nGetTangentOnCurveArcLength|0.71875\tv:-122.63433837890625,42.519317626953125\nGetPositionOnCurve|0.78125\tu:0.29340016841888428,0,0.16657416522502899,0\nGetPositionOnCurveArcLength|0.78125\tu:0.18877200782299042,0,0.22410881519317627,0\nGetTangentOnCurve|0.78125\tv:-103.5390625,39.796875\nGetTangentOnCurveArcLength|0.78125\tv:-138.99156188964844,44.851394653320312\nGetPositionOnCurve|0.84375\tu:0.2276092916727066,0,0.20386619865894318,0\nGetPositionOnCurveArcLength|0.84375\tu:0.13638664782047272,0,0.24999517202377319,0\nGetTangentOnCurve|0.84375\tv:-126.9921875,43.140625\nGetTangentOnCurveArcLength|0.84375\tv:-153.69993591308594,46.948394775390625\nGetPositionOnCurve|0.90625\tu:0.1484319269657135,0,0.24416521191596985,0\nGetPositionOnCurveArcLength|0.90625\tu:0.083781130611896515,0,0.27474504709243774,0\nGetTangentOnCurve|0.90625\tv:-150.4453125,46.484375\nGetTangentOnCurveArcLength|0.90625\tv:-167.17289733886719,48.869255065917969\nGetPositionOnCurve|0.96875\tu:0.05586807057261467,0,0.28747120499610901,0\nGetPositionOnCurveArcLength|0.96875\tu:0.031011015176773071,0,0.29860076308250427,0\nGetTangentOnCurve|0.96875\tv:-173.8984375,49.828125\nGetTangentOnCurveArcLength|0.96875\tv:-179.67585754394531,50.651821136474609\nGetPositionOnCurve|0.030303031206130981\tu:0.4752880334854126,0,0.52106034755706787,0\nGetPositionOnCurveArcLength|0.030303031206130981\tu:0.47369515895843506,0,0.51902949810028076,0\nGetTangentOnCurve|0.030303031206130981\tv:-72.264808654785156,-57.88946533203125\nGetTangentOnCurveArcLength|0.030303031206130981\tv:-72.143714904785156,-58.967918395996094\nGetPositionOnCurve|0.060606062412261963\tu:0.45554924011230469,0,0.49301683902740479,0\nGetPositionOnCurveArcLength|0.060606062412261963\tu:0.45408850908279419,0,0.490692138671875,0\nGetTangentOnCurve|0.060606062412261963\tv:-70.184226989746094,-70.364669799804688\nGetTangentOnCurveArcLength|0.060606062412261963\tv:-69.978103637695312,-71.211578369140625\nGetPositionOnCurve|0.12121212482452393\tu:0.41864326596260071,0,0.42310702800750732,0\nGetPositionOnCurveArcLength|0.12121212482452393\tu:0.42007112503051758,0,0.42627689242362976,0\nGetTangentOnCurve|0.12121212482452393\tv:-62.361915588378906,-88.447311401367188\nGetTangentOnCurveArcLength|0.12121212482452393\tv:-62.780902862548828,-87.882766723632812\nGetPositionOnCurve|0.15151515603065491\tu:0.40215155482292175,0,0.38323706388473511,0\nGetPositionOnCurveArcLength|0.15151515603065491\tu:0.40531304478645325,0,0.39138075709342957,0\nGetTangentOnCurve|0.15151515603065491\tv:-56.62017822265625,-94.05474853515625\nGetTangentOnCurveArcLength|0.15151515603065491\tv:-57.86346435546875,-93.118576049804688\nGetPositionOnCurve|0.21212121844291687\tu:0.37477940320968628,0,0.29865768551826477,0\nGetPositionOnCurveArcLength|0.21212121844291687\tu:0.38007703423500061,0,0.31758314371109009,0\nGetTangentOnCurve|0.21212121844291687\tv:-41.475547790527344,-98.401863098144531\nGetTangentOnCurveArcLength|0.21212121844291687\tv:-45.237129211425781,-98.22998046875\nGetPositionOnCurve|0.24242424964904785\tu:0.36457440257072449,0,0.25594457983970642,0\nGetPositionOnCurveArcLength|0.24242424964904785\tu:0.36975935101509094,0,0.27893006801605225,0\nGetTangentOnCurve|0.24242424964904785\tv:-32.072654724121094,-97.141525268554688\nGetTangentOnCurveArcLength|0.24242424964904785\tv:-37.2989501953125,-98.1060791015625\nGetPositionOnCurve|0.30303031206130981\tu:0.352815181016922,0,0.17466233670711517,0\nGetPositionOnCurveArcLength|0.30303031206130981\tu:0.35505324602127075,0,0.19842930138111115,0\nGetTangentOnCurve|0.30303031206130981\tv:-9.605712890625,-87.753097534179688\nGetTangentOnCurveArcLength|0.30303031206130981\tv:-16.945766448974609,-91.572898864746094\nGetPositionOnCurve|0.39393940567970276\tu:0.36186924576759338,0,0.078071102499961853,0\nGetPositionOnCurveArcLength|0.39393940567970276\tu:0.36269742250442505,0,0.07592378556728363,0\nGetTangentOnCurve|0.39393940567970276\tv:33.247596740722656,-56.501026153564453\nGetTangentOnCurveArcLength|0.39393940567970276\tv:34.672393798828125,-55.271572113037109\nGetPositionOnCurve|0.42424243688583374\tu:0.37335631251335144,0,0.05662185326218605,0\nGetPositionOnCurveArcLength|0.42424243688583374\tu:0.38190475106239319,0,0.047585029155015945,0\nGetTangentOnCurve|0.42424243688583374\tv:49.972801208496094,-41.505168914794922\nGetTangentOnCurveArcLength|0.42424243688583374\tv:59.91741943359375,-32.063591003417969\nGetPositionOnCurve|0.4848484992980957\tu:0.4110603928565979,0,0.035834003239870071,0\nGetPositionOnCurveArcLength|0.4848484992980957\tu:0.42161586880683899,0,0.051389236003160477,0\nGetTangentOnCurve|0.4848484992980957\tv:87.084381103515625,-4.6456527709960938\nGetTangentOnCurveArcLength|0.4848484992980957\tv:-13.550009727478027,26.966989517211914\nGetPositionOnCurve|0.5151515007019043\tu:0.42368477582931519,0,0.041455261409282684,0\nGetPositionOnCurveArcLength|0.5151515007019043\tu:0.40351948142051697,0,0.081684499979019165,0\nGetTangentOnCurve|0.5151515007019043\tv:-3.685600757598877,25.560606002807617\nGetTangentOnCurveArcLength|0.5151515007019043\tv:-40.87493896484375,30.862749099731445\nGetPositionOnCurve|0.57575756311416626\tu:0.41535109281539917,0,0.06515861302614212,0\nGetPositionOnCurveArcLength|0.57575756311416626\tu:0.35751712322235107,0,0.12365508824586868,0\nGetTangentOnCurve|0.57575756311416626\tv:-26.42802619934082,28.803030014038086\nGetTangentOnCurveArcLength|0.57575756311416626\tv:-73.832389831542969,35.561546325683594\nGetPositionOnCurve|0.60606062412261963\tu:0.40646398067474365,0,0.078070603311061859,0\nGetPositionOnCurveArcLength|0.60606062412261963\tu:0.33329212665557861,0,0.1410333663225174,0\nGetTangentOnCurve|0.60606062412261963\tv:-37.799247741699219,30.424243927001953\nGetTangentOnCurveArcLength|0.60606062412261963\tv:-86.267181396484375,37.334396362304688\nGetPositionOnCurve|0.69696968793869019\tu:0.36092141270637512,0,0.12104777991771698,0\nGetPositionOnCurveArcLength|0.69696968793869019\tu:0.25889378786087036,0,0.1867002546787262,0\nGetTangentOnCurve|0.69696968793869019\tv:-71.912872314453125,35.287879943847656\nGetTangentOnCurveArcLength|0.69696968793869019\tv:-116.43051147460938,41.634830474853516\nGetPositionOnCurve|0.75757575035095215\tu:0.31482529640197754,0,0.153233602643013,0\nGetPositionOnCurveArcLength|0.75757575035095215\tu:0.20854057371616364,0,0.21393504738807678,0\nGetTangentOnCurve|0.75757575035095215\tv:-94.655303955078125,38.530303955078125\nGetTangentOnCurveArcLength|0.75757575035095215\tv:-133.01908874511719,43.999893188476562\nGetPositionOnCurve|0.78787881135940552\tu:0.28705692291259766,0,0.17038685083389282,0\nGetPositionOnCurveArcLength|0.78787881135940552\tu:0.1832287460565567,0,0.22691790759563446,0\nGetTangentOnCurve|0.78787881135940552\tv:-106.02652740478516,40.151515960693359\nGetTangentOnCurveArcLength|0.78787881135940552\tv:-140.62075805664062,45.083671569824219\nGetPositionOnCurve|0.84848487377166748\tu:0.22207961976528168,0,0.20681390166282654,0\nGetPositionOnCurveArcLength|0.84848487377166748\tu:0.13240820169448853,0,0.25190630555152893,0\nGetTangentOnCurve|0.84848487377166748\tv:-128.76895141601562,43.393939971923828\nGetTangentOnCurveArcLength|0.84848487377166748\tv:-154.75987243652344,47.099510192871094\nGetPositionOnCurve|0.87878787517547607\tu:0.18487071990966797,0,0.22608771920204163,0\nGetPositionOnCurveArcLength|0.87878787517547607\tu:0.10691868513822556,0,0.2639923095703125,0\nGetTangentOnCurve|0.87878787517547607\tv:-140.14015197753906,45.015151977539062\nGetTangentOnCurveArcLength|0.87878787517547607\tv:-161.38568115234375,48.044162750244141\nGetPositionOnCurve|0.93939393758773804\tu:0.1010122075676918,0,0.26675602793693542,0\nGetPositionOnCurveArcLength|0.93939393758773804\tu:0.055814977735280991,0,0.28749516606330872,0\nGetTangentOnCurve|0.93939393758773804\tv:-162.882568359375,48.257575988769531\nGetTangentOnCurveArcLength|0.93939393758773804\tv:-173.91098022460938,49.829914093017578\nGetPositionOnCurve|0.96969699859619141\tu:0.054362606257200241,0,0.28815051913261414,0\nGetPositionOnCurveArcLength|0.96969699859619141\tu:0.030210381373763084,0,0.29895627498626709,0\nGetTangentOnCurve|0.96969699859619141\tv:-174.25379943847656,49.878791809082031\nGetTangentOnCurveArcLength|0.96969699859619141\tv:-179.85885620117188,50.677909851074219\nGetPositionOnCurve|0.029411764815449715\tu:0.47587642073631287,0,0.52180022001266479,0\nGetPositionOnCurveArcLength|0.029411764815449715\tu:0.47430229187011719,0,0.51980835199356079,0\nGetTangentOnCurve|0.029411764815449715\tv:-72.307525634765625,-57.487888336181641\nGetTangentOnCurveArcLength|0.029411764815449715\tv:-72.190803527832031,-58.558380126953125\nGetPositionOnCurve|0.088235296308994293\tu:0.43819242715835571,0,0.46311649680137634,0\nGetPositionOnCurveArcLength|0.088235296308994293\tu:0.43779218196868896,0,0.46236711740493774,0\nGetTangentOnCurve|0.088235296308994293\tv:-67.223617553710938,-79.743942260742188\nGetTangentOnCurveArcLength|0.088235296308994293\tv:-67.141456604003906,-79.942398071289062\nGetPositionOnCurve|0.14705882966518402\tu:0.40447467565536499,0,0.38924625515937805,0\nGetPositionOnCurveArcLength|0.14705882966518402\tu:0.4073944091796875,0,0.39660444855690002,0\nGetTangentOnCurve|0.14705882966518402\tv:-57.541088104248047,-93.373703002929688\nGetTangentOnCurveArcLength|0.14705882966518402\tv:-58.641929626464844,-92.464324951171875\nGetPositionOnCurve|0.20588235557079315\tu:0.37719357013702393,0,0.30749061703681946,0\nGetPositionOnCurveArcLength|0.20588235557079315\tu:0.38240242004394531,0,0.32540196180343628,0\nGetTangentOnCurve|0.20588235557079315\tv:-43.25994873046875,-98.377166748046875\nGetTangentOnCurveArcLength|0.20588235557079315\tv:-46.725048065185547,-98.028289794921875\nGetPositionOnCurve|0.26470589637756348\tu:0.35881954431533813,0,0.22515067458152771,0\nGetPositionOnCurveArcLength|0.26470589637756348\tu:0.36331665515899658,0,0.24981439113616943,0\nGetTangentOnCurve|0.26470589637756348\tv:-24.38018798828125,-94.754318237304688\nGetTangentOnCurveArcLength|0.26470589637756348\tv:-30.607872009277344,-96.768722534179688\nGetPositionOnCurve|0.32352942228317261\tu:0.35182291269302368,0,0.1495276540517807,0\nGetPositionOnCurveArcLength|0.32352942228317261\tu:0.35253611207008362,0,0.1703457236289978,0\nGetTangentOnCurve|0.32352942228317261\tv:-0.9018096923828125,-82.50518798828125\nGetTangentOnCurveArcLength|0.32352942228317261\tv:-8.1864089965820312,-86.946914672851562\nGetPositionOnCurve|0.38235294818878174\tu:0.35867407917976379,0,0.087922625243663788,0\nGetPositionOnCurveArcLength|0.38235294818878174\tu:0.35806289315223694,0,0.090179525315761566,0\nGetTangentOnCurve|0.38235294818878174\tv:27.175178527832031,-61.6297607421875\nGetTangentOnCurveArcLength|0.38235294818878174\tv:25.876510620117188,-62.70220947265625\nGetPositionOnCurve|0.44117647409439087\tu:0.3818434476852417,0,0.047636788338422775,0\nGetPositionOnCurveArcLength|0.44117647409439087\tu:0.39577966928482056,0,0.039302412420511246,0\nGetTangentOnCurve|0.44117647409439087\tv:59.850784301757812,-32.128009796142578\nGetTangentOnCurveArcLength|0.44117647409439087\tv:73.78851318359375,-18.336984634399414\nGetPositionOnCurve|0.55882352590560913\tu:0.41894680261611938,0,0.058250974863767624,0\nGetPositionOnCurveArcLength|0.55882352590560913\tu:0.37081855535507202,0,0.11316394805908203,0\nGetTangentOnCurve|0.55882352590560913\tv:-20.073528289794922,27.897058486938477\nGetTangentOnCurveArcLength|0.55882352590560913\tv:-66.015998840332031,34.447151184082031\nGetPositionOnCurve|0.61764705181121826\tu:0.40223431587219238,0,0.083194345235824585,0\nGetPositionOnCurveArcLength|0.61764705181121826\tu:0.3239271342754364,0,0.14731362462043762,0\nGetTangentOnCurve|0.61764705181121826\tv:-42.147056579589844,31.044116973876953\nGetTangentOnCurveArcLength|0.61764705181121826\tv:-90.61810302734375,37.9547119140625\nGetPositionOnCurve|0.67647057771682739\tu:0.37366390228271484,0,0.11080131679773331,0\nGetPositionOnCurveArcLength|0.67647057771682739\tu:0.27581813931465149,0,0.17700991034507751,0\nGetTangentOnCurve|0.67647057771682739\tv:-64.2205810546875,34.191177368164062\nGetTangentOnCurveArcLength|0.67647057771682739\tv:-110.29608154296875,40.760234832763672\nGetPositionOnCurve|0.73529410362243652\tu:0.33323559165000916,0,0.14107191562652588,0\nGetPositionOnCurveArcLength|0.73529410362243652\tu:0.22709968686103821,0,0.20413887500762939,0\nGetTangentOnCurve|0.73529410362243652\tv:-86.294113159179688,37.338233947753906\nGetTangentOnCurveArcLength|0.73529410362243652\tv:-127.15696716308594,43.164119720458984\nGetPositionOnCurve|0.79411762952804565\tu:0.28094932436943054,0,0.17400611937046051,0\nGetPositionOnCurveArcLength|0.79411762952804565\tu:0.17800849676132202,0,0.229546919465065,0\nGetTangentOnCurve|0.79411762952804565\tv:-108.36763763427734,40.485294342041016\nGetTangentOnCurveArcLength|0.79411762952804565\tv:-142.13795471191406,45.299980163574219\nGetPositionOnCurve|0.85294115543365479\tu:0.21680514514446259,0,0.2096039354801178,0\nGetPositionOnCurveArcLength|0.85294115543365479\tu:0.12866280972957611,0,0.25369915366172791,0\nGetTangentOnCurve|0.85294115543365479\tv:-130.441162109375,43.632350921630859\nGetTangentOnCurveArcLength|0.85294115543365479\tv:-155.75112915039062,47.240833282470703\nGetPositionOnCurve|0.91176468133926392\tu:0.14080303907394409,0,0.24786536395549774,0\nGetPositionOnCurveArcLength|0.91176468133926392\tu:0.079131036996841431,0,0.27688303589820862,0\nGetTangentOnCurve|0.91176468133926392\tv:-152.51469421386719,46.779411315917969\nGetTangentOnCurveArcLength|0.91176468133926392\tv:-168.31198120117188,49.031654357910156\nGetPositionOnCurve|0.97058820724487305\tu:0.052942980080842972,0,0.28879040479660034,0\nGetPositionOnCurveArcLength|0.97058820724487305\tu:0.029456917196512222,0,0.29929065704345703,0\nGetTangentOnCurve|0.97058820724487305\tv:-174.58822631835938,49.926467895507812\nGetTangentOnCurveArcLength|0.97058820724487305\tv:-180.03091430664062,50.702442169189453\nGetPositionOnCurve|0.02857142873108387\tu:0.47643148899078369,0,0.52249300479888916,0\nGetPositionOnCurveArcLength|0.02857142873108387\tu:0.47487640380859375,0,0.52053940296173096,0\nGetTangentOnCurve|0.02857142873108387\tv:-72.346839904785156,-57.107448577880859\nGetTangentOnCurveArcLength|0.02857142873108387\tv:-72.234275817871094,-58.169395446777344\nGetPositionOnCurve|0.05714285746216774\tu:0.45777377486228943,0,0.49649065732955933,0\nGetPositionOnCurveArcLength|0.05714285746216774\tu:0.45623260736465454,0,0.49409249424934387,0\nGetTangentOnCurve|0.05714285746216774\tv:-70.483772277832031,-69.054794311523438\nGetTangentOnCurveArcLength|0.05714285746216774\tv:-70.278083801269531,-69.964874267578125\nGetPositionOnCurve|0.085714288055896759\tu:0.43974369764328003,0,0.46599507331848145,0\nGetPositionOnCurveArcLength|0.085714288055896759\tu:0.43922197818756104,0,0.46503156423568726,0\nGetTangentOnCurve|0.085714288055896759\tv:-67.535812377929688,-78.967041015625\nGetTangentOnCurveArcLength|0.085714288055896759\tv:-67.431922912597656,-79.229690551757812\nGetPositionOnCurve|0.11428571492433548\tu:0.4226243793964386,0,0.4318428635597229,0\nGetPositionOnCurveArcLength|0.11428571492433548\tu:0.42364606261253357,0,0.43403398990631104,0\nGetTangentOnCurve|0.11428571492433548\tv:-63.502960205078125,-86.84417724609375\nGetTangentOnCurveArcLength|0.11428571492433548\tv:-63.782394409179688,-86.418304443359375\nGetPositionOnCurve|0.17142857611179352\tu:0.39225026965141296,0,0.35591518878936768,0\nGetPositionOnCurveArcLength|0.17142857611179352\tu:0.3963848352432251,0,0.36768218874931335,0\nGetTangentOnCurve|0.17142857611179352\tv:-52.182548522949219,-96.4931640625\nGetTangentOnCurveArcLength|0.17142857611179352\tv:-54.144493103027344,-95.571517944335938\nGetPositionOnCurve|0.22857142984867096\tu:0.36891606450080872,0,0.27540063858032227,0\nGetPositionOnCurveArcLength|0.22857142984867096\tu:0.37426811456680298,0,0.29673737287521362,0\nGetTangentOnCurve|0.22857142984867096\tv:-36.522552490234375,-98.001731872558594\nGetTangentOnCurveArcLength|0.22857142984867096\tv:-41.080768585205078,-98.394386291503906\nGetPositionOnCurve|0.25714287161827087\tu:0.36059659719467163,0,0.23551484942436218,0\nGetPositionOnCurveArcLength|0.25714287161827087\tu:0.36538463830947876,0,0.25976169109344482,0\nGetTangentOnCurve|0.25714287161827087\tv:-27.065200805664062,-95.703369140625\nGetTangentOnCurveArcLength|0.25714287161827087\tv:-32.969131469726562,-97.3487548828125\nGetPositionOnCurve|0.31428572535514832\tu:0.35206839442253113,0,0.1606694757938385,0\nGetPositionOnCurveArcLength|0.31428572535514832\tu:0.35347414016723633,0,0.18305268883705139,0\nGetTangentOnCurve|0.31428572535514832\tv:-4.89581298828125,-85.001327514648438\nGetTangentOnCurveArcLength|0.31428572535514832\tv:-12.284961700439453,-89.217529296875\nGetPositionOnCurve|0.34285715222358704\tu:0.35242584347724915,0,0.12738311290740967,0\nGetPositionOnCurveArcLength|0.34285715222358704\tu:0.35183215141296387,0,0.14363215863704681,0\nGetTangentOnCurve|0.34285715222358704\tv:7.8162307739257812,-76.597640991210938\nGetTangentOnCurveArcLength|0.34285715222358704\tv:1.3102035522460938,-81.063385009765625\nGetPositionOnCurve|0.37142857909202576\tu:0.35624173283576965,0,0.097969770431518555,0\nGetPositionOnCurveArcLength|0.37142857909202576\tu:0.35501646995544434,0,0.10450549423694611,0\nGetTangentOnCurve|0.37142857909202576\tv:21.613166809082031,-66.15887451171875\nGetTangentOnCurveArcLength|0.37142857909202576\tv:18.26544189453125,-68.801101684570312\nGetPositionOnCurve|0.45714285969734192\tu:0.39127075672149658,0,0.041334576904773712,0\nGetPositionOnCurveArcLength|0.45714285969734192\tu:0.40962687134742737,0,0.035971496254205704,0\nGetTangentOnCurve|0.45714285969734192\tv:69.51336669921875,-22.631919860839844\nGetTangentOnCurveArcLength|0.45714285969734192\tv:85.902175903320312,-5.8824081420898438\nGetPositionOnCurve|0.48571428656578064\tu:0.41175118088722229,0,0.035779774188995361,0\nGetPositionOnCurveArcLength|0.48571428656578064\tu:0.42126497626304626,0,0.052452333271503448,0\nGetTangentOnCurve|0.48571428656578064\tv:87.64990234375,-4.0527496337890625\nGetTangentOnCurveArcLength|0.48571428656578064\tv:-14.575355529785156,27.113174438476562\nGetPositionOnCurve|0.51428574323654175\tu:0.42371261119842529,0,0.041137143969535828,0\nGetPositionOnCurveArcLength|0.51428574323654175\tu:0.40412509441375732,0,0.08095964789390564,0\nGetTangentOnCurve|0.51428574323654175\tv:-3.360724925994873,25.514287948608398\nGetTangentOnCurveArcLength|0.51428574323654175\tv:-40.261547088623047,30.775297164916992\nGetPositionOnCurve|0.54285717010498047\tu:0.42143696546554565,0,0.051940251141786575,0\nGetPositionOnCurveArcLength|0.54285717010498047\tu:0.38312381505966187,0,0.10256306082010269,0\nGetTangentOnCurve|0.54285717010498047\tv:-14.0821533203125,27.042858123779297\nGetTangentOnCurveArcLength|0.54285717010498047\tv:-57.852165222167969,33.283218383789062\nGetPositionOnCurve|0.62857145071029663\tu:0.39782500267028809,0,0.088119961321353912,0\nGetPositionOnCurveArcLength|0.62857145071029663\tu:0.31505721807479858,0,0.15308481454849243,0\nGetTangentOnCurve|0.62857145071029663\tv:-46.246437072753906,31.628572463989258\nGetTangentOnCurveArcLength|0.62857145071029663\tv:-94.554573059082031,38.515941619873047\nGetPositionOnCurve|0.65714287757873535\tu:0.38435932993888855,0,0.10143665969371796,0\nGetPositionOnCurveArcLength|0.65714287757873535\tu:0.29171010851860046,0,0.16759555041790009,0\nGetTangentOnCurve|0.65714287757873535\tv:-56.967864990234375,33.157142639160156\nGetTangentOnCurveArcLength|0.65714287757873535\tv:-104.20761108398438,39.892189025878906\nGetPositionOnCurve|0.68571430444717407\tu:0.36809617280960083,0,0.11538174748420715,0\nGetPositionOnCurveArcLength|0.68571430444717407\tu:0.26819443702697754,0,0.18141452968120575,0\nGetTangentOnCurve|0.68571430444717407\tv:-67.689292907714844,34.685714721679688\nGetTangentOnCurveArcLength|0.68571430444717407\tv:-113.10057067871094,41.160072326660156\nGetPositionOnCurve|0.74285715818405151\tu:0.32717731595039368,0,0.1451571136713028,0\nGetPositionOnCurveArcLength|0.74285715818405151\tu:0.22080560028553009,0,0.2074897289276123,0\nGetTangentOnCurve|0.74285715818405151\tv:-89.132148742675781,37.74285888671875\nGetTangentOnCurveArcLength|0.74285715818405151\tv:-129.17485046386719,43.451812744140625\nGetPositionOnCurve|0.77142858505249023\tu:0.30252164602279663,0,0.16098739206790924,0\nGetPositionOnCurveArcLength|0.77142858505249023\tu:0.19697877764701843,0,0.21991567313671112,0\nGetTangentOnCurve|0.77142858505249023\tv:-99.85357666015625,39.271430969238281\nGetTangentOnCurveArcLength|0.77142858505249023\tv:-136.54385375976562,44.502418518066406\nGetPositionOnCurve|0.82857143878936768\tu:0.24481780827045441,0,0.19453310966491699,0\nGetPositionOnCurveArcLength|0.82857143878936768\tu:0.14913174510002136,0,0.24382442235946655,0\nGetTangentOnCurve|0.82857143878936768\tv:-121.29643249511719,42.328571319580078\nGetTangentOnCurveArcLength|0.82857143878936768\tv:-150.25405883789062,46.457107543945312\nGetPositionOnCurve|0.88571429252624512\tu:0.17592394351959229,0,0.23059241473674774,0\nGetPositionOnCurveArcLength|0.88571429252624512\tu:0.10108623653650284,0,0.2667214572429657,0\nGetTangentOnCurve|0.88571429252624512\tv:-142.73928833007812,45.385715484619141\nGetTangentOnCurveArcLength|0.88571429252624512\tv:-162.8638916015625,48.254913330078125\nGetPositionOnCurve|0.91428571939468384\tu:0.13728077709674835,0,0.24956469237804413,0\nGetPositionOnCurveArcLength|0.91428571939468384\tu:0.077004909515380859,0,0.27785813808441162,0\nGetTangentOnCurve|0.91428571939468384\tv:-153.46070861816406,46.914283752441406\nGetTangentOnCurveArcLength|0.91428571939468384\tv:-168.83023071289062,49.105545043945312\nGetPositionOnCurve|0.94285714626312256\tu:0.095840074121952057,0,0.26916530728340149,0\nGetPositionOnCurveArcLength|0.94285714626312256\tu:0.052890341728925705,0,0.28881412744522095,0\nGetTangentOnCurve|0.94285714626312256\tv:-164.18214416503906,48.442855834960938\nGetTangentOnCurveArcLength|0.94285714626312256\tv:-174.60061645507812,49.928237915039062\nGetPositionOnCurve|0.97142857313156128\tu:0.051601916551589966,0,0.28939434885978699,0\nGetPositionOnCurveArcLength|0.97142857313156128\tu:0.028746373951435089,0,0.29960587620735168,0\nGetTangentOnCurve|0.97142857313156128\tv:-174.903564453125,49.971427917480469\nGetTangentOnCurveArcLength|0.97142857313156128\tv:-180.19300842285156,50.725551605224609\nGetPositionOnCurve|0.02777777798473835\tu:0.47695598006248474,0,0.52314305305480957,0\nGetPositionOnCurveArcLength|0.02777777798473835\tu:0.47542014718055725,0,0.52122694253921509,0\nGetTangentOnCurve|0.02777777798473835\tv:-72.383102416992188,-56.746528625488281\nGetTangentOnCurveArcLength|0.02777777798473835\tv:-72.274490356445312,-57.799465179443359\nGetPositionOnCurve|0.1388888955116272\tu:0.40882888436317444,0,0.40014329552650452,0\nGetPositionOnCurveArcLength|0.1388888955116272\tu:0.41128954291343689,0,0.40610146522521973,0\nGetTangentOnCurve|0.1388888955116272\tv:-59.160877227783203,-91.996528625488281\nGetTangentOnCurveArcLength|0.1388888955116272\tv:-60.019180297851562,-91.162834167480469\nGetPositionOnCurve|0.1944444477558136\tu:0.38187766075134277,0,0.32366096973419189,0\nGetPositionOnCurveArcLength|0.1944444477558136\tu:0.38683342933654785,0,0.33960950374603271,0\nGetTangentOnCurve|0.1944444477558136\tv:-46.396987915039062,-98.079864501953125\nGetTangentOnCurveArcLength|0.1944444477558136\tv:-49.333961486816406,-97.46356201171875\nGetPositionOnCurve|0.3055555522441864\tu:0.35260564088821411,0,0.1714845597743988,0\nGetPositionOnCurveArcLength|0.3055555522441864\tu:0.3546602725982666,0,0.19498945772647858,0\nGetTangentOnCurve|0.3055555522441864\tv:-8.56365966796875,-87.1632080078125\nGetTangentOnCurveArcLength|0.3055555522441864\tv:-15.929447174072266,-91.081230163574219\nGetPositionOnCurve|0.3611111044883728\tu:0.35444697737693787,0,0.10809177905321121,0\nGetPositionOnCurveArcLength|0.3611111044883728\tu:0.35315805673599243,0,0.11847535520792007,0\nGetTangentOnCurve|0.3611111044883728\tv:16.505775451660156,-70.1632080078125\nGetTangentOnCurveArcLength|0.3611111044883728\tv:11.679763793945312,-73.79901123046875\nGetPositionOnCurve|0.47222220897674561\tu:0.40148982405662537,0,0.037450172007083893,0\nGetPositionOnCurveArcLength|0.47222220897674561\tu:0.42286491394042969,0,0.035885598510503769,0\nGetTangentOnCurve|0.47222220897674561\tv:78.950225830078125,-13.079862594604492\nGetTangentOnCurveArcLength|0.47222220897674561\tv:96.412841796875,5.2368240356445312\nGetPositionOnCurve|0.52777779102325439\tu:0.42298659682273865,0,0.046160299330949783,0\nGetPositionOnCurveArcLength|0.52777779102325439\tu:0.39442884922027588,0,0.091690614819526672,0\nGetTangentOnCurve|0.52777779102325439\tv:-8.4236164093017578,26.236112594604492\nGetTangentOnCurveArcLength|0.52777779102325439\tv:-49.171390533447266,32.045589447021484\nGetPositionOnCurve|0.6388888955116272\tu:0.39328506588935852,0,0.092856280505657196,0\nGetPositionOnCurveArcLength|0.6388888955116272\tu:0.30664914846420288,0,0.15841569006443024,0\nGetTangentOnCurve|0.6388888955116272\tv:-50.118057250976562,32.180557250976562\nGetTangentOnCurveArcLength|0.6388888955116272\tv:-98.140403747558594,39.027179718017578\nGetPositionOnCurve|0.69444441795349121\tu:0.36256888508796692,0,0.11976807564496994,0\nGetPositionOnCurveArcLength|0.69444441795349121\tu:0.26098206639289856,0,0.18552146852016449,0\nGetTangentOnCurve|0.69444441795349121\tv:-70.96527099609375,35.152778625488281\nGetTangentOnCurveArcLength|0.69444441795349121\tv:-115.69118499755859,41.529422760009766\nGetPositionOnCurve|0.80555558204650879\tu:0.26940548419952393,0,0.18071931600570679,0\nGetPositionOnCurveArcLength|0.80555558204650879\tu:0.16843077540397644,0,0.23433081805706024,0\nGetTangentOnCurve|0.80555558204650879\tv:-112.65972900390625,41.097221374511719\nGetTangentOnCurveArcLength|0.80555558204650879\tv:-144.88026428222656,45.690956115722656\nGetPositionOnCurve|0.8611111044883728\tu:0.20695836842060089,0,0.2147587388753891,0\nGetPositionOnCurveArcLength|0.8611111044883728\tu:0.12179332226514816,0,0.25697192549705505,0\nGetTangentOnCurve|0.8611111044883728\tv:-133.50694274902344,44.069442749023438\nGetTangentOnCurveArcLength|0.8611111044883728\tv:-157.55299377441406,47.497726440429688\nGetPositionOnCurve|0.97222220897674561\tu:0.050333134829998016,0,0.28996524214744568,0\nGetPositionOnCurveArcLength|0.97222220897674561\tu:0.028075335547327995,0,0.29990342259407043,0\nGetTangentOnCurve|0.97222220897674561\tv:-175.20138549804688,50.013885498046875\nGetTangentOnCurveArcLength|0.97222220897674561\tv:-180.34596252441406,50.747360229492188\nGetPositionOnCurve|0.027027027681469917\tu:0.47745239734649658,0,0.52375417947769165,0\nGetPositionOnCurveArcLength|0.027027027681469917\tu:0.47593584656715393,0,0.52187460660934448,0\nGetTangentOnCurve|0.027027027681469917\tv:-72.416633605957031,-56.403671264648438\nGetTangentOnCurveArcLength|0.027027027681469917\tv:-72.311782836914062,-57.447231292724609\nGetPositionOnCurve|0.054054055362939835\tu:0.45976561307907104,0,0.49953323602676392,0\nGetPositionOnCurveArcLength|0.054054055362939835\tu:0.45816507935523987,0,0.49709340929985046,0\nGetTangentOnCurve|0.054054055362939835\tv:-70.73748779296875,-67.861305236816406\nGetTangentOnCurveArcLength|0.054054055362939835\tv:-70.534690856933594,-68.821868896484375\nGetPositionOnCurve|0.081081077456474304\tu:0.44261309504508972,0,0.47121071815490723,0\nGetPositionOnCurveArcLength|0.081081077456474304\tu:0.4418787956237793,0,0.46988937258720398,0\nGetTangentOnCurve|0.081081077456474304\tv:-68.087562561035156,-77.497894287109375\nGetTangentOnCurveArcLength|0.081081077456474304\tv:-67.949501037597656,-77.877815246582031\nGetPositionOnCurve|0.10810811072587967\tu:0.42623442411422729,0,0.439494788646698,0\nGetPositionOnCurveArcLength|0.10810811072587967\tu:0.42689940333366394,0,0.44087707996368408,0\nGetTangentOnCurve|0.10810811072587967\tv:-64.46685791015625,-85.313461303710938\nGetTangentOnCurveArcLength|0.10810811072587967\tv:-64.637374877929688,-85.023696899414062\nGetPositionOnCurve|0.13513512909412384\tu:0.41086927056312561,0,0.40509366989135742,0\nGetPositionOnCurveArcLength|0.13513512909412384\tu:0.41311371326446533,0,0.41042941808700562,0\nGetTangentOnCurve|0.13513512909412384\tv:-59.8753662109375,-91.3079833984375\nGetTangentOnCurveArcLength|0.13513512909412384\tv:-60.6304931640625,-90.519989013671875\nGetPositionOnCurve|0.16216215491294861\tu:0.39675715565681458,0,0.36871552467346191,0\nGetPositionOnCurveArcLength|0.16216215491294861\tu:0.40046361088752747,0,0.37878087162971497,0\nGetTangentOnCurve|0.16216215491294861\tv:-54.313095092773438,-95.481460571289062\nGetTangentOnCurveArcLength|0.16216215491294861\tv:-55.924530029296875,-94.5250244140625\nGetPositionOnCurve|0.18918919563293457\tu:0.38413777947425842,0,0.33106839656829834,0\nGetPositionOnCurveArcLength|0.18918919563293457\tu:0.38894054293632507,0,0.34608113765716553,0\nGetTangentOnCurve|0.18918919563293457\tv:-47.780036926269531,-97.833908081054688\nGetTangentOnCurveArcLength|0.18918919563293457\tv:-50.482872009277344,-97.1202392578125\nGetPositionOnCurve|0.21621622145175934\tu:0.37325066328048706,0,0.29286059737205505,0\nGetPositionOnCurveArcLength|0.21621622145175934\tu:0.37858664989471436,0,0.31242480874061584,0\nGetTangentOnCurve|0.21621622145175934\tv:-40.276203155517578,-98.365325927734375\nGetTangentOnCurveArcLength|0.21621622145175934\tv:-44.234668731689453,-98.321090698242188\nGetPositionOnCurve|0.24324324727058411\tu:0.36433553695678711,0,0.25480026006698608,0\nGetPositionOnCurveArcLength|0.24324324727058411\tu:0.36950433254241943,0,0.2778700590133667,0\nGetTangentOnCurve|0.24324324727058411\tv:-31.801586151123047,-97.07568359375\nGetTangentOnCurveArcLength|0.24324324727058411\tv:-37.066734313964844,-98.076393127441406\nGetPositionOnCurve|0.27027025818824768\tu:0.3576318621635437,0,0.21759548783302307,0\nGetPositionOnCurveArcLength|0.27027025818824768\tu:0.36187863349914551,0,0.24245403707027435,0\nGetTangentOnCurve|0.27027025818824768\tv:-22.356193542480469,-93.96502685546875\nGetTangentOnCurveArcLength|0.27027025818824768\tv:-28.806972503662109,-96.255020141601562\nGetPositionOnCurve|0.29729729890823364\tu:0.35337936878204346,0,0.18195444345474243,0\nGetPositionOnCurveArcLength|0.29729729890823364\tu:0.35602301359176636,0,0.20621523261070251,0\nGetTangentOnCurve|0.29729729890823364\tv:-11.940010070800781,-89.0333251953125\nGetTangentOnCurveArcLength|0.29729729890823364\tv:-19.193729400634766,-92.614242553710938\nGetPositionOnCurve|0.32432430982589722\tu:0.35181763768196106,0,0.14858531951904297,0\nGetPositionOnCurveArcLength|0.32432430982589722\tu:0.35247203707695007,0,0.16925029456615448,0\nGetTangentOnCurve|0.32432430982589722\tv:-0.5530548095703125,-82.280593872070312\nGetTangentOnCurveArcLength|0.32432430982589722\tv:-7.82159423828125,-86.736419677734375\nGetPositionOnCurve|0.35135135054588318\tu:0.35318624973297119,0,0.11819625645875931,0\nGetPositionOnCurveArcLength|0.35135135054588318\tu:0.3521711528301239,0,0.13188976049423218,0\nGetTangentOnCurve|0.35135135054588318\tv:11.8046875,-73.706817626953125\nGetTangentOnCurveArcLength|0.35135135054588318\tv:5.946441650390625,-77.913955688476562\nGetPositionOnCurve|0.37837839126586914\tu:0.35772481560707092,0,0.09149537980556488,0\nGetPositionOnCurveArcLength|0.37837839126586914\tu:0.35681483149528503,0,0.095316275954246521,0\nGetTangentOnCurve|0.37837839126586914\tv:25.133224487304688,-63.311996459960938\nGetTangentOnCurveArcLength|0.37837839126586914\tv:23.029518127441406,-65.021629333496094\nGetPositionOnCurve|0.40540540218353271\tu:0.36567297577857971,0,0.069191031157970428,0\nGetPositionOnCurveArcLength|0.40540540218353271\tu:0.36882159113883972,0,0.063355810940265656,0\nGetTangentOnCurve|0.40540540218353271\tv:39.432518005371094,-51.096149444580078\nGetTangentOnCurveArcLength|0.40540540218353271\tv:43.999824523925781,-46.99627685546875\nGetPositionOnCurve|0.43243244290351868\tu:0.37727034091949463,0,0.051991138607263565,0\nGetPositionOnCurveArcLength|0.43243244290351868\tu:0.38845080137252808,0,0.042900852859020233,0\nGetTangentOnCurve|0.43243244290351868\tv:54.702629089355469,-37.059253692626953\nGetTangentOnCurveArcLength|0.43243244290351868\tv:66.735763549804688,-25.392431259155273\nGetPositionOnCurve|0.45945945382118225\tu:0.39275649189949036,0,0.040603965520858765,0\nGetPositionOnCurveArcLength|0.45945945382118225\tu:0.41165846586227417,0,0.035786580294370651,0\nGetTangentOnCurve|0.45945945382118225\tv:70.9434814453125,-21.201318740844727\nGetTangentOnCurveArcLength|0.45945945382118225\tv:87.574203491210938,-4.1321601867675781\nGetPositionOnCurve|0.48648649454116821\tu:0.41237106919288635,0,0.03573773056268692,0\nGetPositionOnCurveArcLength|0.48648649454116821\tu:0.42093679308891296,0,0.05338766798377037,0\nGetTangentOnCurve|0.48648649454116821\tv:88.1551513671875,-3.5223464965820312\nGetTangentOnCurveArcLength|0.48648649454116821\tv:-15.472930908203125,27.241144180297852\nGetPositionOnCurve|0.51351350545883179\tu:0.42373529076576233,0,0.040853872895240784,0\nGetPositionOnCurveArcLength|0.51351350545883179\tu:0.40466293692588806,0,0.080308258533477783,0\nGetTangentOnCurve|0.51351350545883179\tv:-3.0709428787231445,25.472972869873047\nGetTangentOnCurveArcLength|0.51351350545883179\tv:-39.708835601806641,30.696495056152344\nGetPositionOnCurve|0.54054051637649536\tu:0.42172569036483765,0,0.051040895283222198,0\nGetPositionOnCurveArcLength|0.54054051637649536\tu:0.38488414883613586,0,0.10095417499542236,0\nGetTangentOnCurve|0.54054051637649536\tv:-13.212828636169434,26.918918609619141\nGetTangentOnCurveArcLength|0.54054051637649536\tv:-56.588058471679688,33.102993011474609\nGetPositionOnCurve|0.56756758689880371\tu:0.4172128438949585,0,0.061790239065885544,0\nGetPositionOnCurveArcLength|0.56756758689880371\tu:0.36397677659988403,0,0.11866471916437149,0\nGetTangentOnCurve|0.56756758689880371\tv:-23.354736328125,28.364866256713867\nGetTangentOnCurveArcLength|0.56756758689880371\tv:-70.145339965820312,35.035877227783203\nGetPositionOnCurve|0.59459459781646729\tu:0.41019675135612488,0,0.07310185581445694,0\nGetPositionOnCurveArcLength|0.59459459781646729\tu:0.34250950813293457,0,0.13463535904884338,0\nGetTangentOnCurve|0.59459459781646729\tv:-33.496623992919922,29.810810089111328\nGetTangentOnCurveArcLength|0.59459459781646729\tv:-81.759071350097656,36.691665649414062\nGetPositionOnCurve|0.62162160873413086\tu:0.40067744255065918,0,0.084975771605968475,0\nGetPositionOnCurveArcLength|0.62162160873413086\tu:0.32070422172546387,0,0.14942927658557892,0\nGetTangentOnCurve|0.62162160873413086\tv:-43.638507843017578,31.256755828857422\nGetTangentOnCurveArcLength|0.62162160873413086\tv:-92.067893981933594,38.161411285400391\nGetPositionOnCurve|0.64864861965179443\tu:0.38865488767623901,0,0.097411982715129852,0\nGetPositionOnCurveArcLength|0.64864861965179443\tu:0.29867115616798401,0,0.16336143016815186,0\nGetTangentOnCurve|0.64864861965179443\tv:-53.7803955078125,32.702701568603516\nGetTangentOnCurveArcLength|0.64864861965179443\tv:-101.42568206787109,39.495567321777344\nGetPositionOnCurve|0.67567569017410278\tu:0.3741290271282196,0,0.11041051149368286,0\nGetPositionOnCurveArcLength|0.67567569017410278\tu:0.27647298574447632,0,0.17662836611270905,0\nGetTangentOnCurve|0.67567569017410278\tv:-63.92230224609375,34.148651123046875\nGetTangentOnCurveArcLength|0.67567569017410278\tv:-110.05184936523438,40.725414276123047\nGetPositionOnCurve|0.70270270109176636\tu:0.3570999801158905,0,0.12397132068872452,0\nGetPositionOnCurveArcLength|0.70270270109176636\tu:0.25414940714836121,0,0.18936187028884888,0\nGetTangentOnCurve|0.70270270109176636\tv:-74.064186096191406,35.594596862792969\nGetTangentOnCurveArcLength|0.70270270109176636\tv:-118.09299468994141,41.871852874755859\nGetPositionOnCurve|0.72972971200942993\tu:0.33756768703460693,0,0.13809439539909363,0\nGetPositionOnCurveArcLength|0.72972971200942993\tu:0.23172664642333984,0,0.20165571570396423,0\nGetTangentOnCurve|0.72972971200942993\tv:-84.206077575683594,37.040538787841797\nGetTangentOnCurveArcLength|0.72972971200942993\tv:-125.65290832519531,42.949684143066406\nGetPositionOnCurve|0.75675678253173828\tu:0.31553211808204651,0,0.15277983248233795,0\nGetPositionOnCurveArcLength|0.75675678253173828\tu:0.20922347903251648,0,0.2135789543390274,0\nGetTangentOnCurve|0.75675678253173828\tv:-94.347984313964844,38.486488342285156\nGetTangentOnCurveArcLength|0.75675678253173828\tv:-132.80796813964844,43.969791412353516\nGetPositionOnCurve|0.78378379344940186\tu:0.290993332862854,0,0.16802753508090973,0\nGetPositionOnCurveArcLength|0.78378379344940186\tu:0.18665353953838348,0,0.22518451511859894,0\nGetTangentOnCurve|0.78378379344940186\tv:-104.4898681640625,39.93243408203125\nGetTangentOnCurveArcLength|0.78378379344940186\tv:-139.61643981933594,44.940483093261719\nGetPositionOnCurve|0.81081080436706543\tu:0.26395130157470703,0,0.18383751809597015,0\nGetPositionOnCurveArcLength|0.81081080436706543\tu:0.16402725875377655,0,0.23651370406150818,0\nGetTangentOnCurve|0.81081080436706543\tv:-114.63175201416016,41.378379821777344\nGetTangentOnCurveArcLength|0.81081080436706543\tv:-146.12382507324219,45.868255615234375\nGetPositionOnCurve|0.837837815284729\tu:0.23440602421760559,0,0.20020979642868042,0\nGetPositionOnCurveArcLength|0.837837815284729\tu:0.14135259389877319,0,0.24759970605373383,0\nGetTangentOnCurve|0.837837815284729\tv:-124.77364349365234,42.824325561523438\nGetTangentOnCurveArcLength|0.837837815284729\tv:-152.36656188964844,46.758293151855469\nGetPositionOnCurve|0.86486488580703735\tu:0.2023574560880661,0,0.21714441478252411,0\nGetPositionOnCurveArcLength|0.86486488580703735\tu:0.11863575875759125,0,0.25846964120864868,0\nGetTangentOnCurve|0.86486488580703735\tv:-134.91554260253906,44.270271301269531\nGetTangentOnCurveArcLength|0.86486488580703735\tv:-158.37434387207031,47.614830017089844\nGetPositionOnCurve|0.89189189672470093\tu:0.16780571639537811,0,0.23464128375053406,0\nGetPositionOnCurveArcLength|0.89189189672470093\tu:0.095882505178451538,0,0.26914560794830322,0\nGetTangentOnCurve|0.89189189672470093\tv:-145.05743408203125,45.716217041015625\nGetTangentOnCurveArcLength|0.89189189672470093\tv:-164.17152404785156,48.44134521484375\nGetPositionOnCurve|0.9189189076423645\tu:0.13075071573257446,0,0.25270047783851624,0\nGetPositionOnCurveArcLength|0.9189189076423645\tu:0.073096565902233124,0,0.2796466052532196,0\nGetTangentOnCurve|0.9189189076423645\tv:-155.19932556152344,47.162162780761719\nGetTangentOnCurveArcLength|0.9189189076423645\tv:-169.77877807617188,49.240779876708984\nGetPositionOnCurve|0.94594591856002808\tu:0.091192513704299927,0,0.27132192254066467,0\nGetPositionOnCurveArcLength|0.94594591856002808\tu:0.050281506031751633,0,0.28998848795890808,0\nGetTangentOnCurve|0.94594591856002808\tv:-165.34120178222656,48.608108520507812\nGetTangentOnCurveArcLength|0.94594591856002808\tv:-175.2135009765625,50.015617370605469\nGetPositionOnCurve|0.97297298908233643\tu:0.049130931496620178,0,0.29050573706626892,0\nGetPositionOnCurveArcLength|0.97297298908233643\tu:0.027440527454018593,0,0.30018484592437744,0\nGetTangentOnCurve|0.97297298908233643\tv:-175.48310852050781,50.054054260253906\nGetTangentOnCurveArcLength|0.97297298908233643\tv:-180.49053955078125,50.767971038818359\nGetPositionOnCurve|0.026315789669752121\tu:0.47792282700538635,0,0.5243297815322876,0\nGetPositionOnCurveArcLength|0.026315789669752121\tu:0.4764256477355957,0,0.52248573303222656,0\nGetTangentOnCurve|0.026315789669752121\tv:-72.447715759277344,-56.077560424804688\nGetTangentOnCurveArcLength|0.026315789669752121\tv:-72.346427917480469,-57.111454010009766\nGetPositionOnCurve|0.078947365283966064\tu:0.44394224882125854,0,0.47357934713363647,0\nGetPositionOnCurveArcLength|0.078947365283966064\tu:0.44311517477035522,0,0.47210890054702759,0\nGetTangentOnCurve|0.078947365283966064\tv:-68.332061767578125,-76.803321838378906\nGetTangentOnCurveArcLength|0.078947365283966064\tv:-68.180732727050781,-77.236572265625\nGetPositionOnCurve|0.1315789520740509\tu:0.41282454133033752,0,0.40974834561347961,0\nGetPositionOnCurveArcLength|0.1315789520740509\tu:0.41486197710037231,0,0.41450831294059753,0\nGetTangentOnCurve|0.1315789520740509\tv:-60.53497314453125,-90.623268127441406\nGetTangentOnCurveArcLength|0.1315789520740509\tv:-61.197227478027344,-89.884552001953125\nGetPositionOnCurve|0.18421052396297455\tu:0.38633933663368225,0,0.33806654810905457,0\nGetPositionOnCurveArcLength|0.18421052396297455\tu:0.39097735285758972,0,0.35217884182929993,0\nGetTangentOnCurve|0.18421052396297455\tv:-49.056442260742188,-97.537399291992188\nGetTangentOnCurveArcLength|0.18421052396297455\tv:-51.54327392578125,-96.746536254882812\nGetPositionOnCurve|0.23684211075305939\tu:0.36625608801841736,0,0.26376360654830933,0\nGetPositionOnCurveArcLength|0.23684211075305939\tu:0.37153232097625732,0,0.28613319993019104,0\nGetTangentOnCurve|0.23684211075305939\tv:-33.896465301513672,-97.545700073242188\nGetTangentOnCurveArcLength|0.23684211075305939\tv:-38.855495452880859,-98.270431518554688\nGetPositionOnCurve|0.28947368264198303\tu:0.35434427857398987,0,0.19206923246383667,0\nGetPositionOnCurveArcLength|0.28947368264198303\tu:0.3575102686882019,0,0.21678644418716431,0\nGetTangentOnCurve|0.28947368264198303\tv:-15.0550537109375,-90.648193359375\nGetTangentOnCurveArcLength|0.28947368264198303\tv:-22.135982513427734,-93.875511169433594\nGetPositionOnCurve|0.34210526943206787\tu:0.35237336158752441,0,0.12821312248706818,0\nGetPositionOnCurveArcLength|0.34210526943206787\tu:0.35182309150695801,0,0.14467255771160126,0\nGetTangentOnCurve|0.34210526943206787\tv:7.4677963256835938,-76.844879150390625\nGetTangentOnCurveArcLength|0.34210526943206787\tv:0.9145355224609375,-81.324264526367188\nGetPositionOnCurve|0.39473685622215271\tu:0.36211293935775757,0,0.077424906194210052,0\nGetPositionOnCurveArcLength|0.39473685622215271\tu:0.36307340860366821,0,0.07499261200428009,0\nGetTangentOnCurve|0.39473685622215271\tv:33.672096252441406,-56.135726928710938\nGetTangentOnCurveArcLength|0.39473685622215271\tv:35.303276062011719,-54.724128723144531\nGetPositionOnCurve|0.44736841320991516\tu:0.38533243536949158,0,0.04493444412946701,0\nGetPositionOnCurveArcLength|0.44736841320991516\tu:0.40110307931900024,0,0.037552647292613983,0\nGetTangentOnCurve|0.44736841320991516\tv:63.557815551757812,-28.520786285400391\nGetTangentOnCurveArcLength|0.44736841320991516\tv:78.608642578125,-13.430110931396484\nGetPositionOnCurve|0.55263155698776245\tu:0.42001622915267944,0,0.055780299007892609,0\nGetPositionOnCurveArcLength|0.55263155698776245\tu:0.37562295794487,0,0.10914605855941772,0\nGetTangentOnCurve|0.55263155698776245\tv:-17.749992370605469,27.565788269042969\nGetTangentOnCurveArcLength|0.55263155698776245\tv:-62.954666137695312,34.010692596435547\nGetPositionOnCurve|0.60526317358016968\tu:0.40673813223838806,0,0.077721767127513885,0\nGetPositionOnCurveArcLength|0.60526317358016968\tu:0.33393490314483643,0,0.14059457182884216,0\nGetTangentOnCurve|0.60526317358016968\tv:-37.500007629394531,30.381580352783203\nGetTangentOnCurveArcLength|0.60526317358016968\tv:-85.960479736328125,37.290668487548828\nGetPositionOnCurve|0.65789473056793213\tu:0.38396719098091125,0,0.10179556906223297,0\nGetPositionOnCurveArcLength|0.65789473056793213\tu:0.29109326004981995,0,0.16796733438968658,0\nGetTangentOnCurve|0.65789473056793213\tv:-57.249996185302734,33.197368621826172\nGetTangentOnCurveArcLength|0.65789473056793213\tv:-104.4505615234375,39.926826477050781\nGetPositionOnCurve|0.71052628755569458\tu:0.35170334577560425,0,0.12800173461437225,0\nGetPositionOnCurveArcLength|0.71052628755569458\tu:0.2476678192615509,0,0.1929624080657959,0\nGetTangentOnCurve|0.71052628755569458\tv:-76.999992370605469,36.013156890869141\nGetTangentOnCurveArcLength|0.71052628755569458\tv:-120.32709503173828,42.190372467041016\nGetPositionOnCurve|0.76315790414810181\tu:0.30994650721549988,0,0.15634030103683472,0\nGetPositionOnCurveArcLength|0.76315790414810181\tu:0.20388363301753998,0,0.2163546234369278,0\nGetTangentOnCurve|0.76315790414810181\tv:-96.75,38.828948974609375\nGetTangentOnCurveArcLength|0.76315790414810181\tv:-134.44993591308594,44.203887939453125\nGetPositionOnCurve|0.81578946113586426\tu:0.25869685411453247,0,0.18681120872497559,0\nGetPositionOnCurveArcLength|0.81578946113586426\tu:0.1598537415266037,0,0.23857325315475464,0\nGetTangentOnCurve|0.81578946113586426\tv:-116.49999237060547,41.644737243652344\nGetTangentOnCurveArcLength|0.81578946113586426\tv:-147.29273986816406,46.034904479980469\nGetPositionOnCurve|0.86842107772827148\tu:0.19795416295528412,0,0.21941451728343964,0\nGetPositionOnCurveArcLength|0.86842107772827148\tu:0.11564395576715469,0,0.25988501310348511,0\nGetTangentOnCurve|0.86842107772827148\tv:-136.25001525878906,44.460525512695312\nGetTangentOnCurveArcLength|0.86842107772827148\tv:-159.14866638183594,47.725227355957031\nGetPositionOnCurve|0.92105263471603394\tu:0.1277187168598175,0,0.2541501522064209,0\nGetPositionOnCurveArcLength|0.92105263471603394\tu:0.071296274662017822,0,0.28046867251396179,0\nGetTangentOnCurve|0.92105263471603394\tv:-156,47.276313781738281\nGetTangentOnCurveArcLength|0.92105263471603394\tv:-170.21392822265625,49.302818298339844\nGetPositionOnCurve|0.97368419170379639\tu:0.047990284860134125,0,0.29101812839508057,0\nGetPositionOnCurveArcLength|0.97368419170379639\tu:0.026839094236493111,0,0.30045127868652344,0\nGetTangentOnCurve|0.97368419170379639\tv:-175.75,50.09210205078125\nGetTangentOnCurveArcLength|0.97368419170379639\tv:-180.62741088867188,50.787483215332031\nGetPositionOnCurve|0.025641025975346565\tu:0.47836938500404358,0,0.52487272024154663,0\nGetPositionOnCurveArcLength|0.025641025975346565\tu:0.47689142823219299,0,0.5230633020401001,0\nGetTangentOnCurve|0.025641025975346565\tv:-72.476577758789062,-55.767013549804688\nGetTangentOnCurveArcLength|0.025641025975346565\tv:-72.378684997558594,-56.791015625\nGetPositionOnCurve|0.05128205195069313\tu:0.46155911684036255,0,0.50221818685531616,0\nGetPositionOnCurveArcLength|0.05128205195069313\tu:0.45991575717926025,0,0.49976003170013428,0\nGetTangentOnCurve|0.05128205195069313\tv:-70.954391479492188,-66.769973754882812\nGetTangentOnCurveArcLength|0.05128205195069313\tv:-70.756072998046875,-67.770538330078125\nGetPositionOnCurve|0.10256410390138626\tu:0.42951938509941101,0,0.44624274969100952,0\nGetPositionOnCurveArcLength|0.10256410390138626\tu:0.42987191677093506,0,0.44695502519607544,0\nGetTangentOnCurve|0.10256410390138626\tv:-65.288711547851562,-83.858726501464844\nGetTangentOnCurveArcLength|0.10256410390138626\tv:-65.373893737792969,-83.69915771484375\nGetPositionOnCurve|0.12820513546466827\tu:0.41469916701316833,0,0.41413122415542603,0\nGetPositionOnCurveArcLength|0.12820513546466827\tu:0.41653880476951599,0,0.41835859417915344,0\nGetTangentOnCurve|0.12820513546466827\tv:-61.145214080810547,-89.944526672363281\nGetTangentOnCurveArcLength|0.12820513546466827\tv:-61.723800659179688,-89.2576904296875\nGetPositionOnCurve|0.17948718369007111\tu:0.38848096132278442,0,0.3446841835975647,0\nGetPositionOnCurveArcLength|0.17948718369007111\tu:0.39294582605361938,0,0.35793349146842957,0\nGetTangentOnCurve|0.17948718369007111\tv:-50.236930847167969,-97.198959350585938\nGetTangentOnCurveArcLength|0.17948718369007111\tv:-52.524589538574219,-96.348495483398438\nGetPositionOnCurve|0.20512820780277252\tu:0.3774922788143158,0,0.30855807662010193,0\nGetPositionOnCurveArcLength|0.20512820780277252\tu:0.38268792629241943,0,0.326343834400177,0\nGetTangentOnCurve|0.20512820780277252\tv:-43.472137451171875,-98.367599487304688\nGetTangentOnCurveArcLength|0.20512820780277252\tv:-46.901748657226562,-97.998802185058594\nGetPositionOnCurve|0.25641027092933655\tu:0.36077854037284851,0,0.2365240752696991,0\nGetPositionOnCurveArcLength|0.25641027092933655\tu:0.36559164524078369,0,0.26072174310684204,0\nGetTangentOnCurve|0.25641027092933655\tv:-27.321247100830078,-95.7877197265625\nGetTangentOnCurveArcLength|0.25641027092933655\tv:-33.1927490234375,-97.39788818359375\nGetPositionOnCurve|0.28205129504203796\tu:0.35546278953552246,0,0.20182566344738007,0\nGetPositionOnCurveArcLength|0.28205129504203796\tu:0.35908368229866028,0,0.22675548493862152,0\nGetTangentOnCurve|0.28205129504203796\tv:-17.935153961181641,-92.039199829101562\nGetTangentOnCurveArcLength|0.28205129504203796\tv:-24.802707672119141,-94.911262512207031\nGetPositionOnCurve|0.35897436738014221\tu:0.35413503646850586,0,0.11026116460561752,0\nGetPositionOnCurveArcLength|0.35897436738014221\tu:0.3528822660446167,0,0.12140060216188431,0\nGetTangentOnCurve|0.35897436738014221\tv:15.465736389160156,-70.959320068359375\nGetTangentOnCurveArcLength|0.35897436738014221\tv:10.384994506835938,-74.7484130859375\nGetPositionOnCurve|0.41025641560554504\tu:0.36747890710830688,0,0.065707474946975708,0\nGetPositionOnCurveArcLength|0.41025641560554504\tu:0.37186315655708313,0,0.058656103909015656,0\nGetTangentOnCurve|0.41025641560554504\tv:42.101829528808594,-48.710788726806641\nGetTangentOnCurveArcLength|0.41025641560554504\tv:48.072174072265625,-43.267784118652344\nGetPositionOnCurve|0.43589743971824646\tu:0.37903335690498352,0,0.050191536545753479,0\nGetPositionOnCurveArcLength|0.43589743971824646\tu:0.3913215696811676,0,0.041308559477329254,0\nGetTangentOnCurve|0.43589743971824646\tv:56.730514526367188,-35.127967834472656\nGetTangentOnCurveArcLength|0.43589743971824646\tv:69.562667846679688,-22.582731246948242\nGetPositionOnCurve|0.48717948794364929\tu:0.41293042898178101,0,0.035705018788576126,0\nGetPositionOnCurveArcLength|0.48717948794364929\tu:0.42063084244728088,0,0.054216839373111725,0\nGetTangentOnCurve|0.48717948794364929\tv:88.609222412109375,-3.0451202392578125\nGetTangentOnCurveArcLength|0.48717948794364929\tv:-16.265106201171875,27.354085922241211\nGetPositionOnCurve|0.5128205418586731\tu:0.42375388741493225,0,0.040600072592496872,0\nGetPositionOnCurveArcLength|0.5128205418586731\tu:0.40514358878135681,0,0.079719804227352142,0\nGetTangentOnCurve|0.5128205418586731\tv:-2.810908317565918,25.43589973449707\nGetTangentOnCurveArcLength|0.5128205418586731\tv:-39.208301544189453,30.625133514404297\nGetPositionOnCurve|0.56410259008407593\tu:0.41793128848075867,0,0.060380700975656509,0\nGetPositionOnCurveArcLength|0.56410259008407593\tu:0.36669531464576721,0,0.11650765687227249,0\nGetTangentOnCurve|0.56410259008407593\tv:-22.054496765136719,28.179489135742188\nGetTangentOnCurveArcLength|0.56410259008407593\tv:-68.534385681152344,34.806201934814453\nGetPositionOnCurve|0.58974361419677734\tu:0.41164034605026245,0,0.071030169725418091,0\nGetPositionOnCurveArcLength|0.58974361419677734\tu:0.34639182686805725,0,0.13186740875244141,0\nGetTangentOnCurve|0.58974361419677734\tv:-31.676292419433594,29.55128288269043\nGetTangentOnCurveArcLength|0.58974361419677734\tv:-79.784065246582031,36.410087585449219\nGetPositionOnCurve|0.64102566242218018\tu:0.39229929447174072,0,0.093847416341304779,0\nGetPositionOnCurveArcLength|0.64102566242218018\tu:0.30490443110466003,0,0.15950623154640198,0\nGetTangentOnCurve|0.64102566242218018\tv:-50.919879913330078,32.294872283935547\nGetTangentOnCurveArcLength|0.64102566242218018\tv:-98.868194580078125,39.130943298339844\nGetPositionOnCurve|0.71794873476028442\tu:0.34638950228691101,0,0.13186906278133392,0\nGetPositionOnCurveArcLength|0.71794873476028442\tu:0.24151149392127991,0,0.19634604454040527,0\nGetTangentOnCurve|0.71794873476028442\tv:-79.785263061523438,36.410255432128906\nGetTangentOnCurveArcLength|0.71794873476028442\tv:-122.41133880615234,42.487525939941406\nGetPositionOnCurve|0.74358975887298584\tu:0.32658007740974426,0,0.14555515348911285,0\nGetPositionOnCurveArcLength|0.74358975887298584\tu:0.22019565105438232,0,0.2078128457069397,0\nGetTangentOnCurve|0.74358975887298584\tv:-89.407058715820312,37.782051086425781\nGetTangentOnCurveArcLength|0.74358975887298584\tv:-129.36872863769531,43.479454040527344\nGetPositionOnCurve|0.79487180709838867\tu:0.28020197153091431,0,0.17444565892219543,0\nGetPositionOnCurveArcLength|0.79487180709838867\tu:0.17737725377082825,0,0.22986379265785217,0\nGetTangentOnCurve|0.79487180709838867\tv:-108.65064239501953,40.525642395019531\nGetTangentOnCurveArcLength|0.79487180709838867\tv:-142.3203125,45.325981140136719\nGetPositionOnCurve|0.82051283121109009\tu:0.2536332905292511,0,0.18965005874633789,0\nGetPositionOnCurveArcLength|0.82051283121109009\tu:0.1558927446603775,0,0.24051979184150696,0\nGetTangentOnCurve|0.82051283121109009\tv:-118.27243804931641,41.897438049316406\nGetTangentOnCurveArcLength|0.82051283121109009\tv:-148.39361572265625,46.191860198974609\nGetPositionOnCurve|0.87179487943649292\tu:0.19373670220375061,0,0.22157716751098633,0\nGetPositionOnCurveArcLength|0.87179487943649292\tu:0.11280502378940582,0,0.26122471690177917,0\nGetTangentOnCurve|0.87179487943649292\tv:-137.51602172851562,44.641025543212891\nGetTangentOnCurveArcLength|0.87179487943649292\tv:-159.87995910644531,47.829490661621094\nGetPositionOnCurve|0.89743590354919434\tu:0.16040876507759094,0,0.2382998913526535,0\nGetPositionOnCurveArcLength|0.89743590354919434\tu:0.091210946440696716,0,0.2713133692741394,0\nGetTangentOnCurve|0.89743590354919434\tv:-147.1378173828125,46.012821197509766\nGetTangentOnCurveArcLength|0.89743590354919434\tv:-165.33662414550781,48.607452392578125\nGetPositionOnCurve|0.94871795177459717\tu:0.086993664503097534,0,0.27326363325119019,0\nGetPositionOnCurveArcLength|0.94871795177459717\tu:0.047939874231815338,0,0.29104077816009521,0\nGetTangentOnCurve|0.94871795177459717\tv:-166.38140869140625,48.75640869140625\nGetTangentOnCurveArcLength|0.94871795177459717\tv:-175.76177978515625,50.093784332275391\nGetPositionOnCurve|0.97435897588729858\tu:0.046906493604183197,0,0.29150468111038208,0\nGetPositionOnCurveArcLength|0.97435897588729858\tu:0.026268597692251205,0,0.30070403218269348,0\nGetTangentOnCurve|0.97435897588729858\tv:-176.00320434570312,50.128204345703125\nGetTangentOnCurveArcLength|0.97435897588729858\tv:-180.75714111328125,50.805984497070312\nGetPositionOnCurve|0.02500000037252903\tu:0.47879374027252197,0,0.52538567781448364,0\nGetPositionOnCurveArcLength|0.02500000037252903\tu:0.47733494639396667,0,0.52360999584197998,0\nGetTangentOnCurve|0.02500000037252903\tv:-72.503440856933594,-55.470939636230469\nGetTangentOnCurveArcLength|0.02500000037252903\tv:-72.408775329589844,-56.484889984130859\nGetPositionOnCurve|0.075000002980232239\tu:0.44641345739364624,0,0.47790434956550598,0\nGetPositionOnCurveArcLength|0.075000002980232239\tu:0.44542405009269714,0,0.47618499398231506,0\nGetTangentOnCurve|0.075000002980232239\tv:-68.768440246582031,-75.488441467285156\nGetTangentOnCurveArcLength|0.075000002980232239\tv:-68.596542358398438,-76.018547058105469\nGetPositionOnCurve|0.17499999701976776\tu:0.39056214690208435,0,0.35094794631004333,0\nGetPositionOnCurveArcLength|0.17499999701976776\tu:0.39484825730323792,0,0.36337274312973022,0\nGetTangentOnCurve|0.17499999701976776\tv:-51.330940246582031,-96.825935363769531\nGetTangentOnCurveArcLength|0.17499999701976776\tv:-53.434951782226562,-95.93109130859375\nGetPositionOnCurve|0.22499999403953552\tu:0.37012538313865662,0,0.28044050931930542,0\nGetPositionOnCurveArcLength|0.22499999403953552\tu:0.37548843026161194,0,0.30129104852676392,0\nGetTangentOnCurve|0.22499999403953552\tv:-37.628440856933594,-98.14593505859375\nGetTangentOnCurveArcLength|0.22499999403953552\tv:-42.012908935546875,-98.404647827148438\nGetPositionOnCurve|0.27500000596046448\tu:0.35670396685600281,0,0.21122542023658752,0\nGetPositionOnCurveArcLength|0.27500000596046448\tu:0.36071455478668213,0,0.23617012798786163,0\nGetTangentOnCurve|0.27500000596046448\tv:-20.603435516357422,-93.233436584472656\nGetTangentOnCurveArcLength|0.27500000596046448\tv:-27.231552124023438,-95.75830078125\nGetPositionOnCurve|0.32499998807907104\tu:0.35181513428688049,0,0.14778631925582886,0\nGetPositionOnCurveArcLength|0.32499998807907104\tu:0.35241970419883728,0,0.16831879317760468,0\nGetTangentOnCurve|0.32499998807907104\tv:-0.25594329833984375,-82.08843994140625\nGetTangentOnCurveArcLength|0.32499998807907104\tv:-7.5098724365234375,-86.555496215820312\nGetPositionOnCurve|0.42500001192092896\tu:0.37370356917381287,0,0.056171663105487823,0\nGetPositionOnCurveArcLength|0.42500001192092896\tu:0.38249343633651733,0,0.047096088528633118,0\nGetTangentOnCurve|0.42500001192092896\tv:50.406570434570312,-41.100933074951172\nGetTangentOnCurveArcLength|0.42500001192092896\tv:60.554611206054688,-31.446693420410156\nGetPositionOnCurve|0.47499999403953552\tu:0.4035150408744812,0,0.036963757127523422,0\nGetPositionOnCurveArcLength|0.47499999403953552\tu:0.42384728789329529,0,0.03833770751953125,0\nGetTangentOnCurve|0.47499999403953552\tv:80.7215576171875,-11.258455276489258\nGetTangentOnCurveArcLength|0.47499999403953552\tv:-0.47598433494567871,25.103004455566406\nGetPositionOnCurve|0.52499997615814209\tu:0.42318707704544067,0,0.045114647597074509,0\nGetPositionOnCurveArcLength|0.52499997615814209\tu:0.39646461606025696,0,0.089570999145507812,0\nGetTangentOnCurve|0.52499997615814209\tv:-7.3812408447265625,26.087497711181641\nGetTangentOnCurveArcLength|0.52499997615814209\tv:-47.439708709716797,31.798698425292969\nGetPositionOnCurve|0.57499998807907104\tu:0.41553294658660889,0,0.064844869077205658,0\nGetPositionOnCurveArcLength|0.57499998807907104\tu:0.35811653733253479,0,0.12319951504468918,0\nGetTangentOnCurve|0.57499998807907104\tv:-26.143745422363281,28.76249885559082\nGetTangentOnCurveArcLength|0.57499998807907104\tv:-73.498062133789062,35.513881683349609\nGetPositionOnCurve|0.67500001192092896\tu:0.37452268600463867,0,0.11007868498563766,0\nGetPositionOnCurveArcLength|0.67500001192092896\tu:0.27702963352203369,0,0.17630364000797272,0\nGetTangentOnCurve|0.67500001192092896\tv:-63.668754577636719,34.112499237060547\nGetTangentOnCurveArcLength|0.67500001192092896\tv:-109.84382629394531,40.695755004882812\nGetPositionOnCurve|0.72500002384185791\tu:0.34116652607917786,0,0.13558229804039001,0\nGetPositionOnCurveArcLength|0.72500002384185791\tu:0.23565690219402313,0,0.19953273236751556,0\nGetTangentOnCurve|0.72500002384185791\tv:-82.431259155273438,36.787502288818359\nGetTangentOnCurveArcLength|0.72500002384185791\tv:-124.36103057861328,42.765495300292969\nGetPositionOnCurve|0.77499997615814209\tu:0.29924303293228149,0,0.16301032900810242,0\nGetPositionOnCurveArcLength|0.77499997615814209\tu:0.19399549067020416,0,0.22144478559494019,0\nGetTangentOnCurve|0.77499997615814209\tv:-101.19374084472656,39.462497711181641\nGetTangentOnCurveArcLength|0.77499997615814209\tv:-137.43867492675781,44.629997253417969\nGetPositionOnCurve|0.82499998807907104\tu:0.248752161860466,0,0.19236284494400024,0\nGetPositionOnCurveArcLength|0.82499998807907104\tu:0.15212862193584442,0,0.2423623651266098,0\nGetTangentOnCurve|0.82499998807907104\tv:-119.95624542236328,42.137496948242188\nGetTangentOnCurveArcLength|0.82499998807907104\tv:-149.4322509765625,46.339942932128906\nGetPositionOnCurve|0.92500001192092896\tu:0.12206836044788361,0,0.25684130191802979,0\nGetPositionOnCurveArcLength|0.92500001192092896\tu:0.067965470254421234,0,0.28198695182800293,0\nGetTangentOnCurve|0.92500001192092896\tv:-157.48124694824219,47.487503051757812\nGetTangentOnCurveArcLength|0.92500001192092896\tv:-171.01609802246094,49.417186737060547\nGetPositionOnCurve|0.97500002384185791\tu:0.045875374227762222,0,0.29196718335151672,0\nGetPositionOnCurveArcLength|0.97500002384185791\tu:0.025726458057761192,0,0.30094406008720398,0\nGetTangentOnCurve|0.97500002384185791\tv:-176.24375915527344,50.162498474121094\nGetTangentOnCurveArcLength|0.97500002384185791\tv:-180.88034057617188,50.82354736328125\nGetPositionOnCurve|0.024390242993831635\tu:0.47919753193855286,0,0.52587109804153442,0\nGetPositionOnCurveArcLength|0.024390242993831635\tu:0.47775772213935852,0,0.52412813901901245,0\nGetTangentOnCurve|0.024390242993831635\tv:-72.528480529785156,-55.1883544921875\nGetTangentOnCurveArcLength|0.024390242993831635\tv:-72.4368896484375,-56.192138671875\nGetPositionOnCurve|0.048780485987663269\tu:0.46318221092224121,0,0.50460350513458252,0\nGetPositionOnCurveArcLength|0.048780485987663269\tu:0.46150922775268555,0,0.5021442174911499,0\nGetTangentOnCurve|0.048780485987663269\tv:-71.141357421875,-65.768661499023438\nGetTangentOnCurveArcLength|0.048780485987663269\tv:-70.948501586914062,-66.800537109375\nGetPositionOnCurve|0.073170728981494904\tu:0.44756391644477844,0,0.47988304495811462,0\nGetPositionOnCurveArcLength|0.073170728981494904\tu:0.44650363922119141,0,0.47806021571159363,0\nGetTangentOnCurve|0.073170728981494904\tv:-68.963638305664062,-74.865928649902344\nGetTangentOnCurveArcLength|0.073170728981494904\tv:-68.783920288085938,-75.43988037109375\nGetPositionOnCurve|0.097560971975326538\tu:0.43251875042915344,0,0.45223027467727661,0\nGetPositionOnCurveArcLength|0.097560971975326538\tu:0.4325980544090271,0,0.45238640904426575,0\nGetTangentOnCurve|0.097560971975326538\tv:-65.995315551757812,-82.480148315429688\nGetTangentOnCurveArcLength|0.097560971975326538\tv:-66.013450622558594,-82.443038940429688\nGetPositionOnCurve|0.12195122241973877\tu:0.41822275519371033,0,0.42216557264328003,0\nGetPositionOnCurveArcLength|0.12195122241973877\tu:0.41969418525695801,0,0.42544403672218323,0\nGetTangentOnCurve|0.12195122241973877\tv:-62.23638916015625,-88.611312866210938\nGetTangentOnCurveArcLength|0.12195122241973877\tv:-62.671363830566406,-88.032958984375\nGetPositionOnCurve|0.14634145796298981\tu:0.40485212206840515,0,0.39020943641662598,0\nGetPositionOnCurveArcLength|0.14634145796298981\tu:0.40773233771324158,0,0.39744248986244202,0\nGetTangentOnCurve|0.14634145796298981\tv:-57.686866760253906,-93.259445190429688\nGetTangentOnCurveArcLength|0.14634145796298981\tv:-58.76544189453125,-92.355361938476562\nGetPositionOnCurve|0.17073170840740204\tu:0.39258289337158203,0,0.35688233375549316,0\nGetPositionOnCurveArcLength|0.17073170840740204\tu:0.39668700098991394,0,0.3685210645198822,0\nGetTangentOnCurve|0.17073170840740204\tv:-52.34674072265625,-96.424522399902344\nGetTangentOnCurveArcLength|0.17073170840740204\tv:-54.281410217285156,-95.498519897460938\nGetPositionOnCurve|0.19512194395065308\tu:0.38159117102622986,0,0.3227047324180603,0\nGetPositionOnCurveArcLength|0.19512194395065308\tu:0.38656505942344666,0,0.33877262473106384,0\nGetTangentOnCurve|0.19512194395065308\tv:-46.216018676757812,-98.1065673828125\nGetTangentOnCurveArcLength|0.19512194395065308\tv:-49.183605194091797,-97.503997802734375\nGetPositionOnCurve|0.21951219439506531\tu:0.3720531165599823,0,0.28819707036018372,0\nGetPositionOnCurveArcLength|0.21951219439506531\tu:0.37740817666053772,0,0.30825808644294739,0\nGetTangentOnCurve|0.21951219439506531\tv:-39.294692993164062,-98.305549621582031\nGetTangentOnCurveArcLength|0.21951219439506531\tv:-43.412574768066406,-98.370437622070312\nGetPositionOnCurve|0.24390244483947754\tu:0.36414474248886108,0,0.25387975573539734,0\nGetPositionOnCurveArcLength|0.24390244483947754\tu:0.36930003762245178,0,0.27701646089553833,0\nGetTangentOnCurve|0.24390244483947754\tv:-31.582759857177734,-97.021492004394531\nGetTangentOnCurveArcLength|0.24390244483947754\tv:-36.879131317138672,-98.05145263671875\nGetPositionOnCurve|0.26829269528388977\tu:0.35804218053817749,0,0.22027333080768585,0\nGetPositionOnCurveArcLength|0.26829269528388977\tu:0.36238133907318115,0,0.24507388472557068,0\nGetTangentOnCurve|0.26829269528388977\tv:-23.080226898193359,-94.254379272460938\nGetTangentOnCurveArcLength|0.26829269528388977\tv:-29.453376770019531,-96.44622802734375\nGetPositionOnCurve|0.29268291592597961\tu:0.3539215624332428,0,0.18789820373058319,0\nGetPositionOnCurveArcLength|0.29268291592597961\tu:0.35687816143035889,0,0.21245796978473663,0\nGetTangentOnCurve|0.29268291592597961\tv:-13.787105560302734,-90.004241943359375\nGetTangentOnCurveArcLength|0.29268291592597961\tv:-20.945991516113281,-93.379806518554688\nGetPositionOnCurve|0.31707316637039185\tu:0.35195896029472351,0,0.15727485716342926,0\nGetPositionOnCurveArcLength|0.31707316637039185\tu:0.35315510630607605,0,0.17922765016555786,0\nGetTangentOnCurve|0.31707316637039185\tv:-3.7033767700195312,-84.271049499511719\nGetTangentOnCurveArcLength|0.31707316637039185\tv:-11.076171875,-88.56634521484375\nGetPositionOnCurve|0.34146341681480408\tu:0.35233044624328613,0,0.12892372906208038,0\nGetPositionOnCurveArcLength|0.34146341681480408\tu:0.35181793570518494,0,0.14556089043617249,0\nGetTangentOnCurve|0.34146341681480408\tv:7.1709518432617188,-77.0548095703125\nGetTangentOnCurveArcLength|0.34146341681480408\tv:0.5785369873046875,-81.5447998046875\nGetPositionOnCurve|0.36585366725921631\tu:0.35521221160888672,0,0.10336528718471527,0\nGetPositionOnCurveArcLength|0.36585366725921631\tu:0.35389971733093262,0,0.11201696842908859,0\nGetTangentOnCurve|0.36585366725921631\tv:18.835891723632812,-68.355514526367188\nGetTangentOnCurveArcLength|0.36585366725921631\tv:14.636764526367188,-71.588996887207031\nGetPositionOnCurve|0.39024388790130615\tu:0.36078023910522461,0,0.08112005889415741,0\nGetPositionOnCurveArcLength|0.39024388790130615\tu:0.36105230450630188,0,0.080332368612289429,0\nGetTangentOnCurve|0.39024388790130615\tv:31.291419982910156,-58.173194885253906\nGetTangentOnCurveArcLength|0.39024388790130615\tv:31.789657592773438,-57.749046325683594\nGetPositionOnCurve|0.41463413834571838\tu:0.36921072006225586,0,0.062708355486392975,0\nGetPositionOnCurveArcLength|0.41463413834571838\tu:0.3748181164264679,0,0.054781083017587662,0\nGetTangentOnCurve|0.41463413834571838\tv:44.537544250488281,-46.507797241210938\nGetTangentOnCurveArcLength|0.41463413834571838\tv:51.779273986816406,-39.816989898681641\nGetPositionOnCurve|0.43902438879013062\tu:0.38067972660064697,0,0.048650726675987244,0\nGetPositionOnCurveArcLength|0.43902438879013062\tu:0.39395153522491455,0,0.040060799568891525,0\nGetTangentOnCurve|0.43902438879013062\tv:58.57427978515625,-33.359386444091797\nGetTangentOnCurveArcLength|0.43902438879013062\tv:72.078170776367188,-20.061855316162109\nGetPositionOnCurve|0.46341463923454285\tu:0.39536330103874207,0,0.039467625319957733,0\nGetPositionOnCurveArcLength|0.46341463923454285\tu:0.41513118147850037,0,0.035623069852590561,0\nGetTangentOnCurve|0.46341463923454285\tv:73.401626586914062,-18.7279052734375\nGetTangentOnCurveArcLength|0.46341463923454285\tv:90.379714965820312,-1.1792984008789062\nGetPositionOnCurve|0.48780488967895508\tu:0.41343766450881958,0,0.035679548978805542,0\nGetPositionOnCurveArcLength|0.48780488967895508\tu:0.42034599184989929,0,0.054956965148448944,0\nGetTangentOnCurve|0.48780488967895508\tv:89.019577026367188,-2.6134071350097656\nGetTangentOnCurveArcLength|0.48780488967895508\tv:-16.969465255737305,27.454507827758789\nGetPositionOnCurve|0.51219511032104492\tu:0.42376929521560669,0,0.040371328592300415,0\nGetPositionOnCurveArcLength|0.51219511032104492\tu:0.40557578206062317,0,0.079185374081134796,0\nGetTangentOnCurve|0.51219511032104492\tv:-2.5762152671813965,25.402439117431641\nGetTangentOnCurveArcLength|0.51219511032104492\tv:-38.752704620361328,30.560178756713867\nGetPositionOnCurve|0.53658539056777954\tu:0.42217612266540527,0,0.049515008926391602,0\nGetPositionOnCurveArcLength|0.53658539056777954\tu:0.38787153363227844,0,0.0981593057513237,0\nGetTangentOnCurve|0.53658539056777954\tv:-11.728668212890625,26.707319259643555\nGetTangentOnCurveArcLength|0.53658539056777954\tv:-54.375602722167969,32.787559509277344\nGetPositionOnCurve|0.56097561120986938\tu:0.41854438185691833,0,0.059116598218679428,0\nGetPositionOnCurveArcLength|0.56097561120986938\tu:0.36914047598838806,0,0.11453574150800705,0\nGetTangentOnCurve|0.56097561120986938\tv:-20.881097793579102,28.012195587158203\nGetTangentOnCurveArcLength|0.56097561120986938\tv:-67.052360534667969,34.594905853271484\nGetPositionOnCurve|0.58536583185195923\tu:0.41287395358085632,0,0.069176115095615387,0\nGetPositionOnCurveArcLength|0.58536583185195923\tu:0.34988561272621155,0,0.12933541834354401,0\nGetTangentOnCurve|0.58536583185195923\tv:-30.033527374267578,29.317071914672852\nGetTangentOnCurveArcLength|0.58536583185195923\tv:-77.963966369628906,36.150592803955078\nGetPositionOnCurve|0.60975611209869385\tu:0.40516489744186401,0,0.079693593084812164,0\nGetPositionOnCurveArcLength|0.60975611209869385\tu:0.33031031489372253,0,0.14305548369884491,0\nGetTangentOnCurve|0.60975611209869385\tv:-39.185981750488281,30.621952056884766\nGetTangentOnCurveArcLength|0.60975611209869385\tv:-87.675949096679688,37.535243988037109\nGetPositionOnCurve|0.63414633274078369\tu:0.39541724324226379,0,0.09066898375749588,0\nGetPositionOnCurveArcLength|0.63414633274078369\tu:0.31051754951477051,0,0.15597893297672272,0\nGetTangentOnCurve|0.63414633274078369\tv:-48.338413238525391,31.926828384399414\nGetTangentOnCurveArcLength|0.63414633274078369\tv:-96.507179260253906,38.794326782226562\nGetPositionOnCurve|0.65853661298751831\tu:0.3836309015750885,0,0.10210232436656952,0\nGetPositionOnCurveArcLength|0.65853661298751831\tu:0.29056653380393982,0,0.16828438639640808,0\nGetTangentOnCurve|0.65853661298751831\tv:-57.490863800048828,33.231708526611328\nGetTangentOnCurveArcLength|0.65853661298751831\tv:-104.65756225585938,39.956340789794922\nGetPositionOnCurve|0.68292683362960815\tu:0.3698059618473053,0,0.11399358510971069,0\nGetPositionOnCurveArcLength|0.68292683362960815\tu:0.27049478888511658,0,0.18009258806705475,0\nGetTangentOnCurve|0.68292683362960815\tv:-66.643295288085938,34.536586761474609\nGetTangentOnCurveArcLength|0.68292683362960815\tv:-112.26172637939453,41.040481567382812\nGetPositionOnCurve|0.707317054271698\tu:0.35394242405891418,0,0.12634275853633881,0\nGetPositionOnCurveArcLength|0.707317054271698\tu:0.25032761693000793,0,0.19148974120616913,0\nGetTangentOnCurve|0.707317054271698\tv:-75.795722961425781,35.841461181640625\nGetTangentOnCurveArcLength|0.707317054271698\tv:-119.41536712646484,42.060386657714844\nGetPositionOnCurve|0.73170733451843262\tu:0.336040198802948,0,0.13914990425109863,0\nGetPositionOnCurveArcLength|0.73170733451843262\tu:0.23008263111114502,0,0.20253998041152954,0\nGetTangentOnCurve|0.73170733451843262\tv:-84.948173522949219,37.146343231201172\nGetTangentOnCurveArcLength|0.73170733451843262\tv:-126.18937683105469,43.026168823242188\nGetPositionOnCurve|0.75609755516052246\tu:0.3160993754863739,0,0.15241493284702301,0\nGetPositionOnCurveArcLength|0.75609755516052246\tu:0.20977319777011871,0,0.21329212188720703,0\nGetTangentOnCurve|0.75609755516052246\tv:-94.100608825683594,38.451217651367188\nGetTangentOnCurveArcLength|0.75609755516052246\tv:-132.63778686523438,43.945526123046875\nGetPositionOnCurve|0.7804877758026123\tu:0.29411992430686951,0,0.1661379337310791,0\nGetPositionOnCurveArcLength|0.7804877758026123\tu:0.1894092857837677,0,0.2237846851348877,0\nGetTangentOnCurve|0.7804877758026123\tv:-103.25303649902344,39.756095886230469\nGetTangentOnCurveArcLength|0.7804877758026123\tv:-138.80303955078125,44.824516296386719\nGetPositionOnCurve|0.80487805604934692\tu:0.27010178565979004,0,0.18031886219978333,0\nGetPositionOnCurveArcLength|0.80487805604934692\tu:0.1689983457326889,0,0.23404872417449951,0\nGetTangentOnCurve|0.80487805604934692\tv:-112.40548706054688,41.06097412109375\nGetTangentOnCurveArcLength|0.80487805604934692\tv:-144.71920776367188,45.667995452880859\nGetPositionOnCurve|0.82926827669143677\tu:0.24404506385326385,0,0.19495770335197449,0\nGetPositionOnCurveArcLength|0.82926827669143677\tu:0.14854682981967926,0,0.24410928785800934,0\nGetTangentOnCurve|0.82926827669143677\tv:-121.55792236328125,42.365852355957031\nGetTangentOnCurveArcLength|0.82926827669143677\tv:-150.41392517089844,46.479900360107422\nGetPositionOnCurve|0.85365855693817139\tu:0.21594966948032379,0,0.21005450189113617,0\nGetPositionOnCurveArcLength|0.85365855693817139\tu:0.12805967032909393,0,0.25398731231689453,0\nGetTangentOnCurve|0.85365855693817139\tv:-130.71037292480469,43.670730590820312\nGetTangentOnCurveArcLength|0.85365855693817139\tv:-155.91017150878906,47.263507843017578\nGetPositionOnCurve|0.87804877758026123\tu:0.18581567704677582,0,0.22560922801494598,0\nGetPositionOnCurveArcLength|0.87804877758026123\tu:0.10754091292619705,0,0.26370042562484741,0\nGetTangentOnCurve|0.87804877758026123\tv:-139.86280822753906,44.975608825683594\nGetTangentOnCurveArcLength|0.87804877758026123\tv:-161.22718811035156,48.021564483642578\nGetPositionOnCurve|0.90243899822235107\tu:0.15364310145378113,0,0.24162185192108154,0\nGetPositionOnCurveArcLength|0.90243899822235107\tu:0.086994081735610962,0,0.27326342463493347,0\nGetTangentOnCurve|0.90243899822235107\tv:-149.01522827148438,46.280487060546875\nGetTangentOnCurveArcLength|0.90243899822235107\tv:-166.38130187988281,48.756393432617188\nGetPositionOnCurve|0.92682927846908569\tu:0.1194317638874054,0,0.25809246301651001,0\nGetPositionOnCurveArcLength|0.92682927846908569\tu:0.066421717405319214,0,0.28268936276435852,0\nGetTangentOnCurve|0.92682927846908569\tv:-158.16769409179688,47.585365295410156\nGetTangentOnCurveArcLength|0.92682927846908569\tv:-171.38661193847656,49.470008850097656\nGetPositionOnCurve|0.95121949911117554\tu:0.08318193256855011,0,0.27502095699310303,0\nGetPositionOnCurveArcLength|0.95121949911117554\tu:0.045826740562915802,0,0.29198899865150452,0\nGetTangentOnCurve|0.95121949911117554\tv:-167.32011413574219,48.890243530273438\nGetTangentOnCurveArcLength|0.95121949911117554\tv:-176.25509643554688,50.164115905761719\nGetPositionOnCurve|0.97560977935791016\tu:0.04489334300160408,0,0.29240745306015015,0\nGetPositionOnCurveArcLength|0.97560977935791016\tu:0.025210758671164513,0,0.30117228627204895,0\nGetTangentOnCurve|0.97560977935791016\tv:-176.47256469726562,50.195121765136719\nGetTangentOnCurveArcLength|0.97560977935791016\tv:-180.99745178222656,50.840240478515625\nGetPositionOnCurve|0.02380952425301075\tu:0.47958225011825562,0,0.52633112668991089,0\nGetPositionOnCurveArcLength|0.02380952425301075\tu:0.47816121578216553,0,0.52461999654769897,0\nGetTangentOnCurve|0.02380952425301075\tv:-72.551872253417969,-54.918365478515625\nGetTangentOnCurveArcLength|0.02380952425301075\tv:-72.46319580078125,-55.911911010742188\nGetPositionOnCurve|0.1190476194024086\tu:0.41987958550453186,0,0.42585408687591553,0\nGetPositionOnCurveArcLength|0.1190476194024086\tu:0.42118009924888611,0,0.42871034145355225,0\nGetTangentOnCurve|0.1190476194024086\tv:-62.725341796875,-87.959182739257812\nGetTangentOnCurveArcLength|0.1190476194024086\tv:-63.098735809326172,-87.43621826171875\nGetPositionOnCurve|0.26190477609634399\tu:0.35945606231689453,0,0.22897717356681824,0\nGetPositionOnCurveArcLength|0.26190477609634399\tu:0.3640676736831665,0,0.25350627303123474,0\nGetTangentOnCurve|0.26190477609634399\tv:-25.383499145507812,-95.122451782226562\nGetTangentOnCurveArcLength|0.26190477609634399\tv:-31.4937744140625,-96.999176025390625\nGetPositionOnCurve|0.3095238208770752\tu:0.3523252010345459,0,0.16653500497341156,0\nGetPositionOnCurveArcLength|0.3095238208770752\tu:0.35408708453178406,0,0.1895720362663269,0\nGetTangentOnCurve|0.3095238208770752\tv:-6.9090118408203125,-86.204078674316406\nGetTangentOnCurveArcLength|0.3095238208770752\tv:-14.298656463623047,-90.26629638671875\nGetPositionOnCurve|0.4047619104385376\tu:0.36544227600097656,0,0.069665536284446716,0\nGetPositionOnCurveArcLength|0.4047619104385376\tu:0.36843761801719666,0,0.064009301364421844,0\nGetTangentOnCurve|0.4047619104385376\tv:39.080787658691406,-51.408153533935547\nGetTangentOnCurveArcLength|0.4047619104385376\tv:43.463943481445312,-47.481884002685547\nGetPositionOnCurve|0.4523809552192688\tu:0.38831129670143127,0,0.04298483207821846,0\nGetPositionOnCurveArcLength|0.4523809552192688\tu:0.4054616391658783,0,0.03657284751534462,0\nGetTangentOnCurve|0.4523809552192688\tv:66.596084594726562,-25.530599594116211\nGetTangentOnCurveArcLength|0.4523809552192688\tv:82.397445678710938,-9.5272407531738281\nGetPositionOnCurve|0.5476190447807312\tu:0.42078569531440735,0,0.053801856935024261,0\nGetPositionOnCurveArcLength|0.5476190447807312\tu:0.37948355078697205,0,0.10580959916114807,0\nGetTangentOnCurve|0.5476190447807312\tv:-15.869047164916992,27.297618865966797\nGetTangentOnCurveArcLength|0.5476190447807312\tv:-60.382354736328125,33.643951416015625\nGetPositionOnCurve|0.5952380895614624\tu:0.40999919176101685,0,0.073378033936023712,0\nGetPositionOnCurveArcLength|0.5952380895614624\tu:0.34199365973472595,0,0.13499969244003296,0\nGetTangentOnCurve|0.5952380895614624\tv:-33.738094329833984,29.845237731933594\nGetTangentOnCurveArcLength|0.5952380895614624\tv:-82.017898559570312,36.728569030761719\nGetPositionOnCurve|0.6904761791229248\tu:0.36511367559432983,0,0.11776700615882874,0\nGetPositionOnCurveArcLength|0.6904761791229248\tu:0.26426184177398682,0,0.18366086483001709,0\nGetTangentOnCurve|0.6904761791229248\tv:-69.476188659667969,34.940475463867188\nGetTangentOnCurveArcLength|0.6904761791229248\tv:-114.52039337158203,41.362503051757812\nGetPositionOnCurve|0.73809522390365601\tu:0.33101466298103333,0,0.14257979393005371,0\nGetPositionOnCurveArcLength|0.73809522390365601\tu:0.22476927936077118,0,0.20538307726383209,0\nGetTangentOnCurve|0.73809522390365601\tv:-87.345230102539062,37.488094329833984\nGetTangentOnCurveArcLength|0.73809522390365601\tv:-127.90780639648438,43.271167755126953\nGetPositionOnCurve|0.88095235824584961\tu:0.18209253251552582,0,0.22749146819114685,0\nGetPositionOnCurveArcLength|0.88095235824584961\tu:0.10509634017944336,0,0.26484641432762146,0\nGetTangentOnCurve|0.88095235824584961\tv:-140.95237731933594,45.130950927734375\nGetTangentOnCurveArcLength|0.88095235824584961\tv:-161.8489990234375,48.110218048095703\nGetPositionOnCurve|0.97619044780731201\tu:0.043956946581602097,0,0.29282695055007935,0\nGetPositionOnCurveArcLength|0.97619044780731201\tu:0.024719726294279099,0,0.30138957500457764,0\nGetTangentOnCurve|0.97619044780731201\tv:-176.69046020507812,50.226188659667969\nGetTangentOnCurveArcLength|0.97619044780731201\tv:-181.10888671875,50.856132507324219\nGetPositionOnCurve|0.023255813866853714\tu:0.47994917631149292,0,0.52676767110824585,0\nGetPositionOnCurveArcLength|0.023255813866853714\tu:0.47854667901992798,0,0.52508735656738281,0\nGetTangentOnCurve|0.023255813866853714\tv:-72.573753356933594,-54.66015625\nGetTangentOnCurveArcLength|0.023255813866853714\tv:-72.487869262695312,-55.643417358398438\nGetPositionOnCurve|0.046511627733707428\tu:0.46465796232223511,0,0.50673556327819824,0\nGetPositionOnCurveArcLength|0.046511627733707428\tu:0.4629656970500946,0,0.5042877197265625,0\nGetTangentOnCurve|0.046511627733707428\tv:-71.303741455078125,-64.847015380859375\nGetTangentOnCurveArcLength|0.046511627733707428\tv:-71.116928100585938,-65.902984619140625\nGetPositionOnCurve|0.06976744532585144\tu:0.44971281290054321,0,0.48352029919624329,0\nGetPositionOnCurveArcLength|0.06976744532585144\tu:0.44852861762046814,0,0.48152533173561096,0\nGetTangentOnCurve|0.06976744532585144\tv:-69.314964294433594,-73.685577392578125\nGetTangentOnCurveArcLength|0.06976744532585144\tv:-69.123489379882812,-74.338859558105469\nGetPositionOnCurve|0.093023255467414856\tu:0.43526637554168701,0,0.45757314562797546,0\nGetPositionOnCurveArcLength|0.093023255467414856\tu:0.43510690331459045,0,0.45726677775382996,0\nGetTangentOnCurve|0.093023255467414856\tv:-66.607421875,-81.17584228515625\nGetTangentOnCurveArcLength|0.093023255467414856\tv:-66.572799682617188,-81.252601623535156\nGetPositionOnCurve|0.11627907305955887\tu:0.42147129774093628,0,0.42934522032737732,0\nGetPositionOnCurveArcLength|0.11627907305955887\tu:0.42260941863059998,0,0.43181055784225464,0\nGetTangentOnCurve|0.11627907305955887\tv:-63.181110382080078,-87.31781005859375\nGetTangentOnCurveArcLength|0.11627907305955887\tv:-63.498817443847656,-86.850387573242188\nGetPositionOnCurve|0.13953489065170288\tu:0.40848022699356079,0,0.39928767085075378,0\nGetPositionOnCurveArcLength|0.13953489065170288\tu:0.4109778106212616,0,0.40535441040992737,0\nGetTangentOnCurve|0.13953489065170288\tv:-59.036033630371094,-92.111480712890625\nGetTangentOnCurveArcLength|0.13953489065170288\tv:-59.912620544433594,-91.270599365234375\nGetPositionOnCurve|0.1627907007932663\tu:0.39644581079483032,0,0.36785164475440979,0\nGetPositionOnCurveArcLength|0.1627907007932663\tu:0.40018275380134583,0,0.37803184986114502,0\nGetTangentOnCurve|0.1627907007932663\tv:-54.172187805175781,-95.556854248046875\nGetTangentOnCurveArcLength|0.1627907007932663\tv:-55.806533813476562,-94.601211547851562\nGetPositionOnCurve|0.18604651093482971\tu:0.38552072644233704,0,0.33548834919929504,0\nGetPositionOnCurveArcLength|0.18604651093482971\tu:0.39022165536880493,0,0.34993398189544678,0\nGetTangentOnCurve|0.18604651093482971\tv:-48.589576721191406,-97.6539306640625\nGetTangentOnCurveArcLength|0.18604651093482971\tv:-51.155368804931641,-96.88983154296875\nGetPositionOnCurve|0.20930232107639313\tu:0.37585762143135071,0,0.30264893174171448,0\nGetPositionOnCurveArcLength|0.20930232107639313\tu:0.38111957907676697,0,0.32112199068069458,0\nGetTangentOnCurve|0.20930232107639313\tv:-42.288200378417969,-98.4027099609375\nGetTangentOnCurveArcLength|0.20930232107639313\tv:-45.915233612060547,-98.148216247558594\nGetPositionOnCurve|0.23255814611911774\tu:0.36760911345481873,0,0.26978448033332825,0\nGetPositionOnCurveArcLength|0.23255814611911774\tu:0.37293344736099243,0,0.29163601994514465,0\nGetTangentOnCurve|0.23255814611911774\tv:-35.268047332763672,-97.803207397460938\nGetTangentOnCurveArcLength|0.23255814611911774\tv:-40.019920349121094,-98.352249145507812\nGetPositionOnCurve|0.25581395626068115\tu:0.36092790961265564,0,0.23734623193740845,0\nGetPositionOnCurveArcLength|0.25581395626068115\tu:0.36576098203659058,0,0.26150277256965637,0\nGetTangentOnCurve|0.25581395626068115\tv:-27.529136657714844,-95.855392456054688\nGetTangentOnCurveArcLength|0.25581395626068115\tv:-33.374134063720703,-97.436988830566406\nGetPositionOnCurve|0.27906978130340576\tu:0.35596659779548645,0,0.20578537881374359,0\nGetPositionOnCurveArcLength|0.27906978130340576\tu:0.35975757241249084,0,0.23074297606945038,0\nGetTangentOnCurve|0.27906978130340576\tv:-19.071453094482422,-92.559288024902344\nGetTangentOnCurveArcLength|0.27906978130340576\tv:-25.841716766357422,-95.2852783203125\nGetPositionOnCurve|0.30232557654380798\tu:0.3528779149055481,0,0.17555299401283264,0\nGetPositionOnCurveArcLength|0.30232557654380798\tu:0.35516670346260071,0,0.19938807189464569,0\nGetTangentOnCurve|0.30232557654380798\tv:-9.8950157165527344,-87.914886474609375\nGetTangentOnCurveArcLength|0.30232557654380798\tv:-17.226467132568359,-91.706436157226562\nGetPositionOnCurve|0.32558140158653259\tu:0.35181444883346558,0,0.1471002995967865,0\nGetPositionOnCurveArcLength|0.32558140158653259\tu:0.3523763120174408,0,0.16751696169376373,0\nGetTangentOnCurve|0.32558140158653259\tv:0.00020599365234375,-81.92218017578125\nGetTangentOnCurveArcLength|0.32558140158653259\tv:-7.2404327392578125,-86.398353576660156\nGetPositionOnCurve|0.34883719682693481\tu:0.35292890667915344,0,0.12087845057249069,0\nGetPositionOnCurveArcLength|0.34883719682693481\tu:0.35202378034591675,0,0.13536162674427032,0\nGetTangentOnCurve|0.34883719682693481\tv:10.614181518554688,-74.581192016601562\nGetTangentOnCurveArcLength|0.34883719682693481\tv:4.5415802001953125,-78.885879516601562\nGetPositionOnCurve|0.37209302186965942\tu:0.35637384653091431,0,0.097338557243347168,0\nGetPositionOnCurveArcLength|0.37209302186965942\tu:0.35516828298568726,0,0.10361749678850174,0\nGetTangentOnCurve|0.37209302186965942\tv:21.946937561035156,-65.891899108886719\nGetTangentOnCurveArcLength|0.37209302186965942\tv:18.709228515625,-68.454627990722656\nGetPositionOnCurve|0.39534884691238403\tu:0.3623020350933075,0,0.076931849122047424,0\nGetPositionOnCurveArcLength|0.39534884691238403\tu:0.36336705088615417,0,0.07428307831287384,0\nGetTangentOnCurve|0.39534884691238403\tv:33.998451232910156,-55.854297637939453\nGetTangentOnCurveArcLength|0.39534884691238403\tv:35.789505004882812,-54.300941467285156\nGetPositionOnCurve|0.41860464215278625\tu:0.37086606025695801,0,0.060109421610832214,0\nGetPositionOnCurveArcLength|0.41860464215278625\tu:0.37765461206436157,0,0.051584914326667786,0\nGetTangentOnCurve|0.41860464215278625\tv:46.768722534179688,-44.468421936035156\nGetTangentOnCurveArcLength|0.41860464215278625\tv:55.14959716796875,-36.634822845458984\nGetPositionOnCurve|0.44186046719551086\tu:0.38221859931945801,0,0.047322500497102737,0\nGetPositionOnCurveArcLength|0.44186046719551086\tu:0.39636349678039551,0,0.039078086614608765,0\nGetTangentOnCurve|0.44186046719551086\tv:60.257766723632812,-31.734230041503906\nGetTangentOnCurveArcLength|0.44186046719551086\tv:74.328460693359375,-17.790651321411133\nGetPositionOnCurve|0.46511629223823547\tu:0.39651226997375488,0,0.039022210985422134,0\nGetPositionOnCurveArcLength|0.46511629223823547\tu:0.41662591695785522,0,0.035608798265457153,0\nGetTangentOnCurve|0.46511629223823547\tv:74.465606689453125,-17.651763916015625\nGetTangentOnCurveArcLength|0.46511629223823547\tv:91.5679931640625,0.077350616455078125\nGetPositionOnCurve|0.4883720874786377\tu:0.4138997495174408,0,0.035659845918416977,0\nGetPositionOnCurveArcLength|0.4883720874786377\tu:0.42008084058761597,0,0.05562157928943634,0\nGetTangentOnCurve|0.4883720874786377\tv:89.392166137695312,-2.2210044860839844\nGetTangentOnCurveArcLength|0.4883720874786377\tv:-17.599769592285156,27.544370651245117\nGetPositionOnCurve|0.5116279125213623\tu:0.42378208041191101,0,0.040164139121770859,0\nGetPositionOnCurveArcLength|0.5116279125213623\tu:0.40596634149551392,0,0.078697971999645233,0\nGetTangentOnCurve|0.5116279125213623\tv:-2.3633742332458496,25.372093200683594\nGetTangentOnCurveArcLength|0.5116279125213623\tv:-38.336349487304688,30.500818252563477\nGetPositionOnCurve|0.53488373756408691\tu:0.42235341668128967,0,0.048862215131521225,0\nGetPositionOnCurveArcLength|0.53488373756408691\tu:0.3891492486000061,0,0.09693705290555954,0\nGetTangentOnCurve|0.53488373756408691\tv:-11.090122222900391,26.616279602050781\nGetTangentOnCurveArcLength|0.53488373756408691\tv:-53.401336669921875,32.648658752441406\nGetPositionOnCurve|0.55813956260681152\tu:0.41907137632369995,0,0.057976614683866501,0\nGetPositionOnCurveArcLength|0.55813956260681152\tu:0.37135103344917297,0,0.11272542178630829,0\nGetTangentOnCurve|0.55813956260681152\tv:-19.816871643066406,27.860466003417969\nGetTangentOnCurveArcLength|0.55813956260681152\tv:-65.683761596679688,34.399784088134766\nGetPositionOnCurve|0.58139532804489136\tu:0.41393595933914185,0,0.067507311701774597,0\nGetPositionOnCurveArcLength|0.58139532804489136\tu:0.35304561257362366,0,0.12700940668582916,0\nGetTangentOnCurve|0.58139532804489136\tv:-28.543596267700195,29.104650497436523\nGetTangentOnCurveArcLength|0.58139532804489136\tv:-76.280342102050781,35.910552978515625\nGetPositionOnCurve|0.60465115308761597\tu:0.40694710612297058,0,0.077454365789890289,0\nGetPositionOnCurveArcLength|0.60465115308761597\tu:0.33442807197570801,0,0.14025716483592987,0\nGetTangentOnCurve|0.60465115308761597\tv:-37.270343780517578,30.348836898803711\nGetTangentOnCurveArcLength|0.60465115308761597\tv:-85.72442626953125,37.257011413574219\nGetPositionOnCurve|0.62790697813034058\tu:0.39810487627983093,0,0.087817743420600891,0\nGetPositionOnCurveArcLength|0.62790697813034058\tu:0.3155977725982666,0,0.15273761749267578,0\nGetTangentOnCurve|0.62790697813034058\tv:-45.997093200683594,31.593023300170898\nGetTangentOnCurveArcLength|0.62790697813034058\tv:-94.319374084472656,38.482410430908203\nGetPositionOnCurve|0.65116280317306519\tu:0.38740918040275574,0,0.098597444593906403,0\nGetPositionOnCurveArcLength|0.65116280317306519\tu:0.29661235213279724,0,0.16462127864360809,0\nGetTangentOnCurve|0.65116280317306519\tv:-54.723842620849609,32.837211608886719\nGetTangentOnCurveArcLength|0.65116280317306519\tv:-102.25634765625,39.613998413085938\nGetPositionOnCurve|0.67441862821578979\tu:0.37486016750335693,0,0.10979346185922623,0\nGetPositionOnCurveArcLength|0.67441862821578979\tu:0.27750852704048157,0,0.17602396011352539,0\nGetTangentOnCurve|0.67441862821578979\tv:-63.450592041015625,34.081398010253906\nGetTangentOnCurveArcLength|0.67441862821578979\tv:-109.66453552246094,40.670192718505859\nGetPositionOnCurve|0.69767439365386963\tu:0.36045771837234497,0,0.12140578776597977,0\nGetPositionOnCurveArcLength|0.69767439365386963\tu:0.25831082463264465,0,0.18702854216098785,0\nGetTangentOnCurve|0.69767439365386963\tv:-72.177314758300781,35.325580596923828\nGetTangentOnCurveArcLength|0.69767439365386963\tv:-116.63606262207031,41.664134979248047\nGetPositionOnCurve|0.72093021869659424\tu:0.34420183300971985,0,0.13343445956707001,0\nGetPositionOnCurveArcLength|0.72093021869659424\tu:0.23903676867485046,0,0.19769667088985443,0\nGetTangentOnCurve|0.72093021869659424\tv:-80.904067993164062,36.569766998291016\nGetTangentOnCurveArcLength|0.72093021869659424\tv:-123.23923492431641,42.605560302734375\nGetPositionOnCurve|0.74418604373931885\tu:0.32609257102012634,0,0.14587946236133575,0\nGetPositionOnCurveArcLength|0.74418604373931885\tu:0.21969911456108093,0,0.20807568728923798,0\nGetTangentOnCurve|0.74418604373931885\tv:-89.630813598632812,37.813953399658203\nGetTangentOnCurveArcLength|0.74418604373931885\tv:-129.52633666992188,43.501922607421875\nGetPositionOnCurve|0.76744186878204346\tu:0.30612990260124207,0,0.15874077379703522,0\nGetPositionOnCurveArcLength|0.76744186878204346\tu:0.20030787587165833,0,0.21820265054702759,0\nGetTangentOnCurve|0.76744186878204346\tv:-98.357559204101562,39.058139801025391\nGetTangentOnCurveArcLength|0.76744186878204346\tv:-135.538330078125,44.359062194824219\nGetPositionOnCurve|0.79069769382476807\tu:0.2843138575553894,0,0.17201842367649078,0\nGetPositionOnCurveArcLength|0.79069769382476807\tu:0.18087048828601837,0,0.2281075119972229,0\nGetTangentOnCurve|0.79069769382476807\tv:-107.08431243896484,40.302326202392578\nGetTangentOnCurveArcLength|0.79069769382476807\tv:-141.30816650390625,45.181678771972656\nGetPositionOnCurve|0.8139534592628479\tu:0.26064443588256836,0,0.18571236729621887,0\nGetPositionOnCurveArcLength|0.8139534592628479\tu:0.16139306128025055,0,0.23781470954418182,0\nGetTangentOnCurve|0.8139534592628479\tv:-115.81103515625,41.5465087890625\nGetTangentOnCurveArcLength|0.8139534592628479\tv:-146.86268615722656,45.973594665527344\nGetPositionOnCurve|0.83720928430557251\tu:0.23512156307697296,0,0.19982264935970306,0\nGetPositionOnCurveArcLength|0.83720928430557251\tu:0.14188042283058167,0,0.24734444916248322,0\nGetTangentOnCurve|0.83720928430557251\tv:-124.53778076171875,42.790695190429688\nGetTangentOnCurveArcLength|0.83720928430557251\tv:-152.22415161132812,46.737987518310547\nGetPositionOnCurve|0.86046510934829712\tu:0.20774529874324799,0,0.21434928476810455,0\nGetPositionOnCurveArcLength|0.86046510934829712\tu:0.12233653664588928,0,0.2567138671875,0\nGetTangentOnCurve|0.86046510934829712\tv:-133.2645263671875,44.034881591796875\nGetTangentOnCurveArcLength|0.86046510934829712\tv:-157.4112548828125,47.477523803710938\nGetPositionOnCurve|0.88372093439102173\tu:0.17851558327674866,0,0.22929222881793976,0\nGetPositionOnCurveArcLength|0.88372093439102173\tu:0.10276491194963455,0,0.26593729853630066,0\nGetTangentOnCurve|0.88372093439102173\tv:-141.99128723144531,45.279067993164062\nGetTangentOnCurveArcLength|0.88372093439102173\tv:-162.4398193359375,48.194450378417969\nGetPositionOnCurve|0.90697675943374634\tu:0.14743249118328094,0,0.24465149641036987,0\nGetPositionOnCurveArcLength|0.90697675943374634\tu:0.083168447017669678,0,0.27502715587615967,0\nGetTangentOnCurve|0.90697675943374634\tv:-150.71803283691406,46.52325439453125\nGetTangentOnCurveArcLength|0.90697675943374634\tv:-167.32342529296875,48.890716552734375\nGetPositionOnCurve|0.93023258447647095\tu:0.11449599266052246,0,0.2604270875453949,0\nGetPositionOnCurveArcLength|0.93023258447647095\tu:0.06354936957359314,0,0.28399431705474854,0\nGetTangentOnCurve|0.93023258447647095\tv:-159.44477844238281,47.767440795898438\nGetTangentOnCurveArcLength|0.93023258447647095\tv:-172.07388305664062,49.5679931640625\nGetPositionOnCurve|0.95348834991455078\tu:0.079706199467182159,0,0.27661898732185364,0\nGetPositionOnCurveArcLength|0.95348834991455078\tu:0.043909847736358643,0,0.29284802079200745,0\nGetTangentOnCurve|0.95348834991455078\tv:-168.1715087890625,49.011627197265625\nGetTangentOnCurveArcLength|0.95348834991455078\tv:-176.701416015625,50.227752685546875\nGetPositionOnCurve|0.97674417495727539\tu:0.043062914162874222,0,0.29322722554206848,0\nGetPositionOnCurveArcLength|0.97674417495727539\tu:0.024251511320471764,0,0.30159673094749451,0\nGetTangentOnCurve|0.97674417495727539\tv:-176.89825439453125,50.255813598632812\nGetTangentOnCurveArcLength|0.97674417495727539\tv:-181.215087890625,50.871273040771484\nGetPositionOnCurve|0.022727273404598236\tu:0.48029953241348267,0,0.52718240022659302,0\nGetPositionOnCurveArcLength|0.022727273404598236\tu:0.47891530394554138,0,0.52553212642669678,0\nGetTangentOnCurve|0.022727273404598236\tv:-72.594268798828125,-54.4129638671875\nGetTangentOnCurveArcLength|0.022727273404598236\tv:-72.511032104492188,-55.385948181152344\nGetPositionOnCurve|0.068181820213794708\tu:0.45071768760681152,0,0.48519507050514221,0\nGetPositionOnCurveArcLength|0.068181820213794708\tu:0.44947946071624756,0,0.48312905430793762,0\nGetTangentOnCurve|0.068181820213794708\tv:-69.473396301269531,-73.125778198242188\nGetTangentOnCurveArcLength|0.068181820213794708\tv:-69.27764892578125,-73.814857482910156\nGetPositionOnCurve|0.11363636702299118\tu:0.42300125956535339,0,0.4326535165309906,0\nGetPositionOnCurveArcLength|0.11363636702299118\tu:0.42398509383201599,0,0.43475666642189026,0\nGetTangentOnCurve|0.11363636702299118\tv:-63.606662750244141,-86.687759399414062\nGetTangentOnCurveArcLength|0.11363636702299118\tv:-63.873958587646484,-86.275680541992188\nGetPositionOnCurve|0.15909090638160706\tu:0.39829012751579285,0,0.37292653322219849,0\nGetPositionOnCurveArcLength|0.15909090638160706\tu:0.40184462070465088,0,0.3824324905872345,0\nGetTangentOnCurve|0.15909090638160706\tv:-54.994060516357422,-95.098915100097656\nGetTangentOnCurveArcLength|0.15909090638160706\tv:-56.495384216308594,-94.141830444335938\nGetPositionOnCurve|0.20454545319080353\tu:0.3777240514755249,0,0.3093828558921814,0\nGetPositionOnCurveArcLength|0.20454545319080353\tu:0.38290920853614807,0,0.32707116007804871,0\nGetTangentOnCurve|0.20454545319080353\tv:-43.635589599609375,-98.359245300292969\nGetTangentOnCurveArcLength|0.20454545319080353\tv:-47.037834167480469,-97.975265502929688\nGetPositionOnCurve|0.29545453190803528\tu:0.35358655452728271,0,0.1843203604221344,0\nGetPositionOnCurveArcLength|0.29545453190803528\tu:0.35635676980018616,0,0.20871084928512573,0\nGetTangentOnCurve|0.29545453190803528\tv:-12.681045532226562,-89.42742919921875\nGetTangentOnCurveArcLength|0.29545453190803528\tv:-19.899429321289062,-92.927566528320312\nGetPositionOnCurve|0.34090909361839294\tu:0.35229480266571045,0,0.12953907251358032,0\nGetPositionOnCurveArcLength|0.34090909361839294\tu:0.35181531310081482,0,0.14632807672023773,0\nGetTangentOnCurve|0.34090909361839294\tv:6.9150314331054688,-77.235282897949219\nGetTangentOnCurveArcLength|0.34090909361839294\tv:0.2896881103515625,-81.733627319335938\nGetPositionOnCurve|0.38636362552642822\tu:0.35970747470855713,0,0.084416091442108154,0\nGetPositionOnCurveArcLength|0.38636362552642822\tu:0.35949495434761047,0,0.085108615458011627,0\nGetTangentOnCurve|0.38636362552642822\tv:29.256965637207031,-59.892307281494141\nGetTangentOnCurveArcLength|0.38636362552642822\tv:28.839347839355469,-60.242637634277344\nGetPositionOnCurve|0.43181818723678589\tu:0.37696447968482971,0,0.052320137619972229,0\nGetPositionOnCurveArcLength|0.43181818723678589\tu:0.38794735074043274,0,0.043206799775362015,0\nGetTangentOnCurve|0.43181818723678589\tv:54.344779968261719,-37.398506164550781\nGetTangentOnCurveArcLength|0.43181818723678589\tv:66.230621337890625,-25.891862869262695\nGetPositionOnCurve|0.47727271914482117\tu:0.40520557761192322,0,0.036620106548070908,0\nGetPositionOnCurveArcLength|0.47727271914482117\tu:0.42368334531784058,0,0.041470590978860855,0\nGetTangentOnCurve|0.47727271914482117\tv:82.178451538085938,-9.7538948059082031\nGetTangentOnCurveArcLength|0.47727271914482117\tv:-3.7012453079223633,25.562835693359375\nGetPositionOnCurve|0.52272725105285645\tu:0.42333140969276428,0,0.044263549149036407,0\nGetPositionOnCurveArcLength|0.52272725105285645\tu:0.39811670780181885,0,0.087804920971393585,0\nGetTangentOnCurve|0.52272725105285645\tv:-6.5284013748168945,25.965908050537109\nGetTangentOnCurveArcLength|0.52272725105285645\tv:-45.986515045166016,31.591514587402344\nGetPositionOnCurve|0.56818181276321411\tu:0.41708120703697205,0,0.062041070312261581,0\nGetPositionOnCurveArcLength|0.56818181276321411\tu:0.36349397897720337,0,0.11904416233301163,0\nGetTangentOnCurve|0.56818181276321411\tv:-23.585226058959961,28.397727966308594\nGetTangentOnCurveArcLength|0.56818181276321411\tv:-70.4276123046875,35.076122283935547\nGetPositionOnCurve|0.61363637447357178\tu:0.40375047922134399,0,0.081409052014350891,0\nGetPositionOnCurveArcLength|0.61363637447357178\tu:0.32717415690422058,0,0.14515924453735352,0\nGetTangentOnCurve|0.61363637447357178\tv:-40.642047882080078,30.829545974731445\nGetTangentOnCurveArcLength|0.61363637447357178\tv:-89.133621215820312,37.743068695068359\nGetPositionOnCurve|0.65909093618392944\tu:0.38333934545516968,0,0.10236749798059464,0\nGetPositionOnCurveArcLength|0.65909093618392944\tu:0.29011157155036926,0,0.16855789721012115,0\nGetTangentOnCurve|0.65909093618392944\tv:-57.698875427246094,33.261363983154297\nGetTangentOnCurveArcLength|0.65909093618392944\tv:-104.83603668212891,39.981788635253906\nGetPositionOnCurve|0.70454543828964233\tu:0.35584774613380432,0,0.12491638213396072,0\nGetPositionOnCurveArcLength|0.70454543828964233\tu:0.25262352824211121,0,0.19021311402320862,0\nGetTangentOnCurve|0.70454543828964233\tv:-74.75567626953125,35.693180084228516\nGetTangentOnCurveArcLength|0.70454543828964233\tv:-118.62272644042969,41.947376251220703\nGetPositionOnCurve|0.79545456171035767\tu:0.27962315082550049,0,0.17478558421134949,0\nGetPositionOnCurveArcLength|0.79545456171035767\tu:0.17688946425914764,0,0.23010849952697754,0\nGetTangentOnCurve|0.79545456171035767\tv:-108.86932373046875,40.556819915771484\nGetTangentOnCurveArcLength|0.79545456171035767\tv:-142.46107482910156,45.346050262451172\nGetPositionOnCurve|0.84090906381607056\tu:0.23089022934436798,0,0.20210586488246918,0\nGetPositionOnCurveArcLength|0.84090906381607056\tu:0.13877315819263458,0,0.24884535372257233,0\nGetTangentOnCurve|0.84090906381607056\tv:-125.92612457275391,42.988632202148438\nGetTangentOnCurveArcLength|0.84090906381607056\tv:-153.06059265136719,46.85723876953125\nGetPositionOnCurve|0.88636362552642822\tu:0.17507676780223846,0,0.23101663589477539,0\nGetPositionOnCurveArcLength|0.88636362552642822\tu:0.10053932666778564,0,0.26697668433189392,0\nGetTangentOnCurve|0.88636362552642822\tv:-142.98295593261719,45.420455932617188\nGetTangentOnCurveArcLength|0.88636362552642822\tv:-163.00181579589844,48.274574279785156\nGetPositionOnCurve|0.93181818723678589\tu:0.1121828630566597,0,0.26151785254478455,0\nGetPositionOnCurveArcLength|0.93181818723678589\tu:0.062210988253355026,0,0.28460144996643066,0\nGetTangentOnCurve|0.93181818723678589\tv:-160.03977966308594,47.852272033691406\nGetTangentOnCurveArcLength|0.93181818723678589\tv:-172.39317321777344,49.613517761230469\nGetPositionOnCurve|0.97727274894714355\tu:0.042208492755889893,0,0.29360952973365784,0\nGetPositionOnCurveArcLength|0.97727274894714355\tu:0.023804547265172005,0,0.30179432034492493,0\nGetTangentOnCurve|0.97727274894714355\tv:-177.09660339355469,50.284091949462891\nGetTangentOnCurveArcLength|0.97727274894714355\tv:-181.31640625,50.885715484619141\nGetPositionOnCurve|0.02222222276031971\tu:0.48063439130783081,0,0.52757692337036133,0\nGetPositionOnCurveArcLength|0.02222222276031971\tu:0.47926819324493408,0,0.52595573663711548,0\nGetTangentOnCurve|0.02222222276031971\tv:-72.613517761230469,-54.176109313964844\nGetTangentOnCurveArcLength|0.02222222276031971\tv:-72.532806396484375,-55.138828277587891\nGetPositionOnCurve|0.04444444552063942\tu:0.46600544452667236,0,0.50865167379379272,0\nGetPositionOnCurveArcLength|0.04444444552063942\tu:0.4643021821975708,0,0.50622469186782837,0\nGetTangentOnCurve|0.04444444552063942\tv:-71.44573974609375,-63.996112823486328\nGetTangentOnCurveArcLength|0.04444444552063942\tv:-71.265251159667969,-65.070205688476562\nGetPositionOnCurve|0.088888891041278839\tu:0.43779140710830688,0,0.46236562728881836,0\nGetPositionOnCurveArcLength|0.088888891041278839\tu:0.43742328882217407,0,0.46167391538619995,0\nGetTangentOnCurve|0.088888891041278839\tv:-67.14129638671875,-79.942779541015625\nGetTangentOnCurveArcLength|0.088888891041278839\tv:-67.065139770507812,-80.12457275390625\nGetPositionOnCurve|0.15555556118488312\tu:0.40007814764976501,0,0.37775224447250366,0\nGetPositionOnCurveArcLength|0.15555556118488312\tu:0.40345224738121033,0,0.38661885261535645,0\nGetTangentOnCurve|0.15555556118488312\tv:-55.762405395507812,-94.629440307617188\nGetTangentOnCurveArcLength|0.15555556118488312\tv:-57.140865325927734,-93.678176879882812\nGetPositionOnCurve|0.17777778208255768\tu:0.38926848769187927,0,0.34707316756248474,0\nGetPositionOnCurveArcLength|0.17777778208255768\tu:0.39366689324378967,0,0.3600088357925415,0\nGetTangentOnCurve|0.17777778208255768\tv:-50.656852722167969,-97.062774658203125\nGetTangentOnCurveArcLength|0.17777778208255768\tv:-52.873893737792969,-96.194000244140625\nGetPositionOnCurve|0.24444444477558136\tu:0.36398887634277344,0,0.25312331318855286,0\nGetPositionOnCurveArcLength|0.24444444477558136\tu:0.36913272738456726,0,0.2763141393661499,0\nGetTangentOnCurve|0.24444444477558136\tv:-31.402408599853516,-96.976104736328125\nGetTangentOnCurveArcLength|0.24444444477558136\tv:-36.724380493164062,-98.030250549316406\nGetPositionOnCurve|0.28888890147209167\tu:0.35442525148391724,0,0.19283245503902435,0\nGetPositionOnCurveArcLength|0.28888890147209167\tu:0.35762864351272583,0,0.21757394075393677,0\nGetTangentOnCurve|0.28888890147209167\tv:-15.284626007080078,-90.762779235839844\nGetTangentOnCurveArcLength|0.28888890147209167\tv:-22.350349426269531,-93.962661743164062\nGetPositionOnCurve|0.31111112236976624\tu:0.35222989320755005,0,0.16457070410251617,0\nGetPositionOnCurveArcLength|0.31111112236976624\tu:0.35387346148490906,0,0.18740108609199524,0\nGetTangentOnCurve|0.31111112236976624\tv:-6.2412872314453125,-85.809440612792969\nGetTangentOnCurveArcLength|0.31111112236976624\tv:-13.634468078613281,-89.925460815429688\nGetPositionOnCurve|0.35555556416511536\tu:0.35367795825004578,0,0.1137826219201088,0\nGetPositionOnCurveArcLength|0.35555556416511536\tu:0.35251230001449585,0,0.12609615921974182,0\nGetTangentOnCurve|0.35555556416511536\tv:13.814262390136719,-72.209442138671875\nGetTangentOnCurveArcLength|0.35555556416511536\tv:8.3602218627929688,-76.209915161132812\nGetPositionOnCurve|0.37777778506278992\tu:0.35758784413337708,0,0.092043623328208923,0\nGetPositionOnCurveArcLength|0.37777778506278992\tu:0.35664054751396179,0,0.096100844442844391,0\nGetTangentOnCurve|0.37777778506278992\tv:24.82647705078125,-63.562782287597656\nGetTangentOnCurveArcLength|0.37777778506278992\tv:22.607086181640625,-65.361991882324219\nGetPositionOnCurve|0.42222222685813904\tu:0.37244498729705811,0,0.057843927294015884,0\nGetPositionOnCurveArcLength|0.42222222685813904\tu:0.38035431504249573,0,0.048945143818855286,0\nGetTangentOnCurve|0.42222222685813904\tv:48.819808959960938,-42.576114654541016\nGetTangentOnCurveArcLength|0.42222222685813904\tv:58.213470458984375,-33.706428527832031\nGetPositionOnCurve|0.48888888955116272\tu:0.41432246565818787,0,0.035644587129354477,0\nGetPositionOnCurveArcLength|0.48888888955116272\tu:0.41983386874198914,0,0.056221775710582733,0\nGetTangentOnCurve|0.48888888955116272\tv:89.732040405273438,-1.8627662658691406\nGetTangentOnCurveArcLength|0.48888888955116272\tv:-18.167221069335938,27.625272750854492\nGetPositionOnCurve|0.51111114025115967\tu:0.42379277944564819,0,0.039975583553314209,0\nGetPositionOnCurveArcLength|0.51111114025115967\tu:0.40632101893424988,0,0.078251540660858154,0\nGetTangentOnCurve|0.51111114025115967\tv:-2.1694555282592773,25.344446182250977\nGetTangentOnCurveArcLength|0.51111114025115967\tv:-37.954292297363281,30.446348190307617\nGetPositionOnCurve|0.57777780294418335\tu:0.41485652327537537,0,0.065997429192066193,0\nGetPositionOnCurveArcLength|0.57777780294418335\tu:0.35591697692871094,0,0.12486430257558823,0\nGetTangentOnCurve|0.57777780294418335\tv:-27.186120986938477,28.911111831665039\nGetTangentOnCurveArcLength|0.57777780294418335\tv:-74.717620849609375,35.687755584716797\nGetPositionOnCurve|0.62222224473953247\tu:0.40043744444847107,0,0.085246041417121887,0\nGetPositionOnCurveArcLength|0.62222224473953247\tu:0.32021677494049072,0,0.14974737167358398,0\nGetTangentOnCurve|0.62222224473953247\tv:-43.863899230957031,31.288890838623047\nGetTangentOnCurveArcLength|0.62222224473953247\tv:-92.285186767578125,38.192390441894531\nGetPositionOnCurve|0.64444446563720703\tu:0.39068946242332458,0,0.09544055163860321,0\nGetPositionOnCurveArcLength|0.64444446563720703\tu:0.30211058259010315,0,0.16124196350574493,0\nGetTangentOnCurve|0.64444446563720703\tv:-52.202785491943359,32.477779388427734\nGetTangentOnCurveArcLength|0.64444446563720703\tv:-100.02259063720703,39.295524597167969\nGetPositionOnCurve|0.68888890743255615\tu:0.36611646413803101,0,0.11696998029947281,0\nGetPositionOnCurveArcLength|0.68888890743255615\tu:0.26557305455207825,0,0.18291376531124115,0\nGetTangentOnCurve|0.68888890743255615\tv:-68.880561828613281,34.855556488037109\nGetTangentOnCurveArcLength|0.68888890743255615\tv:-114.0489501953125,41.2952880859375\nGetPositionOnCurve|0.71111112833023071\tu:0.35129150748252869,0,0.12830492854118347,0\nGetPositionOnCurveArcLength|0.71111112833023071\tu:0.24718303978443146,0,0.19323010742664337,0\nGetTangentOnCurve|0.71111112833023071\tv:-77.219451904296875,36.044445037841797\nGetTangentOnCurveArcLength|0.71111112833023071\tv:-120.49253082275391,42.213958740234375\nGetPositionOnCurve|0.75555557012557983\tu:0.31656461954116821,0,0.15211519598960876,0\nGetPositionOnCurveArcLength|0.75555557012557983\tu:0.21022514998912811,0,0.21305613219738007,0\nGetTangentOnCurve|0.75555557012557983\tv:-93.897224426269531,38.422222137451172\nGetTangentOnCurveArcLength|0.75555557012557983\tv:-132.49769592285156,43.925556182861328\nGetPositionOnCurve|0.82222223281860352\tu:0.25178194046020508,0,0.19068169593811035,0\nGetPositionOnCurveArcLength|0.82222223281860352\tu:0.15445888042449951,0,0.24122251570224762,0\nGetTangentOnCurve|0.82222223281860352\tv:-118.91389465332031,41.9888916015625\nGetTangentOnCurveArcLength|0.82222223281860352\tv:-148.79011535644531,46.248390197753906\nGetPositionOnCurve|0.84444445371627808\tu:0.22680309414863586,0,0.20429745316505432,0\nGetPositionOnCurveArcLength|0.84444445371627808\tu:0.13580320775508881,0,0.2502758800983429,0\nGetTangentOnCurve|0.84444445371627808\tv:-127.25277709960938,43.177780151367188\nGetTangentOnCurveArcLength|0.84444445371627808\tv:-153.8558349609375,46.970619201660156\nGetPositionOnCurve|0.91111111640930176\tu:0.14171262085437775,0,0.2474256306886673,0\nGetPositionOnCurveArcLength|0.91111111640930176\tu:0.07968226820230484,0,0.27662995457649231,0\nGetTangentOnCurve|0.91111111640930176\tv:-152.26943969726562,46.74444580078125\nGetTangentOnCurveArcLength|0.91111111640930176\tv:-168.17735290527344,49.012458801269531\nGetPositionOnCurve|0.95555555820465088\tu:0.076524049043655396,0,0.27807843685150146,0\nGetPositionOnCurveArcLength|0.95555555820465088\tu:0.042163100093603134,0,0.29362988471984863,0\nGetTangentOnCurve|0.95555555820465088\tv:-168.94721984863281,49.122222900390625\nGetTangentOnCurveArcLength|0.95555555820465088\tv:-177.10713195800781,50.285594940185547\nGetPositionOnCurve|0.97777777910232544\tu:0.041391275823116302,0,0.29397502541542053,0\nGetPositionOnCurveArcLength|0.97777777910232544\tu:0.023377405479550362,0,0.30198317766189575,0\nGetTangentOnCurve|0.97777777910232544\tv:-177.28611755371094,50.311111450195312\nGetTangentOnCurveArcLength|0.97777777910232544\tv:-181.41317749023438,50.899513244628906\nGetPositionOnCurve|0.021739130839705467\tu:0.48095479607582092,0,0.52795273065567017,0\nGetPositionOnCurveArcLength|0.021739130839705467\tu:0.47960630059242249,0,0.52635985612869263,0\nGetTangentOnCurve|0.021739130839705467\tv:-72.631614685058594,-53.948959350585938\nGetTangentOnCurveArcLength|0.021739130839705467\tv:-72.553321838378906,-54.901451110839844\nGetPositionOnCurve|0.065217390656471252\tu:0.45260244607925415,0,0.48829150199890137,0\nGetPositionOnCurveArcLength|0.065217390656471252\tu:0.45126989483833313,0,0.48610830307006836,0\nGetTangentOnCurve|0.065217390656471252\tv:-69.760635375976562,-72.0623779296875\nGetTangentOnCurveArcLength|0.065217390656471252\tv:-69.558891296386719,-72.816024780273438\nGetPositionOnCurve|0.10869564861059189\tu:0.42588874697685242,0,0.43877294659614563,0\nGetPositionOnCurveArcLength|0.10869564861059189\tu:0.42658731341362,0,0.4402293860912323,0\nGetTangentOnCurve|0.10869564861059189\tv:-64.377365112304688,-85.463134765625\nGetTangentOnCurveArcLength|0.10869564861059189\tv:-64.5576171875,-85.159988403320312\nGetPositionOnCurve|0.15217390656471252\tu:0.40181136131286621,0,0.38234511017799377,0\nGetPositionOnCurveArcLength|0.15217390656471252\tu:0.4050079882144928,0,0.3906061053276062,0\nGetTangentOnCurve|0.15217390656471252\tv:-56.481807708740234,-94.151229858398438\nGetTangentOnCurveArcLength|0.15217390656471252\tv:-57.746753692626953,-93.21197509765625\nGetPositionOnCurve|0.19565217196941376\tu:0.38136771321296692,0,0.32195621728897095,0\nGetPositionOnCurveArcLength|0.19565217196941376\tu:0.38635554909706116,0,0.33811724185943604,0\nGetTangentOnCurve|0.19565217196941376\tv:-46.073959350585938,-98.126655578613281\nGetTangentOnCurveArcLength|0.19565217196941376\tv:-49.065574645996094,-97.535018920898438\nGetPositionOnCurve|0.23913043737411499\tu:0.36555543541908264,0,0.26055440306663513,0\nGetPositionOnCurveArcLength|0.23913043737411499\tu:0.37079820036888123,0,0.28318476676940918,0\nGetTangentOnCurve|0.23913043737411499\tv:-33.153827667236328,-97.389419555664062\nGetTangentOnCurveArcLength|0.23913043737411499\tv:-38.222850799560547,-98.211021423339844\nGetPositionOnCurve|0.28260868787765503\tu:0.35537201166152954,0,0.20108795166015625,0\nGetPositionOnCurveArcLength|0.28260868787765503\tu:0.35896030068397522,0,0.22600884735584259,0\nGetTangentOnCurve|0.28260868787765503\tv:-17.721412658691406,-91.93951416015625\nGetTangentOnCurveArcLength|0.28260868787765503\tv:-24.6064453125,-94.838714599609375\nGetPositionOnCurve|0.32608696818351746\tu:0.35181495547294617,0,0.14650490880012512,0\nGetPositionOnCurveArcLength|0.32608696818351746\tu:0.35233980417251587,0,0.16681958734989166,0\nGetTangentOnCurve|0.32608696818351746\tv:0.22330474853515625,-81.776931762695312\nGetTangentOnCurveArcLength|0.32608696818351746\tv:-7.005218505859375,-86.260581970214844\nGetPositionOnCurve|0.3695652186870575\tu:0.35588183999061584,0,0.099753536283969879,0\nGetPositionOnCurveArcLength|0.3695652186870575\tu:0.35461238026618958,0,0.10700450837612152,0\nGetTangentOnCurve|0.3695652186870575\tv:20.680290222167969,-66.901710510253906\nGetTangentOnCurveArcLength|0.3695652186870575\tv:17.033828735351562,-69.756431579589844\nGetPositionOnCurve|0.41304346919059753\tu:0.36857020854949951,0,0.063782066106796265,0\nGetPositionOnCurveArcLength|0.41304346919059753\tu:0.37372252345085144,0,0.056147348135709763,0\nGetTangentOnCurve|0.41304346919059753\tv:43.649566650390625,-47.313819885253906\nGetTangentOnCurveArcLength|0.41304346919059753\tv:50.430130004882812,-41.078945159912109\nGetPositionOnCurve|0.45652174949645996\tu:0.39087751507759094,0,0.0415385402739048,0\nGetPositionOnCurveArcLength|0.45652174949645996\tu:0.40908259153366089,0,0.036032699048519135,0\nGetTangentOnCurve|0.45652174949645996\tv:69.131149291992188,-23.013216018676758\nGetTangentOnCurveArcLength|0.45652174949645996\tv:85.450225830078125,-6.3542594909667969\nGetPositionOnCurve|0.54347825050354004\tu:0.42135640978813171,0,0.052182067185640335,0\nGetPositionOnCurveArcLength|0.54347825050354004\tu:0.38265061378479004,0,0.10299102962017059,0\nGetTangentOnCurve|0.54347825050354004\tv:-14.315214157104492,27.076086044311523\nGetTangentOnCurveArcLength|0.54347825050354004\tv:-58.187267303466797,33.33099365234375\nGetPositionOnCurve|0.58695650100708008\tu:0.41243332624435425,0,0.069848082959651947,0\nGetPositionOnCurveArcLength|0.58695650100708008\tu:0.34861728549003601,0,0.13025926053524017,0\nGetTangentOnCurve|0.58695650100708008\tv:-30.630428314208984,29.402172088623047\nGetTangentOnCurveArcLength|0.58695650100708008\tv:-78.62957763671875,36.245491027832031\nGetPositionOnCurve|0.63043481111526489\tu:0.39703205227851868,0,0.088969290256500244,0\nGetPositionOnCurveArcLength|0.63043481111526489\tu:0.31354087591171265,0,0.15405580401420593,0\nGetTangentOnCurve|0.63043481111526489\tv:-46.945663452148438,31.728261947631836\nGetTangentOnCurveArcLength|0.63043481111526489\tv:-95.21124267578125,38.609565734863281\nGetPositionOnCurve|0.67391306161880493\tu:0.37515264749526978,0,0.10954564064741135,0\nGetPositionOnCurveArcLength|0.67391306161880493\tu:0.27792486548423767,0,0.17578056454658508,0\nGetTangentOnCurve|0.67391306161880493\tv:-63.260879516601562,34.054347991943359\nGetTangentOnCurveArcLength|0.67391306161880493\tv:-109.50841522216797,40.647933959960938\nGetPositionOnCurve|0.71739131212234497\tu:0.34679514169692993,0,0.13157716393470764,0\nGetPositionOnCurveArcLength|0.71739131212234497\tu:0.24197405576705933,0,0.19609300792217255,0\nGetTangentOnCurve|0.71739131212234497\tv:-79.576087951660156,36.380435943603516\nGetTangentOnCurveArcLength|0.71739131212234497\tv:-122.25597381591797,42.465377807617188\nGetPositionOnCurve|0.76086956262588501\tu:0.31195941567420959,0,0.15506385266780853,0\nGetPositionOnCurveArcLength|0.76086956262588501\tu:0.20579300820827484,0,0.21536436676979065,0\nGetTangentOnCurve|0.76086956262588501\tv:-95.891304016113281,38.706520080566406\nGetTangentOnCurveArcLength|0.76086956262588501\tv:-133.86512756347656,44.120513916015625\nGetPositionOnCurve|0.80434781312942505\tu:0.27064558863639832,0,0.18000569939613342,0\nGetPositionOnCurveArcLength|0.80434781312942505\tu:0.16944248974323273,0,0.23382782936096191,0\nGetTangentOnCurve|0.80434781312942505\tv:-112.20652008056641,41.032608032226562\nGetTangentOnCurveArcLength|0.80434781312942505\tv:-144.59304809570312,45.650009155273438\nGetPositionOnCurve|0.84782606363296509\tu:0.2228536456823349,0,0.2064027339220047,0\nGetPositionOnCurveArcLength|0.84782606363296509\tu:0.13296195864677429,0,0.25164070725440979,0\nGetTangentOnCurve|0.84782606363296509\tv:-128.521728515625,43.358695983886719\nGetTangentOnCurveArcLength|0.84782606363296509\tv:-154.61277770996094,47.078536987304688\nGetPositionOnCurve|0.8913043737411499\tu:0.16858343780040741,0,0.23425495624542236,0\nGetPositionOnCurveArcLength|0.8913043737411499\tu:0.096377439796924591,0,0.26891547441482544,0\nGetTangentOnCurve|0.8913043737411499\tv:-144.83695983886719,45.684783935546875\nGetTangentOnCurveArcLength|0.8913043737411499\tv:-164.047607421875,48.423675537109375\nGetPositionOnCurve|0.93478262424468994\tu:0.10783515125513077,0,0.26356232166290283,0\nGetPositionOnCurveArcLength|0.93478262424468994\tu:0.059708371758460999,0,0.28573518991470337,0\nGetTangentOnCurve|0.93478262424468994\tv:-161.15217590332031,48.010871887207031\nGetTangentOnCurveArcLength|0.93478262424468994\tv:-172.9886474609375,49.698413848876953\nGetPositionOnCurve|0.97826087474822998\tu:0.040608722716569901,0,0.29432487487792969,0\nGetPositionOnCurveArcLength|0.97826087474822998\tu:0.022968901321291924,0,0.3021637499332428,0\nGetTangentOnCurve|0.97826087474822998\tv:-177.46739196777344,50.336956024169922\nGetTangentOnCurveArcLength|0.97826087474822998\tv:-181.50567626953125,50.912704467773438\nGetPositionOnCurve|0.021276595070958138\tu:0.48126164078712463,0,0.52831101417541504,0\nGetPositionOnCurveArcLength|0.021276595070958138\tu:0.479930579662323,0,0.52674555778503418,0\nGetTangentOnCurve|0.021276595070958138\tv:-72.648651123046875,-53.730930328369141\nGetTangentOnCurveArcLength|0.021276595070958138\tv:-72.572654724121094,-54.673259735107422\nGetPositionOnCurve|0.042553190141916275\tu:0.46724048256874084,0,0.51038247346878052,0\nGetPositionOnCurveArcLength|0.042553190141916275\tu:0.46553286910057068,0,0.50798296928405762,0\nGetTangentOnCurve|0.042553190141916275\tv:-71.5706787109375,-63.208297729492188\nGetTangentOnCurveArcLength|0.042553190141916275\tv:-71.396621704101562,-64.295539855957031\nGetPositionOnCurve|0.063829787075519562\tu:0.45348727703094482,0,0.48972529172897339,0\nGetPositionOnCurveArcLength|0.063829787075519562\tu:0.45211374759674072,0,0.48749420046806335,0\nGetTangentOnCurve|0.063829787075519562\tv:-69.891067504882812,-71.557098388671875\nGetTangentOnCurveArcLength|0.063829787075519562\tv:-69.687385559082031,-72.339797973632812\nGetPositionOnCurve|0.08510638028383255\tu:0.44011881947517395,0,0.46668490767478943,0\nGetPositionOnCurveArcLength|0.08510638028383255\tu:0.43956843018531799,0,0.46567189693450928,0\nGetTangentOnCurve|0.08510638028383255\tv:-67.609832763671875,-78.777328491210938\nGetTangentOnCurveArcLength|0.08510638028383255\tv:-67.50103759765625,-79.055435180664062\nGetPositionOnCurve|0.10638298094272614\tu:0.42725211381912231,0,0.44160693883895874,0\nGetPositionOnCurveArcLength|0.10638298094272614\tu:0.42781895399093628,0,0.44277486205101013,0\nGetTangentOnCurve|0.10638298094272614\tv:-64.726966857910156,-84.869003295898438\nGetTangentOnCurveArcLength|0.10638298094272614\tv:-64.869682312011719,-84.619026184082031\nGetPositionOnCurve|0.12765957415103912\tu:0.41500401496887207,0,0.4148368239402771,0\nGetPositionOnCurveArcLength|0.12765957415103912\tu:0.41681161522865295,0,0.41897934675216675,0\nGetTangentOnCurve|0.12765957415103912\tv:-61.242473602294922,-89.832107543945312\nGetTangentOnCurveArcLength|0.12765957415103912\tv:-61.807929992675781,-89.15411376953125\nGetPositionOnCurve|0.14893616735935211\tu:0.40349143743515015,0,0.38672006130218506,0\nGetPositionOnCurveArcLength|0.14893616735935211\tu:0.40651386976242065,0,0.3944074809551239,0\nGetTangentOnCurve|0.14893616735935211\tv:-57.156349182128906,-93.666648864746094\nGetTangentOnCurveArcLength|0.14893616735935211\tv:-58.316337585449219,-92.744705200195312\nGetPositionOnCurve|0.1702127605676651\tu:0.39283126592636108,0,0.35760214924812317,0\nGetPositionOnCurveArcLength|0.1702127605676651\tu:0.39691245555877686,0,0.36914530396461487,0\nGetTangentOnCurve|0.1702127605676651\tv:-52.468597412109375,-96.37261962890625\nGetTangentOnCurveArcLength|0.1702127605676651\tv:-54.383041381835938,-95.443565368652344\nGetPositionOnCurve|0.19148936867713928\tu:0.38314038515090942,0,0.32782855629920959,0\nGetPositionOnCurveArcLength|0.19148936867713928\tu:0.38801282644271851,0,0.34325289726257324,0\nGetTangentOnCurve|0.19148936867713928\tv:-47.179206848144531,-97.950027465820312\nGetTangentOnCurveArcLength|0.19148936867713928\tv:-49.983772277832031,-97.2769775390625\nGetPositionOnCurve|0.21276596188545227\tu:0.37453576922416687,0,0.29774487018585205,0\nGetPositionOnCurveArcLength|0.21276596188545227\tu:0.37984046339988708,0,0.31677234172821045,0\nGetTangentOnCurve|0.21276596188545227\tv:-41.288192749023438,-98.398872375488281\nGetTangentOnCurveArcLength|0.21276596188545227\tv:-45.080665588378906,-98.246513366699219\nGetPositionOnCurve|0.23404255509376526\tu:0.3671342134475708,0,0.26769647002220154,0\nGetPositionOnCurveArcLength|0.23404255509376526\tu:0.37244400382041931,0,0.28973177075386047,0\nGetTangentOnCurve|0.23404255509376526\tv:-34.795551300048828,-97.719154357910156\nGetTangentOnCurveArcLength|0.23404255509376526\tv:-39.619350433349609,-98.328216552734375\nGetPositionOnCurve|0.25531914830207825\tu:0.36105269193649292,0,0.23802889883518219,0\nGetPositionOnCurveArcLength|0.25531914830207825\tu:0.36590206623077393,0,0.26215040683746338,0\nGetTangentOnCurve|0.25531914830207825\tv:-27.701278686523438,-95.910873413085938\nGetTangentOnCurveArcLength|0.25531914830207825\tv:-33.524177551269531,-97.46881103515625\nGetPositionOnCurve|0.27659574151039124\tu:0.35640805959701538,0,0.20908769965171814,0\nGetPositionOnCurveArcLength|0.27659574151039124\tu:0.3603343665599823,0,0.23404441773891449,0\nGetTangentOnCurve|0.27659574151039124\tv:-20.005374908447266,-92.974021911621094\nGetTangentOnCurveArcLength|0.27659574151039124\tv:-26.690460205078125,-95.577926635742188\nGetPositionOnCurve|0.29787233471870422\tu:0.35331729054450989,0,0.18121832609176636,0\nGetPositionOnCurveArcLength|0.29787233471870422\tu:0.35592100024223328,0,0.20543575286865234,0\nGetTangentOnCurve|0.29787233471870422\tv:-11.707843780517578,-88.908607482910156\nGetTangentOnCurveArcLength|0.29787233471870422\tv:-18.97186279296875,-92.514373779296875\nGetPositionOnCurve|0.31914892792701721\tu:0.35189720988273621,0,0.15476621687412262,0\nGetPositionOnCurveArcLength|0.31914892792701721\tu:0.35293740034103394,0,0.17637543380260468,0\nGetTangentOnCurve|0.31914892792701721\tv:-2.808685302734375,-83.714630126953125\nGetTangentOnCurveArcLength|0.31914892792701721\tv:-10.161094665527344,-88.06292724609375\nGetPositionOnCurve|0.3404255211353302\tu:0.35226476192474365,0,0.13007700443267822,0\nGetPositionOnCurveArcLength|0.3404255211353302\tu:0.35181447863578796,0,0.14699737727642059,0\nGetTangentOnCurve|0.3404255211353302\tv:6.692108154296875,-77.39208984375\nGetTangentOnCurveArcLength|0.3404255211353302\tv:0.03871917724609375,-81.897140502929688\nGetPositionOnCurve|0.36170211434364319\tu:0.35453686118125916,0,0.10749605298042297,0\nGetPositionOnCurveArcLength|0.36170211434364319\tu:0.35324057936668396,0,0.11766774207353592,0\nGetTangentOnCurve|0.36170211434364319\tv:16.794525146484375,-69.94097900390625\nGetTangentOnCurveArcLength|0.36170211434364319\tv:12.041961669921875,-73.531402587890625\nGetPositionOnCurve|0.38297873735427856\tu:0.35883030295372009,0,0.087368972599506378,0\nGetPositionOnCurveArcLength|0.38297873735427856\tu:0.35827472805976868,0,0.089380331337451935,0\nGetTangentOnCurve|0.38297873735427856\tv:27.49859619140625,-61.361289978027344\nGetTangentOnCurveArcLength|0.38297873735427856\tv:26.332870483398438,-62.32635498046875\nGetPositionOnCurve|0.40425533056259155\tu:0.36526209115982056,0,0.07004113495349884,0\nGetPositionOnCurveArcLength|0.40425533056259155\tu:0.3681386411190033,0,0.064528539776802063,0\nGetTangentOnCurve|0.40425533056259155\tv:38.804267883300781,-51.653076171875\nGetTangentOnCurveArcLength|0.40425533056259155\tv:43.042900085449219,-47.862564086914062\nGetPositionOnCurve|0.42553192377090454\tu:0.37394917011260986,0,0.055858146399259567,0\nGetPositionOnCurveArcLength|0.42553192377090454\tu:0.38290899991989136,0,0.046759627759456635,0\nGetTangentOnCurve|0.42553192377090454\tv:50.711593627929688,-40.816234588623047\nGetTangentOnCurveArcLength|0.42553192377090454\tv:61.001327514648438,-31.013408660888672\nGetPositionOnCurve|0.44680851697921753\tu:0.385008305311203,0,0.045165520161390305,0\nGetPositionOnCurveArcLength|0.44680851697921753\tu:0.40061861276626587,0,0.037685588002204895,0\nGetTangentOnCurve|0.44680851697921753\tv:63.220504760742188,-28.850906372070312\nGetTangentOnCurveArcLength|0.44680851697921753\tv:78.179122924804688,-13.87004280090332\nGetPositionOnCurve|0.46808511018753052\tu:0.39855647087097168,0,0.038308672606945038,0\nGetPositionOnCurveArcLength|0.46808511018753052\tu:0.41923359036445618,0,0.035660393536090851,0\nGetTangentOnCurve|0.46808511018753052\tv:76.331100463867188,-15.756935119628906\nGetTangentOnCurveArcLength|0.46808511018753052\tv:93.614898681640625,2.2502288818359375\nGetPositionOnCurve|0.48936170339584351\tu:0.41471058130264282,0,0.035633061081171036,0\nGetPositionOnCurveArcLength|0.48936170339584351\tu:0.41960364580154419,0,0.05676640197634697,0\nGetTangentOnCurve|0.48936170339584351\tv:90.043289184570312,-1.5344810485839844\nGetTangentOnCurveArcLength|0.48936170339584351\tv:-18.680698394775391,27.698480606079102\nGetPositionOnCurve|0.51063829660415649\tu:0.42380174994468689,0,0.039803240448236465,0\nGetPositionOnCurveArcLength|0.51063829660415649\tu:0.40664458274841309,0,0.077841095626354218,0\nGetTangentOnCurve|0.51063829660415649\tv:-1.992020845413208,25.319149017333984\nGetTangentOnCurveArcLength|0.51063829660415649\tv:-37.6024169921875,30.396181106567383\nGetPositionOnCurve|0.53191488981246948\tu:0.42263901233673096,0,0.047728635370731354,0\nGetPositionOnCurveArcLength|0.53191488981246948\tu:0.39136666059494019,0,0.094774089753627777,0\nGetTangentOnCurve|0.53191488981246948\tv:-9.9760627746582031,26.457447052001953\nGetTangentOnCurveArcLength|0.53191488981246948\tv:-51.666980743408203,32.401390075683594\nGetPositionOnCurve|0.55319148302078247\tu:0.41992494463920593,0,0.056002501398324966,0\nGetPositionOnCurveArcLength|0.55319148302078247\tu:0.37519007921218872,0,0.10951391607522964,0\nGetTangentOnCurve|0.55319148302078247\tv:-17.960103988647461,27.595745086669922\nGetTangentOnCurveArcLength|0.55319148302078247\tv:-63.236572265625,34.050884246826172\nGetPositionOnCurve|0.57446807622909546\tu:0.41565948724746704,0,0.0646248459815979,0\nGetPositionOnCurveArcLength|0.57446807622909546\tu:0.35853716731071472,0,0.12287894636392593,0\nGetTangentOnCurve|0.57446807622909546\tv:-25.944145202636719,28.734043121337891\nGetTangentOnCurveArcLength|0.57446807622909546\tv:-73.262527465820312,35.480300903320312\nGetPositionOnCurve|0.59574466943740845\tu:0.40984266996383667,0,0.073595665395259857,0\nGetPositionOnCurveArcLength|0.59574466943740845\tu:0.34158751368522644,0,0.13528604805469513,0\nGetTangentOnCurve|0.59574466943740845\tv:-33.928188323974609,29.872339248657227\nGetTangentOnCurveArcLength|0.59574466943740845\tv:-82.221145629882812,36.757545471191406\nGetPositionOnCurve|0.61702126264572144\tu:0.40247452259063721,0,0.082914970815181732,0\nGetPositionOnCurveArcLength|0.61702126264572144\tu:0.32443410158157349,0,0.14697876572608948,0\nGetTangentOnCurve|0.61702126264572144\tv:-41.912227630615234,31.010637283325195\nGetTangentOnCurveArcLength|0.61702126264572144\tv:-90.387908935546875,37.921894073486328\nGetPositionOnCurve|0.63829785585403442\tu:0.39355501532554626,0,0.092582739889621735,0\nGetPositionOnCurveArcLength|0.63829785585403442\tu:0.30713158845901489,0,0.15811322629451752,0\nGetTangentOnCurve|0.63829785585403442\tv:-49.896270751953125,32.148933410644531\nGetTangentOnCurveArcLength|0.63829785585403442\tv:-97.938209533691406,38.99835205078125\nGetPositionOnCurve|0.65957444906234741\tu:0.38308414816856384,0,0.10259898751974106,0\nGetPositionOnCurveArcLength|0.65957444906234741\tu:0.28971469402313232,0,0.16879625618457794,0\nGetTangentOnCurve|0.65957444906234741\tv:-57.880313873291016,33.2872314453125\nGetTangentOnCurveArcLength|0.65957444906234741\tv:-104.99147033691406,40.003948211669922\nGetPositionOnCurve|0.6808510422706604\tu:0.37106195092201233,0,0.1129637137055397,0\nGetPositionOnCurveArcLength|0.6808510422706604\tu:0.27220714092254639,0,0.17910462617874146,0\nGetTangentOnCurve|0.6808510422706604\tv:-65.864356994628906,34.425529479980469\nGetTangentOnCurveArcLength|0.6808510422706604\tv:-111.63322448730469,40.950874328613281\nGetPositionOnCurve|0.70212763547897339\tu:0.35748839378356934,0,0.12367691844701767,0\nGetPositionOnCurveArcLength|0.70212763547897339\tu:0.25462549924850464,0,0.18909581005573273,0\nGetTangentOnCurve|0.70212763547897339\tv:-73.848396301269531,35.563827514648438\nGetTangentOnCurveArcLength|0.70212763547897339\tv:-117.92722320556641,41.848220825195312\nGetPositionOnCurve|0.72340422868728638\tu:0.34236347675323486,0,0.13473859429359436,0\nGetPositionOnCurveArcLength|0.72340422868728638\tu:0.23698243498802185,0,0.19881381094455719,0\nGetTangentOnCurve|0.72340422868728638\tv:-81.832435607910156,36.702125549316406\nGetTangentOnCurveArcLength|0.72340422868728638\tv:-123.92228698730469,42.70294189453125\nGetPositionOnCurve|0.74468082189559937\tu:0.32568717002868652,0,0.14614875614643097,0\nGetPositionOnCurveArcLength|0.74468082189559937\tu:0.21928703784942627,0,0.20829366147518158,0\nGetTangentOnCurve|0.74468082189559937\tv:-89.816474914550781,37.840423583984375\nGetTangentOnCurveArcLength|0.74468082189559937\tv:-129.65699768066406,43.520553588867188\nGetPositionOnCurve|0.76595747470855713\tu:0.3074595034122467,0,0.15790741145610809,0\nGetPositionOnCurveArcLength|0.76595747470855713\tu:0.2015470564365387,0,0.21756316721439362,0\nGetTangentOnCurve|0.76595747470855713\tv:-97.800544738769531,38.978725433349609\nGetTangentOnCurveArcLength|0.76595747470855713\tv:-135.16213989257812,44.305427551269531\nGetPositionOnCurve|0.78723406791687012\tu:0.28768050670623779,0,0.17001451551914215,0\nGetPositionOnCurveArcLength|0.78723406791687012\tu:0.18376807868480682,0,0.22664539515972137,0\nGetTangentOnCurve|0.78723406791687012\tv:-105.78458404541016,40.117023468017578\nGetTangentOnCurveArcLength|0.78723406791687012\tv:-140.46307373046875,45.061191558837891\nGetPositionOnCurve|0.80851066112518311\tu:0.26635017991065979,0,0.18247009813785553,0\nGetPositionOnCurveArcLength|0.80851066112518311\tu:0.16595479846000671,0,0.23555944859981537,0\nGetTangentOnCurve|0.80851066112518311\tv:-113.76862335205078,41.255317687988281\nGetTangentOnCurveArcLength|0.80851066112518311\tv:-145.58079528808594,45.79083251953125\nGetPositionOnCurve|0.82978725433349609\tu:0.24346847832202911,0,0.19527415931224823,0\nGetPositionOnCurveArcLength|0.82978725433349609\tu:0.14811131358146667,0,0.24432125687599182,0\nGetTangentOnCurve|0.82978725433349609\tv:-121.75267028808594,42.39361572265625\nGetTangentOnCurveArcLength|0.82978725433349609\tv:-150.53285217285156,46.496856689453125\nGetPositionOnCurve|0.85106384754180908\tu:0.21903541684150696,0,0.20842669904232025,0\nGetPositionOnCurveArcLength|0.85106384754180908\tu:0.13024076819419861,0,0.25294455885887146,0\nGetTangentOnCurve|0.85106384754180908\tv:-129.73670959472656,43.531913757324219\nGetTangentOnCurveArcLength|0.85106384754180908\tv:-155.33427429199219,47.181404113769531\nGetPositionOnCurve|0.87234044075012207\tu:0.19305102527141571,0,0.22192771732807159,0\nGetPositionOnCurveArcLength|0.87234044075012207\tu:0.11234579235315323,0,0.26144108176231384,0\nGetTangentOnCurve|0.87234044075012207\tv:-137.72074890136719,44.670211791992188\nGetTangentOnCurveArcLength|0.87234044075012207\tv:-159.99794006347656,47.846305847167969\nGetPositionOnCurve|0.89361703395843506\tu:0.16551528871059418,0,0.23577721416950226,0\nGetPositionOnCurveArcLength|0.89361703395843506\tu:0.09442901611328125,0,0.2698209285736084,0\nGetTangentOnCurve|0.89361703395843506\tv:-145.70478820800781,45.808509826660156\nGetTangentOnCurveArcLength|0.89361703395843506\tv:-164.534912109375,48.493152618408203\nGetPositionOnCurve|0.91489362716674805\tu:0.13642819225788116,0,0.24997518956661224,0\nGetPositionOnCurveArcLength|0.91489362716674805\tu:0.076491996645927429,0,0.2780931293964386,0\nGetTangentOnCurve|0.91489362716674805\tv:-153.68882751464844,46.946807861328125\nGetTangentOnCurveArcLength|0.91489362716674805\tv:-168.95501708984375,49.123332977294922\nGetPositionOnCurve|0.93617022037506104\tu:0.10578970611095428,0,0.26452162861824036,0\nGetPositionOnCurveArcLength|0.93617022037506104\tu:0.058536894619464874,0,0.28626525402069092,0\nGetTangentOnCurve|0.93617022037506104\tv:-161.67288208007812,48.085105895996094\nGetTangentOnCurveArcLength|0.93617022037506104\tv:-173.26667785644531,49.738052368164062\nGetPositionOnCurve|0.95744681358337402\tu:0.07359989732503891,0,0.2794165313243866,0\nGetPositionOnCurveArcLength|0.95744681358337402\tu:0.040564969182014465,0,0.29434439539909363,0\nGetTangentOnCurve|0.95744681358337402\tv:-169.65692138671875,49.223403930664062\nGetTangentOnCurveArcLength|0.95744681358337402\tv:-177.47752380371094,50.338401794433594\nGetPositionOnCurve|0.97872340679168701\tu:0.039858710020780563,0,0.29465991258621216,0\nGetPositionOnCurveArcLength|0.97872340679168701\tu:0.022577712312340736,0,0.30233660340309143,0\nGetTangentOnCurve|0.97872340679168701\tv:-177.64096069335938,50.361701965332031\nGetTangentOnCurveArcLength|0.97872340679168701\tv:-181.59422302246094,50.925323486328125\nGetPositionOnCurve|0.02083333395421505\tu:0.4815557599067688,0,0.52865302562713623,0\nGetPositionOnCurveArcLength|0.02083333395421505\tu:0.4802418053150177,0,0.52711421251296997,0\nGetTangentOnCurve|0.02083333395421505\tv:-72.664710998535156,-53.521484375\nGetTangentOnCurveArcLength|0.02083333395421505\tv:-72.590911865234375,-54.453723907470703\nGetPositionOnCurve|0.1041666641831398\tu:0.42856556177139282,0,0.44430413842201233,0\nGetPositionOnCurveArcLength|0.1041666641831398\tu:0.42900750041007996,0,0.4452044665813446,0\nGetTangentOnCurve|0.1041666641831398\tv:-65.055335998535156,-84.287109375\nGetTangentOnCurveArcLength|0.1041666641831398\tv:-65.163993835449219,-84.0892333984375\nGetPositionOnCurve|0.1458333283662796\tu:0.40512004494667053,0,0.39089101552963257,0\nGetPositionOnCurveArcLength|0.1458333283662796\tu:0.40797215700149536,0,0.39803561568260193,0\nGetTangentOnCurve|0.1458333283662796\tv:-57.789714813232422,-93.177734375\nGetTangentOnCurveArcLength|0.1458333283662796\tv:-58.852626800537109,-92.277557373046875\nGetPositionOnCurve|0.2291666716337204\tu:0.36871805787086487,0,0.27456137537956238,0\nGetPositionOnCurveArcLength|0.2291666716337204\tu:0.37406697869300842,0,0.2959769070148468,0\nGetTangentOnCurve|0.2291666716337204\tv:-36.336585998535156,-97.974609375\nGetTangentOnCurveArcLength|0.2291666716337204\tv:-40.923748016357422,-98.390167236328125\nGetPositionOnCurve|0.2708333432674408\tu:0.35751748085021973,0,0.21683453023433685,0\nGetPositionOnCurveArcLength|0.2708333432674408\tu:0.36173719167709351,0,0.24170723557472229,0\nGetTangentOnCurve|0.2708333432674408\tv:-22.149085998535156,-93.880859375\nGetTangentOnCurveArcLength|0.2708333432674408\tv:-28.621597290039062,-96.198822021484375\nGetPositionOnCurve|0.3541666567325592\tu:0.35350698232650757,0,0.11523069441318512,0\nGetPositionOnCurveArcLength|0.3541666567325592\tu:0.35238608717918396,0,0.12800812721252441,0\nGetTangentOnCurve|0.3541666567325592\tv:13.147781372070312,-72.708984375\nGetTangentOnCurveArcLength|0.3541666567325592\tv:7.5536880493164062,-76.784011840820312\nGetPositionOnCurve|0.3958333432674408\tu:0.36245301365852356,0,0.076543241739273071,0\nGetPositionOnCurveArcLength|0.3958333432674408\tu:0.36360266804695129,0,0.073724649846553802,0\nGetTangentOnCurve|0.3958333432674408\tv:34.257164001464844,-55.630859375\nGetTangentOnCurveArcLength|0.3958333432674408\tv:36.175651550292969,-53.964099884033203\nGetPositionOnCurve|0.4791666567325592\tu:0.40663748979568481,0,0.036371517926454544,0\nGetPositionOnCurveArcLength|0.4791666567325592\tu:0.42336606979370117,0,0.044042766094207764,0\nGetTangentOnCurve|0.4791666567325592\tv:83.397781372070312,-8.490234375\nGetTangentOnCurveArcLength|0.4791666567325592\tv:-6.3065156936645508,25.934272766113281\nGetPositionOnCurve|0.52083331346511841\tu:0.42343819141387939,0,0.043557334691286087,0\nGetPositionOnCurveArcLength|0.52083331346511841\tu:0.39948326349258423,0,0.086309827864170074,0\nGetTangentOnCurve|0.52083331346511841\tv:-5.8177008628845215,25.864582061767578\nGetTangentOnCurveArcLength|0.52083331346511841\tv:-44.748809814453125,31.415054321289062\nGetPositionOnCurve|0.60416668653488159\tu:0.40711158514022827,0,0.0772428959608078,0\nGetPositionOnCurveArcLength|0.60416668653488159\tu:0.33481830358505249,0,0.13998976349830627,0\nGetTangentOnCurve|0.60416668653488159\tv:-37.088550567626953,30.322917938232422\nGetTangentOnCurveArcLength|0.60416668653488159\tv:-85.537155151367188,37.230316162109375\nGetPositionOnCurve|0.64583331346511841\tu:0.39002400636672974,0,0.096090301871299744,0\nGetPositionOnCurveArcLength|0.64583331346511841\tu:0.30097481608390808,0,0.16194392740726471,0\nGetTangentOnCurve|0.64583331346511841\tv:-52.723949432373047,32.552082061767578\nGetTangentOnCurveArcLength|0.64583331346511841\tv:-100.48808288574219,39.361892700195312\nGetPositionOnCurve|0.72916668653488159\tu:0.33800011873245239,0,0.13779446482658386,0\nGetPositionOnCurveArcLength|0.72916668653488159\tu:0.23219473659992218,0,0.20140351355075836,0\nGetTangentOnCurve|0.72916668653488159\tv:-83.994796752929688,37.010417938232422\nGetTangentOnCurveArcLength|0.72916668653488159\tv:-125.49974060058594,42.927845001220703\nGetPositionOnCurve|0.77083331346511841\tu:0.30306386947631836,0,0.16065116226673126,0\nGetPositionOnCurveArcLength|0.77083331346511841\tu:0.19747596979141235,0,0.21966029703617096,0\nGetTangentOnCurve|0.77083331346511841\tv:-99.630203247070312,39.239582061767578\nGetTangentOnCurveArcLength|0.77083331346511841\tv:-136.39414978027344,44.4810791015625\nGetPositionOnCurve|0.85416668653488159\tu:0.21534265577793121,0,0.21037390828132629,0\nGetPositionOnCurveArcLength|0.85416668653488159\tu:0.12763245403766632,0,0.25419133901596069,0\nGetTangentOnCurve|0.85416668653488159\tv:-130.90104675292969,43.697917938232422\nGetTangentOnCurveArcLength|0.85416668653488159\tv:-156.02272033691406,47.279556274414062\nGetPositionOnCurve|0.89583331346511841\tu:0.16255779564380646,0,0.23723986744880676,0\nGetPositionOnCurveArcLength|0.89583331346511841\tu:0.092561483383178711,0,0.2706875205039978,0\nGetTangentOnCurve|0.89583331346511841\tv:-146.53645324707031,45.927082061767578\nGetTangentOnCurveArcLength|0.89583331346511841\tv:-165.00064086914062,48.559551239013672\nGetPositionOnCurve|0.97916668653488159\tu:0.039139281958341599,0,0.29498124122619629,0\nGetPositionOnCurveArcLength|0.97916668653488159\tu:0.022202722728252411,0,0.30250224471092224,0\nGetTangentOnCurve|0.97916668653488159\tv:-177.80729675292969,50.385417938232422\nGetTangentOnCurveArcLength|0.97916668653488159\tv:-181.67904663085938,50.937416076660156\nGetPositionOnCurve|0.020408162847161293\tu:0.4818379282951355,0,0.5289798378944397,0\nGetPositionOnCurveArcLength|0.020408162847161293\tu:0.48054084181785583,0,0.52746683359146118,0\nGetTangentOnCurve|0.020408162847161293\tv:-72.67987060546875,-53.320125579833984\nGetTangentOnCurveArcLength|0.020408162847161293\tv:-72.608169555664062,-54.242362976074219\nGetPositionOnCurve|0.040816325694322586\tu:0.46837660670280457,0,0.51195293664932251,0\nGetPositionOnCurveArcLength|0.040816325694322586\tu:0.46666991710662842,0,0.5095859169960022,0\nGetTangentOnCurve|0.040816325694322586\tv:-71.681228637695312,-62.476936340332031\nGetTangentOnCurveArcLength|0.040816325694322586\tv:-71.513580322265625,-63.573188781738281\nGetPositionOnCurve|0.061224490404129028\tu:0.45515301823616028,0,0.49238970875740051,0\nGetPositionOnCurveArcLength|0.061224490404129028\tu:0.45370808243751526,0,0.4900810718536377,0\nGetTangentOnCurve|0.061224490404129028\tv:-70.129058837890625,-70.595428466796875\nGetTangentOnCurveArcLength|0.061224490404129028\tv:-69.923187255859375,-71.430404663085938\nGetPositionOnCurve|0.081632651388645172\tu:0.44227027893066406,0,0.47059494256973267,0\nGetPositionOnCurveArcLength|0.081632651388645172\tu:0.44156050682067871,0,0.46931374073028564,0\nGetTangentOnCurve|0.081632651388645172\tv:-68.02337646484375,-77.67559814453125\nGetTangentOnCurveArcLength|0.081632651388645172\tv:-67.888999938964844,-78.041648864746094\nGetPositionOnCurve|0.10204081982374191\tu:0.42983156442642212,0,0.44687357544898987,0\nGetPositionOnCurveArcLength|0.10204081982374191\tu:0.43015509843826294,0,0.44752553105354309,0\nGetTangentOnCurve|0.10204081982374191\tv:-65.364173889160156,-83.71746826171875\nGetTangentOnCurveArcLength|0.10204081982374191\tv:-65.441902160644531,-83.570510864257812\nGetPositionOnCurve|0.12244898080825806\tu:0.41794005036354065,0,0.42153051495552063,0\nGetPositionOnCurveArcLength|0.12244898080825806\tu:0.41944077610969543,0,0.42488256096839905,0\nGetTangentOnCurve|0.12244898080825806\tv:-62.151447296142578,-88.721000671386719\nGetTangentOnCurveArcLength|0.12244898080825806\tv:-62.597297668457031,-88.133453369140625\nGetPositionOnCurve|0.16326530277729034\tu:0.39621123671531677,0,0.36719894409179688,0\nGetPositionOnCurveArcLength|0.16326530277729034\tu:0.39997106790542603,0,0.37746593356132507,0\nGetTangentOnCurve|0.16326530277729034\tv:-54.065441131591797,-95.613128662109375\nGetTangentOnCurveArcLength|0.16326530277729034\tv:-55.717178344726562,-94.658233642578125\nGetPositionOnCurve|0.18367347121238708\tu:0.38658025860786438,0,0.33882012963294983,0\nGetPositionOnCurveArcLength|0.18367347121238708\tu:0.39119940996170044,0,0.35283464193344116,0\nGetTangentOnCurve|0.18367347121238708\tv:-49.192157745361328,-97.501724243164062\nGetTangentOnCurveArcLength|0.18367347121238708\tv:-51.656059265136719,-96.703414916992188\nGetPositionOnCurve|0.20408163964748383\tu:0.37790915369987488,0,0.310039222240448,0\nGetPositionOnCurveArcLength|0.20408163964748383\tu:0.38308572769165039,0,0.32764971256256104,0\nGetTangentOnCurve|0.20408163964748383\tv:-43.765357971191406,-98.35198974609375\nGetTangentOnCurveArcLength|0.20408163964748383\tv:-47.145858764648438,-97.9560546875\nGetPositionOnCurve|0.22448979318141937\tu:0.37030106782913208,0,0.2811610996723175,0\nGetPositionOnCurveArcLength|0.22448979318141937\tu:0.37566462159156799,0,0.30194029211997986,0\nGetTangentOnCurve|0.22448979318141937\tv:-37.785037994384766,-98.163948059082031\nGetTangentOnCurveArcLength|0.22448979318141937\tv:-42.144683837890625,-98.404006958007812\nGetPositionOnCurve|0.24489796161651611\tu:0.36385908722877502,0,0.25249060988426208,0\nGetPositionOnCurveArcLength|0.24489796161651611\tu:0.36899316310882568,0,0.27572625875473022,0\nGetTangentOnCurve|0.24489796161651611\tv:-31.251197814941406,-96.937576293945312\nGetTangentOnCurveArcLength|0.24489796161651611\tv:-36.594562530517578,-98.01202392578125\nGetPositionOnCurve|0.26530611515045166\tu:0.35868647694587708,0,0.22433272004127502,0\nGetPositionOnCurveArcLength|0.26530611515045166\tu:0.36315807700157166,0,0.24902217090129852,0\nGetTangentOnCurve|0.26530611515045166\tv:-24.163841247558594,-94.672897338867188\nGetTangentOnCurveArcLength|0.26530611515045166\tv:-30.416271209716797,-96.716926574707031\nGetPositionOnCurve|0.30612245202064514\tu:0.35256192088127136,0,0.17077414691448212,0\nGetPositionOnCurveArcLength|0.30612245202064514\tu:0.35457503795623779,0,0.19421647489070892,0\nGetTangentOnCurve|0.30612245202064514\tv:-8.3285598754882812,-87.028579711914062\nGetTangentOnCurveArcLength|0.30612245202064514\tv:-15.699047088623047,-90.968017578125\nGetPositionOnCurve|0.32653060555458069\tu:0.35181629657745361,0,0.14598327875137329,0\nGetPositionOnCurveArcLength|0.32653060555458069\tu:0.35230869054794312,0,0.16620756685733795,0\nGetTangentOnCurve|0.32653060555458069\tv:0.4193572998046875,-81.648941040039062\nGetTangentOnCurveArcLength|0.32653060555458069\tv:-6.7981643676757812,-86.138870239257812\nGetPositionOnCurve|0.34693878889083862\tu:0.35275262594223022,0,0.12292452901601791,0\nGetPositionOnCurveArcLength|0.34693878889083862\tu:0.35193929076194763,0,0.13798575103282928,0\nGetTangentOnCurve|0.34693878889083862\tv:9.720794677734375,-75.231002807617188\nGetTangentOnCurveArcLength|0.34693878889083862\tv:3.4992218017578125,-79.597259521484375\nGetPositionOnCurve|0.36734694242477417\tu:0.35547411441802979,0,0.10190283507108688,0\nGetPositionOnCurveArcLength|0.36734694242477417\tu:0.3541719913482666,0,0.1099952831864357,0\nGetTangentOnCurve|0.36734694242477417\tv:19.575752258300781,-67.774734497070312\nGetTangentOnCurveArcLength|0.36734694242477417\tv:15.592254638671875,-70.862831115722656\nGetPositionOnCurve|0.38775509595870972\tu:0.36008390784263611,0,0.083223134279251099,0\nGetPositionOnCurveArcLength|0.38775509595870972\tu:0.36003363132476807,0,0.083379954099655151,0\nGetTangentOnCurve|0.38775509595870972\tv:29.984214782714844,-59.280158996582031\nGetTangentOnCurveArcLength|0.38775509595870972\tv:29.888015747070312,-59.361289978027344\nGetPositionOnCurve|0.40816327929496765\tu:0.3666851818561554,0,0.067190103232860565,0\nGetPositionOnCurveArcLength|0.40816327929496765\tu:0.37051951885223389,0,0.060633596032857895,0\nGetTangentOnCurve|0.40816327929496765\tv:40.946220397949219,-49.747238159179688\nGetTangentOnCurveArcLength|0.40816327929496765\tv:46.308837890625,-44.890430450439453\nGetPositionOnCurve|0.44897958636283875\tu:0.3862747848033905,0,0.04428429901599884,0\nGetPositionOnCurveArcLength|0.44897958636283875\tu:0.40250030159950256,0,0.037196975201368332,0\nGetTangentOnCurve|0.44897958636283875\tv:64.53076171875,-27.566503524780273\nGetTangentOnCurveArcLength|0.44897958636283875\tv:79.837677001953125,-12.168401718139648\nGetPositionOnCurve|0.46938776969909668\tu:0.39946946501731873,0,0.038021169602870941,0\nGetPositionOnCurveArcLength|0.46938776969909668\tu:0.42037740349769592,0,0.035712480545043945,0\nGetTangentOnCurve|0.46938776969909668\tv:77.153335571289062,-14.918617248535156\nGetTangentOnCurveArcLength|0.46938776969909668\tv:94.502639770507812,3.1957817077636719\nGetPositionOnCurve|0.48979592323303223\tu:0.41506817936897278,0,0.035624440759420395,0\nGetPositionOnCurveArcLength|0.48979592323303223\tu:0.41938871145248413,0,0.057262878865003586,0\nGetTangentOnCurve|0.48979592323303223\tv:90.329391479492188,-1.2324409484863281\nGetTangentOnCurveArcLength|0.48979592323303223\tv:-19.147605895996094,27.765048980712891\nGetPositionOnCurve|0.51020407676696777\tu:0.42380934953689575,0,0.039645127952098846,0\nGetPositionOnCurveArcLength|0.51020407676696777\tu:0.40694078803062439,0,0.077462479472160339,0\nGetTangentOnCurve|0.51020407676696777\tv:-1.8290798664093018,25.295917510986328\nGetTangentOnCurveArcLength|0.51020407676696777\tv:-37.277317047119141,30.349830627441406\nGetPositionOnCurve|0.53061223030090332\tu:0.42275479435920715,0,0.04723338782787323,0\nGetPositionOnCurveArcLength|0.53061223030090332\tu:0.39233452081680298,0,0.093812212347984314,0\nGetTangentOnCurve|0.53061223030090332\tv:-9.4872398376464844,26.387754440307617\nGetTangentOnCurveArcLength|0.53061223030090332\tv:-50.891452789306641,32.290821075439453\nGetPositionOnCurve|0.55102038383483887\tu:0.42027297616004944,0,0.055142257362604141,0\nGetPositionOnCurveArcLength|0.55102038383483887\tu:0.37686684727668762,0,0.10808220505714417,0\nGetTangentOnCurve|0.55102038383483887\tv:-17.14539909362793,27.479591369628906\nGetTangentOnCurveArcLength|0.55102038383483887\tv:-62.137489318847656,33.894187927246094\nGetPositionOnCurve|0.59183675050735474\tu:0.41102737188339233,0,0.071921847760677338,0\nGetPositionOnCurveArcLength|0.59183675050735474\tu:0.34471797943115234,0,0.13306646049022675,0\nGetTangentOnCurve|0.59183675050735474\tv:-32.461742401123047,29.663265228271484\nGetTangentOnCurveArcLength|0.59183675050735474\tv:-80.641502380371094,36.532333374023438\nGetPositionOnCurve|0.61224490404129028\tu:0.40426364541053772,0,0.080792553722858429,0\nGetPositionOnCurveArcLength|0.61224490404129028\tu:0.32829937338829041,0,0.14440707862377167,0\nGetTangentOnCurve|0.61224490404129028\tv:-40.119899749755859,30.755102157592773\nGetTangentOnCurveArcLength|0.61224490404129028\tv:-88.613380432128906,37.668895721435547\nGetPositionOnCurve|0.63265305757522583\tu:0.39607259631156921,0,0.08998386561870575,0\nGetPositionOnCurveArcLength|0.63265305757522583\tu:0.31173437833786011,0,0.15520693361759186,0\nGetTangentOnCurve|0.63265305757522583\tv:-47.778060913085938,31.846939086914062\nGetTangentOnCurveArcLength|0.63265305757522583\tv:-95.987693786621094,38.720264434814453\nGetPositionOnCurve|0.65306121110916138\tu:0.3864542543888092,0,0.099495783448219299,0\nGetPositionOnCurveArcLength|0.65306121110916138\tu:0.29505693912506104,0,0.16556884348392487,0\nGetTangentOnCurve|0.65306121110916138\tv:-55.43621826171875,32.938774108886719\nGetTangentOnCurveArcLength|0.65306121110916138\tv:-102.87947082519531,39.702835083007812\nGetPositionOnCurve|0.67346936464309692\tu:0.37540867924690247,0,0.10932831466197968,0\nGetPositionOnCurveArcLength|0.67346936464309692\tu:0.27829021215438843,0,0.17556683719158173,0\nGetTangentOnCurve|0.67346936464309692\tv:-63.094375610351562,34.030609130859375\nGetTangentOnCurveArcLength|0.67346936464309692\tv:-109.37125396728516,40.628379821777344\nGetPositionOnCurve|0.69387757778167725\tu:0.36293569207191467,0,0.11948147416114807,0\nGetPositionOnCurveArcLength|0.69387757778167725\tu:0.26145076751708984,0,0.18525628745555878,0\nGetTangentOnCurve|0.69387757778167725\tv:-70.7525634765625,35.122451782226562\nGetTangentOnCurveArcLength|0.69387757778167725\tv:-115.52459716796875,41.505672454833984\nGetPositionOnCurve|0.73469388484954834\tu:0.33370798826217651,0,0.14074958860874176,0\nGetPositionOnCurveArcLength|0.73469388484954834\tu:0.22759902477264404,0,0.20387169718742371,0\nGetTangentOnCurve|0.73469388484954834\tv:-86.068878173828125,37.306121826171875\nGetTangentOnCurveArcLength|0.73469388484954834\tv:-126.99551391601562,43.141098022460938\nGetPositionOnCurve|0.75510203838348389\tu:0.3169531524181366,0,0.15186455845832825,0\nGetPositionOnCurveArcLength|0.75510203838348389\tu:0.21060332655906677,0,0.21285854279994965,0\nGetTangentOnCurve|0.75510203838348389\tv:-93.727043151855469,38.397956848144531\nGetTangentOnCurveArcLength|0.75510203838348389\tv:-132.38037109375,43.908828735351562\nGetPositionOnCurve|0.77551019191741943\tu:0.29877105355262756,0,0.16330012679100037,0\nGetPositionOnCurveArcLength|0.77551019191741943\tu:0.1935691237449646,0,0.22166286408901215,0\nGetTangentOnCurve|0.77551019191741943\tv:-101.38520050048828,39.489795684814453\nGetTangentOnCurveArcLength|0.77551019191741943\tv:-137.56608581542969,44.648162841796875\nGetPositionOnCurve|0.79591834545135498\tu:0.27916166186332703,0,0.17505632340908051,0\nGetPositionOnCurveArcLength|0.79591834545135498\tu:0.17650127410888672,0,0.23030312359333038,0\nGetTangentOnCurve|0.79591834545135498\tv:-109.04335784912109,40.581630706787109\nGetTangentOnCurveArcLength|0.79591834545135498\tv:-142.572998046875,45.362007141113281\nGetPositionOnCurve|0.8163265585899353\tu:0.25812491774559021,0,0.18713314831256866,0\nGetPositionOnCurveArcLength|0.8163265585899353\tu:0.15940342843532562,0,0.23879493772983551,0\nGetTangentOnCurve|0.8163265585899353\tv:-116.7015380859375,41.673469543457031\nGetTangentOnCurveArcLength|0.8163265585899353\tv:-147.41830444335938,46.052810668945312\nGetPositionOnCurve|0.83673471212387085\tu:0.23566092550754547,0,0.19953055679798126,0\nGetPositionOnCurveArcLength|0.83673471212387085\tu:0.1422787606716156,0,0.24715171754360199,0\nGetTangentOnCurve|0.83673471212387085\tv:-124.35970306396484,42.765304565429688\nGetTangentOnCurveArcLength|0.83673471212387085\tv:-152.11659240722656,46.722652435302734\nGetPositionOnCurve|0.87755101919174194\tu:0.18645103275775909,0,0.22528721392154694,0\nGetPositionOnCurveArcLength|0.87755101919174194\tu:0.10796000808477402,0,0.26350370049476624,0\nGetTangentOnCurve|0.87755101919174194\tv:-139.676025390625,44.948982238769531\nGetTangentOnCurveArcLength|0.87755101919174194\tv:-161.12034606933594,48.006332397460938\nGetPositionOnCurve|0.89795917272567749\tu:0.15970516204833984,0,0.23864644765853882,0\nGetPositionOnCurveArcLength|0.89795917272567749\tu:0.090769901871681213,0,0.27151763439178467,0\nGetTangentOnCurve|0.89795917272567749\tv:-147.33418273925781,46.040817260742188\nGetTangentOnCurveArcLength|0.89795917272567749\tv:-165.44619750976562,48.623077392578125\nGetPositionOnCurve|0.91836732625961304\tu:0.1315319836139679,0,0.25232627987861633,0\nGetPositionOnCurveArcLength|0.91836732625961304\tu:0.073561817407608032,0,0.27943393588066101,0\nGetTangentOnCurve|0.91836732625961304\tv:-154.99234008789062,47.132652282714844\nGetTangentOnCurveArcLength|0.91836732625961304\tv:-169.6661376953125,49.224716186523438\nGetPositionOnCurve|0.93877553939819336\tu:0.10193139314651489,0,0.26632675528526306,0\nGetPositionOnCurveArcLength|0.93877553939819336\tu:0.056337088346481323,0,0.28725939989089966,0\nGetTangentOnCurve|0.93877553939819336\tv:-162.65052795410156,48.224491119384766\nGetTangentOnCurveArcLength|0.93877553939819336\tv:-173.78758239746094,49.81231689453125\nGetPositionOnCurve|0.95918369293212891\tu:0.07090362161397934,0,0.28064784407615662,0\nGetPositionOnCurveArcLength|0.95918369293212891\tu:0.039097093045711517,0,0.29500007629394531,0\nGetTangentOnCurve|0.95918369293212891\tv:-170.30868530273438,49.316329956054688\nGetTangentOnCurveArcLength|0.95918369293212891\tv:-177.81704711914062,50.386806488037109\nGetPositionOnCurve|0.97959184646606445\tu:0.038448560982942581,0,0.29528951644897461,0\nGetPositionOnCurveArcLength|0.97959184646606445\tu:0.021843131631612778,0,0.30266109108924866,0\nGetTangentOnCurve|0.97959184646606445\tv:-177.96684265136719,50.408164978027344\nGetTangentOnCurveArcLength|0.97959184646606445\tv:-181.76036071777344,50.949012756347656\nGetPositionOnCurve|0.019999999552965164\tu:0.48210886120796204,0,0.52929240465164185,0\nGetPositionOnCurveArcLength|0.019999999552965164\tu:0.48082828521728516,0,0.52780455350875854,0\nGetTangentOnCurve|0.019999999552965164\tv:-72.694198608398438,-53.126399993896484\nGetTangentOnCurveArcLength|0.019999999552965164\tv:-72.624504089355469,-54.038726806640625\nGetPositionOnCurve|0.059999998658895493\tu:0.45593783259391785,0,0.49362945556640625,0\nGetPositionOnCurveArcLength|0.059999998658895493\tu:0.45446199178695679,0,0.49128985404968262,0\nGetTangentOnCurve|0.059999998658895493\tv:-70.237800598144531,-70.137603759765625\nGetTangentOnCurveArcLength|0.059999998658895493\tv:-70.031524658203125,-70.996025085449219\nGetPositionOnCurve|0.14000000059604645\tu:0.40822964906692505,0,0.39867097139358521,0\nGetPositionOnCurveArcLength|0.14000000059604645\tu:0.41075378656387329,0,0.40481606125831604,0\nGetTangentOnCurve|0.14000000059604645\tv:-58.94580078125,-92.193603515625\nGetTangentOnCurveArcLength|0.14000000059604645\tv:-59.835651397705078,-91.347663879394531\nGetPositionOnCurve|0.18000000715255737\tu:0.38824602961540222,0,0.34396687150001526,0\nGetPositionOnCurveArcLength|0.18000000715255737\tu:0.39273044466972351,0,0.35731017589569092,0\nGetTangentOnCurve|0.18000000715255737\tv:-50.110198974609375,-97.2384033203125\nGetTangentOnCurveArcLength|0.18000000715255737\tv:-52.419197082519531,-96.393768310546875\nGetPositionOnCurve|0.2199999988079071\tu:0.37187835574150085,0,0.28750711679458618,0\nGetPositionOnCurveArcLength|0.2199999988079071\tu:0.37723538279533386,0,0.30764025449752808,0\nGetTangentOnCurve|0.2199999988079071\tv:-39.148204803466797,-98.294403076171875\nGetTangentOnCurveArcLength|0.2199999988079071\tv:-43.289741516113281,-98.375907897949219\nGetPositionOnCurve|0.25999999046325684\tu:0.35990351438522339,0,0.23158746957778931,0\nGetPositionOnCurveArcLength|0.25999999046325684\tu:0.3645884096622467,0,0.25601157546043396,0\nGetTangentOnCurve|0.25999999046325684\tv:-26.059803009033203,-95.361602783203125\nGetTangentOnCurveArcLength|0.25999999046325684\tv:-32.088497161865234,-97.145332336425781\nGetPositionOnCurve|0.34000000357627869\tu:0.35223916172981262,0,0.13055123388767242,0\nGetPositionOnCurveArcLength|0.34000000357627869\tu:0.35181480646133423,0,0.14758633077144623,0\nGetTangentOnCurve|0.34000000357627869\tv:6.4962005615234375,-77.52960205078125\nGetTangentOnCurveArcLength|0.34000000357627869\tv:-0.18137359619140625,-82.04010009765625\nGetPositionOnCurve|0.37999999523162842\tu:0.35810315608978271,0,0.090026140213012695,0\nGetPositionOnCurveArcLength|0.37999999523162842\tu:0.35730397701263428,0,0.093208447098731995,0\nGetTangentOnCurve|0.37999999523162842\tv:25.96380615234375,-62.630405426025391\nGetTangentOnCurveArcLength|0.37999999523162842\tv:24.180290222167969,-64.089424133300781\nGetPositionOnCurve|0.41999998688697815\tu:0.37146705389022827,0,0.059223916381597519,0\nGetPositionOnCurveArcLength|0.41999998688697815\tu:0.37868368625640869,0,0.050535790622234344,0\nGetTangentOnCurve|0.41999998688697815\tv:47.557792663574219,-43.742412567138672\nGetTangentOnCurveArcLength|0.41999998688697815\tv:56.332809448242188,-35.507881164550781\nGetPositionOnCurve|0.46000000834465027\tu:0.39310750365257263,0,0.040440402925014496,0\nGetPositionOnCurveArcLength|0.46000000834465027\tu:0.41213282942771912,0,0.035753209143877029,0\nGetTangentOnCurve|0.46000000834465027\tv:71.278213500976562,-20.865592956542969\nGetTangentOnCurveArcLength|0.46000000834465027\tv:87.961227416992188,-3.7260208129882812\nGetPositionOnCurve|0.54000002145767212\tu:0.42179042100906372,0,0.050831664353609085,0\nGetPositionOnCurveArcLength|0.54000002145767212\tu:0.38529372215270996,0,0.10057590901851654,0\nGetTangentOnCurve|0.54000002145767212\tv:-13.010007858276367,26.89000129699707\nGetTangentOnCurveArcLength|0.54000002145767212\tv:-56.289852142333984,33.060478210449219\nGetPositionOnCurve|0.57999998331069946\tu:0.41429635882377625,0,0.066923730075359344,0\nGetPositionOnCurveArcLength|0.57999998331069946\tu:0.35415405035018921,0,0.12618499994277954,0\nGetTangentOnCurve|0.57999998331069946\tv:-28.019992828369141,29.029998779296875\nGetTangentOnCurveArcLength|0.57999998331069946\tv:-75.680908203125,35.825092315673828\nGetPositionOnCurve|0.62000000476837158\tu:0.40131917595863342,0,0.084247477352619171,0\nGetPositionOnCurveArcLength|0.62000000476837158\tu:0.32201975584030151,0,0.14856837689876556,0\nGetTangentOnCurve|0.62000000476837158\tv:-43.030002593994141,31.170000076293945\nGetTangentOnCurveArcLength|0.62000000476837158\tv:-91.478889465332031,38.077438354492188\nGetPositionOnCurve|0.6600000262260437\tu:0.38285890221595764,0,0.10280288755893707,0\nGetPositionOnCurveArcLength|0.6600000262260437\tu:0.28936538100242615,0,0.16900588572025299,0\nGetTangentOnCurve|0.6600000262260437\tv:-58.040008544921875,33.310001373291016\nGetTangentOnCurveArcLength|0.6600000262260437\tv:-105.12809753417969,40.023426055908203\nGetPositionOnCurve|0.74000000953674316\tu:0.32948902249336243,0,0.14360864460468292,0\nGetPositionOnCurveArcLength|0.74000000953674316\tu:0.22318409383296967,0,0.20622704923152924,0\nGetTangentOnCurve|0.74000000953674316\tv:-88.060005187988281,37.590000152587891\nGetTangentOnCurveArcLength|0.74000000953674316\tv:-128.41603088378906,43.3436279296875\nGetPositionOnCurve|0.77999997138977051\tu:0.29457950592041016,0,0.16585896909236908,0\nGetPositionOnCurveArcLength|0.77999997138977051\tu:0.18981702625751495,0,0.22357717156410217,0\nGetTangentOnCurve|0.77999997138977051\tv:-103.06999206542969,39.729999542236328\nGetTangentOnCurveArcLength|0.77999997138977051\tv:-138.68228149414062,44.807300567626953\nGetPositionOnCurve|0.81999999284744263\tu:0.25418677926063538,0,0.1893409937620163,0\nGetPositionOnCurveArcLength|0.81999999284744263\tu:0.15632282197475433,0,0.24030880630016327,0\nGetTangentOnCurve|0.81999999284744263\tv:-118.07999420166016,41.869998931884766\nGetTangentOnCurveArcLength|0.81999999284744263\tv:-148.27447509765625,46.174873352050781\nGetPositionOnCurve|0.86000001430511475\tu:0.20831093192100525,0,0.21405468881130219,0\nGetPositionOnCurveArcLength|0.86000001430511475\tu:0.12272762507200241,0,0.25652799010276794,0\nGetTangentOnCurve|0.86000001430511475\tv:-133.09001159667969,44.010002136230469\nGetTangentOnCurveArcLength|0.86000001430511475\tv:-157.30914306640625,47.462963104248047\nGetPositionOnCurve|0.93999999761581421\tu:0.10011006146669388,0,0.26717698574066162,0\nGetPositionOnCurveArcLength|0.93999999761581421\tu:0.055303215980529785,0,0.28772613406181335,0\nGetTangentOnCurve|0.93999999761581421\tv:-163.11000061035156,48.290000915527344\nGetTangentOnCurveArcLength|0.93999999761581421\tv:-174.0318603515625,49.847145080566406\nGetPositionOnCurve|0.98000001907348633\tu:0.037784907966852188,0,0.29558563232421875,0\nGetPositionOnCurveArcLength|0.98000001907348633\tu:0.021497787907719612,0,0.30281361937522888,0\nGetTangentOnCurve|0.98000001907348633\tv:-178.12001037597656,50.430000305175781\nGetTangentOnCurveArcLength|0.98000001907348633\tv:-181.83840942382812,50.960140228271484\nGetPositionOnCurve|0.019607843831181526\tu:0.48236924409866333,0,0.52959167957305908,0\nGetPositionOnCurveArcLength|0.019607843831181526\tu:0.48110485076904297,0,0.52812808752059937,0\nGetTangentOnCurve|0.019607843831181526\tv:-72.707756042480469,-52.93988037109375\nGetTangentOnCurveArcLength|0.019607843831181526\tv:-72.639984130859375,-53.842411041259766\nGetPositionOnCurve|0.039215687662363052\tu:0.46942514181137085,0,0.51338404417037964,0\nGetPositionOnCurveArcLength|0.039215687662363052\tu:0.46772357821464539,0,0.51105278730392456,0\nGetTangentOnCurve|0.039215687662363052\tv:-71.779556274414062,-61.796279907226562\nGetTangentOnCurveArcLength|0.039215687662363052\tv:-71.618194580078125,-62.898094177246094\nGetPositionOnCurve|0.078431375324726105\tu:0.44426435232162476,0,0.47414892911911011,0\nGetPositionOnCurveArcLength|0.078431375324726105\tu:0.44341537356376648,0,0.47264394164085388,0\nGetTangentOnCurve|0.078431375324726105\tv:-68.390281677246094,-76.633651733398438\nGetTangentOnCurveArcLength|0.078431375324726105\tv:-68.235969543457031,-77.0797119140625\nGetPositionOnCurve|0.098039217293262482\tu:0.4322306215763092,0,0.45166224241256714,0\nGetPositionOnCurveArcLength|0.098039217293262482\tu:0.43233567476272583,0,0.45186948776245117,0\nGetTangentOnCurve|0.098039217293262482\tv:-65.929206848144531,-82.6146240234375\nGetTangentOnCurveArcLength|0.098039217293262482\tv:-65.953353881835938,-82.565643310546875\nGetPositionOnCurve|0.13725490868091583\tu:0.40971401333808899,0,0.40230274200439453,0\nGetPositionOnCurveArcLength|0.13725490868091583\tu:0.41208088397979736,0,0.40798819065093994,0\nGetTangentOnCurve|0.13725490868091583\tv:-59.474189758300781,-91.701126098632812\nGetTangentOnCurveArcLength|0.13725490868091583\tv:-60.286933898925781,-90.886512756347656\nGetPositionOnCurve|0.15686275064945221\tu:0.39941412210464478,0,0.3759707510471344,0\nGetPositionOnCurveArcLength|0.15686275064945221\tu:0.40285557508468628,0,0.38507306575775146,0\nGetTangentOnCurve|0.15686275064945221\tv:-55.480247497558594,-94.806655883789062\nGetTangentOnCurveArcLength|0.15686275064945221\tv:-56.903640747070312,-93.852432250976562\nGetPositionOnCurve|0.19607843458652496\tu:0.38118860125541687,0,0.32135432958602905,0\nGetPositionOnCurveArcLength|0.19607843458652496\tu:0.38618737459182739,0,0.33759006857872009,0\nGetTangentOnCurve|0.19607843458652496\tv:-45.959484100341797,-98.142303466796875\nGetTangentOnCurveArcLength|0.19607843458652496\tv:-48.970451354980469,-97.559577941894531\nGetPositionOnCurve|0.21568627655506134\tu:0.37344595789909363,0,0.29361069202423096,0\nGetPositionOnCurveArcLength|0.21568627655506134\tu:0.37877786159515381,0,0.31309351325035095,0\nGetTangentOnCurve|0.21568627655506134\tv:-40.432670593261719,-98.372406005859375\nGetTangentOnCurveArcLength|0.21568627655506134\tv:-44.365562438964844,-98.3111572265625\nGetPositionOnCurve|0.25490197539329529\tu:0.36115849018096924,0,0.23860472440719604,0\nGetPositionOnCurveArcLength|0.25490197539329529\tu:0.36602145433425903,0,0.26269635558128357,0\nGetTangentOnCurve|0.25490197539329529\tv:-27.846160888671875,-95.957183837890625\nGetTangentOnCurveArcLength|0.25490197539329529\tv:-33.650394439697266,-97.495201110839844\nGetPositionOnCurve|0.27450981736183167\tu:0.35679662227630615,0,0.21188324689865112,0\nGetPositionOnCurveArcLength|0.27450981736183167\tu:0.36083266139030457,0,0.23682257533073425,0\nGetTangentOnCurve|0.27450981736183167\tv:-20.786472320556641,-93.311843872070312\nGetTangentOnCurveArcLength|0.27450981736183167\tv:-27.396797180175781,-95.812408447265625\nGetPositionOnCurve|0.31372550129890442\tu:0.35209408402442932,0,0.16135521233081818,0\nGetPositionOnCurveArcLength|0.31372550129890442\tu:0.35354185104370117,0,0.18382070958614349,0\nGetTangentOnCurve|0.31372550129890442\tv:-5.1342239379882812,-85.145759582519531\nGetTangentOnCurveArcLength|0.31372550129890442\tv:-12.52520751953125,-89.345046997070312\nGetPositionOnCurve|0.37254902720451355\tu:0.35646572709083557,0,0.096906840801239014,0\nGetPositionOnCurveArcLength|0.37254902720451355\tu:0.35527488589286804,0,0.10300903767347336,0\nGetTangentOnCurve|0.37254902720451355\tv:22.17633056640625,-65.708045959472656\nGetTangentOnCurveArcLength|0.37254902720451355\tv:19.015274047851562,-68.215003967285156\nGetPositionOnCurve|0.39215686917304993\tu:0.36133572459220886,0,0.079530671238899231,0\nGetPositionOnCurveArcLength|0.39215686917304993\tu:0.36188399791717529,0,0.078031688928604126,0\nGetTangentOnCurve|0.39215686917304993\tv:32.301765441894531,-57.311843872070312\nGetTangentOnCurveArcLength|0.39215686917304993\tv:33.273368835449219,-56.478878021240234\nGetPositionOnCurve|0.43137255311012268\tu:0.37674382328987122,0,0.052560765296220779,0\nGetPositionOnCurveArcLength|0.43137255311012268\tu:0.38758328557014465,0,0.043433263897895813,0\nGetTangentOnCurve|0.43137255311012268\tv:54.085502624511719,-37.644035339355469\nGetTangentOnCurveArcLength|0.43137255311012268\tv:65.863433837890625,-26.254375457763672\nGetPositionOnCurve|0.45098039507865906\tu:0.3874649703502655,0,0.043507803231477737,0\nGetPositionOnCurveArcLength|0.45098039507865906\tu:0.40424057841300964,0,0.036809466779232025,0\nGetTangentOnCurve|0.45098039507865906\tv:65.743789672851562,-26.372415542602539\nGetTangentOnCurveArcLength|0.45098039507865906\tv:81.349151611328125,-10.611015319824219\nGetPositionOnCurve|0.49019607901573181\tu:0.41539880633354187,0,0.035618074238300323,0\nGetPositionOnCurveArcLength|0.49019607901573181\tu:0.41918781399726868,0,0.057717315852642059,0\nGetTangentOnCurve|0.49019607901573181\tv:90.593276977539062,-0.95371627807617188\nGetTangentOnCurveArcLength|0.49019607901573181\tv:-19.573997497558594,27.825839996337891\nGetPositionOnCurve|0.50980395078659058\tu:0.42381575703620911,0,0.03949955478310585,0\nGetPositionOnCurveArcLength|0.50980395078659058\tu:0.4072130024433136,0,0.077112115919589996,0\nGetTangentOnCurve|0.50980395078659058\tv:-1.6789324283599854,25.274511337280273\nGetTangentOnCurveArcLength|0.50980395078659058\tv:-36.976032257080078,30.306877136230469\nGetPositionOnCurve|0.54901963472366333\tu:0.42057937383651733,0,0.054352723062038422,0\nGetPositionOnCurveArcLength|0.54901963472366333\tu:0.37840762734413147,0,0.10674988478422165,0\nGetTangentOnCurve|0.54901963472366333\tv:-16.394617080688477,27.372550964355469\nGetTangentOnCurveArcLength|0.54901963472366333\tv:-61.110115051269531,33.747711181640625\nGetPositionOnCurve|0.56862747669219971\tu:0.41698488593101501,0,0.062223240733146667,0\nGetPositionOnCurveArcLength|0.56862747669219971\tu:0.3631434440612793,0,0.11931890249252319,0\nGetTangentOnCurve|0.56862747669219971\tv:-23.752460479736328,28.42156982421875\nGetTangentOnCurveArcLength|0.56862747669219971\tv:-70.631813049316406,35.105236053466797\nGetPositionOnCurve|0.60784316062927246\tu:0.40584319829940796,0,0.078852154314517975,0\nGetPositionOnCurveArcLength|0.60784316062927246\tu:0.33185446262359619,0,0.14201104640960693,0\nGetTangentOnCurve|0.60784316062927246\tv:-38.468147277832031,30.519609451293945\nGetTangentOnCurveArcLength|0.60784316062927246\tv:-86.949264526367188,37.431640625\nGetPositionOnCurve|0.62745100259780884\tu:0.398296058177948,0,0.087610550224781036,0\nGetPositionOnCurveArcLength|0.62745100259780884\tu:0.31596863269805908,0,0.15249910950660706,0\nGetTangentOnCurve|0.62745100259780884\tv:-45.82598876953125,31.568628311157227\nGetTangentOnCurveArcLength|0.62745100259780884\tv:-94.157684326171875,38.459358215332031\nGetPositionOnCurve|0.68627452850341797\tu:0.36774933338165283,0,0.11566145718097687,0\nGetPositionOnCurveArcLength|0.68627452850341797\tu:0.26773202419281006,0,0.18167954683303833,0\nGetTangentOnCurve|0.68627452850341797\tv:-67.899513244628906,34.715686798095703\nGetTangentOnCurveArcLength|0.68627452850341797\tv:-113.26844024658203,41.184005737304688\nGetPositionOnCurve|0.72549021244049072\tu:0.3407970666885376,0,0.13584186136722565,0\nGetPositionOnCurveArcLength|0.72549021244049072\tu:0.23524966835975647,0,0.1997532993555069,0\nGetTangentOnCurve|0.72549021244049072\tv:-82.615203857421875,36.813728332519531\nGetTangentOnCurveArcLength|0.72549021244049072\tv:-124.49551391601562,42.78466796875\nGetPositionOnCurve|0.7450980544090271\tu:0.32534462213516235,0,0.14637599885463715,0\nGetPositionOnCurveArcLength|0.7450980544090271\tu:0.21893958747386932,0,0.20847736299037933,0\nGetTangentOnCurve|0.7450980544090271\tv:-89.973045349121094,37.862747192382812\nGetTangentOnCurveArcLength|0.7450980544090271\tv:-129.76705932617188,43.536243438720703\nGetPositionOnCurve|0.78431373834609985\tu:0.290487140417099,0,0.16833211481571198,0\nGetPositionOnCurveArcLength|0.78431373834609985\tu:0.18621043860912323,0,0.22540917992591858,0\nGetTangentOnCurve|0.78431373834609985\tv:-104.68872833251953,39.960784912109375\nGetTangentOnCurveArcLength|0.78431373834609985\tv:-139.74678039550781,44.959068298339844\nGetPositionOnCurve|0.80392158031463623\tu:0.2710820734500885,0,0.17975412309169769,0\nGetPositionOnCurveArcLength|0.80392158031463623\tu:0.16979953646659851,0,0.23365020751953125,0\nGetTangentOnCurve|0.80392158031463623\tv:-112.04656982421875,41.009803771972656\nGetTangentOnCurveArcLength|0.80392158031463623\tv:-144.49154663085938,45.635536193847656\nGetPositionOnCurve|0.84313726425170898\tu:0.22831928730010986,0,0.20348599553108215,0\nGetPositionOnCurveArcLength|0.84313726425170898\tu:0.13690140843391418,0,0.2497473806142807,0\nGetTangentOnCurve|0.84313726425170898\tv:-126.76225280761719,43.107841491699219\nGetTangentOnCurveArcLength|0.84313726425170898\tv:-153.562255859375,46.928764343261719\nGetPositionOnCurve|0.86274510622024536\tu:0.20496155321598053,0,0.21579587459564209,0\nGetPositionOnCurveArcLength|0.86274510622024536\tu:0.120418980717659,0,0.25762435793876648,0\nGetTangentOnCurve|0.86274510622024536\tv:-134.12010192871094,44.1568603515625\nGetTangentOnCurveArcLength|0.86274510622024536\tv:-157.9110107421875,47.548774719238281\nGetPositionOnCurve|0.90196079015731812\tu:0.1542934775352478,0,0.24130347371101379,0\nGetPositionOnCurveArcLength|0.90196079015731812\tu:0.087397187948226929,0,0.27307730913162231,0\nGetTangentOnCurve|0.90196079015731812\tv:-148.83578491210938,46.254901885986328\nGetTangentOnCurveArcLength|0.90196079015731812\tv:-166.28172302246094,48.742195129394531\nGetPositionOnCurve|0.92156863212585449\tu:0.12698312103748322,0,0.25450125336647034,0\nGetPositionOnCurveArcLength|0.92156863212585449\tu:0.07086094468832016,0,0.28066730499267578,0\nGetTangentOnCurve|0.92156863212585449\tv:-156.19363403320312,47.303924560546875\nGetTangentOnCurveArcLength|0.92156863212585449\tv:-170.31898498535156,49.317794799804688\nGetPositionOnCurve|0.96078431606292725\tu:0.068409748375415802,0,0.28178459405899048,0\nGetPositionOnCurveArcLength|0.96078431606292725\tu:0.037744320929050446,0,0.29560372233390808,0\nGetTangentOnCurve|0.96078431606292725\tv:-170.90931701660156,49.401962280273438\nGetTangentOnCurveArcLength|0.96078431606292725\tv:-178.12936401367188,50.43133544921875\nGetPositionOnCurve|0.98039215803146362\tu:0.037146754562854767,0,0.29587021470069885,0\nGetPositionOnCurveArcLength|0.98039215803146362\tu:0.021166238933801651,0,0.30295994877815247,0\nGetTangentOnCurve|0.98039215803146362\tv:-178.26715087890625,50.450981140136719\nGetTangentOnCurveArcLength|0.98039215803146362\tv:-181.91331481933594,50.970817565917969\nGetPositionOnCurve|0.019230769947171211\tu:0.48261964321136475,0,0.52987843751907349,0\nGetPositionOnCurveArcLength|0.019230769947171211\tu:0.48137110471725464,0,0.5284385085105896,0\nGetTangentOnCurve|0.019230769947171211\tv:-72.720596313476562,-52.760169982910156\nGetTangentOnCurveArcLength|0.019230769947171211\tv:-72.6546630859375,-53.653018951416016\nGetPositionOnCurve|0.057692307978868484\tu:0.45742020010948181,0,0.49594384431838989,0\nGetPositionOnCurveArcLength|0.057692307978868484\tu:0.45589083433151245,0,0.49355551600456238,0\nGetTangentOnCurve|0.057692307978868484\tv:-70.43731689453125,-69.264610290527344\nGetTangentOnCurveArcLength|0.057692307978868484\tv:-70.231346130371094,-70.16510009765625\nGetPositionOnCurve|0.096153847873210907\tu:0.4333680272102356,0,0.453896164894104,0\nGetPositionOnCurveArcLength|0.096153847873210907\tu:0.43337231874465942,0,0.45390450954437256,0\nGetTangentOnCurve|0.096153847873210907\tv:-66.188056945800781,-82.0811767578125\nGetTangentOnCurveArcLength|0.096153847873210907\tv:-66.189018249511719,-82.07916259765625\nGetPositionOnCurve|0.13461539149284363\tu:0.41115367412567139,0,0.40577614307403564,0\nGetPositionOnCurveArcLength|0.13461539149284363\tu:0.41336798667907715,0,0.41102686524391174,0\nGetTangentOnCurve|0.13461539149284363\tv:-59.972816467285156,-91.209869384765625\nGetTangentOnCurveArcLength|0.13461539149284363\tv:-60.714073181152344,-90.428726196289062\nGetPositionOnCurve|0.17307692766189575\tu:0.39146769046783447,0,0.35362473130226135,0\nGetPositionOnCurveArcLength|0.17307692766189575\tu:0.39567321538925171,0,0.36569541692733765,0\nGetTangentOnCurve|0.17307692766189575\tv:-51.791603088378906,-96.650703430175781\nGetTangentOnCurveArcLength|0.17307692766189575\tv:-53.818660736083984,-95.740493774414062\nGetPositionOnCurve|0.21153846383094788\tu:0.37500059604644775,0,0.2994827926158905,0\nGetPositionOnCurveArcLength|0.21153846383094788\tu:0.38029143214225769,0,0.31831550598144531,0\nGetTangentOnCurve|0.21153846383094788\tv:-41.644412994384766,-98.403656005859375\nGetTangentOnCurveArcLength|0.21153846383094788\tv:-45.378101348876953,-98.214347839355469\nGetPositionOnCurve|0.28846153616905212\tu:0.35448521375656128,0,0.19339083135128021,0\nGetPositionOnCurveArcLength|0.28846153616905212\tu:0.35771575570106506,0,0.21814939379692078,0\nGetTangentOnCurve|0.28846153616905212\tv:-15.452114105224609,-90.845977783203125\nGetTangentOnCurveArcLength|0.28846153616905212\tv:-22.506568908691406,-94.0257568359375\nGetPositionOnCurve|0.32692307233810425\tu:0.35181805491447449,0,0.14552254974842072,0\nGetPositionOnCurveArcLength|0.32692307233810425\tu:0.35228189826011658,0,0.16566596925258636,0\nGetTangentOnCurve|0.32692307233810425\tv:0.59300994873046875,-81.535316467285156\nGetTangentOnCurveArcLength|0.32692307233810425\tv:-6.614410400390625,-86.030494689941406\nGetPositionOnCurve|0.36538460850715637\tu:0.35513201355934143,0,0.10382725298404694,0\nGetPositionOnCurveArcLength|0.36538460850715637\tu:0.35381811857223511,0,0.11265330761671066,0\nGetTangentOnCurve|0.36538460850715637\tv:18.604103088378906,-68.536788940429688\nGetTangentOnCurveArcLength|0.36538460850715637\tv:14.339073181152344,-71.814056396484375\nGetPositionOnCurve|0.4038461446762085\tu:0.36511752009391785,0,0.070345818996429443,0\nGetPositionOnCurveArcLength|0.4038461446762085\tu:0.36789914965629578,0,0.06495106965303421,0\nGetTangentOnCurve|0.4038461446762085\tv:38.5811767578125,-51.850410461425781\nGetTangentOnCurveArcLength|0.4038461446762085\tv:42.703300476074219,-48.169109344482422\nGetPositionOnCurve|0.44230768084526062\tu:0.38246524333953857,0,0.047119196504354477,0\nGetPositionOnCurveArcLength|0.44230768084526062\tu:0.39674568176269531,0,0.038935765624046326,0\nGetTangentOnCurve|0.44230768084526062\tv:60.524215698242188,-31.476169586181641\nGetTangentOnCurveArcLength|0.44230768084526062\tv:74.68035888671875,-17.434125900268555\nGetPositionOnCurve|0.48076921701431274\tu:0.40786561369895935,0,0.036188084632158279,0\nGetPositionOnCurveArcLength|0.48076921701431274\tu:0.42298328876495361,0,0.046176634728908539,0\nGetTangentOnCurve|0.48076921701431274\tv:84.433242797851562,-7.4140052795410156\nGetTangentOnCurveArcLength|0.48076921701431274\tv:-8.4398555755615234,26.238426208496094\nGetPositionOnCurve|0.51923078298568726\tu:0.42351895570755005,0,0.042961936444044113,0\nGetPositionOnCurveArcLength|0.51923078298568726\tu:0.40063175559043884,0,0.085027284920215607,0\nGetTangentOnCurve|0.51923078298568726\tv:-5.2163515090942383,25.778846740722656\nGetTangentOnCurveArcLength|0.51923078298568726\tv:-43.681488037109375,31.262884140014648\nGetPositionOnCurve|0.55769228935241699\tu:0.41915199160575867,0,0.057797390967607498,0\nGetPositionOnCurveArcLength|0.55769228935241699\tu:0.3716990053653717,0,0.11243791878223419,0\nGetTangentOnCurve|0.55769228935241699\tv:-19.649030685424805,27.836536407470703\nGetTangentOnCurveArcLength|0.55769228935241699\tv:-65.4656982421875,34.368694305419922\nGetPositionOnCurve|0.5961538553237915\tu:0.40971559286117554,0,0.073771603405475616,0\nGetPositionOnCurveArcLength|0.5961538553237915\tu:0.34125930070877075,0,0.13551703095436096,0\nGetTangentOnCurve|0.5961538553237915\tv:-34.081733703613281,29.894231796264648\nGetTangentOnCurveArcLength|0.5961538553237915\tv:-82.384994506835938,36.780906677246094\nGetPositionOnCurve|0.63461536169052124\tu:0.39520981907844543,0,0.090884529054164886,0\nGetPositionOnCurveArcLength|0.63461536169052124\tu:0.31013524532318115,0,0.15622095763683319,0\nGetTangentOnCurve|0.63461536169052124\tv:-48.514415740966797,31.951921463012695\nGetTangentOnCurveArcLength|0.63461536169052124\tv:-96.669830322265625,38.817516326904297\nGetPositionOnCurve|0.67307692766189575\tu:0.37563452124595642,0,0.10913621634244919,0\nGetPositionOnCurveArcLength|0.67307692766189575\tu:0.27861341834068298,0,0.17537760734558105,0\nGetTangentOnCurve|0.67307692766189575\tv:-62.947120666503906,34.009616851806641\nGetTangentOnCurveArcLength|0.67307692766189575\tv:-109.249755859375,40.611057281494141\nGetPositionOnCurve|0.71153843402862549\tu:0.35098984837532043,0,0.12852659821510315,0\nGetPositionOnCurveArcLength|0.71153843402862549\tu:0.24682877957820892,0,0.19342559576034546,0\nGetTangentOnCurve|0.71153843402862549\tv:-77.379798889160156,36.067306518554688\nGetTangentOnCurveArcLength|0.71153843402862549\tv:-120.61327362060547,42.231170654296875\nGetPositionOnCurve|0.78846156597137451\tu:0.28649207949638367,0,0.17072364687919617,0\nGetPositionOnCurveArcLength|0.78846156597137451\tu:0.18274115025997162,0,0.22716411948204041,0\nGetTangentOnCurve|0.78846156597137451\tv:-106.24520111083984,40.182693481445312\nGetTangentOnCurveArcLength|0.78846156597137451\tv:-140.76316833496094,45.103973388671875\nGetPositionOnCurve|0.82692307233810425\tu:0.24663908779621124,0,0.19353024661540985,0\nGetPositionOnCurveArcLength|0.82692307233810425\tu:0.15051504969596863,0,0.24315011501312256,0\nGetTangentOnCurve|0.82692307233810425\tv:-120.67787933349609,42.240386962890625\nGetTangentOnCurveArcLength|0.82692307233810425\tv:-149.87528991699219,46.403106689453125\nGetPositionOnCurve|0.86538463830947876\tu:0.20171661674976349,0,0.21747560799121857,0\nGetPositionOnCurveArcLength|0.86538463830947876\tu:0.11819851398468018,0,0.25867670774459839,0\nGetTangentOnCurve|0.86538463830947876\tv:-135.11058044433594,44.298080444335938\nGetTangentOnCurveArcLength|0.86538463830947876\tv:-158.48774719238281,47.630996704101562\nGetPositionOnCurve|0.9038461446762085\tu:0.15172475576400757,0,0.24255964159965515,0\nGetPositionOnCurveArcLength|0.9038461446762085\tu:0.085807867348194122,0,0.27381086349487305,0\nGetTangentOnCurve|0.9038461446762085\tv:-149.54325866699219,46.355766296386719\nGetTangentOnCurveArcLength|0.9038461446762085\tv:-166.67399597167969,48.798126220703125\nGetPositionOnCurve|0.94230771064758301\tu:0.096663385629653931,0,0.26878246665000916,0\nGetPositionOnCurveArcLength|0.94230771064758301\tu:0.053354308009147644,0,0.28860506415367126,0\nGetTangentOnCurve|0.94230771064758301\tv:-163.97596740722656,48.413459777832031\nGetTangentOnCurveArcLength|0.94230771064758301\tv:-174.49139404296875,49.912666320800781\nGetPositionOnCurve|0.98076921701431274\tu:0.036532677710056305,0,0.29614400863647461,0\nGetPositionOnCurveArcLength|0.98076921701431274\tu:0.020847337320446968,0,0.30310076475143433,0\nGetTangentOnCurve|0.98076921701431274\tv:-178.40864562988281,50.471153259277344\nGetTangentOnCurveArcLength|0.98076921701431274\tv:-181.98533630371094,50.981086730957031\nGetPositionOnCurve|0.018867924809455872\tu:0.48286062479019165,0,0.53015339374542236,0\nGetPositionOnCurveArcLength|0.018867924809455872\tu:0.48162767291069031,0,0.52873647212982178,0\nGetTangentOnCurve|0.018867924809455872\tv:-72.732780456542969,-52.586906433105469\nGetTangentOnCurveArcLength|0.018867924809455872\tv:-72.668601989746094,-53.470195770263672\nGetPositionOnCurve|0.037735849618911743\tu:0.47039583325386047,0,0.51469314098358154,0\nGetPositionOnCurveArcLength|0.037735849618911743\tu:0.4687027633190155,0,0.51239997148513794,0\nGetTangentOnCurve|0.037735849618911743\tv:-71.867431640625,-61.161312103271484\nGetTangentOnCurveArcLength|0.037735849618911743\tv:-71.712188720703125,-62.26580810546875\nGetPositionOnCurve|0.056603774428367615\tu:0.45812088251113892,0,0.49702546000480652,0\nGetPositionOnCurveArcLength|0.056603774428367615\tu:0.45656850934028625,0,0.49461847543716431,0\nGetTangentOnCurve|0.056603774428367615\tv:-70.528968811035156,-68.848213195800781\nGetTangentOnCurveArcLength|0.056603774428367615\tv:-70.323616027832031,-69.76751708984375\nGetPositionOnCurve|0.075471699237823486\tu:0.44611731171607971,0,0.47739148139953613,0\nGetPositionOnCurveArcLength|0.075471699237823486\tu:0.4451465904712677,0,0.47569999098777771,0\nGetTangentOnCurve|0.075471699237823486\tv:-68.717384338378906,-75.647605895996094\nGetTangentOnCurveArcLength|0.075471699237823486\tv:-68.54766845703125,-76.166297912597656\nGetPositionOnCurve|0.094339624047279358\tu:0.43446671962738037,0,0.45603200793266296,0\nGetPositionOnCurveArcLength|0.094339624047279358\tu:0.43437549471855164,0,0.45585557818412781,0\nGetTangentOnCurve|0.094339624047279358\tv:-66.432670593261719,-81.559494018554688\nGetTangentOnCurveArcLength|0.094339624047279358\tv:-66.412574768066406,-81.60302734375\nGetPositionOnCurve|0.11320754885673523\tu:0.42325052618980408,0,0.43318808078765869,0\nGetPositionOnCurveArcLength|0.11320754885673523\tu:0.42420941591262817,0,0.43523353338241577,0\nGetTangentOnCurve|0.11320754885673523\tv:-63.674839019775391,-86.583877563476562\nGetTangentOnCurveArcLength|0.11320754885673523\tv:-63.934215545654297,-86.180976867675781\nGetPositionOnCurve|0.1320754736661911\tu:0.41255027055740356,0,0.40910059213638306,0\nGetPositionOnCurveArcLength|0.1320754736661911\tu:0.41461670398712158,0,0.41394010186195374,0\nGetTangentOnCurve|0.1320754736661911\tv:-60.443885803222656,-90.72076416015625\nGetTangentOnCurveArcLength|0.1320754736661911\tv:-61.118824005126953,-89.974830627441406\nGetPositionOnCurve|0.15094339847564697\tu:0.40244752168655396,0,0.38401049375534058,0\nGetPositionOnCurveArcLength|0.15094339847564697\tu:0.4055783748626709,0,0.39205268025398254,0\nGetTangentOnCurve|0.15094339847564697\tv:-56.73980712890625,-93.970138549804688\nGetTangentOnCurveArcLength|0.15094339847564697\tv:-57.964427947998047,-93.03680419921875\nGetPositionOnCurve|0.16981132328510284\tu:0.3930237889289856,0,0.35815867781639099,0\nGetPositionOnCurveArcLength|0.16981132328510284\tu:0.39708715677261353,0,0.36962792277336121,0\nGetTangentOnCurve|0.16981132328510284\tv:-52.562606811523438,-96.332015991210938\nGetTangentOnCurveArcLength|0.16981132328510284\tv:-54.461471557617188,-95.400703430175781\nGetPositionOnCurve|0.18867924809455872\tu:0.38436061143875122,0,0.33178618550300598,0\nGetPositionOnCurveArcLength|0.18867924809455872\tu:0.38914734125137329,0,0.34670713543891907,0\nGetTangentOnCurve|0.18867924809455872\tv:-47.912288665771484,-97.806381225585938\nGetTangentOnCurveArcLength|0.18867924809455872\tv:-50.592720031738281,-97.084129333496094\nGetPositionOnCurve|0.20754717290401459\tu:0.37653946876525879,0,0.30513384938240051,0\nGetPositionOnCurveArcLength|0.20754717290401459\tu:0.38177549839019775,0,0.32332032918930054,0\nGetTangentOnCurve|0.20754717290401459\tv:-42.788848876953125,-98.39324951171875\nGetTangentOnCurveArcLength|0.20754717290401459\tv:-46.33258056640625,-98.089500427246094\nGetPositionOnCurve|0.22641509771347046\tu:0.36964190006256104,0,0.27844271063804626,0\nGetPositionOnCurveArcLength|0.22641509771347046\tu:0.37500211596488953,0,0.29948854446411133,0\nGetTangentOnCurve|0.22641509771347046\tv:-37.192283630371094,-98.092605590820312\nGetTangentOnCurveArcLength|0.22641509771347046\tv:-41.645591735839844,-98.403671264648438\nGetPositionOnCurve|0.24528302252292633\tu:0.36374944448471069,0,0.25195363163948059,0\nGetPositionOnCurveArcLength|0.24528302252292633\tu:0.36887499690055847,0,0.27522686123847961,0\nGetTangentOnCurve|0.24528302252292633\tv:-31.122596740722656,-96.904457092285156\nGetTangentOnCurveArcLength|0.24528302252292633\tv:-36.484088897705078,-97.996185302734375\nGetPositionOnCurve|0.2641509473323822\tu:0.35894361138343811,0,0.22590760886669159,0\nGetPositionOnCurveArcLength|0.2641509473323822\tu:0.36346402764320374,0,0.25054660439491272,0\nGetTangentOnCurve|0.2641509473323822\tv:-24.579788208007812,-94.828811645507812\nGetTangentOnCurveArcLength|0.2641509473323822\tv:-30.784477233886719,-96.815872192382812\nGetPositionOnCurve|0.28301885724067688\tu:0.35530591011047363,0,0.2005455493927002,0\nGetPositionOnCurveArcLength|0.28301885724067688\tu:0.35887002944946289,0,0.22545933723449707,0\nGetTangentOnCurve|0.28301885724067688\tv:-17.563858032226562,-91.865653991699219\nGetTangentOnCurveArcLength|0.28301885724067688\tv:-24.461643218994141,-94.7847900390625\nGetPositionOnCurve|0.30188679695129395\tu:0.35291793942451477,0,0.17610833048820496,0\nGetPositionOnCurveArcLength|0.30188679695129395\tu:0.35523819923400879,0,0.19998481869697571,0\nGetTangentOnCurve|0.30188679695129395\tv:-10.074802398681641,-88.014999389648438\nGetTangentOnCurveArcLength|0.30188679695129395\tv:-17.400615692138672,-91.788803100585938\nGetPositionOnCurve|0.32075470685958862\tu:0.35186111927032471,0,0.15283708274364471,0\nGetPositionOnCurveArcLength|0.32075470685958862\tu:0.35278099775314331,0,0.1741667240858078,0\nGetTangentOnCurve|0.32075470685958862\tv:-2.1126327514648438,-83.276840209960938\nGetTangentOnCurveArcLength|0.32075470685958862\tv:-9.4441909790039062,-87.662384033203125\nGetPositionOnCurve|0.33962264657020569\tu:0.35221704840660095,0,0.13097250461578369,0\nGetPositionOnCurveArcLength|0.33962264657020569\tu:0.35181590914726257,0,0.14810842275619507,0\nGetTangentOnCurve|0.33962264657020569\tv:6.3226776123046875,-77.651168823242188\nGetTangentOnCurveArcLength|0.33962264657020569\tv:-0.3758697509765625,-82.166091918945312\nGetPositionOnCurve|0.35849055647850037\tu:0.35406720638275146,0,0.11075572669506073,0\nGetPositionOnCurveArcLength|0.35849055647850037\tu:0.35282468795776367,0,0.1220640242099762,0\nGetTangentOnCurve|0.35849055647850037\tv:15.2310791015625,-71.13800048828125\nGetTangentOnCurveArcLength|0.35849055647850037\tv:10.094985961914062,-74.959503173828125\nGetPositionOnCurve|0.37735849618911743\tu:0.35749316215515137,0,0.092427618801593781,0\nGetPositionOnCurveArcLength|0.37735849618911743\tu:0.35652101039886475,0,0.096649803221225739,0\nGetTangentOnCurve|0.37735849618911743\tv:24.612632751464844,-63.737312316894531\nGetTangentOnCurveArcLength|0.37735849618911743\tv:22.313362121582031,-65.598068237304688\nGetPositionOnCurve|0.39622640609741211\tu:0.36257639527320862,0,0.076229125261306763,0\nGetPositionOnCurveArcLength|0.39622640609741211\tu:0.36379584670066833,0,0.073273748159408569,0\nGetTangentOnCurve|0.39622640609741211\tv:34.467292785644531,-55.449142456054688\nGetTangentOnCurveArcLength|0.39622640609741211\tv:36.489738464355469,-53.689609527587891\nGetPositionOnCurve|0.41509434580802917\tu:0.36939844489097595,0,0.062401145696640015,0\nGetPositionOnCurveArcLength|0.41509434580802917\tu:0.37513956427574158,0,0.054394837468862534,0\nGetTangentOnCurve|0.41509434580802917\tv:44.795082092285156,-46.273448944091797\nGetTangentOnCurveArcLength|0.41509434580802917\tv:52.169822692871094,-39.450408935546875\nGetPositionOnCurve|0.43396225571632385\tu:0.37804082036018372,0,0.051184676587581635,0\nGetPositionOnCurveArcLength|0.43396225571632385\tu:0.38971206545829773,0,0.042170077562332153,0\nGetTangentOnCurve|0.43396225571632385\tv:55.595977783203125,-36.210262298583984\nGetTangentOnCurveArcLength|0.43396225571632385\tv:67.988739013671875,-24.150146484375\nGetPositionOnCurve|0.45283019542694092\tu:0.38858509063720703,0,0.042820718139410019,0\nGetPositionOnCurveArcLength|0.45283019542694092\tu:0.40585371851921082,0,0.036502812057733536,0\nGetTangentOnCurve|0.45283019542694092\tv:66.870025634765625,-25.259571075439453\nGetTangentOnCurveArcLength|0.45283019542694092\tv:82.732025146484375,-9.1806755065917969\nGetPositionOnCurve|0.4716981053352356\tu:0.40111273527145386,0,0.037550069391727448,0\nGetPositionOnCurveArcLength|0.4716981053352356\tu:0.42240512371063232,0,0.035847559571266174,0\nGetTangentOnCurve|0.4716981053352356\tv:78.617156982421875,-13.421348571777344\nGetTangentOnCurveArcLength|0.4716981053352356\tv:96.061843872070312,4.8611335754394531\nGetPositionOnCurve|0.49056604504585266\tu:0.41570529341697693,0,0.035613738000392914,0\nGetPositionOnCurveArcLength|0.49056604504585266\tu:0.41899970173835754,0,0.058134879916906357,0\nGetTangentOnCurve|0.49056604504585266\tv:90.837448120117188,-0.695648193359375\nGetTangentOnCurveArcLength|0.49056604504585266\tv:-19.964963912963867,27.881580352783203\nGetPositionOnCurve|0.50943398475646973\tu:0.42382118105888367,0,0.03936506062746048,0\nGetPositionOnCurveArcLength|0.50943398475646973\tu:0.40746402740478516,0,0.07678695023059845,0\nGetTangentOnCurve|0.50943398475646973\tv:-1.5401027202606201,25.254718780517578\nGetTangentOnCurveArcLength|0.50943398475646973\tv:-36.696037292480469,30.266956329345703\nGetPositionOnCurve|0.5283018946647644\tu:0.42294579744338989,0,0.046358253806829453,0\nGetPositionOnCurveArcLength|0.5283018946647644\tu:0.39404281973838806,0,0.092085957527160645,0\nGetTangentOnCurve|0.5283018946647644\tv:-8.6202859878540039,26.264150619506836\nGetTangentOnCurveArcLength|0.5283018946647644\tv:-49.492908477783203,32.091426849365234\nGetPositionOnCurve|0.54716980457305908\tu:0.42085045576095581,0,0.053625483065843582,0\nGetPositionOnCurveArcLength|0.54716980457305908\tu:0.37982812523841858,0,0.10550667345523834,0\nGetTangentOnCurve|0.54716980457305908\tv:-15.700469970703125,27.273584365844727\nGetTangentOnCurveArcLength|0.54716980457305908\tv:-60.147411346435547,33.610458374023438\nGetPositionOnCurve|0.56603771448135376\tu:0.41753512620925903,0,0.061166755855083466,0\nGetPositionOnCurveArcLength|0.56603771448135376\tu:0.36517822742462158,0,0.11771585047245026,0\nGetTangentOnCurve|0.56603771448135376\tv:-22.78065299987793,28.283018112182617\nGetTangentOnCurveArcLength|0.56603771448135376\tv:-69.438003540039062,34.935031890869141\nGetPositionOnCurve|0.58490568399429321\tu:0.41299977898597717,0,0.068982094526290894,0\nGetPositionOnCurveArcLength|0.58490568399429321\tu:0.35025227069854736,0,0.1290673166513443,0\nGetTangentOnCurve|0.58490568399429321\tv:-29.860857009887695,29.292453765869141\nGetTangentOnCurveArcLength|0.58490568399429321\tv:-77.770484924316406,36.123008728027344\nGetPositionOnCurve|0.60377359390258789\tu:0.40724450349807739,0,0.077071458101272583,0\nGetPositionOnCurveArcLength|0.60377359390258789\tu:0.33513492345809937,0,0.13977250456809998,0\nGetTangentOnCurve|0.60377359390258789\tv:-36.9410400390625,30.301887512207031\nGetTangentOnCurveArcLength|0.60377359390258789\tv:-85.384941101074219,37.208610534667969\nGetPositionOnCurve|0.62264150381088257\tu:0.40026918053627014,0,0.085434854030609131,0\nGetPositionOnCurveArcLength|0.62264150381088257\tu:0.31987640261650085,0,0.14996917545795441,0\nGetTangentOnCurve|0.62264150381088257\tv:-44.021224975585938,31.311321258544922\nGetTangentOnCurveArcLength|0.62264150381088257\tv:-92.436607360839844,38.213981628417969\nGetPositionOnCurve|0.64150941371917725\tu:0.39207392930984497,0,0.094072297215461731,0\nGetPositionOnCurveArcLength|0.64150941371917725\tu:0.30450928211212158,0,0.1597525030374527,0\nGetTangentOnCurve|0.64150941371917725\tv:-51.101406097412109,32.320755004882812\nGetTangentOnCurveArcLength|0.64150941371917725\tv:-99.03228759765625,39.154335021972656\nGetPositionOnCurve|0.6603773832321167\tu:0.38265863060951233,0,0.10298380255699158,0\nGetPositionOnCurveArcLength|0.6603773832321167\tu:0.28905552625656128,0,0.16919165849685669,0\nGetTangentOnCurve|0.6603773832321167\tv:-58.181613922119141,33.330188751220703\nGetTangentOnCurveArcLength|0.6603773832321167\tv:-105.24913787841797,40.040683746337891\nGetPositionOnCurve|0.67924529314041138\tu:0.37202337384223938,0,0.11216932535171509,0\nGetPositionOnCurveArcLength|0.67924529314041138\tu:0.27353113889694214,0,0.17833837866783142,0\nGetTangentOnCurve|0.67924529314041138\tv:-65.261795043945312,34.339622497558594\nGetTangentOnCurveArcLength|0.67924529314041138\tv:-111.14481353759766,40.881240844726562\nGetPositionOnCurve|0.69811320304870605\tu:0.36016812920570374,0,0.12162890285253525,0\nGetPositionOnCurveArcLength|0.69811320304870605\tu:0.25794774293899536,0,0.18723283708095551,0\nGetTangentOnCurve|0.69811320304870605\tv:-72.34197998046875,35.349056243896484\nGetTangentOnCurveArcLength|0.69811320304870605\tv:-116.76390838623047,41.682365417480469\nGetPositionOnCurve|0.71698111295700073\tu:0.34709292650222778,0,0.13136249780654907,0\nGetPositionOnCurveArcLength|0.71698111295700073\tu:0.24231448769569397,0,0.19590663909912109,0\nGetTangentOnCurve|0.71698111295700073\tv:-79.422164916992188,36.358489990234375\nGetTangentOnCurveArcLength|0.71698111295700073\tv:-122.14150238037109,42.449054718017578\nGetPositionOnCurve|0.73584908246994019\tu:0.33279767632484436,0,0.14137017726898193,0\nGetPositionOnCurveArcLength|0.73584908246994019\tu:0.22663813829421997,0,0.20438563823699951,0\nGetTangentOnCurve|0.73584908246994019\tv:-86.502365112304688,37.367927551269531\nGetTangentOnCurveArcLength|0.73584908246994019\tv:-127.3060302734375,43.185371398925781\nGetPositionOnCurve|0.75471699237823486\tu:0.31728252768516541,0,0.15165187418460846,0\nGetPositionOnCurveArcLength|0.75471699237823486\tu:0.21092437207698822,0,0.21269074082374573,0\nGetTangentOnCurve|0.75471699237823486\tv:-93.582550048828125,38.377357482910156\nGetTangentOnCurveArcLength|0.75471699237823486\tv:-132.28068542480469,43.894615173339844\nGetPositionOnCurve|0.77358490228652954\tu:0.30054736137390137,0,0.16220761835575104,0\nGetPositionOnCurveArcLength|0.77358490228652954\tu:0.19517768919467926,0,0.22083951532840729,0\nGetTangentOnCurve|0.77358490228652954\tv:-100.66273498535156,39.386791229248047\nGetTangentOnCurveArcLength|0.77358490228652954\tv:-137.08477783203125,44.579544067382812\nGetPositionOnCurve|0.79245281219482422\tu:0.28259217739105225,0,0.17303737998008728,0\nGetPositionOnCurveArcLength|0.79245281219482422\tu:0.17940181493759155,0,0.22884675860404968,0\nGetTangentOnCurve|0.79245281219482422\tv:-107.742919921875,40.396224975585938\nGetTangentOnCurveArcLength|0.79245281219482422\tv:-141.73458862304688,45.242473602294922\nGetPositionOnCurve|0.81132078170776367\tu:0.26341697573661804,0,0.18414124846458435,0\nGetPositionOnCurveArcLength|0.81132078170776367\tu:0.16359980404376984,0,0.23672507703304291,0\nGetTangentOnCurve|0.81132078170776367\tv:-114.8231201171875,41.405662536621094\nGetTangentOnCurveArcLength|0.81132078170776367\tv:-146.24397277832031,45.885383605957031\nGetPositionOnCurve|0.83018869161605835\tu:0.24302184581756592,0,0.1955191045999527,0\nGetPositionOnCurveArcLength|0.83018869161605835\tu:0.14777442812919617,0,0.24448521435260773,0\nGetTangentOnCurve|0.83018869161605835\tv:-121.90330505371094,42.415092468261719\nGetTangentOnCurveArcLength|0.83018869161605835\tv:-150.62478637695312,46.509963989257812\nGetPositionOnCurve|0.84905660152435303\tu:0.22140674293041229,0,0.2071710079908371,0\nGetPositionOnCurveArcLength|0.84905660152435303\tu:0.1319277286529541,0,0.25213664770126343,0\nGetTangentOnCurve|0.84905660152435303\tv:-128.98348999023438,43.424530029296875\nGetTangentOnCurveArcLength|0.84905660152435303\tv:-154.88739013671875,47.117691040039062\nGetPositionOnCurve|0.86792451143264771\tu:0.19857162237167358,0,0.21909694373607635,0\nGetPositionOnCurveArcLength|0.86792451143264771\tu:0.11606179922819138,0,0.25968754291534424,0\nGetTangentOnCurve|0.86792451143264771\tv:-136.06367492675781,44.4339599609375\nGetTangentOnCurveArcLength|0.86792451143264771\tv:-159.04075622558594,47.7098388671875\nGetPositionOnCurve|0.88679248094558716\tu:0.17451648414134979,0,0.23129695653915405,0\nGetPositionOnCurveArcLength|0.88679248094558716\tu:0.10017812997102737,0,0.26714518666267395,0\nGetTangentOnCurve|0.88679248094558716\tv:-143.14387512207031,45.443397521972656\nGetTangentOnCurveArcLength|0.88679248094558716\tv:-163.09284973144531,48.287551879882812\nGetPositionOnCurve|0.90566039085388184\tu:0.14924140274524689,0,0.2437710165977478,0\nGetPositionOnCurveArcLength|0.90566039085388184\tu:0.084278404712677002,0,0.27451595664024353,0\nGetTangentOnCurve|0.90566039085388184\tv:-150.22406005859375,46.452831268310547\nGetTangentOnCurveArcLength|0.90566039085388184\tv:-167.05062866210938,48.851821899414062\nGetPositionOnCurve|0.92452830076217651\tu:0.12274637073278427,0,0.25651907920837402,0\nGetPositionOnCurveArcLength|0.92452830076217651\tu:0.068363554775714874,0,0.28180563449859619,0\nGetTangentOnCurve|0.92452830076217651\tv:-157.30424499511719,47.462265014648438\nGetTangentOnCurveArcLength|0.92452830076217651\tv:-170.92042541503906,49.403541564941406\nGetPositionOnCurve|0.94339621067047119\tu:0.095031321048736572,0,0.26954114437103271,0\nGetPositionOnCurveArcLength|0.94339621067047119\tu:0.052435051649808884,0,0.28901919722557068,0\nGetTangentOnCurve|0.94339621067047119\tv:-164.38442993164062,48.471694946289062\nGetTangentOnCurveArcLength|0.94339621067047119\tv:-174.70773315429688,49.943504333496094\nGetPositionOnCurve|0.96226418018341064\tu:0.066096231341362,0,0.28283736109733582,0\nGetPositionOnCurveArcLength|0.96226418018341064\tu:0.036493729799985886,0,0.29616132378578186,0\nGetTangentOnCurve|0.96226418018341064\tv:-171.46463012695312,49.481132507324219\nGetTangentOnCurveArcLength|0.96226418018341064\tv:-178.41761779785156,50.472431182861328\nGetPositionOnCurve|0.98113209009170532\tu:0.03594120591878891,0,0.29640758037567139,0\nGetPositionOnCurveArcLength|0.98113209009170532\tu:0.02054031565785408,0,0.30323624610900879,0\nGetTangentOnCurve|0.98113209009170532\tv:-178.54481506347656,50.490566253662109\nGetTangentOnCurveArcLength|0.98113209009170532\tv:-182.05464172363281,50.990966796875\nGetPositionOnCurve|0.018518518656492233\tu:0.48309272527694702,0,0.53041738271713257,0\nGetPositionOnCurveArcLength|0.018518518656492233\tu:0.48187506198883057,0,0.52902275323867798,0\nGetTangentOnCurve|0.018518518656492233\tv:-72.744338989257812,-52.419754028320312\nGetTangentOnCurveArcLength|0.018518518656492233\tv:-72.681846618652344,-53.293601989746094\nGetPositionOnCurve|0.092592589557170868\tu:0.4355284571647644,0,0.45807579159736633,0\nGetPositionOnCurveArcLength|0.092592589557170868\tu:0.43534684181213379,0,0.45772761106491089,0\nGetTangentOnCurve|0.092592589557170868\tv:-66.664093017578125,-81.04937744140625\nGetTangentOnCurveArcLength|0.092592589557170868\tv:-66.624855041503906,-81.137054443359375\nGetPositionOnCurve|0.12962962687015533\tu:0.41390538215637207,0,0.4122847318649292,0\nGetPositionOnCurveArcLength|0.12962962687015533\tu:0.41582861542701721,0,0.41673526167869568,0\nGetTangentOnCurve|0.12962962687015533\tv:-60.889404296875,-90.234565734863281\nGetTangentOnCurveArcLength|0.12962962687015533\tv:-61.502784729003906,-89.525238037109375\nGetPositionOnCurve|0.20370370149612427\tu:0.37806040048599243,0,0.31057402491569519,0\nGetPositionOnCurveArcLength|0.20370370149612427\tu:0.3832298219203949,0,0.32812094688415527,0\nGetTangentOnCurve|0.20370370149612427\tv:-43.870883941650391,-98.345680236816406\nGetTangentOnCurveArcLength|0.20370370149612427\tv:-47.233684539794922,-97.940093994140625\nGetPositionOnCurve|0.24074074625968933\tu:0.36507174372673035,0,0.25829923152923584,0\nGetPositionOnCurveArcLength|0.24074074625968933\tu:0.37028768658638,0,0.28110635280609131,0\nGetTangentOnCurve|0.24074074625968933\tv:-32.627059936523438,-97.2716064453125\nGetTangentOnCurveArcLength|0.24074074625968933\tv:-37.773147583007812,-98.16259765625\nGetPositionOnCurve|0.31481480598449707\tu:0.35204529762268066,0,0.16002286970615387,0\nGetPositionOnCurveArcLength|0.31481480598449707\tu:0.35341125726699829,0,0.18232721090316772,0\nGetTangentOnCurve|0.31481480598449707\tv:-4.6702728271484375,-84.86419677734375\nGetTangentOnCurveArcLength|0.31481480598449707\tv:-12.057289123535156,-89.096099853515625\nGetPositionOnCurve|0.35185185074806213\tu:0.35324075818061829,0,0.117666095495224,0\nGetPositionOnCurveArcLength|0.35185185074806213\tu:0.35220542550086975,0,0.13119904696941376,0\nGetTangentOnCurve|0.35185185074806213\tv:12.042694091796875,-73.530860900878906\nGetTangentOnCurveArcLength|0.35185185074806213\tv:6.2295455932617188,-77.716316223144531\nGetPositionOnCurve|0.42592594027519226\tu:0.37413206696510315,0,0.055627342313528061,0\nGetPositionOnCurveArcLength|0.42592594027519226\tu:0.38321805000305176,0,0.046514056622982025,0\nGetTangentOnCurve|0.42592594027519226\tv:50.937759399414062,-40.604930877685547\nGetTangentOnCurveArcLength|0.42592594027519226\tv:61.331878662109375,-30.69232177734375\nGetPositionOnCurve|0.46296295523643494\tu:0.39506113529205322,0,0.039590246975421906,0\nGetPositionOnCurveArcLength|0.46296295523643494\tu:0.41473442316055298,0,0.035632401704788208,0\nGetTangentOnCurve|0.46296295523643494\tv:73.119857788085938,-19.012355804443359\nGetTangentOnCurveArcLength|0.46296295523643494\tv:90.062362670898438,-1.5143089294433594\nGetPositionOnCurve|0.53703701496124268\tu:0.42212739586830139,0,0.049688633531332016,0\nGetPositionOnCurveArcLength|0.53703701496124268\tu:0.38753160834312439,0,0.098481655120849609,0\nGetTangentOnCurve|0.53703701496124268\tv:-11.898139953613281,26.731479644775391\nGetTangentOnCurveArcLength|0.53703701496124268\tv:-54.631866455078125,32.8240966796875\nGetPositionOnCurve|0.57407408952713013\tu:0.41575255990028381,0,0.06446201354265213,0\nGetPositionOnCurveArcLength|0.57407408952713013\tu:0.35884860157966614,0,0.12264108657836914,0\nGetTangentOnCurve|0.57407408952713013\tv:-25.796302795410156,28.712963104248047\nGetTangentOnCurveArcLength|0.57407408952713013\tv:-73.087638854980469,35.455368041992188\nGetPositionOnCurve|0.64814811944961548\tu:0.3889002799987793,0,0.09717656672000885,0\nGetPositionOnCurveArcLength|0.64814811944961548\tu:0.29908078908920288,0,0.16310997307300568,0\nGetTangentOnCurve|0.64814811944961548\tv:-53.592582702636719,32.675926208496094\nGetTangentOnCurveArcLength|0.64814811944961548\tv:-101.25959014892578,39.471885681152344\nGetPositionOnCurve|0.68518519401550293\tu:0.36842277646064758,0,0.11511779576539993,0\nGetPositionOnCurveArcLength|0.68518519401550293\tu:0.26863116025924683,0,0.18116401135921478,0\nGetTangentOnCurve|0.68518519401550293\tv:-67.490745544433594,34.65740966796875\nGetTangentOnCurveArcLength|0.68518519401550293\tv:-112.94178771972656,41.137435913085938\nGetPositionOnCurve|0.75925928354263306\tu:0.31336516141891479,0,0.15416803956031799,0\nGetPositionOnCurveArcLength|0.75925928354263306\tu:0.20713634788990021,0,0.21466615796089172,0\nGetTangentOnCurve|0.75925928354263306\tv:-95.28704833984375,38.620372772216797\nGetTangentOnCurveArcLength|0.75925928354263306\tv:-133.4521484375,44.061630249023438\nGetPositionOnCurve|0.79629629850387573\tu:0.27878504991531372,0,0.17527706921100616,0\nGetPositionOnCurveArcLength|0.79629629850387573\tu:0.17618481814861298,0,0.2304617315530777,0\nGetTangentOnCurve|0.79629629850387573\tv:-109.18518829345703,40.601852416992188\nGetTangentOnCurveArcLength|0.79629629850387573\tv:-142.66416931152344,45.375007629394531\nGetPositionOnCurve|0.87037038803100586\tu:0.19552214443683624,0,0.22066299617290497,0\nGetPositionOnCurveArcLength|0.87037038803100586\tu:0.11400377750396729,0,0.26065942645072937,0\nGetTangentOnCurve|0.87037038803100586\tv:-136.98149108886719,44.564815521240234\nGetTangentOnCurveArcLength|0.87037038803100586\tv:-159.57157897949219,47.7855224609375\nGetPositionOnCurve|0.90740740299224854\tu:0.1468394547700882,0,0.24493984878063202,0\nGetPositionOnCurveArcLength|0.90740740299224854\tu:0.082805335521697998,0,0.27519431710243225,0\nGetTangentOnCurve|0.90740740299224854\tv:-150.87962341308594,46.546295166015625\nGetTangentOnCurveArcLength|0.90740740299224854\tv:-167.41256713867188,48.903427124023438\nGetPositionOnCurve|0.98148149251937866\tu:0.035371266305446625,0,0.29666146636009216,0\nGetPositionOnCurveArcLength|0.98148149251937866\tu:0.020244894549250603,0,0.30336660146713257,0\nGetTangentOnCurve|0.98148149251937866\tv:-178.67593383789062,50.509262084960938\nGetTangentOnCurveArcLength|0.98148149251937866\tv:-182.12130737304688,51.000473022460938\nGetPositionOnCurve|0.018181817606091499\tu:0.48331642150878906,0,0.53067094087600708,0\nGetPositionOnCurveArcLength|0.018181817606091499\tu:0.48211374878883362,0,0.52929800748825073,0\nGetTangentOnCurve|0.018181817606091499\tv:-72.755332946777344,-52.258388519287109\nGetTangentOnCurveArcLength|0.018181817606091499\tv:-72.6944580078125,-53.122928619384766\nGetPositionOnCurve|0.036363635212182999\tu:0.47129693627357483,0,0.51589483022689819,0\nGetPositionOnCurveArcLength|0.036363635212182999\tu:0.46961504220962524,0,0.51364129781723022,0\nGetTangentOnCurve|0.036363635212182999\tv:-71.946319580078125,-60.567642211914062\nGetTangentOnCurveArcLength|0.036363635212182999\tv:-71.796989440917969,-61.67242431640625\nGetPositionOnCurve|0.054545454680919647\tu:0.45944824814796448,0,0.4990527331829071,0\nGetPositionOnCurveArcLength|0.054545454680919647\tu:0.45785632729530334,0,0.49661803245544434,0\nGetTangentOnCurve|0.054545454680919647\tv:-70.697975158691406,-68.052764892578125\nGetTangentOnCurveArcLength|0.054545454680919647\tv:-70.49456787109375,-69.005699157714844\nGetPositionOnCurve|0.072727270424365997\tu:0.44784331321716309,0,0.48036029934883118,0\nGetPositionOnCurveArcLength|0.072727270424365997\tu:0.44676625728607178,0,0.47851347923278809,0\nGetTangentOnCurve|0.072727270424365997\tv:-69.010292053222656,-74.713760375976562\nGetTangentOnCurveArcLength|0.072727270424365997\tv:-68.828834533691406,-75.298233032226562\nGetPositionOnCurve|0.10909090936183929\tu:0.42565649747848511,0,0.43828660249710083,0\nGetPositionOnCurveArcLength|0.10909090936183929\tu:0.42637765407562256,0,0.43979328870773315,0\nGetTangentOnCurve|0.10909090936183929\tv:-64.316902160644531,-85.563346862792969\nGetTangentOnCurveArcLength|0.10909090936183929\tv:-64.503768920898438,-85.251235961914062\nGetPositionOnCurve|0.12727272510528564\tu:0.41522049903869629,0,0.41533660888671875,0\nGetPositionOnCurveArcLength|0.12727272510528564\tu:0.41700536012649536,0,0.41941925883293152,0\nGetTangentOnCurve|0.12727272510528564\tv:-61.311199188232422,-89.751937866210938\nGetTangentOnCurveArcLength|0.12727272510528564\tv:-61.867420196533203,-89.080284118652344\nGetPositionOnCurve|0.14545454084873199\tu:0.40532007813453674,0,0.39139866828918457,0\nGetPositionOnCurveArcLength|0.14545454084873199\tu:0.40815117955207825,0,0.39847755432128906,0\nGetTangentOnCurve|0.14545454084873199\tv:-57.866157531738281,-93.116409301757812\nGetTangentOnCurveArcLength|0.14545454084873199\tv:-58.917465209960938,-92.219223022460938\nGetPositionOnCurve|0.16363635659217834\tu:0.39602819085121155,0,0.36668834090232849,0\nGetPositionOnCurveArcLength|0.16363635659217834\tu:0.39980587363243103,0,0.37702333927154541,0\nGetTangentOnCurve|0.16363635659217834\tv:-53.981781005859375,-95.65673828125\nGetTangentOnCurveArcLength|0.16363635659217834\tv:-55.647163391113281,-94.7025146484375\nGetPositionOnCurve|0.21818181872367859\tu:0.37253296375274658,0,0.29007911682128906,0\nGetPositionOnCurveArcLength|0.21818181872367859\tu:0.37788158655166626,0,0.30994153022766113,0\nGetTangentOnCurve|0.21818181872367859\tv:-39.692604064941406,-98.332931518554688\nGetTangentOnCurveArcLength|0.21818181872367859\tv:-43.746059417724609,-98.353103637695312\nGetPositionOnCurve|0.23636363446712494\tu:0.36640453338623047,0,0.2644352912902832,0\nGetPositionOnCurveArcLength|0.23636363446712494\tu:0.37168711423873901,0,0.28674885630607605,0\nGetTangentOnCurve|0.23636363446712494\tv:-34.050868988037109,-97.576736450195312\nGetTangentOnCurveArcLength|0.23636363446712494\tv:-38.986820220947266,-98.281463623046875\nGetPositionOnCurve|0.25454545021057129\tu:0.36124935746192932,0,0.23909707367420197,0\nGetPositionOnCurveArcLength|0.25454545021057129\tu:0.36612376570701599,0,0.26316270232200623,0\nGetTangentOnCurve|0.25454545021057129\tv:-27.969795227050781,-95.996406555175781\nGetTangentOnCurveArcLength|0.25454545021057129\tv:-33.758029937744141,-97.5174560546875\nGetPositionOnCurve|0.29090908169746399\tu:0.35415059328079224,0,0.19019998610019684,0\nGetPositionOnCurveArcLength|0.29090908169746399\tu:0.35722383856773376,0,0.21485176682472229,0\nGetTangentOnCurve|0.29090908169746399\tv:-14.489627838134766,-90.36334228515625\nGetTangentOnCurveArcLength|0.29090908169746399\tv:-21.6065673828125,-93.657455444335938\nGetPositionOnCurve|0.30909091234207153\tu:0.35235288739204407,0,0.16707226634025574,0\nGetPositionOnCurveArcLength|0.30909091234207153\tu:0.35414692759513855,0,0.19016380608081818,0\nGetTangentOnCurve|0.30909091234207153\tv:-7.0905380249023438,-86.310615539550781\nGetTangentOnCurveArcLength|0.30909091234207153\tv:-14.478641510009766,-90.357772827148438\nGetPositionOnCurve|0.32727271318435669\tu:0.35182023048400879,0,0.14511258900165558,0\nGetPositionOnCurveArcLength|0.32727271318435669\tu:0.35225865244865417,0,0.16518346965312958,0\nGetTangentOnCurve|0.32727271318435669\tv:0.74788665771484375,-81.433761596679688\nGetTangentOnCurveArcLength|0.32727271318435669\tv:-6.450286865234375,-85.933433532714844\nGetPositionOnCurve|0.34545454382896423\tu:0.35262557864189148,0,0.12453655898571014,0\nGetPositionOnCurveArcLength|0.34545454382896423\tu:0.35188877582550049,0,0.14003828167915344,0\nGetTangentOnCurve|0.34545454382896423\tv:9.0256576538085938,-75.732772827148438\nGetTangentOnCurveArcLength|0.34545454382896423\tv:2.6951751708984375,-80.140228271484375\nGetPositionOnCurve|0.38181817531585693\tu:0.35854202508926392,0,0.088397733867168427,0\nGetPositionOnCurveArcLength|0.38181817531585693\tu:0.35788527131080627,0,0.090864576399326324,0\nGetTangentOnCurve|0.38181817531585693\tv:26.899208068847656,-61.8583984375\nGetTangentOnCurveArcLength|0.38181817531585693\tv:25.488311767578125,-63.021041870117188\nGetPositionOnCurve|0.41818180680274963\tu:0.37068593502044678,0,0.06038067489862442,0\nGetPositionOnCurveArcLength|0.41818180680274963\tu:0.37734594941139221,0,0.051910564303398132,0\nGetTangentOnCurve|0.41818180680274963\tv:46.530113220214844,-44.687488555908203\nGetTangentOnCurveArcLength|0.41818180680274963\tv:54.790809631347656,-36.975574493408203\nGetPositionOnCurve|0.43636363744735718\tu:0.37927553057670593,0,0.049956779927015305,0\nGetPositionOnCurveArcLength|0.43636363744735718\tu:0.3917115330696106,0,0.041111238300800323,0\nGetTangentOnCurve|0.43636363744735718\tv:57.00457763671875,-34.865837097167969\nGetTangentOnCurveArcLength|0.43636363744735718\tv:69.939971923828125,-22.205842971801758\nGetPositionOnCurve|0.47272726893424988\tu:0.40185469388961792,0,0.037356261163949966,0\nGetPositionOnCurveArcLength|0.47272726893424988\tu:0.423307865858078,0,0.035924732685089111,0\nGetTangentOnCurve|0.47272726893424988\tv:79.271514892578125,-12.750137329101562\nGetTangentOnCurveArcLength|0.47272726893424988\tv:96.750152587890625,5.5981407165527344\nGetPositionOnCurve|0.49090909957885742\tu:0.41599023342132568,0,0.035610884428024292,0\nGetPositionOnCurveArcLength|0.49090909957885742\tu:0.41882330179214478,0,0.058519884943962097,0\nGetTangentOnCurve|0.49090909957885742\tv:91.06402587890625,-0.45605850219726562\nGetTangentOnCurveArcLength|0.49090909957885742\tv:-20.324762344360352,27.932876586914062\nGetPositionOnCurve|0.50909090042114258\tu:0.42382580041885376,0,0.039240438491106033,0\nGetPositionOnCurveArcLength|0.50909090042114258\tu:0.40769627690315247,0,0.076484255492687225,0\nGetTangentOnCurve|0.50909090042114258\tv:-1.4113602638244629,25.236362457275391\nGetTangentOnCurveArcLength|0.50909090042114258\tv:-36.43505859375,30.229747772216797\nGetPositionOnCurve|0.52727270126342773\tu:0.42302501201629639,0,0.045969724655151367,0\nGetPositionOnCurveArcLength|0.52727270126342773\tu:0.39480030536651611,0,0.091308265924453735,0\nGetTangentOnCurve|0.52727270126342773\tv:-8.2340812683105469,26.209089279174805\nGetTangentOnCurveArcLength|0.52727270126342773\tv:-48.860008239746094,32.001194000244141\nGetPositionOnCurve|0.56363636255264282\tu:0.41802483797073364,0,0.060191743075847626,0\nGetPositionOnCurveArcLength|0.56363636255264282\tu:0.36706042289733887,0,0.11621516197919846,0\nGetTangentOnCurve|0.56363636255264282\tv:-21.879545211791992,28.154544830322266\nGetTangentOnCurveArcLength|0.56363636255264282\tv:-68.315132141113281,34.774940490722656\nGetPositionOnCurve|0.58181816339492798\tu:0.41382542252540588,0,0.067684464156627655,0\nGetPositionOnCurveArcLength|0.58181816339492798\tu:0.35270953178405762,0,0.12725849449634552,0\nGetTangentOnCurve|0.58181816339492798\tv:-28.702266693115234,29.12727165222168\nGetTangentOnCurveArcLength|0.58181816339492798\tv:-76.461174011230469,35.936336517333984\nGetPositionOnCurve|0.61818182468414307\tu:0.40202799439430237,0,0.083433322608470917,0\nGetPositionOnCurveArcLength|0.61818182468414307\tu:0.32349377870559692,0,0.14759936928749084,0\nGetTangentOnCurve|0.61818182468414307\tv:-42.347728729248047,31.072727203369141\nGetTangentOnCurveArcLength|0.61818182468414307\tv:-90.814376831054688,37.982696533203125\nGetPositionOnCurve|0.65454542636871338\tu:0.38569909334182739,0,0.10020005702972412,0\nGetPositionOnCurveArcLength|0.65454542636871338\tu:0.29384034872055054,0,0.16630746424198151,0\nGetTangentOnCurve|0.65454542636871338\tv:-55.993171691894531,33.018180847167969\nGetTangentOnCurveArcLength|0.65454542636871338\tv:-103.36423492431641,39.771949768066406\nGetPositionOnCurve|0.67272728681564331\tu:0.37583529949188232,0,0.10896516591310501,0\nGetPositionOnCurveArcLength|0.67272728681564331\tu:0.27890130877494812,0,0.17520895600318909,0\nGetTangentOnCurve|0.67272728681564331\tv:-62.81591796875,33.990909576416016\nGetTangentOnCurveArcLength|0.67272728681564331\tv:-109.14143371582031,40.595615386962891\nGetPositionOnCurve|0.69090908765792847\tu:0.36483868956565857,0,0.11798471957445145,0\nGetPositionOnCurveArcLength|0.69090908765792847\tu:0.26390421390533447,0,0.1838642954826355,0\nGetTangentOnCurve|0.69090908765792847\tv:-69.638633728027344,34.963638305664062\nGetTangentOnCurveArcLength|0.69090908765792847\tv:-114.64862823486328,41.380783081054688\nGetPositionOnCurve|0.70909088850021362\tu:0.35270917415618896,0,0.12725873291492462,0\nGetPositionOnCurveArcLength|0.70909088850021362\tu:0.24885758757591248,0,0.19230449199676514,0\nGetTangentOnCurve|0.70909088850021362\tv:-76.461357116699219,35.936363220214844\nGetTangentOnCurveArcLength|0.70909088850021362\tv:-119.92012023925781,42.132347106933594\nGetPositionOnCurve|0.74545454978942871\tu:0.32505151629447937,0,0.14657025039196014,0\nGetPositionOnCurveArcLength|0.74545454978942871\tu:0.2186426967382431,0,0.20863425731658936,0\nGetTangentOnCurve|0.74545454978942871\tv:-90.106819152832031,37.881820678710938\nGetTangentOnCurveArcLength|0.74545454978942871\tv:-129.86103820800781,43.549640655517578\nGetPositionOnCurve|0.76363635063171387\tu:0.30952337384223938,0,0.15660770237445831,0\nGetPositionOnCurveArcLength|0.76363635063171387\tu:0.20348431169986725,0,0.21656143665313721,0\nGetTangentOnCurve|0.76363635063171387\tv:-96.929542541503906,38.854545593261719\nGetTangentOnCurveArcLength|0.76363635063171387\tv:-134.57191467285156,44.221279144287109\nGetPositionOnCurve|0.7818182110786438\tu:0.29286235570907593,0,0.16689965128898621,0\nGetPositionOnCurveArcLength|0.7818182110786438\tu:0.18829700350761414,0,0.22435024380683899,0\nGetTangentOnCurve|0.7818182110786438\tv:-103.75228118896484,39.827274322509766\nGetTangentOnCurveArcLength|0.7818182110786438\tv:-139.13191223144531,44.871406555175781\nGetPositionOnCurve|0.83636361360549927\tu:0.23608213663101196,0,0.19930225610733032,0\nGetPositionOnCurveArcLength|0.83636361360549927\tu:0.14259059727191925,0,0.24700076878070831,0\nGetTangentOnCurve|0.83636361360549927\tv:-124.22044372558594,42.745452880859375\nGetTangentOnCurveArcLength|0.83636361360549927\tv:-152.03233337402344,46.710639953613281\nGetPositionOnCurve|0.8545454740524292\tu:0.21488961577415466,0,0.21061211824417114,0\nGetPositionOnCurveArcLength|0.8545454740524292\tu:0.12731404602527618,0,0.25434333086013794,0\nGetTangentOnCurve|0.8545454740524292\tv:-131.04318237304688,43.718185424804688\nGetTangentOnCurveArcLength|0.8545454740524292\tv:-156.10655212402344,47.29150390625\nGetPositionOnCurve|0.87272727489471436\tu:0.19256424903869629,0,0.22217640280723572,0\nGetPositionOnCurveArcLength|0.87272727489471436\tu:0.11202030628919601,0,0.26159441471099854,0\nGetTangentOnCurve|0.87272727489471436\tv:-137.86590576171875,44.690910339355469\nGetTangentOnCurveArcLength|0.87272727489471436\tv:-160.08151245117188,47.858222961425781\nGetPositionOnCurve|0.89090907573699951\tu:0.16910603642463684,0,0.23399518430233002,0\nGetPositionOnCurveArcLength|0.89090907573699951\tu:0.096710518002510071,0,0.26876053214073181,0\nGetTangentOnCurve|0.89090907573699951\tv:-144.68862915039062,45.66363525390625\nGetTangentOnCurveArcLength|0.89090907573699951\tv:-163.96415710449219,48.411781311035156\nGetPositionOnCurve|0.9272727370262146\tu:0.1187908947467804,0,0.25839617848396301,0\nGetPositionOnCurveArcLength|0.9272727370262146\tu:0.066047497093677521,0,0.28285950422286987,0\nGetTangentOnCurve|0.9272727370262146\tv:-158.33409118652344,47.609092712402344\nGetTangentOnCurveArcLength|0.9272727370262146\tv:-171.47630310058594,49.482795715332031\nGetPositionOnCurve|0.94545453786849976\tu:0.091934062540531158,0,0.27097836136817932,0\nGetPositionOnCurveArcLength|0.94545453786849976\tu:0.050696492195129395,0,0.28980180621147156,0\nGetTangentOnCurve|0.94545453786849976\tv:-165.15681457519531,48.581817626953125\nGetTangentOnCurveArcLength|0.94545453786849976\tv:-175.11614990234375,50.001735687255859\nGetPositionOnCurve|0.96363633871078491\tu:0.063944324851036072,0,0.28381502628326416,0\nGetPositionOnCurveArcLength|0.96363633871078491\tu:0.035333782434463501,0,0.29667815566062927,0\nGetTangentOnCurve|0.96363633871078491\tv:-171.97953796386719,49.554542541503906\nGetTangentOnCurveArcLength|0.96363633871078491\tv:-178.68455505371094,50.510490417480469\nGetPositionOnCurve|0.98181819915771484\tu:0.03482167050242424,0,0.29690620303153992,0\nGetPositionOnCurveArcLength|0.98181819915771484\tu:0.019960029050707817,0,0.30349227786064148,0\nGetTangentOnCurve|0.98181819915771484\tv:-178.80227661132812,50.527275085449219\nGetTangentOnCurveArcLength|0.98181819915771484\tv:-182.18556213378906,51.009635925292969\nGetPositionOnCurve|0.01785714365541935\tu:0.48353219032287598,0,0.53091466426849365,0\nGetPositionOnCurveArcLength|0.01785714365541935\tu:0.48234415054321289,0,0.52956289052963257,0\nGetTangentOnCurve|0.01785714365541935\tv:-72.765785217285156,-52.102519989013672\nGetTangentOnCurveArcLength|0.01785714365541935\tv:-72.706459045410156,-52.957878112792969\nGetPositionOnCurve|0.0535714291036129\tu:0.46007746458053589,0,0.50000381469726562,0\nGetPositionOnCurveArcLength|0.0535714291036129\tu:0.4584687352180481,0,0.49755951762199402,0\nGetTangentOnCurve|0.0535714291036129\tv:-70.775985717773438,-67.67266845703125\nGetTangentOnCurveArcLength|0.0535714291036129\tv:-70.573844909667969,-68.640579223632812\nGetPositionOnCurve|0.089285716414451599\tu:0.4375481903553009,0,0.46190884709358215,0\nGetPositionOnCurveArcLength|0.089285716414451599\tu:0.43719971179962158,0,0.46125257015228271,0\nGetTangentOnCurve|0.089285716414451599\tv:-67.091041564941406,-80.062980651855469\nGetTangentOnCurveArcLength|0.089285716414451599\tv:-67.018600463867188,-80.234664916992188\nGetPositionOnCurve|0.1607142835855484\tu:0.39747744798660278,0,0.3707028329372406,0\nGetPositionOnCurveArcLength|0.1607142835855484\tu:0.40111282467842102,0,0.38050398230552673,0\nGetTangentOnCurve|0.1607142835855484\tv:-54.63568115234375,-95.304046630859375\nGetTangentOnCurveArcLength|0.1607142835855484\tv:-56.194808959960938,-94.346649169921875\nGetPositionOnCurve|0.1964285671710968\tu:0.38104179501533508,0,0.32085984945297241,0\nGetPositionOnCurveArcLength|0.1964285671710968\tu:0.38604947924613953,0,0.33715689182281494,0\nGetTangentOnCurve|0.1964285671710968\tv:-45.865272521972656,-98.154815673828125\nGetTangentOnCurveArcLength|0.1964285671710968\tv:-48.892158508300781,-97.579490661621094\nGetPositionOnCurve|0.2321428507566452\tu:0.36774313449859619,0,0.27036893367767334,0\nGetPositionOnCurveArcLength|0.2321428507566452\tu:0.37307104468345642,0,0.29216828942298889,0\nGetTangentOnCurve|0.2321428507566452\tv:-35.399715423583984,-97.825729370117188\nGetTangentOnCurveArcLength|0.2321428507566452\tv:-40.131435394287109,-98.358154296875\nGetPositionOnCurve|0.2678571343421936\tu:0.35813429951667786,0,0.22086422145366669,0\nGetPositionOnCurveArcLength|0.2678571343421936\tu:0.36249333620071411,0,0.24565039575099945,0\nGetTangentOnCurve|0.2678571343421936\tv:-23.239002227783203,-94.316802978515625\nGetTangentOnCurveArcLength|0.2678571343421936\tv:-29.594802856445312,-96.487060546875\nGetPositionOnCurve|0.3035714328289032\tu:0.35276827216148376,0,0.17397964000701904,0\nGetPositionOnCurveArcLength|0.3035714328289032\tu:0.35496723651885986,0,0.19769264757633209,0\nGetTangentOnCurve|0.3035714328289032\tv:-9.3831329345703125,-87.628036499023438\nGetTangentOnCurveArcLength|0.3035714328289032\tv:-16.729339599609375,-91.469268798828125\nGetPositionOnCurve|0.33928570151329041\tu:0.35219782590866089,0,0.13134928047657013,0\nGetPositionOnCurveArcLength|0.33928570151329041\tu:0.35181757807731628,0,0.14857488870620728,0\nGetTangentOnCurve|0.33928570151329041\tv:6.167877197265625,-77.759414672851562\nGetTangentOnCurveArcLength|0.33928570151329041\tv:-0.5491790771484375,-82.278091430664062\nGetPositionOnCurve|0.41071429848670959\tu:0.36765551567077637,0,0.065387316048145294,0\nGetPositionOnCurveArcLength|0.41071429848670959\tu:0.37216323614120483,0,0.058234017342329025,0\nGetTangentOnCurve|0.41071429848670959\tv:42.355392456054688,-48.482612609863281\nGetTangentOnCurveArcLength|0.41071429848670959\tv:48.458915710449219,-42.910270690917969\nGetPositionOnCurve|0.4464285671710968\tu:0.38478931784629822,0,0.045323871076107025,0\nGetPositionOnCurveArcLength|0.4464285671710968\tu:0.40029004216194153,0,0.037778567522764206,0\nGetTangentOnCurve|0.4464285671710968\tv:62.991867065429688,-29.074462890625\nGetTangentOnCurveArcLength|0.4464285671710968\tv:77.886886596679688,-14.169075012207031\nGetPositionOnCurve|0.4821428656578064\tu:0.40893039107322693,0,0.036050811409950256,0\nGetPositionOnCurveArcLength|0.4821428656578064\tu:0.42258089780807495,0,0.047968760132789612,0\nGetTangentOnCurve|0.4821428656578064\tv:85.323501586914062,-6.4864692687988281\nGetTangentOnCurveArcLength|0.4821428656578064\tv:-10.212615013122559,26.491172790527344\nGetPositionOnCurve|0.5178571343421936\tu:0.42358112335205078,0,0.042453151196241379,0\nGetPositionOnCurveArcLength|0.5178571343421936\tu:0.40161016583442688,0,0.083914503455162048,0\nGetTangentOnCurve|0.5178571343421936\tv:-4.7008895874023438,25.705356597900391\nGetTangentOnCurveArcLength|0.5178571343421936\tv:-42.751220703125,31.130254745483398\nGetPositionOnCurve|0.55357140302658081\tu:0.41986235976219177,0,0.056153405457735062,0\nGetPositionOnCurveArcLength|0.55357140302658081\tu:0.37489613890647888,0,0.10976298898458481,0\nGetTangentOnCurve|0.55357140302658081\tv:-18.102668762207031,27.616069793701172\nGetTangentOnCurveArcLength|0.55357140302658081\tv:-63.427268981933594,34.078071594238281\nGetPositionOnCurve|0.58928573131561279\tu:0.4117724597454071,0,0.07083556056022644,0\nGetPositionOnCurveArcLength|0.58928573131561279\tu:0.3467576801776886,0,0.13160412013530731,0\nGetTangentOnCurve|0.58928573131561279\tv:-31.504470825195312,29.526786804199219\nGetTangentOnCurveArcLength|0.58928573131561279\tv:-79.595413208007812,36.383190155029297\nGetPositionOnCurve|0.66071426868438721\tu:0.3824794590473175,0,0.10314540565013885,0\nGetPositionOnCurveArcLength|0.66071426868438721\tu:0.28877896070480347,0,0.16935737431049347,0\nGetTangentOnCurve|0.66071426868438721\tv:-58.308029174804688,33.348213195800781\nGetTangentOnCurveArcLength|0.66071426868438721\tv:-105.35704803466797,40.056068420410156\nGetPositionOnCurve|0.69642859697341919\tu:0.36127620935440063,0,0.12077316641807556,0\nGetPositionOnCurveArcLength|0.69642859697341919\tu:0.25934132933616638,0,0.18644802272319794,0\nGetTangentOnCurve|0.69642859697341919\tv:-71.709831237792969,35.258930206298828\nGetTangentOnCurveArcLength|0.69642859697341919\tv:-116.2724609375,41.612297058105469\nGetPositionOnCurve|0.7321428656578064\tu:0.33570197224617004,0,0.1393827497959137,0\nGetPositionOnCurveArcLength|0.7321428656578064\tu:0.22972054779529572,0,0.20273442566394806,0\nGetTangentOnCurve|0.7321428656578064\tv:-85.111610412597656,37.169643402099609\nGetTangentOnCurveArcLength|0.7321428656578064\tv:-126.30722045898438,43.04296875\nGetPositionOnCurve|0.7678571343421936\tu:0.30575662851333618,0,0.15897421538829803,0\nGetPositionOnCurveArcLength|0.7678571343421936\tu:0.19996115565299988,0,0.2183813750743866,0\nGetTangentOnCurve|0.7678571343421936\tv:-98.513389587402344,39.080356597900391\nGetTangentOnCurveArcLength|0.7678571343421936\tv:-135.64340209960938,44.374042510986328\nGetPositionOnCurve|0.80357140302658081\tu:0.27144017815589905,0,0.17954754829406738,0\nGetPositionOnCurveArcLength|0.80357140302658081\tu:0.17009285092353821,0,0.23350420594215393,0\nGetTangentOnCurve|0.80357140302658081\tv:-111.91516876220703,40.991069793701172\nGetTangentOnCurveArcLength|0.80357140302658081\tv:-144.40811157226562,45.623641967773438\nGetPositionOnCurve|0.83928573131561279\tu:0.23275257647037506,0,0.20110277831554413,0\nGetPositionOnCurveArcLength|0.83928573131561279\tu:0.14013653993606567,0,0.24818733334541321,0\nGetTangentOnCurve|0.83928573131561279\tv:-125.31697082519531,42.901786804199219\nGetTangentOnCurveArcLength|0.83928573131561279\tv:-152.69415283203125,46.804996490478516\nGetPositionOnCurve|0.91071426868438721\tu:0.14226418733596802,0,0.24715876579284668,0\nGetPositionOnCurveArcLength|0.91071426868438721\tu:0.080016814172267914,0,0.27647635340690613,0\nGetTangentOnCurve|0.91071426868438721\tv:-152.12052917480469,46.723213195800781\nGetTangentOnCurveArcLength|0.91071426868438721\tv:-168.09559631347656,49.000804901123047\nGetPositionOnCurve|0.94642859697341919\tu:0.090463265776634216,0,0.27165961265563965,0\nGetPositionOnCurveArcLength|0.94642859697341919\tu:0.049873806536197662,0,0.29017180204391479,0\nGetTangentOnCurve|0.94642859697341919\tv:-165.52232360839844,48.633930206298828\nGetTangentOnCurveArcLength|0.94642859697341919\tv:-175.30908203125,50.029243469238281\nGetPositionOnCurve|0.9821428656578064\tu:0.0342913419008255,0,0.29714226722717285,0\nGetPositionOnCurveArcLength|0.9821428656578064\tu:0.019685370847582817,0,0.30361342430114746,0\nGetTangentOnCurve|0.9821428656578064\tv:-178.92410278320312,50.544643402099609\nGetTangentOnCurveArcLength|0.9821428656578064\tv:-182.24749755859375,51.018463134765625\nGetPositionOnCurve|0.017543859779834747\tu:0.48374035954475403,0,0.53114920854568481,0\nGetPositionOnCurveArcLength|0.017543859779834747\tu:0.48256668448448181,0,0.52981787919998169,0\nGetTangentOnCurve|0.017543859779834747\tv:-72.775741577148438,-51.951869964599609\nGetTangentOnCurveArcLength|0.017543859779834747\tv:-72.717903137207031,-52.798187255859375\nGetPositionOnCurve|0.035087719559669495\tu:0.47213566303253174,0,0.51700162887573242,0\nGetPositionOnCurveArcLength|0.035087719559669495\tu:0.47046709060668945,0,0.51478862762451172,0\nGetTangentOnCurve|0.035087719559669495\tv:-72.017425537109375,-60.011428833007812\nGetTangentOnCurveArcLength|0.035087719559669495\tv:-71.873771667480469,-61.114501953125\nGetPositionOnCurve|0.070175439119338989\tu:0.44945463538169861,0,0.48308733105659485,0\nGetPositionOnCurveArcLength|0.070175439119338989\tu:0.44828471541404724,0,0.48111158609390259,0\nGetTangentOnCurve|0.070175439119338989\tv:-69.273658752441406,-73.828598022460938\nGetTangentOnCurveArcLength|0.070175439119338989\tv:-69.083404541015625,-74.472549438476562\nGetPositionOnCurve|0.087719298899173737\tu:0.43850934505462646,0,0.46370795369148254,0\nGetPositionOnCurveArcLength|0.087719298899173737\tu:0.4380839467048645,0,0.46291369199752808,0\nGetTangentOnCurve|0.087719298899173737\tv:-67.288200378417969,-79.586219787597656\nGetTangentOnCurveArcLength|0.087719298899173737\tv:-67.201416015625,-79.797813415527344\nGetPositionOnCurve|0.12280701845884323\tu:0.41773694753646851,0,0.421073317527771,0\nGetPositionOnCurveArcLength|0.12280701845884323\tu:0.41925874352455139,0,0.42447850108146667,0\nGetTangentOnCurve|0.12280701845884323\tv:-62.090141296386719,-88.799514770507812\nGetTangentOnCurveArcLength|0.12280701845884323\tv:-62.543880462646484,-88.205413818359375\nGetPositionOnCurve|0.14035087823867798\tu:0.408040851354599,0,0.39820536971092224,0\nGetPositionOnCurveArcLength|0.14035087823867798\tu:0.410584956407547,0,0.40440970659255981,0\nGetTangentOnCurve|0.14035087823867798\tv:-58.877540588378906,-92.25518798828125\nGetTangentOnCurveArcLength|0.14035087823867798\tv:-59.777442932128906,-91.405525207519531\nGetPositionOnCurve|0.17543859779834747\tu:0.39035674929618835,0,0.35033676028251648,0\nGetPositionOnCurveArcLength|0.17543859779834747\tu:0.39466094970703125,0,0.36284226179122925,0\nGetTangentOnCurve|0.17543859779834747\tv:-51.225181579589844,-96.864608764648438\nGetTangentOnCurveArcLength|0.17543859779834747\tv:-53.346900939941406,-95.973587036132812\nGetPositionOnCurve|0.19298245012760162\tu:0.38249975442886353,0,0.3257235586643219,0\nGetPositionOnCurveArcLength|0.19298245012760162\tu:0.38741523027420044,0,0.34141349792480469,0\nGetTangentOnCurve|0.19298245012760162\tv:-46.785434722900391,-98.018356323242188\nGetTangentOnCurveArcLength|0.19298245012760162\tv:-49.65667724609375,-97.373336791992188\nGetPositionOnCurve|0.22807016968727112\tu:0.36908364295959473,0,0.2761075496673584,0\nGetPositionOnCurveArcLength|0.22807016968727112\tu:0.37443795800209045,0,0.29737737774848938,0\nGetTangentOnCurve|0.22807016968727112\tv:-36.678787231445312,-98.023887634277344\nGetTangentOnCurveArcLength|0.22807016968727112\tv:-41.212623596191406,-98.397384643554688\nGetPositionOnCurve|0.24561403691768646\tu:0.36365550756454468,0,0.25149217247962952,0\nGetPositionOnCurveArcLength|0.24561403691768646\tu:0.36877363920211792,0,0.27479743957519531,0\nGetTangentOnCurve|0.24561403691768646\tv:-31.011886596679688,-96.875686645507812\nGetTangentOnCurveArcLength|0.24561403691768646\tv:-36.388950347900391,-97.982330322265625\nGetPositionOnCurve|0.28070175647735596\tu:0.35568699240684509,0,0.20361520349979401,0\nGetPositionOnCurveArcLength|0.28070175647735596\tu:0.35938578844070435,0,0.22856156527996063,0\nGetTangentOnCurve|0.28070175647735596\tv:-18.450942993164062,-92.277351379394531\nGetTangentOnCurveArcLength|0.28070175647735596\tv:-25.275215148925781,-95.083480834960938\nGetPositionOnCurve|0.29824560880661011\tu:0.35327762365341187,0,0.18074098229408264,0\nGetPositionOnCurveArcLength|0.29824560880661011\tu:0.35585534572601318,0,0.20492962002754211,0\nGetTangentOnCurve|0.29824560880661011\tv:-11.556903839111328,-88.827217102050781\nGetTangentOnCurveArcLength|0.29824560880661011\tv:-18.827423095703125,-92.449005126953125\nGetPositionOnCurve|0.35087719559669495\tu:0.3531356155872345,0,0.11869965493679047,0\nGetPositionOnCurveArcLength|0.35087719559669495\tu:0.35214018821716309,0,0.13254410028457642,0\nGetTangentOnCurve|0.35087719559669495\tv:11.57952880859375,-73.872917175292969\nGetTangentOnCurveArcLength|0.35087719559669495\tv:5.6793441772460938,-78.099884033203125\nGetPositionOnCurve|0.38596490025520325\tu:0.35960134863853455,0,0.084760211408138275,0\nGetPositionOnCurveArcLength|0.38596490025520325\tu:0.35934463143348694,0,0.085606992244720459,0\nGetTangentOnCurve|0.38596490025520325\tv:29.049057006835938,-60.06683349609375\nGetTangentOnCurveArcLength|0.38596490025520325\tv:28.540847778320312,-60.492477416992188\nGetPositionOnCurve|0.40350878238677979\tu:0.36499893665313721,0,0.070597916841506958,0\nGetPositionOnCurveArcLength|0.40350878238677979\tu:0.36770322918891907,0,0.065301358699798584,0\nGetTangentOnCurve|0.40350878238677979\tv:38.39739990234375,-52.012809753417969\nGetTangentOnCurveArcLength|0.40350878238677979\tv:42.423751831054688,-48.421054840087891\nGetPositionOnCurve|0.43859648704528809\tu:0.38045132160186768,0,0.048856887966394424,0\nGetPositionOnCurveArcLength|0.43859648704528809\tu:0.39358967542648315,0,0.040221236646175385,0\nGetTangentOnCurve|0.43859648704528809\tv:58.321212768554688,-33.60284423828125\nGetTangentOnCurveArcLength|0.43859648704528809\tv:71.73602294921875,-20.405824661254883\nGetPositionOnCurve|0.45614033937454224\tu:0.39063712954521179,0,0.041665442287921906,0\nGetPositionOnCurveArcLength|0.45614033937454224\tu:0.4087485671043396,0,0.036072764545679092,0\nGetTangentOnCurve|0.45614033937454224\tv:68.896697998046875,-23.246870040893555\nGetTangentOnCurveArcLength|0.45614033937454224\tv:85.171981811523438,-6.6444587707519531\nGetPositionOnCurve|0.49122807383537292\tu:0.41625580191612244,0,0.035609293729066849,0\nGetPositionOnCurveArcLength|0.49122807383537292\tu:0.41865766048431396,0,0.058875948190689087,0\nGetTangentOnCurve|0.49122807383537292\tv:91.274810791015625,-0.23302841186523438\nGetTangentOnCurveArcLength|0.49122807383537292\tv:-20.65692138671875,27.980234146118164\nGetPositionOnCurve|0.50877195596694946\tu:0.42382973432540894,0,0.039124667644500732,0\nGetPositionOnCurveArcLength|0.50877195596694946\tu:0.40791162848472595,0,0.076201938092708588,0\nGetTangentOnCurve|0.50877195596694946\tv:-1.2916765213012695,25.21929931640625\nGetTangentOnCurveArcLength|0.50877195596694946\tv:-36.191352844238281,30.195003509521484\nGetPositionOnCurve|0.54385966062545776\tu:0.421306312084198,0,0.052330717444419861,0\nGetPositionOnCurveArcLength|0.54385966062545776\tu:0.3823598325252533,0,0.10325313359498978,0\nGetTangentOnCurve|0.54385966062545776\tv:-14.458337783813477,27.096492767333984\nGetTangentOnCurveArcLength|0.54385966062545776\tv:-58.392257690429688,33.360221862792969\nGetPositionOnCurve|0.56140351295471191\tu:0.41846242547035217,0,0.059289135038852692,0\nGetPositionOnCurveArcLength|0.56140351295471191\tu:0.36880636215209961,0,0.11480703949928284,0\nGetTangentOnCurve|0.56140351295471191\tv:-21.041667938232422,28.035087585449219\nGetTangentOnCurveArcLength|0.56140351295471191\tv:-67.256790161132812,34.624053955078125\nGetPositionOnCurve|0.59649121761322021\tu:0.40961042046546936,0,0.073916763067245483,0\nGetPositionOnCurveArcLength|0.59649121761322021\tu:0.3409886360168457,0,0.1357073038816452,0\nGetTangentOnCurve|0.59649121761322021\tv:-34.208328247070312,29.912281036376953\nGetTangentOnCurveArcLength|0.59649121761322021\tv:-82.519866943359375,36.800132751464844\nGetPositionOnCurve|0.61403506994247437\tu:0.4036022424697876,0,0.081585973501205444,0\nGetPositionOnCurveArcLength|0.61403506994247437\tu:0.32685157656669617,0,0.14537429809570312,0\nGetTangentOnCurve|0.61403506994247437\tv:-40.791660308837891,30.850875854492188\nGetTangentOnCurveArcLength|0.61403506994247437\tv:-89.282180786132812,37.764247894287109\nGetPositionOnCurve|0.64912283420562744\tu:0.38842156529426575,0,0.09763520210981369,0\nGetPositionOnCurveArcLength|0.64912283420562744\tu:0.29828295111656189,0,0.16359949111938477,0\nGetTangentOnCurve|0.64912283420562744\tv:-53.958343505859375,32.728073120117188\nGetTangentOnCurveArcLength|0.64912283420562744\tv:-101.58283233642578,39.517971038818359\nGetPositionOnCurve|0.70175439119338989\tu:0.35773986577987671,0,0.12348597496747971,0\nGetPositionOnCurveArcLength|0.70175439119338989\tu:0.25493454933166504,0,0.18892295658588409,0\nGetTangentOnCurve|0.70175439119338989\tv:-73.708335876464844,35.543861389160156\nGetTangentOnCurveArcLength|0.70175439119338989\tv:-117.81949615478516,41.832859039306641\nGetPositionOnCurve|0.71929824352264404\tu:0.34540310502052307,0,0.13257676362991333,0\nGetPositionOnCurveArcLength|0.71929824352264404\tu:0.24039153754711151,0,0.19695794582366943,0\nGetTangentOnCurve|0.71929824352264404\tv:-80.291664123535156,36.482456207275391\nGetTangentOnCurveArcLength|0.71929824352264404\tv:-122.78669738769531,42.541042327880859\nGetPositionOnCurve|0.75438594818115234\tu:0.31756523251533508,0,0.15146912634372711,0\nGetPositionOnCurveArcLength|0.75438594818115234\tu:0.21120023727416992,0,0.21254648268222809,0\nGetTangentOnCurve|0.75438594818115234\tv:-93.458328247070312,38.359649658203125\nGetTangentOnCurveArcLength|0.75438594818115234\tv:-132.19496154785156,43.882392883300781\nGetPositionOnCurve|0.77192980051040649\tu:0.30206418037414551,0,0.16127070784568787,0\nGetPositionOnCurveArcLength|0.77192980051040649\tu:0.19656014442443848,0,0.22013059258460999,0\nGetTangentOnCurve|0.77192980051040649\tv:-100.04165649414062,39.298244476318359\nGetTangentOnCurveArcLength|0.77192980051040649\tv:-136.66976928710938,44.520374298095703\nGetPositionOnCurve|0.80701756477355957\tu:0.26789766550064087,0,0.18158465623855591,0\nGetPositionOnCurveArcLength|0.80701756477355957\tu:0.16720588505268097,0,0.23493902385234833,0\nGetTangentOnCurve|0.80701756477355957\tv:-113.20834350585938,41.175437927246094\nGetTangentOnCurveArcLength|0.80701756477355957\tv:-145.22724914550781,45.740425109863281\nGetPositionOnCurve|0.82456141710281372\tu:0.24923227727413177,0,0.1920970231294632,0\nGetPositionOnCurveArcLength|0.82456141710281372\tu:0.1524965763092041,0,0.24218255281448364,0\nGetTangentOnCurve|0.82456141710281372\tv:-119.79167175292969,42.114036560058594\nGetTangentOnCurveArcLength|0.82456141710281372\tv:-149.33103942871094,46.325511932373047\nGetPositionOnCurve|0.85964912176132202\tu:0.20873722434043884,0,0.21383252739906311,0\nGetPositionOnCurveArcLength|0.85964912176132202\tu:0.12302283942699432,0,0.2563876211643219,0\nGetTangentOnCurve|0.85964912176132202\tv:-132.95832824707031,43.991226196289062\nGetTangentOnCurveArcLength|0.85964912176132202\tv:-157.23200988769531,47.45196533203125\nGetPositionOnCurve|0.87719297409057617\tu:0.186907559633255,0,0.22505567967891693,0\nGetPositionOnCurveArcLength|0.87719297409057617\tu:0.10826145857572556,0,0.26336219906806946,0\nGetTangentOnCurve|0.87719297409057617\tv:-139.54165649414062,44.929824829101562\nGetTangentOnCurveArcLength|0.87719297409057617\tv:-161.04344177246094,47.995368957519531\nGetPositionOnCurve|0.91228067874908447\tu:0.14008386433124542,0,0.24821273982524872,0\nGetPositionOnCurveArcLength|0.91228067874908447\tu:0.078695811331272125,0,0.27708277106285095,0\nGetTangentOnCurve|0.91228067874908447\tv:-152.70832824707031,46.807014465332031\nGetTangentOnCurveArcLength|0.91228067874908447\tv:-168.41819763183594,49.046798706054688\nGetPositionOnCurve|0.9298245906829834\tu:0.11508983373641968,0,0.26014673709869385,0\nGetPositionOnCurveArcLength|0.9298245906829834\tu:0.063893668353557587,0,0.28383797407150269,0\nGetTangentOnCurve|0.9298245906829834\tv:-159.29167175292969,47.745613098144531\nGetTangentOnCurveArcLength|0.9298245906829834\tv:-171.99163818359375,49.556266784667969\nGetPositionOnCurve|0.9649122953414917\tu:0.061937548220157623,0,0.28472542762756348,0\nGetPositionOnCurveArcLength|0.9649122953414917\tu:0.034255355596542358,0,0.29715827107429504,0\nGetTangentOnCurve|0.9649122953414917\tv:-172.45834350585938,49.622810363769531\nGetTangentOnCurveArcLength|0.9649122953414917\tv:-178.932373046875,50.545822143554688\nGetPositionOnCurve|0.98245614767074585\tu:0.033779267221689224,0,0.29737013578414917,0\nGetPositionOnCurveArcLength|0.98245614767074585\tu:0.01942046731710434,0,0.30373024940490723,0\nGetTangentOnCurve|0.98245614767074585\tv:-179.04167175292969,50.5614013671875\nGetTangentOnCurveArcLength|0.98245614767074585\tv:-182.30722045898438,51.0269775390625\nGetPositionOnCurve|0.017241379246115685\tu:0.48394140601158142,0,0.53137505054473877,0\nGetPositionOnCurveArcLength|0.017241379246115685\tu:0.48278185725212097,0,0.53006362915039062,0\nGetTangentOnCurve|0.017241379246115685\tv:-72.785224914550781,-51.806182861328125\nGetTangentOnCurveArcLength|0.017241379246115685\tv:-72.728813171386719,-52.643592834472656\nGetPositionOnCurve|0.051724139600992203\tu:0.4612727165222168,0,0.50179284811019897,0\nGetPositionOnCurveArcLength|0.051724139600992203\tu:0.45963552594184875,0,0.49933645129203796,0\nGetTangentOnCurve|0.051724139600992203\tv:-70.920478820800781,-66.945304870605469\nGetTangentOnCurveArcLength|0.051724139600992203\tv:-70.721336364746094,-67.939849853515625\nGetPositionOnCurve|0.086206898093223572\tu:0.43944001197814941,0,0.46543478965759277,0\nGetPositionOnCurveArcLength|0.086206898093223572\tu:0.43894171714782715,0,0.46451205015182495,0\nGetTangentOnCurve|0.086206898093223572\tv:-67.475479125976562,-79.120094299316406\nGetTangentOnCurveArcLength|0.086206898093223572\tv:-67.375648498535156,-79.370208740234375\nGetPositionOnCurve|0.12068965286016464\tu:0.41894102096557617,0,0.42377153038978577,0\nGetPositionOnCurveArcLength|0.12068965286016464\tu:0.42033812403678894,0,0.42686504125595093,0\nGetTangentOnCurve|0.12068965286016464\tv:-62.450210571289062,-88.330558776855469\nGetTangentOnCurveArcLength|0.12068965286016464\tv:-62.858024597167969,-87.775894165039062\nGetPositionOnCurve|0.15517240762710571\tu:0.40027335286140442,0,0.37827378511428833,0\nGetPositionOnCurveArcLength|0.15517240762710571\tu:0.40362763404846191,0,0.38707149028778076,0\nGetTangentOnCurve|0.15517240762710571\tv:-55.844680786132812,-94.576690673828125\nGetTangentOnCurveArcLength|0.15517240762710571\tv:-57.210079193115234,-93.626480102539062\nGetPositionOnCurve|0.18965516984462738\tu:0.38393467664718628,0,0.33041241765022278,0\nGetPositionOnCurveArcLength|0.18965516984462738\tu:0.38875192403793335,0,0.34550866484642029,0\nGetTangentOnCurve|0.18965516984462738\tv:-47.658889770507812,-97.858505249023438\nGetTangentOnCurveArcLength|0.18965516984462738\tv:-50.382225036621094,-97.152809143066406\nGetPositionOnCurve|0.22413793206214905\tu:0.37042263150215149,0,0.28165808320045471,0\nGetPositionOnCurveArcLength|0.22413793206214905\tu:0.37578645348548889,0,0.30238783359527588,0\nGetTangentOnCurve|0.22413793206214905\tv:-37.892833709716797,-98.175979614257812\nGetTangentOnCurveArcLength|0.22413793206214905\tv:-42.235366821289062,-98.403266906738281\nGetPositionOnCurve|0.25862067937850952\tu:0.3602348268032074,0,0.23348170518875122,0\nGetPositionOnCurveArcLength|0.25862067937850952\tu:0.36497056484222412,0,0.25782313942909241,0\nGetTangentOnCurve|0.25862067937850952\tv:-26.546527862548828,-95.529136657714844\nGetTangentOnCurveArcLength|0.25862067937850952\tv:-32.51531982421875,-97.245895385742188\nGetPositionOnCurve|0.29310345649719238\tu:0.35386893153190613,0,0.18735389411449432,0\nGetPositionOnCurveArcLength|0.29310345649719238\tu:0.35679754614830017,0,0.21188986301422119,0\nGetTangentOnCurve|0.29310345649719238\tv:-13.619945526123047,-89.917953491210938\nGetTangentOnCurveArcLength|0.29310345649719238\tv:-20.788303375244141,-93.312637329101562\nGetPositionOnCurve|0.32758620381355286\tu:0.35182255506515503,0,0.14474548399448395,0\nGetPositionOnCurveArcLength|0.32758620381355286\tu:0.35223826766014099,0,0.16475081443786621,0\nGetTangentOnCurve|0.32758620381355286\tv:0.88689422607421875,-81.342453002929688\nGetTangentOnCurveArcLength|0.32758620381355286\tv:-6.3028030395507812,-85.845977783203125\nGetPositionOnCurve|0.36206895112991333\tu:0.35459339618682861,0,0.10712723433971405,0\nGetPositionOnCurveArcLength|0.36206895112991333\tu:0.35329318046569824,0,0.11716689169406891,0\nGetTangentOnCurve|0.36206895112991333\tv:16.973991394042969,-69.8026123046875\nGetTangentOnCurveArcLength|0.36206895112991333\tv:12.267616271972656,-73.364242553710938\nGetPositionOnCurve|0.39655172824859619\tu:0.36267906427383423,0,0.075969941914081573,0\nGetPositionOnCurveArcLength|0.39655172824859619\tu:0.36395704746246338,0,0.072902046144008636,0\nGetTangentOnCurve|0.39655172824859619\tv:34.641357421875,-55.298454284667969\nGetTangentOnCurveArcLength|0.39655172824859619\tv:36.750137329101562,-53.461692810058594\nGetPositionOnCurve|0.43103447556495667\tu:0.37657716870307922,0,0.052744310349225998,0\nGetPositionOnCurveArcLength|0.43103447556495667\tu:0.38730764389038086,0,0.043607696890830994,0\nGetTangentOnCurve|0.43103447556495667\tv:53.88897705078125,-37.829963684082031\nGetTangentOnCurveArcLength|0.43103447556495667\tv:65.584442138671875,-26.529531478881836\nGetPositionOnCurve|0.46551725268363953\tu:0.39678537845611572,0,0.038921218365430832,0\nGetPositionOnCurveArcLength|0.46551725268363953\tu:0.41697812080383301,0,0.035610172897577286,0\nGetTangentOnCurve|0.46551725268363953\tv:74.71685791015625,-17.397130966186523\nGetTangentOnCurveArcLength|0.46551725268363953\tv:91.846405029296875,0.37227249145507812\nGetPositionOnCurve|0.53448277711868286\tu:0.42239376902580261,0,0.048708721995353699,0\nGetPositionOnCurveArcLength|0.53448277711868286\tu:0.38944962620735168,0,0.096647217869758606,0\nGetTangentOnCurve|0.53448277711868286\tv:-10.939661979675293,26.594829559326172\nGetTangentOnCurveArcLength|0.53448277711868286\tv:-53.169700622558594,32.615634918212891\nGetPositionOnCurve|0.56896549463272095\tu:0.41691133379936218,0,0.062361519783735275,0\nGetPositionOnCurveArcLength|0.56896549463272095\tu:0.36287751793861389,0,0.11952698230743408,0\nGetTangentOnCurve|0.56896549463272095\tv:-23.879301071166992,28.439653396606445\nGetTangentOnCurveArcLength|0.56896549463272095\tv:-70.786346435546875,35.127265930175781\nGetPositionOnCurve|0.60344827175140381\tu:0.40735405683517456,0,0.076929658651351929,0\nGetPositionOnCurveArcLength|0.60344827175140381\tu:0.33539685606956482,0,0.13959258794784546,0\nGetTangentOnCurve|0.60344827175140381\tv:-36.818962097167969,30.284482955932617\nGetTangentOnCurveArcLength|0.60344827175140381\tv:-85.2587890625,37.190628051757812\nGetPositionOnCurve|0.63793104887008667\tu:0.39372193813323975,0,0.09241311252117157,0\nGetPositionOnCurveArcLength|0.63793104887008667\tu:0.30743095278739929,0,0.15792535245418549,0\nGetTangentOnCurve|0.63793104887008667\tv:-49.758625030517578,32.129310607910156\nGetTangentOnCurveArcLength|0.63793104887008667\tv:-97.812545776367188,38.980434417724609\nGetPositionOnCurve|0.67241376638412476\tu:0.37601497769355774,0,0.10881186276674271,0\nGetPositionOnCurveArcLength|0.67241376638412476\tu:0.27915939688682556,0,0.17505764961242676,0\nGetTangentOnCurve|0.67241376638412476\tv:-62.698265075683594,33.974136352539062\nGetTangentOnCurveArcLength|0.67241376638412476\tv:-109.04421234130859,40.581752777099609\nGetPositionOnCurve|0.70689654350280762\tu:0.35423320531845093,0,0.12612596154212952,0\nGetPositionOnCurveArcLength|0.70689654350280762\tu:0.25067597627639771,0,0.19129638373851776,0\nGetTangentOnCurve|0.70689654350280762\tv:-75.637924194335938,35.818965911865234\nGetTangentOnCurveArcLength|0.70689654350280762\tv:-119.29543304443359,42.043289184570312\nGetPositionOnCurve|0.74137932062149048\tu:0.32837653160095215,0,0.14435538649559021,0\nGetPositionOnCurveArcLength|0.74137932062149048\tu:0.22203601896762848,0,0.20683704316616058,0\nGetTangentOnCurve|0.74137932062149048\tv:-88.577590942382812,37.663795471191406\nGetTangentOnCurveArcLength|0.74137932062149048\tv:-128.78286743164062,43.395923614501953\nGetPositionOnCurve|0.77586209774017334\tu:0.29844504594802856,0,0.16350013017654419,0\nGetPositionOnCurveArcLength|0.77586209774017334\tu:0.1932750791311264,0,0.22181321680545807,0\nGetTangentOnCurve|0.77586209774017334\tv:-101.51725006103516,39.508621215820312\nGetTangentOnCurveArcLength|0.77586209774017334\tv:-137.65388488769531,44.660682678222656\nGetPositionOnCurve|0.81034481525421143\tu:0.26443874835968018,0,0.18356016278266907,0\nGetPositionOnCurveArcLength|0.81034481525421143\tu:0.16441774368286133,0,0.23632055521011353,0\nGetTangentOnCurve|0.81034481525421143\tv:-114.45689392089844,41.353446960449219\nGetTangentOnCurveArcLength|0.81034481525421143\tv:-146.01397705078125,45.852592468261719\nGetPositionOnCurve|0.84482759237289429\tu:0.22635756433010101,0,0.20453552901744843,0\nGetPositionOnCurveArcLength|0.84482759237289429\tu:0.13548126816749573,0,0.25043070316314697,0\nGetTangentOnCurve|0.84482759237289429\tv:-127.39656066894531,43.198276519775391\nGetTangentOnCurveArcLength|0.84482759237289429\tv:-153.94178771972656,46.982872009277344\nGetPositionOnCurve|0.87931036949157715\tu:0.18420155346393585,0,0.22642625868320465,0\nGetPositionOnCurveArcLength|0.87931036949157715\tu:0.10647878795862198,0,0.26419860124588013,0\nGetTangentOnCurve|0.87931036949157715\tv:-140.33621215820312,45.043106079101562\nGetTangentOnCurveArcLength|0.87931036949157715\tv:-161.49765014648438,48.060123443603516\nGetPositionOnCurve|0.91379308700561523\tu:0.13797077536582947,0,0.24923223257064819,0\nGetPositionOnCurveArcLength|0.91379308700561523\tu:0.077420376241207123,0,0.27766770124435425,0\nGetTangentOnCurve|0.91379308700561523\tv:-153.27584838867188,46.887931823730469\nGetTangentOnCurveArcLength|0.91379308700561523\tv:-168.72908020019531,49.091121673583984\nGetPositionOnCurve|0.9482758641242981\tu:0.087665051221847534,0,0.2729535698890686,0\nGetPositionOnCurveArcLength|0.9482758641242981\tu:0.048313472419977188,0,0.29087299108505249,0\nGetTangentOnCurve|0.9482758641242981\tv:-166.21551513671875,48.732757568359375\nGetTangentOnCurveArcLength|0.9482758641242981\tv:-175.67442321777344,50.081329345703125\nGetPositionOnCurve|0.98275864124298096\tu:0.033284503966569901,0,0.29759025573730469,0\nGetPositionOnCurveArcLength|0.98275864124298096\tu:0.01916448213160038,0,0.30384314060211182,0\nGetTangentOnCurve|0.98275864124298096\tv:-179.15518188476562,50.577587127685547\nGetTangentOnCurveArcLength|0.98275864124298096\tv:-182.36489868164062,51.035202026367188\nGetPositionOnCurve|0.016949152573943138\tu:0.48413565754890442,0,0.53159254789352417,0\nGetPositionOnCurveArcLength|0.016949152573943138\tu:0.48298990726470947,0,0.53030049800872803,0\nGetTangentOnCurve|0.016949152573943138\tv:-72.794273376464844,-51.665218353271484\nGetTangentOnCurveArcLength|0.016949152573943138\tv:-72.739234924316406,-52.493858337402344\nGetPositionOnCurve|0.033898305147886276\tu:0.472918301820755,0,0.51802420616149902,0\nGetPositionOnCurveArcLength|0.033898305147886276\tu:0.47126466035842896,0,0.51585203409194946,0\nGetTangentOnCurve|0.033898305147886276\tv:-72.081764221191406,-59.489265441894531\nGetTangentOnCurveArcLength|0.033898305147886276\tv:-71.94354248046875,-60.588958740234375\nGetPositionOnCurve|0.050847455859184265\tu:0.46184077858924866,0,0.50263518095016479,0\nGetPositionOnCurveArcLength|0.050847455859184265\tu:0.46019166707992554,0,0.50017577409744263,0\nGetTangentOnCurve|0.050847455859184265\tv:-70.987464904785156,-66.597137451171875\nGetTangentOnCurveArcLength|0.050847455859184265\tv:-70.790000915527344,-67.603469848632812\nGetPositionOnCurve|0.067796610295772552\tu:0.45096215605735779,0,0.48559999465942383,0\nGetPositionOnCurveArcLength|0.067796610295772552\tu:0.44971117377281189,0,0.48351758718490601,0\nGetTangentOnCurve|0.067796610295772552\tv:-69.511383056640625,-72.98883056640625\nGetTangentOnCurveArcLength|0.067796610295772552\tv:-69.314704895019531,-73.686477661132812\nGetPositionOnCurve|0.08474576473236084\tu:0.44034159183502197,0,0.46709337830543518,0\nGetPositionOnCurveArcLength|0.08474576473236084\tu:0.43977424502372742,0,0.46605128049850464,0\nGetTangentOnCurve|0.08474576473236084\tv:-67.653511047363281,-78.664352416992188\nGetTangentOnCurveArcLength|0.08474576473236084\tv:-67.541862487792969,-78.951629638671875\nGetPositionOnCurve|0.10169491171836853\tu:0.43003809452056885,0,0.44729003310203552,0\nGetPositionOnCurveArcLength|0.10169491171836853\tu:0.43034255504608154,0,0.44790232181549072,0\nGetTangentOnCurve|0.10169491171836853\tv:-65.413856506347656,-83.623703002929688\nGetTangentOnCurveArcLength|0.10169491171836853\tv:-65.486717224121094,-83.485122680664062\nGetPositionOnCurve|0.11864406615495682\tu:0.42011088132858276,0,0.42636454105377197,0\nGetPositionOnCurveArcLength|0.11864406615495682\tu:0.42138767242431641,0,0.42916309833526611,0\nGetTangentOnCurve|0.11864406615495682\tv:-62.792407989501953,-87.86688232421875\nGetTangentOnCurveArcLength|0.11864406615495682\tv:-63.157501220703125,-87.351860046386719\nGetPositionOnCurve|0.1355932205915451\tu:0.41061896085739136,0,0.4044916033744812,0\nGetPositionOnCurveArcLength|0.1355932205915451\tu:0.41288992762565613,0,0.40990251302719116,0\nGetTangentOnCurve|0.1355932205915451\tv:-59.789176940917969,-91.393890380859375\nGetTangentOnCurveArcLength|0.1355932205915451\tv:-60.556610107421875,-90.599967956542969\nGetPositionOnCurve|0.1525423675775528\tu:0.40162143111228943,0,0.38184583187103271,0\nGetPositionOnCurveArcLength|0.1525423675775528\tu:0.40483757853507996,0,0.39017245173454285,0\nGetTangentOnCurve|0.1525423675775528\tv:-56.404159545898438,-94.2047119140625\nGetTangentOnCurveArcLength|0.1525423675775528\tv:-57.6812744140625,-93.26385498046875\nGetPositionOnCurve|0.16949152946472168\tu:0.39317739009857178,0,0.35860186815261841,0\nGetPositionOnCurveArcLength|0.16949152946472168\tu:0.397226482629776,0,0.37001216411590576,0\nGetTangentOnCurve|0.16949152946472168\tv:-52.637351989746094,-96.29937744140625\nGetTangentOnCurveArcLength|0.16949152946472168\tv:-54.523818969726562,-95.366340637207031\nGetPositionOnCurve|0.18644067645072937\tu:0.38534602522850037,0,0.33493441343307495,0\nGetPositionOnCurveArcLength|0.18644067645072937\tu:0.39006009697914124,0,0.34945142269134521,0\nGetTangentOnCurve|0.18644067645072937\tv:-48.488761901855469,-97.6778564453125\nGetTangentOnCurveArcLength|0.18644067645072937\tv:-51.071609497070312,-96.919761657714844\nGetPositionOnCurve|0.20338982343673706\tu:0.37818625569343567,0,0.31101816892623901,0\nGetPositionOnCurveArcLength|0.20338982343673706\tu:0.38334968686103821,0,0.32851219177246094,0\nGetTangentOnCurve|0.20338982343673706\tv:-43.958381652832031,-98.340164184570312\nGetTangentOnCurveArcLength|0.20338982343673706\tv:-47.306510925292969,-97.926651000976562\nGetPositionOnCurve|0.22033898532390594\tu:0.37175732851028442,0,0.28702771663665771,0\nGetPositionOnCurveArcLength|0.22033898532390594\tu:0.37711554765701294,0,0.307210773229599,0\nGetTangentOnCurve|0.22033898532390594\tv:-39.046215057373047,-98.286308288574219\nGetTangentOnCurveArcLength|0.22033898532390594\tv:-43.204193115234375,-98.379440307617188\nGetPositionOnCurve|0.23728813230991364\tu:0.36611831188201904,0,0.26313769817352295,0\nGetPositionOnCurveArcLength|0.23728813230991364\tu:0.37138840556144714,0,0.28555890917778015,0\nGetTangentOnCurve|0.23728813230991364\tv:-33.752262115478516,-97.516265869140625\nGetTangentOnCurveArcLength|0.23728813230991364\tv:-38.732753753662109,-98.259719848632812\nGetPositionOnCurve|0.25423729419708252\tu:0.36132824420928955,0,0.239522784948349,0\nGetPositionOnCurveArcLength|0.25423729419708252\tu:0.36621242761611938,0,0.26356568932533264,0\nGetTangentOnCurve|0.25423729419708252\tv:-28.076519012451172,-96.030052185058594\nGetTangentOnCurveArcLength|0.25423729419708252\tv:-33.850898742675781,-97.536453247070312\nGetPositionOnCurve|0.27118644118309021\tu:0.35744625329971313,0,0.21635772287845612,0\nGetPositionOnCurveArcLength|0.27118644118309021\tu:0.36164888739585876,0,0.24123877286911011,0\nGetTangentOnCurve|0.27118644118309021\tv:-22.018997192382812,-93.827682495117188\nGetTangentOnCurveArcLength|0.27118644118309021\tv:-28.505058288574219,-96.163177490234375\nGetPositionOnCurve|0.2881355881690979\tu:0.35453140735626221,0,0.19381700456142426,0\nGetPositionOnCurveArcLength|0.2881355881690979\tu:0.35778257250785828,0,0.21858811378479004,0\nGetTangentOnCurve|0.2881355881690979\tv:-15.579685211181641,-90.90911865234375\nGetTangentOnCurveArcLength|0.2881355881690979\tv:-22.625453948974609,-94.073532104492188\nGetPositionOnCurve|0.30508473515510559\tu:0.35264286398887634,0,0.17207542061805725,0\nGetPositionOnCurveArcLength|0.30508473515510559\tu:0.35473191738128662,0,0.19563131034374237,0\nGetTangentOnCurve|0.30508473515510559\tv:-8.7585906982421875,-87.274375915527344\nGetTangentOnCurveArcLength|0.30508473515510559\tv:-16.120189666748047,-91.174468994140625\nGetPositionOnCurve|0.32203391194343567\tu:0.35183969140052795,0,0.15130755305290222,0\nGetPositionOnCurveArcLength|0.32203391194343567\tu:0.35266405344009399,0,0.17240579426288605,0\nGetTangentOnCurve|0.32203391194343567\tv:-1.5556869506835938,-82.923469543457031\nGetTangentOnCurveArcLength|0.32203391194343567\tv:-8.8673477172851562,-87.336257934570312\nGetPositionOnCurve|0.33898305892944336\tu:0.35218095779418945,0,0.13168807327747345,0\nGetPositionOnCurveArcLength|0.33898305892944336\tu:0.35181960463523865,0,0.14899376034736633,0\nGetTangentOnCurve|0.33898305892944336\tv:6.0289840698242188,-77.856399536132812\nGetTangentOnCurveArcLength|0.33898305892944336\tv:-0.70442962646484375,-82.378204345703125\nGetPositionOnCurve|0.35593220591545105\tu:0.35372579097747803,0,0.1133916825056076,0\nGetPositionOnCurveArcLength|0.35593220591545105\tu:0.35254889726638794,0,0.12557804584503174,0\nGetTangentOnCurve|0.35593220591545105\tv:13.995437622070312,-72.073150634765625\nGetTangentOnCurveArcLength|0.35593220591545105\tv:8.5805130004882812,-76.05230712890625\nGetPositionOnCurve|0.37288135290145874\tu:0.35653331875801086,0,0.096592962741851807,0\nGetPositionOnCurveArcLength|0.37288135290145874\tu:0.35535377264022827,0,0.10256633907556534,0\nGetTangentOnCurve|0.37288135290145874\tv:22.34368896484375,-65.573738098144531\nGetTangentOnCurveArcLength|0.37288135290145874\tv:19.238945007324219,-68.039520263671875\nGetPositionOnCurve|0.38983049988746643\tu:0.36066251993179321,0,0.081466622650623322,0\nGetPositionOnCurveArcLength|0.38983049988746643\tu:0.36087816953659058,0,0.080834366381168365,0\nGetTangentOnCurve|0.38983049988746643\tv:31.073722839355469,-58.358119964599609\nGetTangentOnCurveArcLength|0.38983049988746643\tv:31.471527099609375,-58.020011901855469\nGetPositionOnCurve|0.40677964687347412\tu:0.36617261171340942,0,0.068187244236469269,0\nGetPositionOnCurveArcLength|0.40677964687347412\tu:0.36965718865394592,0,0.061983123421669006,0\nGetTangentOnCurve|0.40677964687347412\tv:40.185539245605469,-50.426353454589844\nGetTangentOnCurveArcLength|0.40677964687347412\tv:45.148139953613281,-45.951717376708984\nGetPositionOnCurve|0.4237288236618042\tu:0.37312260270118713,0,0.056929610669612885,0\nGetPositionOnCurveArcLength|0.4237288236618042\tu:0.38150781393051147,0,0.047923136502504349,0\nGetTangentOnCurve|0.4237288236618042\tv:49.679161071777344,-41.778400421142578\nGetTangentOnCurveArcLength|0.4237288236618042\tv:59.484786987304688,-32.481636047363281\nGetPositionOnCurve|0.44067797064781189\tu:0.38157165050506592,0,0.047868248075246811,0\nGetPositionOnCurveArcLength|0.44067797064781189\tu:0.39535504579544067,0,0.03947097435593605,0\nGetTangentOnCurve|0.44067797064781189\tv:59.554550170898438,-32.414299011230469\nGetTangentOnCurveArcLength|0.44067797064781189\tv:73.393936157226562,-18.735681533813477\nGetPositionOnCurve|0.45762711763381958\tu:0.39157882332801819,0,0.041177928447723389,0\nGetPositionOnCurveArcLength|0.45762711763381958\tu:0.41005131602287292,0,0.035927202552556992,0\nGetTangentOnCurve|0.45762711763381958\tv:69.811737060546875,-22.333969116210938\nGetTangentOnCurveArcLength|0.45762711763381958\tv:86.253448486328125,-5.5153160095214844\nGetPositionOnCurve|0.47457626461982727\tu:0.40320318937301636,0,0.037033189088106155,0\nGetPositionOnCurveArcLength|0.47457626461982727\tu:0.42384982109069824,0,0.037751313298940659,0\nGetTangentOnCurve|0.47457626461982727\tv:80.450698852539062,-11.53752326965332\nGetTangentOnCurveArcLength|0.47457626461982727\tv:0.1342846155166626,25.015998840332031\nGetPositionOnCurve|0.49152541160583496\tu:0.41650390625,0,0.035608746111392975,0\nGetPositionOnCurveArcLength|0.49152541160583496\tu:0.41850185394287109,0,0.059206221252679825,0\nGetTangentOnCurve|0.49152541160583496\tv:91.471435546875,-0.024906158447265625\nGetTangentOnCurveArcLength|0.49152541160583496\tv:-20.964519500732422,28.024089813232422\nGetPositionOnCurve|0.50847458839416504\tu:0.42383310198783875,0,0.039016794413328171,0\nGetPositionOnCurveArcLength|0.50847458839416504\tu:0.40811198949813843,0,0.075937874615192413,0\nGetTangentOnCurve|0.50847458839416504\tv:-1.1800892353057861,25.203390121459961\nGetTangentOnCurveArcLength|0.50847458839416504\tv:-35.963161468505859,30.162469863891602\nGetPositionOnCurve|0.52542370557785034\tu:0.423158198595047,0,0.045273769646883011,0\nGetPositionOnCurveArcLength|0.52542370557785034\tu:0.39615523815155029,0,0.089897044003009796,0\nGetTangentOnCurve|0.52542370557785034\tv:-7.5402450561523438,26.11016845703125\nGetTangentOnCurveArcLength|0.52542370557785034\tv:-47.706951141357422,31.836799621582031\nGetPositionOnCurve|0.54237288236618042\tu:0.42149883508682251,0,0.051751904189586639,0\nGetPositionOnCurveArcLength|0.54237288236618042\tu:0.38349241018295288,0,0.10222837328910828,0\nGetTangentOnCurve|0.54237288236618042\tv:-13.900424003601074,27.016948699951172\nGetTangentOnCurveArcLength|0.54237288236618042\tv:-57.589759826660156,33.245807647705078\nGetPositionOnCurve|0.5593220591545105\tu:0.4188549816608429,0,0.058451179414987564,0\nGetPositionOnCurveArcLength|0.5593220591545105\tu:0.37043020129203796,0,0.11348281800746918,0\nGetTangentOnCurve|0.5593220591545105\tv:-20.260602951049805,27.923730850219727\nGetTangentOnCurveArcLength|0.5593220591545105\tv:-66.257293701171875,34.481552124023438\nGetPositionOnCurve|0.5762711763381958\tu:0.41522669792175293,0,0.065371572971343994,0\nGetPositionOnCurveArcLength|0.5762711763381958\tu:0.35711053013801575,0,0.12396331131458282,0\nGetTangentOnCurve|0.5762711763381958\tv:-26.620758056640625,28.830507278442383\nGetTangentOnCurveArcLength|0.5762711763381958\tv:-74.058326721191406,35.593757629394531\nGetPositionOnCurve|0.59322035312652588\tu:0.41061389446258545,0,0.072513125836849213,0\nGetPositionOnCurveArcLength|0.59322035312652588\tu:0.34361043572425842,0,0.13385511934757233,0\nGetTangentOnCurve|0.59322035312652588\tv:-32.980937957763672,29.737289428710938\nGetTangentOnCurveArcLength|0.59322035312652588\tv:-81.203880310058594,36.612510681152344\nGetPositionOnCurve|0.61016947031021118\tu:0.40501669049263,0,0.079875797033309937,0\nGetPositionOnCurveArcLength|0.61016947031021118\tu:0.32997649908065796,0,0.1432805210351944,0\nGetTangentOnCurve|0.61016947031021118\tv:-39.341094970703125,30.644065856933594\nGetTangentOnCurveArcLength|0.61016947031021118\tv:-87.832252502441406,37.557529449462891\nGetPositionOnCurve|0.62711864709854126\tu:0.39843496680259705,0,0.087459616363048553,0\nGetPositionOnCurveArcLength|0.62711864709854126\tu:0.31623885035514832,0,0.1523251086473465,0\nGetTangentOnCurve|0.62711864709854126\tv:-45.701271057128906,31.550848007202148\nGetTangentOnCurveArcLength|0.62711864709854126\tv:-94.0396728515625,38.442531585693359\nGetPositionOnCurve|0.64406782388687134\tu:0.39086875319480896,0,0.09526459127664566,0\nGetPositionOnCurveArcLength|0.64406782388687134\tu:0.30241850018501282,0,0.16105128824710846,0\nGetTangentOnCurve|0.64406782388687134\tv:-52.061450958251953,32.457630157470703\nGetTangentOnCurveArcLength|0.64406782388687134\tv:-99.896018981933594,39.277481079101562\nGetPositionOnCurve|0.66101694107055664\tu:0.38231807947158813,0,0.10329067707061768,0\nGetPositionOnCurveArcLength|0.66101694107055664\tu:0.2885303795337677,0,0.16950623691082001,0\nGetTangentOnCurve|0.66101694107055664\tv:-58.421607971191406,33.364406585693359\nGetTangentOnCurveArcLength|0.66101694107055664\tv:-105.45394897460938,40.06988525390625\nGetPositionOnCurve|0.67796611785888672\tu:0.37278294563293457,0,0.11153792589902878,0\nGetPositionOnCurveArcLength|0.67796611785888672\tu:0.27458560466766357,0,0.1777266263961792,0\nGetTangentOnCurve|0.67796611785888672\tv:-64.781784057617188,34.271186828613281\nGetTangentOnCurveArcLength|0.67796611785888672\tv:-110.75429534912109,40.8255615234375\nGetPositionOnCurve|0.69491523504257202\tu:0.36226338148117065,0,0.12000628560781479,0\nGetPositionOnCurveArcLength|0.69491523504257202\tu:0.26059287786483765,0,0.18574151396751404,0\nGetTangentOnCurve|0.69491523504257202\tv:-71.141944885253906,35.177963256835938\nGetTangentOnCurveArcLength|0.69491523504257202\tv:-115.82933044433594,41.549118041992188\nGetPositionOnCurve|0.7118644118309021\tu:0.35075929760932922,0,0.12869581580162048,0\nGetPositionOnCurveArcLength|0.7118644118309021\tu:0.24655848741531372,0,0.19357466697692871,0\nGetTangentOnCurve|0.7118644118309021\tv:-77.502120971679688,36.084747314453125\nGetTangentOnCurveArcLength|0.7118644118309021\tv:-120.70532989501953,42.244297027587891\nGetPositionOnCurve|0.72881358861923218\tu:0.33827072381973267,0,0.13760647177696228,0\nGetPositionOnCurveArcLength|0.72881358861923218\tu:0.23248820006847382,0,0.20124532282352448,0\nGetTangentOnCurve|0.72881358861923218\tv:-83.862297058105469,36.991527557373047\nGetTangentOnCurveArcLength|0.72881358861923218\tv:-125.40361785888672,42.914138793945312\nGetPositionOnCurve|0.74576270580291748\tu:0.32479774951934814,0,0.14673826098442078,0\nGetPositionOnCurveArcLength|0.74576270580291748\tu:0.21838605403900146,0,0.20876984298229218,0\nGetTangentOnCurve|0.74576270580291748\tv:-90.222457885742188,37.898303985595703\nGetTangentOnCurveArcLength|0.74576270580291748\tv:-129.94221496582031,43.561214447021484\nGetPositionOnCurve|0.76271188259124756\tu:0.31034025549888611,0,0.15609119832515717,0\nGetPositionOnCurveArcLength|0.76271188259124756\tu:0.2042558342218399,0,0.21616177260875702,0\nGetTangentOnCurve|0.76271188259124756\tv:-96.582633972167969,38.805084228515625\nGetTangentOnCurveArcLength|0.76271188259124756\tv:-134.33613586425781,44.187660217285156\nGetPositionOnCurve|0.77966099977493286\tu:0.29489836096763611,0,0.16566523909568787,0\nGetPositionOnCurveArcLength|0.77966099977493286\tu:0.19010025262832642,0,0.22343297302722931,0\nGetTangentOnCurve|0.77966099977493286\tv:-102.94278717041016,39.711864471435547\nGetTangentOnCurveArcLength|0.77966099977493286\tv:-138.59834289550781,44.795333862304688\nGetPositionOnCurve|0.79661017656326294\tu:0.27847191691398621,0,0.17546047270298004,0\nGetPositionOnCurveArcLength|0.79661017656326294\tu:0.17592212557792664,0,0.23059333860874176,0\nGetTangentOnCurve|0.79661017656326294\tv:-109.30297088623047,40.618644714355469\nGetTangentOnCurveArcLength|0.79661017656326294\tv:-142.73980712890625,45.385787963867188\nGetPositionOnCurve|0.81355929374694824\tu:0.26106104254722595,0,0.18547679483890533,0\nGetPositionOnCurveArcLength|0.81355929374694824\tu:0.16172346472740173,0,0.23765169084072113,0\nGetTangentOnCurve|0.81355929374694824\tv:-115.66312408447266,41.525421142578125\nGetTangentOnCurveArcLength|0.81355929374694824\tv:-146.77021789550781,45.960411071777344\nGetPositionOnCurve|0.83050847053527832\tu:0.24266567826271057,0,0.1957143098115921,0\nGetPositionOnCurveArcLength|0.83050847053527832\tu:0.14750602841377258,0,0.24461573362350464,0\nGetTangentOnCurve|0.83050847053527832\tv:-122.02330017089844,42.432205200195312\nGetTangentOnCurveArcLength|0.83050847053527832\tv:-150.69798278808594,46.520397186279297\nGetPositionOnCurve|0.8474576473236084\tu:0.22328580915927887,0,0.20617292821407318,0\nGetPositionOnCurveArcLength|0.8474576473236084\tu:0.13327144086360931,0,0.25149217247962952,0\nGetTangentOnCurve|0.8474576473236084\tv:-128.38348388671875,43.338981628417969\nGetTangentOnCurveArcLength|0.8474576473236084\tv:-154.53050231933594,47.066806793212891\nGetPositionOnCurve|0.8644067645072937\tu:0.2029215544462204,0,0.21685266494750977,0\nGetPositionOnCurveArcLength|0.8644067645072937\tu:0.11902130395174026,0,0.25828701257705688,0\nGetTangentOnCurve|0.8644067645072937\tv:-134.74363708496094,44.245761871337891\nGetTangentOnCurveArcLength|0.8644067645072937\tv:-158.2742919921875,47.600563049316406\nGetPositionOnCurve|0.88135594129562378\tu:0.18157275021076202,0,0.22775359451770782,0\nGetPositionOnCurveArcLength|0.88135594129562378\tu:0.10475649684667587,0,0.26500555872917175,0\nGetTangentOnCurve|0.88135594129562378\tv:-141.10382080078125,45.152542114257812\nGetTangentOnCurveArcLength|0.88135594129562378\tv:-161.93525695800781,48.122512817382812\nGetPositionOnCurve|0.89830505847930908\tu:0.15923956036567688,0,0.2388756275177002,0\nGetPositionOnCurveArcLength|0.89830505847930908\tu:0.090478487312793732,0,0.27165254950523376,0\nGetTangentOnCurve|0.89830505847930908\tv:-147.46397399902344,46.059318542480469\nGetTangentOnCurveArcLength|0.89830505847930908\tv:-165.5185546875,48.633392333984375\nGetPositionOnCurve|0.91525423526763916\tu:0.13592180609703064,0,0.25021880865097046,0\nGetPositionOnCurveArcLength|0.91525423526763916\tu:0.076187759637832642,0,0.27823245525360107,0\nGetTangentOnCurve|0.91525423526763916\tv:-153.82415771484375,46.966102600097656\nGetTangentOnCurveArcLength|0.91525423526763916\tv:-169.02899169921875,49.133880615234375\nGetPositionOnCurve|0.93220341205596924\tu:0.11161960661411285,0,0.26178312301635742,0\nGetPositionOnCurveArcLength|0.93220341205596924\tu:0.06188567727804184,0,0.28474894165992737,0\nGetTangentOnCurve|0.93220341205596924\tv:-160.184326171875,47.872882843017578\nGetTangentOnCurveArcLength|0.93220341205596924\tv:-172.470703125,49.624568939208984\nGetPositionOnCurve|0.94915252923965454\tu:0.086333006620407104,0,0.27356860041618347,0\nGetPositionOnCurveArcLength|0.94915252923965454\tu:0.04757293313741684,0,0.29120552539825439,0\nGetTangentOnCurve|0.94915252923965454\tv:-166.54447937011719,48.7796630859375\nGetTangentOnCurveArcLength|0.94915252923965454\tv:-175.84754943847656,50.106010437011719\nGetPositionOnCurve|0.96610170602798462\tu:0.060061834752559662,0,0.28557518124580383,0\nGetPositionOnCurveArcLength|0.96610170602798462\tu:0.033249840140342712,0,0.29760566353797913,0\nGetTangentOnCurve|0.96610170602798462\tv:-172.9046630859375,49.686439514160156\nGetTangentOnCurveArcLength|0.96610170602798462\tv:-179.16313171386719,50.578720092773438\nGetPositionOnCurve|0.98305082321166992\tu:0.032806325703859329,0,0.29780289530754089,0\nGetPositionOnCurveArcLength|0.98305082321166992\tu:0.01891748420894146,0,0.30395203828811646,0\nGetTangentOnCurve|0.98305082321166992\tv:-179.26481628417969,50.593219757080078\nGetTangentOnCurveArcLength|0.98305082321166992\tv:-182.42054748535156,51.043136596679688\nGetPositionOnCurve|0.01666666753590107\tu:0.48432347178459167,0,0.53180229663848877,0\nGetPositionOnCurveArcLength|0.01666666753590107\tu:0.48319122195243835,0,0.53052908182144165,0\nGetTangentOnCurve|0.01666666753590107\tv:-72.80291748046875,-51.528751373291016\nGetTangentOnCurveArcLength|0.01666666753590107\tv:-72.749198913574219,-52.348747253417969\nGetPositionOnCurve|0.11666666716337204\tu:0.42124775052070618,0,0.42885801196098328,0\nGetPositionOnCurveArcLength|0.11666666716337204\tu:0.4224085807800293,0,0.4313773512840271,0\nGetTangentOnCurve|0.11666666716337204\tv:-63.117916107177734,-87.40875244140625\nGetTangentOnCurveArcLength|0.11666666716337204\tv:-63.443241119384766,-86.93341064453125\nGetPositionOnCurve|0.18333333730697632\tu:0.38673320412635803,0,0.33929726481437683,0\nGetPositionOnCurveArcLength|0.18333333730697632\tu:0.39134025573730469,0,0.35324981808662415,0\nGetTangentOnCurve|0.18333333730697632\tv:-49.277915954589844,-97.478744506835938\nGetTangentOnCurveArcLength|0.18333333730697632\tv:-51.727325439453125,-96.675827026367188\nGetPositionOnCurve|0.21666666865348816\tu:0.37308526039123535,0,0.29222312569618225,0\nGetPositionOnCurveArcLength|0.21666666865348816\tu:0.37842443585395813,0,0.31185612082481384,0\nGetTangentOnCurve|0.21666666865348816\tv:-40.142917633056641,-98.358749389648438\nGetTangentOnCurveArcLength|0.21666666865348816\tv:-44.123119354248047,-98.3291015625\nGetPositionOnCurve|0.28333333134651184\tu:0.35525569319725037,0,0.20013003051280975,0\nGetPositionOnCurveArcLength|0.28333333134651184\tu:0.35880112648010254,0,0.22503776848316193,0\nGetTangentOnCurve|0.28333333134651184\tv:-17.442913055419922,-91.808746337890625\nGetTangentOnCurveArcLength|0.28333333134651184\tv:-24.350360870361328,-94.743148803710938\nGetPositionOnCurve|0.31666666269302368\tu:0.3519730269908905,0,0.15776811540126801,0\nGetPositionOnCurveArcLength|0.31666666269302368\tu:0.35319972038269043,0,0.17978593707084656,0\nGetTangentOnCurve|0.31666666269302368\tv:-3.8779144287109375,-84.378746032714844\nGetTangentOnCurveArcLength|0.31666666269302368\tv:-11.253898620605469,-88.663070678710938\nGetPositionOnCurve|0.38333332538604736\tu:0.35891968011856079,0,0.087056279182434082,0\nGetPositionOnCurveArcLength|0.38333332538604736\tu:0.35839664936065674,0,0.088928662240505219,0\nGetTangentOnCurve|0.38333332538604736\tv:27.682075500488281,-61.208755493164062\nGetTangentOnCurveArcLength|0.38333332538604736\tv:26.59246826171875,-62.112060546875\nGetPositionOnCurve|0.48333331942558289\tu:0.40986219048500061,0,0.035946521908044815,0\nGetPositionOnCurveArcLength|0.48333331942558289\tu:0.42218253016471863,0,0.049492001533508301,0\nGetTangentOnCurve|0.48333331942558289\tv:86.097076416015625,-5.6787643432617188\nGetTangentOnCurveArcLength|0.48333331942558289\tv:-11.706201553344727,26.70411491394043\nGetPositionOnCurve|0.51666665077209473\tu:0.42362982034683228,0,0.042013384401798248,0\nGetPositionOnCurveArcLength|0.51666665077209473\tu:0.40245330333709717,0,0.082939699292182922,0\nGetTangentOnCurve|0.51666665077209473\tv:-4.2541608810424805,25.641666412353516\nGetTangentOnCurveArcLength|0.51666665077209473\tv:-41.933025360107422,31.013603210449219\nGetPositionOnCurve|0.61666667461395264\tu:0.40261003375053406,0,0.082756794989109039,0\nGetPositionOnCurveArcLength|0.61666667461395264\tu:0.32472130656242371,0,0.1467888355255127,0\nGetTangentOnCurve|0.61666667461395264\tv:-41.779170989990234,30.991666793823242\nGetTangentOnCurveArcLength|0.61666667461395264\tv:-90.257270812988281,37.903266906738281\nGetPositionOnCurve|0.68333333730697632\tu:0.36955830454826355,0,0.11419564485549927,0\nGetPositionOnCurveArcLength|0.68333333730697632\tu:0.27015948295593262,0,0.18028564751148224,0\nGetTangentOnCurve|0.68333333730697632\tv:-66.79583740234375,34.558334350585938\nGetTangentOnCurveArcLength|0.68333333730697632\tv:-112.3843994140625,41.057968139648438\nGetPositionOnCurve|0.71666663885116577\tu:0.34732088446617126,0,0.13119803369045258,0\nGetPositionOnCurveArcLength|0.71666663885116577\tu:0.24257536232471466,0,0.19576376676559448,0\nGetTangentOnCurve|0.71666663885116577\tv:-79.304153442382812,36.341667175292969\nGetTangentOnCurveArcLength|0.71666663885116577\tv:-122.0537109375,42.436538696289062\nGetPositionOnCurve|0.78333336114883423\tu:0.29142278432846069,0,0.16776879131793976,0\nGetPositionOnCurveArcLength|0.78333336114883423\tu:0.18703010678291321,0,0.224993497133255,0\nGetTangentOnCurve|0.78333336114883423\tv:-104.32084655761719,39.908332824707031\nGetTangentOnCurveArcLength|0.78333336114883423\tv:-139.50556945800781,44.924674987792969\nGetPositionOnCurve|0.81666666269302368\tu:0.25776225328445435,0,0.18733711540699005,0\nGetPositionOnCurveArcLength|0.81666666269302368\tu:0.15911810100078583,0,0.23893539607524872,0\nGetTangentOnCurve|0.81666666269302368\tv:-116.82916259765625,41.691665649414062\nGetTangentOnCurveArcLength|0.81666666269302368\tv:-147.49781799316406,46.06414794921875\nGetPositionOnCurve|0.88333332538604736\tu:0.17901796102523804,0,0.2290397584438324,0\nGetPositionOnCurveArcLength|0.88333332538604736\tu:0.10309133678674698,0,0.26578468084335327,0\nGetTangentOnCurve|0.88333332538604736\tv:-141.8458251953125,45.258331298828125\nGetTangentOnCurveArcLength|0.88333332538604736\tv:-162.35722351074219,48.18267822265625\nGetPositionOnCurve|0.98333334922790527\tu:0.032343652099370956,0,0.29800862073898315,0\nGetPositionOnCurveArcLength|0.98333334922790527\tu:0.018678570166230202,0,0.30405735969543457,0\nGetTangentOnCurve|0.98333334922790527\tv:-179.37083435058594,50.608333587646484\nGetTangentOnCurveArcLength|0.98333334922790527\tv:-182.47434997558594,51.050807952880859\nGetPositionOnCurve|0.016393441706895828\tu:0.48450514674186707,0,0.53200459480285645,0\nGetPositionOnCurveArcLength|0.016393441706895828\tu:0.48338612914085388,0,0.53074973821640015,0\nGetTangentOnCurve|0.016393441706895828\tv:-72.811172485351562,-51.396568298339844\nGetTangentOnCurveArcLength|0.016393441706895828\tv:-72.758720397949219,-52.208065032958984\nGetPositionOnCurve|0.032786883413791656\tu:0.47365021705627441,0,0.51897162199020386,0\nGetPositionOnCurveArcLength|0.032786883413791656\tu:0.47201287746429443,0,0.51684027910232544,0\nGetTangentOnCurve|0.032786883413791656\tv:-72.140182495117188,-58.998153686523438\nGetTangentOnCurveArcLength|0.032786883413791656\tv:-72.007156372070312,-60.093093872070312\nGetPositionOnCurve|0.049180328845977783\tu:0.46292251348495483,0,0.50422465801239014,0\nGetPositionOnCurveArcLength|0.049180328845977783\tu:0.46125364303588867,0,0.50176459550857544,0\nGetTangentOnCurve|0.049180328845977783\tv:-71.112030029296875,-65.929756164550781\nGetTangentOnCurveArcLength|0.049180328845977783\tv:-70.918220520019531,-66.956947326660156\nGetPositionOnCurve|0.065573766827583313\tu:0.45237544178962708,0,0.48792168498039246,0\nGetPositionOnCurveArcLength|0.065573766827583313\tu:0.45105376839637756,0,0.48575147986412048,0\nGetTangentOnCurve|0.065573766827583313\tv:-69.726722717285156,-72.191375732421875\nGetTangentOnCurveArcLength|0.065573766827583313\tv:-69.525558471679688,-72.93743896484375\nGetPositionOnCurve|0.08196721225976944\tu:0.44206249713897705,0,0.47022077441215515,0\nGetPositionOnCurveArcLength|0.08196721225976944\tu:0.44136771559715271,0,0.46896421909332275,0\nGetTangentOnCurve|0.08196721225976944\tv:-67.984245300292969,-77.78302001953125\nGetTangentOnCurveArcLength|0.08196721225976944\tv:-67.852149963378906,-78.140640258789062\nGetPositionOnCurve|0.098360657691955566\tu:0.43203717470169067,0,0.4512799084186554,0\nGetPositionOnCurveArcLength|0.098360657691955566\tu:0.43215954303741455,0,0.45152178406715393,0\nGetTangentOnCurve|0.098360657691955566\tv:-65.884605407714844,-82.704681396484375\nGetTangentOnCurveArcLength|0.098360657691955566\tv:-65.912834167480469,-82.647750854492188\nGetPositionOnCurve|0.1147540956735611\tu:0.42235291004180908,0,0.4312572181224823,0\nGetPositionOnCurveArcLength|0.1147540956735611\tu:0.42340189218521118,0,0.43351218104362488,0\nGetTangentOnCurve|0.1147540956735611\tv:-63.427810668945312,-86.95635986328125\nGetTangentOnCurveArcLength|0.1147540956735611\tv:-63.716098785400391,-86.520614624023438\nGetPositionOnCurve|0.13114753365516663\tu:0.41306322813034058,0,0.41031065583229065,0\nGetPositionOnCurveArcLength|0.13114753365516663\tu:0.41507542133331299,0,0.41500174999237061,0\nGetTangentOnCurve|0.13114753365516663\tv:-60.613849639892578,-90.538055419921875\nGetTangentOnCurveArcLength|0.13114753365516663\tv:-61.265167236328125,-89.805702209472656\nGetPositionOnCurve|0.14754098653793335\tu:0.40422153472900391,0,0.38859820365905762,0\nGetPositionOnCurveArcLength|0.14754098653793335\tu:0.40716776251792908,0,0.39604070782661438,0\nGetTangentOnCurve|0.14754098653793335\tv:-57.442722320556641,-93.449775695800781\nGetTangentOnCurveArcLength|0.14754098653793335\tv:-58.558635711669922,-92.537002563476562\nGetPositionOnCurve|0.16393442451953888\tu:0.39588132500648499,0,0.3662780225276947,0\nGetPositionOnCurveArcLength|0.16393442451953888\tu:0.39967328310012817,0,0.37666752934455872,0\nGetTangentOnCurve|0.16393442451953888\tv:-53.914436340332031,-95.691513061523438\nGetTangentOnCurveArcLength|0.16393442451953888\tv:-55.590812683105469,-94.737899780273438\nGetPositionOnCurve|0.18032786250114441\tu:0.38809609413146973,0,0.34350806474685669,0\nGetPositionOnCurveArcLength|0.18032786250114441\tu:0.3925929069519043,0,0.35691142082214355,0\nGetTangentOnCurve|0.18032786250114441\tv:-50.028995513916016,-97.263267517089844\nGetTangentOnCurveArcLength|0.18032786250114441\tv:-52.351669311523438,-96.422439575195312\nGetPositionOnCurve|0.19672131538391113\tu:0.38091930747032166,0,0.32044637203216553,0\nGetPositionOnCurveArcLength|0.19672131538391113\tu:0.38593438267707825,0,0.33679458498954773,0\nGetTangentOnCurve|0.19672131538391113\tv:-45.786380767822266,-98.1650390625\nGetTangentOnCurveArcLength|0.19672131538391113\tv:-48.826606750488281,-97.595962524414062\nGetPositionOnCurve|0.21311475336551666\tu:0.37440437078475952,0,0.29725101590156555,0\nGetPositionOnCurveArcLength|0.21311475336551666\tu:0.37971276044845581,0,0.31633347272872925,0\nGetTangentOnCurve|0.21311475336551666\tv:-41.186607360839844,-98.396835327148438\nGetTangentOnCurveArcLength|0.21311475336551666\tv:-44.995807647705078,-98.255111694335938\nGetPositionOnCurve|0.22950819134712219\tu:0.3686048686504364,0,0.27407997846603394,0\nGetPositionOnCurveArcLength|0.22950819134712219\tu:0.37395185232162476,0,0.29554039239883423,0\nGetTangentOnCurve|0.22950819134712219\tv:-36.229679107666016,-97.958648681640625\nGetTangentOnCurveArcLength|0.22950819134712219\tv:-40.833442687988281,-98.387405395507812\nGetPositionOnCurve|0.24590164422988892\tu:0.36357420682907104,0,0.25109133124351501,0\nGetPositionOnCurveArcLength|0.24590164422988892\tu:0.36868575215339661,0,0.27442419528961182,0\nGetTangentOnCurve|0.24590164422988892\tv:-30.915580749511719,-96.850479125976562\nGetTangentOnCurveArcLength|0.24590164422988892\tv:-36.306133270263672,-97.9700927734375\nGetPositionOnCurve|0.26229506731033325\tu:0.35936585068702698,0,0.22844311594963074,0\nGetPositionOnCurveArcLength|0.26229506731033325\tu:0.36396196484565735,0,0.25299233198165894,0\nGetTangentOnCurve|0.26229506731033325\tv:-25.244327545166016,-95.07232666015625\nGetTangentOnCurveArcLength|0.26229506731033325\tv:-31.371139526367188,-96.968177795410156\nGetPositionOnCurve|0.27868852019309998\tu:0.35603326559066772,0,0.20629328489303589,0\nGetPositionOnCurveArcLength|0.27868852019309998\tu:0.35984542965888977,0,0.23125222325325012,0\nGetTangentOnCurve|0.27868852019309998\tv:-19.215904235839844,-92.624198913574219\nGetTangentOnCurveArcLength|0.27868852019309998\tv:-25.973304748535156,-95.331428527832031\nGetPositionOnCurve|0.2950819730758667\tu:0.3536299467086792,0,0.18479996919631958,0\nGetPositionOnCurveArcLength|0.2950819730758667\tu:0.35642549395561218,0,0.20921498537063599,0\nGetTangentOnCurve|0.2950819730758667\tv:-12.830318450927734,-89.506080627441406\nGetTangentOnCurveArcLength|0.2950819730758667\tv:-20.0411376953125,-92.989669799804688\nGetPositionOnCurve|0.31147539615631104\tu:0.35220938920974731,0,0.16412115097045898,0\nGetPositionOnCurveArcLength|0.31147539615631104\tu:0.35382574796676636,0,0.18690265715122223,0\nGetTangentOnCurve|0.31147539615631104\tv:-6.08758544921875,-85.717987060546875\nGetTangentOnCurveArcLength|0.31147539615631104\tv:-13.4810791015625,-89.846038818359375\nGetPositionOnCurve|0.32786884903907776\tu:0.35182502865791321,0,0.14441485702991486,0\nGetPositionOnCurveArcLength|0.32786884903907776\tu:0.35222026705741882,0,0.16436056792736053,0\nGetTangentOnCurve|0.32786884903907776\tv:1.0123291015625,-81.259902954101562\nGetTangentOnCurveArcLength|0.32786884903907776\tv:-6.16949462890625,-85.766754150390625\nGetPositionOnCurve|0.34426230192184448\tu:0.35253033041954041,0,0.12583912909030914,0\nGetPositionOnCurveArcLength|0.34426230192184448\tu:0.35185784101486206,0,0.14168770611286163,0\nGetTangentOnCurve|0.34426230192184448\tv:8.469390869140625,-76.131866455078125\nGetTangentOnCurveArcLength|0.34426230192184448\tv:2.05596923828125,-80.568214416503906\nGetPositionOnCurve|0.36065572500228882\tu:0.35437878966331482,0,0.10855203866958618,0\nGetPositionOnCurveArcLength|0.36065572500228882\tu:0.35309633612632751,0,0.11909814178943634,0\nGetTangentOnCurve|0.36065572500228882\tv:16.283615112304688,-70.333824157714844\nGetTangentOnCurveArcLength|0.36065572500228882\tv:11.401878356933594,-74.003738403320312\nGetPositionOnCurve|0.37704917788505554\tu:0.35742387175559998,0,0.092711634933948517,0\nGetPositionOnCurveArcLength|0.37704917788505554\tu:0.35643398761749268,0,0.09705536812543869,0\nGetTangentOnCurve|0.37704917788505554\tv:24.455024719238281,-63.865798950195312\nGetTangentOnCurveArcLength|0.37704917788505554\tv:22.097312927246094,-65.771408081054688\nGetPositionOnCurve|0.39344263076782227\tu:0.3617190420627594,0,0.078475788235664368,0\nGetPositionOnCurveArcLength|0.39344263076782227\tu:0.36246693134307861,0,0.076507680118083954,0\nGetTangentOnCurve|0.39344263076782227\tv:32.983573913574219,-56.727790832519531\nGetTangentOnCurveArcLength|0.39344263076782227\tv:34.280891418457031,-55.610336303710938\nGetPositionOnCurve|0.4098360538482666\tu:0.36731773614883423,0,0.066002719104290009,0\nGetPositionOnCurveArcLength|0.4098360538482666\tu:0.3715895414352417,0,0.059047013521194458,0\nGetTangentOnCurve|0.4098360538482666\tv:41.869285583496094,-48.919826507568359\nGetTangentOnCurveArcLength|0.4098360538482666\tv:47.717391967773438,-43.595252990722656\nGetPositionOnCurve|0.42622950673103333\tu:0.37427350878715515,0,0.055450383573770523,0\nGetPositionOnCurveArcLength|0.42622950673103333\tu:0.38345679640769958,0,0.046326946467161179,0\nGetTangentOnCurve|0.42622950673103333\tv:51.112174987792969,-40.441841125488281\nGetTangentOnCurveArcLength|0.42622950673103333\tv:61.586334228515625,-30.444911956787109\nGetPositionOnCurve|0.44262295961380005\tu:0.38263976573944092,0,0.046976760029792786,0\nGetPositionOnCurveArcLength|0.44262295961380005\tu:0.39701563119888306,0,0.038837295025587082,0\nGetTangentOnCurve|0.44262295961380005\tv:60.71221923828125,-31.293886184692383\nGetTangentOnCurveArcLength|0.44262295961380005\tv:74.92816162109375,-17.182888031005859\nGetPositionOnCurve|0.45901638269424438\tu:0.39247000217437744,0,0.040740035474300385,0\nGetPositionOnCurveArcLength|0.45901638269424438\tu:0.41126969456672668,0,0.03581671416759491,0\nGetTangentOnCurve|0.45901638269424438\tv:70.669403076171875,-21.475978851318359\nGetTangentOnCurveArcLength|0.45901638269424438\tv:87.256011962890625,-4.4658203125\nGetPositionOnCurve|0.47540983557701111\tu:0.40381765365600586,0,0.036898113787174225,0\nGetPositionOnCurveArcLength|0.47540983557701111\tu:0.42383629083633423,0,0.038904692977666855,0\nGetTangentOnCurve|0.47540983557701111\tv:80.9837646484375,-10.988090515136719\nGetTangentOnCurveArcLength|0.47540983557701111\tv:-1.0640528202056885,25.186847686767578\nGetPositionOnCurve|0.49180328845977783\tu:0.41673627495765686,0,0.035609018057584763,0\nGetPositionOnCurveArcLength|0.49180328845977783\tu:0.41835510730743408,0,0.059513505548238754,0\nGetTangentOnCurve|0.49180328845977783\tv:91.655303955078125,0.16980743408203125\nGetTangentOnCurveArcLength|0.49180328845977783\tv:-21.250280380249023,28.064830780029297\nGetPositionOnCurve|0.50819671154022217\tu:0.42383596301078796,0,0.038916055113077164,0\nGetPositionOnCurveArcLength|0.50819671154022217\tu:0.40829882025718689,0,0.075690388679504395,0\nGetTangentOnCurve|0.50819671154022217\tv:-1.0758159160614014,25.18852424621582\nGetTangentOnCurveArcLength|0.50819671154022217\tv:-35.749053955078125,30.131942749023438\nGetPositionOnCurve|0.5245901346206665\tu:0.42321443557739258,0,0.044960875064134598,0\nGetPositionOnCurveArcLength|0.5245901346206665\tu:0.39676350355148315,0,0.089254692196846008,0\nGetTangentOnCurve|0.5245901346206665\tv:-7.2274484634399414,26.065572738647461\nGetTangentOnCurveArcLength|0.5245901346206665\tv:-47.180133819580078,31.761692047119141\nGetPositionOnCurve|0.54098361730575562\tu:0.42167189717292786,0,0.051212593913078308,0\nGetPositionOnCurveArcLength|0.54098361730575562\tu:0.38454800844192505,0,0.10126347839832306,0\nGetTangentOnCurve|0.54098361730575562\tv:-13.37910270690918,26.942623138427734\nGetTangentOnCurveArcLength|0.54098361730575562\tv:-56.831611633300781,33.137718200683594\nGetPositionOnCurve|0.55737704038619995\tu:0.41920840740203857,0,0.057671170681715012,0\nGetPositionOnCurveArcLength|0.55737704038619995\tu:0.37194415926933289,0,0.11223498731851578,0\nGetTangentOnCurve|0.55737704038619995\tv:-19.530735015869141,27.819671630859375\nGetTangentOnCurveArcLength|0.55737704038619995\tv:-65.311660766601562,34.346733093261719\nGetPositionOnCurve|0.57377046346664429\tu:0.41582390666007996,0,0.064336612820625305,0\nGetPositionOnCurveArcLength|0.57377046346664429\tu:0.35908854007720947,0,0.1224576011300087,0\nGetTangentOnCurve|0.57377046346664429\tv:-25.682367324829102,28.696720123291016\nGetTangentOnCurveArcLength|0.57377046346664429\tv:-72.952621459960938,35.436119079589844\nGetPositionOnCurve|0.5901639461517334\tu:0.41151845455169678,0,0.071208961308002472,0\nGetPositionOnCurveArcLength|0.5901639461517334\tu:0.34605589509010315,0,0.13210877776145935,0\nGetTangentOnCurve|0.5901639461517334\tv:-31.834022521972656,29.573770523071289\nGetTangentOnCurveArcLength|0.5901639461517334\tv:-79.956901550292969,36.434726715087891\nGetPositionOnCurve|0.60655736923217773\tu:0.40629208087921143,0,0.078288160264492035,0\nGetPositionOnCurveArcLength|0.60655736923217773\tu:0.33289158344268799,0,0.14130626618862152,0\nGetTangentOnCurve|0.60655736923217773\tv:-37.985652923583984,30.45081901550293\nGetTangentOnCurveArcLength|0.60655736923217773\tv:-86.457748413085938,37.361564636230469\nGetPositionOnCurve|0.62295079231262207\tu:0.40014469623565674,0,0.085574224591255188,0\nGetPositionOnCurveArcLength|0.62295079231262207\tu:0.31962531805038452,0,0.15013265609741211,0\nGetTangentOnCurve|0.62295079231262207\tv:-44.137283325195312,31.32786750793457\nGetTangentOnCurveArcLength|0.62295079231262207\tv:-92.548149108886719,38.229881286621094\nGetPositionOnCurve|0.63934427499771118\tu:0.39307630062103271,0,0.093067213892936707,0\nGetPositionOnCurveArcLength|0.63934427499771118\tu:0.30627748370170593,0,0.15864843130111694,0\nGetTangentOnCurve|0.63934427499771118\tv:-50.2889404296875,32.204917907714844\nGetTangentOnCurveArcLength|0.63934427499771118\tv:-98.2958984375,39.049346923828125\nGetPositionOnCurve|0.65573769807815552\tu:0.38508701324462891,0,0.10076703131198883,0\nGetPositionOnCurveArcLength|0.65573769807815552\tu:0.29286274313926697,0,0.1668994277715683,0\nGetTangentOnCurve|0.65573769807815552\tv:-56.440570831298828,33.081966400146484\nGetTangentOnCurveArcLength|0.65573769807815552\tv:-103.75212860107422,39.827251434326172\nGetPositionOnCurve|0.67213112115859985\tu:0.37617671489715576,0,0.10867373645305634,0\nGetPositionOnCurveArcLength|0.67213112115859985\tu:0.27939209342002869,0,0.17492116987705231,0\nGetTangentOnCurve|0.67213112115859985\tv:-62.592201232910156,33.959014892578125\nGetTangentOnCurveArcLength|0.67213112115859985\tv:-108.95649719238281,40.569248199462891\nGetPositionOnCurve|0.68852460384368896\tu:0.36634540557861328,0,0.11678734421730042,0\nGetPositionOnCurveArcLength|0.68852460384368896\tu:0.26587393879890442,0,0.18274205923080444,0\nGetTangentOnCurve|0.68852460384368896\tv:-68.743858337402344,34.836067199707031\nGetTangentOnCurveArcLength|0.68852460384368896\tv:-113.94049072265625,41.279823303222656\nGetPositionOnCurve|0.7049180269241333\tu:0.35559314489364624,0,0.1251077800989151,0\nGetPositionOnCurveArcLength|0.7049180269241333\tu:0.25231492519378662,0,0.19038504362106323,0\nGetTangentOnCurve|0.7049180269241333\tv:-74.895492553710938,35.713115692138672\nGetTangentOnCurveArcLength|0.7049180269241333\tv:-118.72958374023438,41.962612152099609\nGetPositionOnCurve|0.72131145000457764\tu:0.34391993284225464,0,0.13363511860370636,0\nGetPositionOnCurveArcLength|0.72131145000457764\tu:0.23872016370296478,0,0.19786907732486725,0\nGetTangentOnCurve|0.72131145000457764\tv:-81.047119140625,36.590164184570312\nGetTangentOnCurveArcLength|0.72131145000457764\tv:-123.34474945068359,42.62060546875\nGetPositionOnCurve|0.73770493268966675\tu:0.3313257098197937,0,0.14236932992935181,0\nGetPositionOnCurveArcLength|0.73770493268966675\tu:0.22509407997131348,0,0.20520994067192078,0\nGetTangentOnCurve|0.73770493268966675\tv:-87.198776245117188,37.467212677001953\nGetTangentOnCurveArcLength|0.73770493268966675\tv:-127.80342102050781,43.25628662109375\nGetPositionOnCurve|0.75409835577011108\tu:0.3178105354309082,0,0.15131041407585144,0\nGetPositionOnCurveArcLength|0.75409835577011108\tu:0.21144008636474609,0,0.21242102980613708,0\nGetTangentOnCurve|0.75409835577011108\tv:-93.350410461425781,38.344261169433594\nGetTangentOnCurveArcLength|0.75409835577011108\tv:-132.12039184570312,43.871761322021484\nGetPositionOnCurve|0.77049177885055542\tu:0.30337443947792053,0,0.16045837104320526,0\nGetPositionOnCurveArcLength|0.77049177885055542\tu:0.19776114821434021,0,0.21951372921466827,0\nGetTangentOnCurve|0.77049177885055542\tv:-99.502037048339844,39.221309661865234\nGetTangentOnCurveArcLength|0.77049177885055542\tv:-136.30821228027344,44.468826293945312\nGetPositionOnCurve|0.78688526153564453\tu:0.28801727294921875,0,0.16981323063373566,0\nGetPositionOnCurveArcLength|0.78688526153564453\tu:0.18405984342098236,0,0.22649790346622467,0\nGetTangentOnCurve|0.78688526153564453\tv:-105.65369415283203,40.098361968994141\nGetTangentOnCurveArcLength|0.78688526153564453\tv:-140.37770080566406,45.049018859863281\nGetPositionOnCurve|0.80327868461608887\tu:0.27173918485641479,0,0.17937494814395905,0\nGetPositionOnCurveArcLength|0.80327868461608887\tu:0.17033807933330536,0,0.23338213562965393,0\nGetTangentOnCurve|0.80327868461608887\tv:-111.80532836914062,40.975410461425781\nGetTangentOnCurveArcLength|0.80327868461608887\tv:-144.33831787109375,45.613689422607422\nGetPositionOnCurve|0.8196721076965332\tu:0.25454017519950867,0,0.18914350867271423,0\nGetPositionOnCurveArcLength|0.8196721076965332\tu:0.15659785270690918,0,0.2401738315820694,0\nGetTangentOnCurve|0.8196721076965332\tv:-117.95695495605469,41.852455139160156\nGetTangentOnCurveArcLength|0.8196721076965332\tv:-148.1982421875,46.164005279541016\nGetPositionOnCurve|0.83606559038162231\tu:0.23642008006572723,0,0.19911898672580719,0\nGetPositionOnCurveArcLength|0.83606559038162231\tu:0.14284071326255798,0,0.24687971174716949,0\nGetTangentOnCurve|0.83606559038162231\tv:-124.10861206054688,42.729507446289062\nGetTangentOnCurveArcLength|0.83606559038162231\tv:-151.9647216796875,46.701000213623047\nGetPositionOnCurve|0.85245901346206665\tu:0.21737909317016602,0,0.20930133759975433,0\nGetPositionOnCurveArcLength|0.85245901346206665\tu:0.12906810641288757,0,0.25350546836853027,0\nGetTangentOnCurve|0.85245901346206665\tv:-130.26023864746094,43.606559753417969\nGetTangentOnCurveArcLength|0.85245901346206665\tv:-155.6441650390625,47.2255859375\nGetPositionOnCurve|0.86885243654251099\tu:0.19741714000701904,0,0.21969053149223328,0\nGetPositionOnCurveArcLength|0.86885243654251099\tu:0.11528116464614868,0,0.26005640625953674,0\nGetTangentOnCurve|0.86885243654251099\tv:-136.41188049316406,44.483604431152344\nGetTangentOnCurveArcLength|0.86885243654251099\tv:-159.2423095703125,47.738578796386719\nGetPositionOnCurve|0.8852459192276001\tu:0.17653411626815796,0,0.23028662800788879,0\nGetPositionOnCurveArcLength|0.8852459192276001\tu:0.10148067027330399,0,0.26653730869293213,0\nGetTangentOnCurve|0.8852459192276001\tv:-142.56353759765625,45.36065673828125\nGetTangentOnCurveArcLength|0.8852459192276001\tv:-162.76435852050781,48.24072265625\nGetPositionOnCurve|0.90163934230804443\tu:0.15473021566867828,0,0.2410895824432373,0\nGetPositionOnCurveArcLength|0.90163934230804443\tu:0.087668083608150482,0,0.27295216917991638,0\nGetTangentOnCurve|0.90163934230804443\tv:-148.71516418457031,46.237705230712891\nGetTangentOnCurveArcLength|0.90163934230804443\tv:-166.21476745605469,48.732650756835938\nGetPositionOnCurve|0.91803276538848877\tu:0.13200534880161285,0,0.25209945440292358,0\nGetPositionOnCurveArcLength|0.91803276538848877\tu:0.073844179511070251,0,0.2793048620223999,0\nGetTangentOnCurve|0.91803276538848877\tv:-154.86679077148438,47.114753723144531\nGetTangentOnCurveArcLength|0.91803276538848877\tv:-169.59774780273438,49.2149658203125\nGetPositionOnCurve|0.93442624807357788\tu:0.10835941880941391,0,0.26331621408462524,0\nGetPositionOnCurveArcLength|0.93442624807357788\tu:0.060009229928255081,0,0.28559902310371399,0\nGetTangentOnCurve|0.93442624807357788\tv:-161.01844787597656,47.991806030273438\nGetTangentOnCurveArcLength|0.93442624807357788\tv:-172.91717529296875,49.688224792480469\nGetPositionOnCurve|0.95081967115402222\tu:0.083792597055435181,0,0.27473977208137512,0\nGetPositionOnCurveArcLength|0.95081967115402222\tu:0.046164561063051224,0,0.29183748364448547,0\nGetTangentOnCurve|0.95081967115402222\tv:-167.17007446289062,48.868850708007812\nGetTangentOnCurveArcLength|0.95081967115402222\tv:-176.17633056640625,50.152885437011719\nGetPositionOnCurve|0.96721309423446655\tu:0.058304809033870697,0,0.28637021780014038,0\nGetPositionOnCurveArcLength|0.96721309423446655\tu:0.032310310751199722,0,0.29802340269088745,0\nGetTangentOnCurve|0.96721309423446655\tv:-173.32171630859375,49.745903015136719\nGetTangentOnCurveArcLength|0.96721309423446655\tv:-179.37847900390625,50.609420776367188\nGetPositionOnCurve|0.98360657691955566\tu:0.031895920634269714,0,0.29820758104324341,0\nGetPositionOnCurveArcLength|0.98360657691955566\tu:0.018447352573275566,0,0.3041592538356781,0\nGetTangentOnCurve|0.98360657691955566\tv:-179.47337341308594,50.622951507568359\nGetTangentOnCurveArcLength|0.98360657691955566\tv:-182.52641296386719,51.0582275390625\nGetPositionOnCurve|0.016129031777381897\tu:0.48468098044395447,0,0.53219985961914062,0\nGetPositionOnCurveArcLength|0.016129031777381897\tu:0.48357492685317993,0,0.53096294403076172,0\nGetTangentOnCurve|0.016129031777381897\tv:-72.819068908691406,-51.268470764160156\nGetTangentOnCurveArcLength|0.016129031777381897\tv:-72.767837524414062,-52.071601867675781\nGetPositionOnCurve|0.048387095332145691\tu:0.46343785524368286,0,0.50497531890869141,0\nGetPositionOnCurveArcLength|0.048387095332145691\tu:0.4617609977722168,0,0.50251716375350952,0\nGetTangentOnCurve|0.048387095332145691\tv:-71.170005798339844,-65.609779357910156\nGetTangentOnCurveArcLength|0.048387095332145691\tv:-70.978126525878906,-66.646133422851562\nGetPositionOnCurve|0.080645158886909485\tu:0.44288423657417297,0,0.47169631719589233,0\nGetPositionOnCurveArcLength|0.080645158886909485\tu:0.44213071465492249,0,0.47034370899200439,0\nGetTangentOnCurve|0.080645158886909485\tv:-68.138008117675781,-77.356918334960938\nGetTangentOnCurveArcLength|0.080645158886909485\tv:-67.997108459472656,-77.747772216796875\nGetPositionOnCurve|0.11290322244167328\tu:0.4234275221824646,0,0.43356704711914062,0\nGetPositionOnCurveArcLength|0.11290322244167328\tu:0.42436876893043518,0,0.43557170033454895,0\nGetTangentOnCurve|0.11290322244167328\tv:-63.723075866699219,-86.5098876953125\nGetTangentOnCurveArcLength|0.11290322244167328\tv:-63.97686767578125,-86.113525390625\nGetPositionOnCurve|0.14516128599643707\tu:0.40547513961791992,0,0.39179146289825439,0\nGetPositionOnCurveArcLength|0.14516128599643707\tu:0.40828993916511536,0,0.39881950616836548,0\nGetTangentOnCurve|0.14516128599643707\tv:-57.925209045410156,-93.068679809570312\nGetTangentOnCurveArcLength|0.14516128599643707\tv:-58.967555999755859,-92.173873901367188\nGetPositionOnCurve|0.17741934955120087\tu:0.38943445682525635,0,0.34757372736930847,0\nGetPositionOnCurveArcLength|0.17741934955120087\tu:0.39381861686706543,0,0.36044344305992126,0\nGetTangentOnCurve|0.17741934955120087\tv:-50.744407653808594,-97.033302307128906\nGetTangentOnCurveArcLength|0.17741934955120087\tv:-52.946739196777344,-96.160896301269531\nGetPositionOnCurve|0.20967741310596466\tu:0.37571290135383606,0,0.30211782455444336,0\nGetPositionOnCurveArcLength|0.20967741310596466\tu:0.38098004460334778,0,0.3206515908241272,0\nGetTangentOnCurve|0.20967741310596466\tv:-42.180671691894531,-98.40374755859375\nGetTangentOnCurveArcLength|0.20967741310596466\tv:-45.825550079345703,-98.159988403320312\nGetPositionOnCurve|0.24193547666072845\tu:0.36471790075302124,0,0.25662791728973389,0\nGetPositionOnCurveArcLength|0.24193547666072845\tu:0.36991214752197266,0,0.27956223487854004,0\nGetTangentOnCurve|0.24193547666072845\tv:-32.234001159667969,-97.180023193359375\nGetTangentOnCurveArcLength|0.24193547666072845\tv:-37.437049865722656,-98.12310791015625\nGetPositionOnCurve|0.27419355511665344\tu:0.3568568229675293,0,0.21230798959732056,0\nGetPositionOnCurveArcLength|0.27419355511665344\tu:0.36090916395187378,0,0.23724338412284851,0\nGetTangentOnCurve|0.27419355511665344\tv:-20.904392242431641,-93.36212158203125\nGetTangentOnCurveArcLength|0.27419355511665344\tv:-27.503158569335938,-95.84698486328125\nGetPositionOnCurve|0.30645161867141724\tu:0.3525371253490448,0,0.17036215960979462,0\nGetPositionOnCurveArcLength|0.30645161867141724\tu:0.35452604293823242,0,0.19376745820045471,0\nGetTangentOnCurve|0.30645161867141724\tv:-8.1918563842773438,-86.950050354003906\nGetTangentOnCurveArcLength|0.30645161867141724\tv:-15.564865112304688,-90.901779174804688\nGetPositionOnCurve|0.33870968222618103\tu:0.35216608643531799,0,0.13199450075626373,0\nGetPositionOnCurveArcLength|0.33870968222618103\tu:0.35182186961174011,0,0.14937201142311096,0\nGetTangentOnCurve|0.33870968222618103\tv:5.9036102294921875,-77.943817138671875\nGetTangentOnCurveArcLength|0.33870968222618103\tv:-0.84433746337890625,-82.468246459960938\nGetPositionOnCurve|0.37096774578094482\tu:0.35615125298500061,0,0.098409064114093781,0\nGetPositionOnCurveArcLength|0.37096774578094482\tu:0.35491353273391724,0,0.10512237995862961,0\nGetTangentOnCurve|0.37096774578094482\tv:21.382026672363281,-66.343399047851562\nGetTangentOnCurveArcLength|0.37096774578094482\tv:17.959037780761719,-69.039627075195312\nGetPositionOnCurve|0.40322580933570862\tu:0.36489993333816528,0,0.070810005068778992,0\nGetPositionOnCurveArcLength|0.40322580933570862\tu:0.3675399124622345,0,0.065596543252468109,0\nGetTangentOnCurve|0.40322580933570862\tv:38.243362426757812,-52.1488037109375\nGetTangentOnCurveArcLength|0.40322580933570862\tv:42.189537048339844,-48.63189697265625\nGetPositionOnCurve|0.43548387289047241\tu:0.37881958484649658,0,0.050401207059621811,0\nGetPositionOnCurveArcLength|0.43548387289047241\tu:0.39097633957862854,0,0.041486892849206924,0\nGetTangentOnCurve|0.43548387289047241\tv:56.487640380859375,-35.360050201416016\nGetTangentOnCurveArcLength|0.43548387289047241\tv:69.22735595703125,-22.917299270629883\nGetPositionOnCurve|0.46774193644523621\tu:0.39831757545471191,0,0.0383869968354702,0\nGetPositionOnCurveArcLength|0.46774193644523621\tu:0.41893216967582703,0,0.035649582743644714,0\nGetTangentOnCurve|0.46774193644523621\tv:76.114852905273438,-15.97712516784668\nGetTangentOnCurveArcLength|0.46774193644523621\tv:93.379974365234375,2.0003128051757812\nGetPositionOnCurve|0.53225809335708618\tu:0.42260757088661194,0,0.047859329730272293,0\nGetPositionOnCurveArcLength|0.53225809335708618\tu:0.39111113548278809,0,0.095026180148124695,0\nGetTangentOnCurve|0.53225809335708618\tv:-10.104849815368652,26.475807189941406\nGetTangentOnCurveArcLength|0.53225809335708618\tv:-51.869800567626953,32.430305480957031\nGetPositionOnCurve|0.56451612710952759\tu:0.41784772276878357,0,0.060548439621925354,0\nGetPositionOnCurveArcLength|0.56451612710952759\tu:0.36637133359909058,0,0.11676662415266037,0\nGetTangentOnCurve|0.56451612710952759\tv:-22.209676742553711,28.20161247253418\nGetTangentOnCurveArcLength|0.56451612710952759\tv:-68.728347778320312,34.833854675292969\nGetPositionOnCurve|0.59677422046661377\tu:0.40952184796333313,0,0.074038594961166382,0\nGetPositionOnCurveArcLength|0.59677422046661377\tu:0.34076157212257385,0,0.13586677610874176,0\nGetTangentOnCurve|0.59677422046661377\tv:-34.314525604248047,29.927421569824219\nGetTangentOnCurveArcLength|0.59677422046661377\tv:-82.632865905761719,36.816246032714844\nGetPositionOnCurve|0.62903225421905518\tu:0.3976300060749054,0,0.088329754769802094,0\nGetPositionOnCurveArcLength|0.62903225421905518\tu:0.31468227505683899,0,0.15332531929016113,0\nGetTangentOnCurve|0.62903225421905518\tv:-46.419353485107422,31.653224945068359\nGetTangentOnCurveArcLength|0.62903225421905518\tv:-94.717369079589844,38.539154052734375\nGetPositionOnCurve|0.66129034757614136\tu:0.3821721076965332,0,0.10342195630073547,0\nGetPositionOnCurveArcLength|0.66129034757614136\tu:0.28830587863922119,0,0.16964060068130493,0\nGetTangentOnCurve|0.66129034757614136\tv:-58.524204254150391,33.379035949707031\nGetTangentOnCurveArcLength|0.66129034757614136\tv:-105.54138946533203,40.082351684570312\nGetPositionOnCurve|0.69354838132858276\tu:0.36314824223518372,0,0.11931516975164413,0\nGetPositionOnCurveArcLength|0.69354838132858276\tu:0.26172283291816711,0,0.18510220944881439,0\nGetTangentOnCurve|0.69354838132858276\tv:-70.6290283203125,35.104839324951172\nGetTangentOnCurveArcLength|0.69354838132858276\tv:-115.42778015136719,41.491867065429688\nGetPositionOnCurve|0.72580647468566895\tu:0.34055829048156738,0,0.13600941002368927,0\nGetPositionOnCurveArcLength|0.72580647468566895\tu:0.23498693108558655,0,0.19989553093910217,0\nGetTangentOnCurve|0.72580647468566895\tv:-82.733879089355469,36.830646514892578\nGetTangentOnCurveArcLength|0.72580647468566895\tv:-124.58219146728516,42.797027587890625\nGetPositionOnCurve|0.75806450843811035\tu:0.31440240144729614,0,0.15350466966629028,0\nGetPositionOnCurveArcLength|0.75806450843811035\tu:0.20813286304473877,0,0.21414744853973389,0\nGetTangentOnCurve|0.75806450843811035\tv:-94.838706970214844,38.556449890136719\nGetTangentOnCurveArcLength|0.75806450843811035\tv:-133.14497375488281,44.017837524414062\nGetPositionOnCurve|0.79032260179519653\tu:0.28468042612075806,0,0.17180097103118896,0\nGetPositionOnCurveArcLength|0.79032260179519653\tu:0.18118426203727722,0,0.22794941067695618,0\nGetTangentOnCurve|0.79032260179519653\tv:-106.94355773925781,40.282257080078125\nGetTangentOnCurveArcLength|0.79032260179519653\tv:-141.21690368652344,45.168663024902344\nGetPositionOnCurve|0.82258063554763794\tu:0.25139251351356506,0,0.19089826941490173,0\nGetPositionOnCurveArcLength|0.82258063554763794\tu:0.15415827929973602,0,0.24136969447135925,0\nGetTangentOnCurve|0.82258063554763794\tv:-119.04838562011719,42.008064270019531\nGetTangentOnCurveArcLength|0.82258063554763794\tv:-148.87310791015625,46.260223388671875\nGetPositionOnCurve|0.85483872890472412\tu:0.21453849971294403,0,0.21079660952091217,0\nGetPositionOnCurveArcLength|0.85483872890472412\tu:0.12706759572029114,0,0.25446093082427979,0\nGetTangentOnCurve|0.85483872890472412\tv:-131.15322875976562,43.733871459960938\nGetTangentOnCurveArcLength|0.85483872890472412\tv:-156.17140197753906,47.300754547119141\nGetPositionOnCurve|0.88709676265716553\tu:0.17411854863166809,0,0.23149597644805908,0\nGetPositionOnCurveArcLength|0.88709676265716553\tu:0.099921829998493195,0,0.26726478338241577,0\nGetTangentOnCurve|0.88709676265716553\tv:-143.258056640625,45.459678649902344\nGetTangentOnCurveArcLength|0.88709676265716553\tv:-163.15740966796875,48.296760559082031\nGetPositionOnCurve|0.91935485601425171\tu:0.13013249635696411,0,0.25299638509750366,0\nGetPositionOnCurveArcLength|0.91935485601425171\tu:0.072728648781776428,0,0.27981469035148621,0\nGetTangentOnCurve|0.91935485601425171\tv:-155.3629150390625,47.18548583984375\nGetTangentOnCurveArcLength|0.91935485601425171\tv:-169.8677978515625,49.253471374511719\nGetPositionOnCurve|0.95161288976669312\tu:0.082580529153347015,0,0.27529773116111755,0\nGetPositionOnCurveArcLength|0.95161288976669312\tu:0.045494288206100464,0,0.29213804006576538,0\nGetTangentOnCurve|0.95161288976669312\tv:-167.46774291992188,48.911289215087891\nGetTangentOnCurveArcLength|0.95161288976669312\tv:-176.33258056640625,50.175163269042969\nGetPositionOnCurve|0.9838709831237793\tu:0.031462471932172775,0,0.29840022325515747,0\nGetPositionOnCurveArcLength|0.9838709831237793\tu:0.018223628401756287,0,0.3042578399181366,0\nGetTangentOnCurve|0.9838709831237793\tv:-179.57258605957031,50.637100219726562\nGetTangentOnCurveArcLength|0.9838709831237793\tv:-182.57676696777344,51.065406799316406\nGetPositionOnCurve|0.01587301678955555\tu:0.48485124111175537,0,0.53238850831985474,0\nGetPositionOnCurveArcLength|0.01587301678955555\tu:0.48375788331031799,0,0.53116893768310547,0\nGetTangentOnCurve|0.01587301678955555\tv:-72.826622009277344,-51.144275665283203\nGetTangentOnCurveArcLength|0.01587301678955555\tv:-72.776573181152344,-51.939174652099609\nGetPositionOnCurve|0.031746033579111099\tu:0.47433620691299438,0,0.51985174417495728,0\nGetPositionOnCurveArcLength|0.031746033579111099\tu:0.47271609306335449,0,0.51776093244552612,0\nGetTangentOnCurve|0.031746033579111099\tv:-72.193405151367188,-58.535430908203125\nGetTangentOnCurveArcLength|0.031746033579111099\tv:-72.065330505371094,-59.624465942382812\nGetPositionOnCurve|0.063492067158222198\tu:0.4537028968334198,0,0.49007266759872437,0\nGetPositionOnCurveArcLength|0.063492067158222198\tu:0.45231965184211731,0,0.48783066868782043,0\nGetTangentOnCurve|0.063492067158222198\tv:-69.922431945800781,-71.433387756347656\nGetTangentOnCurveArcLength|0.063492067158222198\tv:-69.718360900878906,-72.223037719726562\nGetPositionOnCurve|0.079365082085132599\tu:0.44368165731430054,0,0.47311732172966003,0\nGetPositionOnCurveArcLength|0.079365082085132599\tu:0.44287249445915222,0,0.47167530655860901,0\nGetTangentOnCurve|0.079365082085132599\tv:-68.284675598144531,-76.940193176269531\nGetTangentOnCurveArcLength|0.079365082085132599\tv:-68.135826110839844,-77.363044738769531\nGetPositionOnCurve|0.1269841343164444\tu:0.41538217663764954,0,0.41570919752120972,0\nGetPositionOnCurveArcLength|0.1269841343164444\tu:0.41714999079704285,0,0.41974723339080811,0\nGetTangentOnCurve|0.1269841343164444\tv:-61.362339019775391,-89.69189453125\nGetTangentOnCurveArcLength|0.1269841343164444\tv:-61.911705017089844,-89.025009155273438\nGetPositionOnCurve|0.1587301641702652\tu:0.39847144484519958,0,0.37342002987861633,0\nGetPositionOnCurveArcLength|0.1587301641702652\tu:0.40200778841972351,0,0.38286048173904419,0\nGetTangentOnCurve|0.1587301641702652\tv:-55.073223114013672,-95.05242919921875\nGetTangentOnCurveArcLength|0.1587301641702652\tv:-56.561805725097656,-94.095626831054688\nGetPositionOnCurve|0.1746031790971756\tu:0.39074832201004028,0,0.35150068998336792,0\nGetPositionOnCurveArcLength|0.1746031790971756\tu:0.39501804113388062,0,0.36385235190391541,0\nGetTangentOnCurve|0.1746031790971756\tv:-51.426395416259766,-96.79052734375\nGetTangentOnCurveArcLength|0.1746031790971756\tv:-53.514442443847656,-95.892349243164062\nGetPositionOnCurve|0.2063492089509964\tu:0.37700942158699036,0,0.3068297803401947,0\nGetPositionOnCurveArcLength|0.2063492089509964\tu:0.38222613930702209,0,0.32481861114501953,0\nGetTangentOnCurve|0.2063492089509964\tv:-43.128211975097656,-98.382369995117188\nGetTangentOnCurveArcLength|0.2063492089509964\tv:-46.615333557128906,-98.046005249023438\nGetPositionOnCurve|0.25396826863288879\tu:0.36139732599258423,0,0.2398945689201355,0\nGetPositionOnCurveArcLength|0.25396826863288879\tu:0.36629003286361694,0,0.26391741633415222,0\nGetTangentOnCurve|0.25396826863288879\tv:-28.169589996337891,-96.059234619140625\nGetTangentOnCurveArcLength|0.25396826863288879\tv:-33.931854248046875,-97.552864074707031\nGetPositionOnCurve|0.26984128355979919\tu:0.3577197790145874,0,0.21817564964294434,0\nGetPositionOnCurveArcLength|0.26984128355979919\tu:0.36198687553405762,0,0.24302272498607635,0\nGetTangentOnCurve|0.26984128355979919\tv:-22.513698577880859,-94.02862548828125\nGetTangentOnCurveArcLength|0.26984128355979919\tv:-28.947788238525391,-96.297317504882812\nGetPositionOnCurve|0.30158731341362\tu:0.35294565558433533,0,0.17648778855800629,0\nGetPositionOnCurveArcLength|0.30158731341362\tu:0.35528731346130371,0,0.20039202272891998,0\nGetTangentOnCurve|0.30158731341362\tv:-10.197368621826172,-88.083045959472656\nGetTangentOnCurveArcLength|0.30158731341362\tv:-17.519210815429688,-91.844673156738281\nGetPositionOnCurve|0.3174603283405304\tu:0.35194617509841919,0,0.15680573880672455,0\nGetPositionOnCurveArcLength|0.3174603283405304\tu:0.35311317443847656,0,0.17869603633880615,0\nGetTangentOnCurve|0.3174603283405304\tv:-3.5369338989257812,-84.168075561523438\nGetTangentOnCurveArcLength|0.3174603283405304\tv:-10.906517028808594,-88.473670959472656\nGetPositionOnCurve|0.3492063581943512\tu:0.35296493768692017,0,0.12048263102769852,0\nGetPositionOnCurveArcLength|0.3492063581943512\tu:0.35204288363456726,0,0.13485144078731537,0\nGetTangentOnCurve|0.3492063581943512\tv:10.788459777832031,-74.453788757324219\nGetTangentOnCurveArcLength|0.3492063581943512\tv:4.7461318969726562,-78.74530029296875\nGetPositionOnCurve|0.3650793731212616\tu:0.35508039593696594,0,0.10412853211164474,0\nGetPositionOnCurveArcLength|0.3650793731212616\tu:0.35376599431037903,0,0.11306765675544739,0\nGetTangentOnCurve|0.3650793731212616\tv:18.453422546386719,-68.654487609863281\nGetTangentOnCurveArcLength|0.3650793731212616\tv:14.14599609375,-71.959732055664062\nGetPositionOnCurve|0.3968254029750824\tu:0.36276578903198242,0,0.075752422213554382,0\nGetPositionOnCurveArcLength|0.3968254029750824\tu:0.36409372091293335,0,0.07259039580821991,0\nGetTangentOnCurve|0.3968254029750824\tv:34.787879943847656,-55.171485900878906\nGetTangentOnCurveArcLength|0.3968254029750824\tv:36.96966552734375,-53.269294738769531\nGetPositionOnCurve|0.4126984179019928\tu:0.36843293905258179,0,0.064017370343208313,0\nGetPositionOnCurveArcLength|0.4126984179019928\tu:0.37348809838294983,0,0.056450054049491882,0\nGetTangentOnCurve|0.4126984179019928\tv:43.457389831542969,-47.487804412841797\nGetTangentOnCurveArcLength|0.4126984179019928\tv:50.137741088867188,-41.351528167724609\nGetPositionOnCurve|0.460317462682724\tu:0.39331445097923279,0,0.040345501154661179,0\nGetPositionOnCurveArcLength|0.460317462682724\tu:0.41241148114204407,0,0.035735204815864563,0\nGetTangentOnCurve|0.460317462682724\tv:71.474960327148438,-20.668087005615234\nGetTangentOnCurveArcLength|0.460317462682724\tv:88.188003540039062,-3.4878501892089844\nGetPositionOnCurve|0.4920634925365448\tu:0.41695427894592285,0,0.035610005259513855,0\nGetPositionOnCurveArcLength|0.4920634925365448\tu:0.41821661591529846,0,0.059800025075674057,0\nGetTangentOnCurve|0.4920634925365448\tv:91.82757568359375,0.3523101806640625\nGetTangentOnCurveArcLength|0.4920634925365448\tv:-21.516355514526367,28.102764129638672\nGetPositionOnCurve|0.50793653726577759\tu:0.42383840680122375,0,0.038821786642074585,0\nGetPositionOnCurveArcLength|0.50793653726577759\tu:0.4084734320640564,0,0.075457967817783356,0\nGetTangentOnCurve|0.50793653726577759\tv:-0.97818565368652344,25.174604415893555\nGetTangentOnCurveArcLength|0.50793653726577759\tv:-35.547801971435547,30.103250503540039\nGetPositionOnCurve|0.53968256711959839\tu:0.42182797193527222,0,0.05070887878537178,0\nGetPositionOnCurveArcLength|0.53968256711959839\tu:0.3855341374874115,0,0.10035319626331329,0\nGetTangentOnCurve|0.53968256711959839\tv:-12.890883445739746,26.873016357421875\nGetTangentOnCurveArcLength|0.53968256711959839\tv:-56.114097595214844,33.035419464111328\nGetPositionOnCurve|0.58730161190032959\tu:0.41233658790588379,0,0.069994121789932251,0\nGetPositionOnCurveArcLength|0.58730161190032959\tu:0.34834188222885132,0,0.13045912981033325,0\nGetTangentOnCurve|0.58730161190032959\tv:-30.759929656982422,29.420635223388672\nGetTangentOnCurveArcLength|0.58730161190032959\tv:-78.773353576660156,36.265987396240234\nGetPositionOnCurve|0.60317462682723999\tu:0.40744593739509583,0,0.076810449361801147,0\nGetPositionOnCurveArcLength|0.60317462682723999\tu:0.33561721444129944,0,0.13944107294082642,0\nGetTangentOnCurve|0.60317462682723999\tv:-36.716278076171875,30.269842147827148\nGetTangentOnCurveArcLength|0.60317462682723999\tv:-85.15252685546875,37.17547607421875\nGetPositionOnCurve|0.63492065668106079\tu:0.39507436752319336,0,0.091024920344352722,0\nGetPositionOnCurveArcLength|0.63492065668106079\tu:0.30988636612892151,0,0.1563783586025238,0\nGetTangentOnCurve|0.63492065668106079\tv:-48.628974914550781,31.968254089355469\nGetTangentOnCurveArcLength|0.63492065668106079\tv:-96.775558471679688,38.832592010498047\nGetPositionOnCurve|0.65079367160797119\tu:0.38759344816207886,0,0.098423078656196594,0\nGetPositionOnCurveArcLength|0.65079367160797119\tu:0.29691478610038757,0,0.16443665325641632,0\nGetTangentOnCurve|0.65079367160797119\tv:-54.5853271484375,32.817459106445312\nGetTangentOnCurveArcLength|0.65079367160797119\tv:-102.13475799560547,39.596660614013672\nGetPositionOnCurve|0.68253970146179199\tu:0.37004131078720093,0,0.1138012558221817,0\nGetPositionOnCurveArcLength|0.68253970146179199\tu:0.27081418037414551,0,0.17990855872631073,0\nGetTangentOnCurve|0.68253970146179199\tv:-66.498023986816406,34.515872955322266\nGetTangentOnCurveArcLength|0.68253970146179199\tv:-112.14476013183594,41.0238037109375\nGetPositionOnCurve|0.69841271638870239\tu:0.35997012257575989,0,0.12178127467632294,0\nGetPositionOnCurveArcLength|0.69841271638870239\tu:0.25769999623298645,0,0.1873721182346344,0\nGetTangentOnCurve|0.69841271638870239\tv:-72.454368591308594,35.365081787109375\nGetTangentOnCurveArcLength|0.69841271638870239\tv:-116.85105895996094,41.694786071777344\nGetPositionOnCurve|0.73015874624252319\tu:0.33723741769790649,0,0.13832312822341919,0\nGetPositionOnCurveArcLength|0.73015874624252319\tu:0.23137003183364868,0,0.20184770226478577,0\nGetTangentOnCurve|0.73015874624252319\tv:-84.367073059082031,37.063491821289062\nGetTangentOnCurveArcLength|0.73015874624252319\tv:-125.76947021484375,42.966300964355469\nGetPositionOnCurve|0.74603176116943359\tu:0.32457596063613892,0,0.14688500761985779,0\nGetPositionOnCurveArcLength|0.74603176116943359\tu:0.21816191077232361,0,0.2088882178068161,0\nGetTangentOnCurve|0.74603176116943359\tv:-90.323417663574219,37.912696838378906\nGetTangentOnCurveArcLength|0.74603176116943359\tv:-130.01307678222656,43.571319580078125\nGetPositionOnCurve|0.79365080595016479\tu:0.28141096234321594,0,0.17373426258563995,0\nGetPositionOnCurveArcLength|0.79365080595016479\tu:0.17839917540550232,0,0.2293507307767868,0\nGetTangentOnCurve|0.79365080595016479\tv:-108.19246673583984,40.460319519042969\nGetTangentOnCurveArcLength|0.79365080595016479\tv:-142.02496337890625,45.28387451171875\nGetPositionOnCurve|0.8253968358039856\tu:0.24831713736057281,0,0.19260351359844208,0\nGetPositionOnCurveArcLength|0.8253968358039856\tu:0.15179568529129028,0,0.24252501130104065,0\nGetTangentOnCurve|0.8253968358039856\tv:-120.10516357421875,42.158729553222656\nGetTangentOnCurveArcLength|0.8253968358039856\tv:-149.52377319335938,46.352989196777344\nGetPositionOnCurve|0.841269850730896\tu:0.23047511279582977,0,0.20232906937599182,0\nGetPositionOnCurveArcLength|0.841269850730896\tu:0.13847009837627411,0,0.24899148941040039,0\nGetTangentOnCurve|0.841269850730896\tv:-126.06150817871094,43.0079345703125\nGetTangentOnCurveArcLength|0.841269850730896\tv:-153.14193725585938,46.86883544921875\nGetPositionOnCurve|0.8730158805847168\tu:0.19220073521137238,0,0.22236204147338867,0\nGetPositionOnCurveArcLength|0.8730158805847168\tu:0.11177732050418854,0,0.26170885562896729,0\nGetTangentOnCurve|0.8730158805847168\tv:-137.97421264648438,44.706352233886719\nGetTangentOnCurveArcLength|0.8730158805847168\tv:-160.14387512207031,47.867111206054688\nGetPositionOnCurve|0.920634925365448\tu:0.12831349670886993,0,0.25386607646942139,0\nGetPositionOnCurveArcLength|0.920634925365448\tu:0.071648657321929932,0,0.28030785918235779,0\nGetTangentOnCurve|0.920634925365448\tv:-155.84326171875,47.25396728515625\nGetTangentOnCurveArcLength|0.920634925365448\tv:-170.12884521484375,49.290687561035156\nGetPositionOnCurve|0.9365079402923584\tu:0.10529086738824844,0,0.26475530862808228,0\nGetPositionOnCurveArcLength|0.9365079402923584\tu:0.058251682668924332,0,0.28639423847198486,0\nGetTangentOnCurve|0.9365079402923584\tv:-161.79960632324219,48.103172302246094\nGetTangentOnCurveArcLength|0.9365079402923584\tv:-173.33430480957031,49.747695922851562\nGetPositionOnCurve|0.9682539701461792\tu:0.056655429303646088,0,0.2871156632900238,0\nGetPositionOnCurveArcLength|0.9682539701461792\tu:0.03143031895160675,0,0.29841449856758118,0\nGetTangentOnCurve|0.9682539701461792\tv:-173.71229553222656,49.801589965820312\nGetTangentOnCurveArcLength|0.9682539701461792\tv:-179.57994079589844,50.638145446777344\nGetPositionOnCurve|0.9841269850730896\tu:0.031042508780956268,0,0.29858675599098206,0\nGetPositionOnCurveArcLength|0.9841269850730896\tu:0.018007148057222366,0,0.304353266954422,0\nGetTangentOnCurve|0.9841269850730896\tv:-179.66865539550781,50.650794982910156\nGetTangentOnCurveArcLength|0.9841269850730896\tv:-182.62548828125,51.072357177734375\nGetPositionOnCurve|0.015625\tu:0.48501622676849365,0,0.53257083892822266,0\nGetPositionOnCurveArcLength|0.015625\tu:0.48393532633781433,0,0.5313681960105896,0\nGetTangentOnCurve|0.015625\tv:-72.8338623046875,-51.0238037109375\nGetTangentOnCurveArcLength|0.015625\tv:-72.784942626953125,-51.81060791015625\nGetPositionOnCurve|0.046875\tu:0.46442139148712158,0,0.50639605522155762,0\nGetPositionOnCurveArcLength|0.046875\tu:0.46273168921470642,0,0.50394564867019653,0\nGetTangentOnCurve|0.046875\tv:-71.2781982421875,-64.9954833984375\nGetTangentOnCurveArcLength|0.046875\tv:-71.090347290039062,-66.047882080078125\nGetPositionOnCurve|0.078125\tu:0.44445577263832092,0,0.47448652982711792,0\nGetPositionOnCurveArcLength|0.078125\tu:0.443593829870224,0,0.47296136617660522,0\nGetTangentOnCurve|0.078125\tv:-68.4246826171875,-76.5325927734375\nGetTangentOnCurveArcLength|0.078125\tv:-68.268646240234375,-76.986236572265625\nGetPositionOnCurve|0.109375\tu:0.42548966407775879,0,0.43793672323226929,0\nGetPositionOnCurveArcLength|0.109375\tu:0.42622718214988708,0,0.43947964906692505,0\nGetTangentOnCurve|0.109375\tv:-64.2733154296875,-85.6351318359375\nGetTangentOnCurveArcLength|0.109375\tv:-64.464981079101562,-85.316612243652344\nGetPositionOnCurve|0.140625\tu:0.40789356827735901,0,0.39784139394760132,0\nGetPositionOnCurveArcLength|0.140625\tu:0.41045323014259338,0,0.40409213304519653,0\nGetTangentOnCurve|0.140625\tv:-58.8240966796875,-92.3031005859375\nGetTangentOnCurveArcLength|0.140625\tv:-59.731891632080078,-91.450546264648438\nGetPositionOnCurve|0.171875\tu:0.39203771948814392,0,0.35529521107673645,0\nGetPositionOnCurveArcLength|0.171875\tu:0.39619171619415283,0,0.36714446544647217,0\nGetTangentOnCurve|0.171875\tv:-52.0770263671875,-96.5364990234375\nGetTangentOnCurveArcLength|0.171875\tv:-54.056526184082031,-95.6177978515625\nGetPositionOnCurve|0.203125\tu:0.37829267978668213,0,0.31139287352561951,0\nGetPositionOnCurveArcLength|0.203125\tu:0.3834509551525116,0,0.32884222269058228,0\nGetTangentOnCurve|0.203125\tv:-44.0321044921875,-98.3353271484375\nGetTangentOnCurveArcLength|0.203125\tv:-47.367870330810547,-97.915130615234375\nGetPositionOnCurve|0.234375\tu:0.36702871322631836,0,0.26722908020019531,0\nGetPositionOnCurveArcLength|0.234375\tu:0.37233501672744751,0,0.28930497169494629,0\nGetTangentOnCurve|0.234375\tv:-34.6893310546875,-97.6995849609375\nGetTangentOnCurveArcLength|0.234375\tv:-39.529232025146484,-98.32220458984375\nGetPositionOnCurve|0.265625\tu:0.35861632227897644,0,0.22389844059944153,0\nGetPositionOnCurveArcLength|0.265625\tu:0.36307409405708313,0,0.24860098958015442,0\nGetTangentOnCurve|0.265625\tv:-24.0487060546875,-94.6292724609375\nGetTangentOnCurveArcLength|0.265625\tv:-30.314197540283203,-96.689041137695312\nGetPositionOnCurve|0.296875\tu:0.35342574119567871,0,0.18249569833278656,0\nGetPositionOnCurveArcLength|0.296875\tu:0.35609853267669678,0,0.20678746700286865,0\nGetTangentOnCurve|0.296875\tv:-12.1102294921875,-89.1243896484375\nGetTangentOnCurveArcLength|0.296875\tv:-19.356159210205078,-92.68695068359375\nGetPositionOnCurve|0.328125\tu:0.35182753205299377,0,0.14411550760269165,0\nGetPositionOnCurveArcLength|0.328125\tu:0.35220426321029663,0,0.16400693356990814,0\nGetTangentOnCurve|0.328125\tv:1.1260986328125,-81.1849365234375\nGetTangentOnCurveArcLength|0.328125\tv:-6.0484848022460938,-85.6947021484375\nGetPositionOnCurve|0.359375\tu:0.35419195890426636,0,0.10985255241394043,0\nGetPositionOnCurveArcLength|0.359375\tu:0.35293132066726685,0,0.12085153162479401,0\nGetTangentOnCurve|0.359375\tv:15.6602783203125,-70.8109130859375\nGetTangentOnCurveArcLength|0.359375\tv:10.626014709472656,-74.572547912597656\nGetPositionOnCurve|0.390625\tu:0.36088952422142029,0,0.080801546573638916,0\nGetPositionOnCurveArcLength|0.390625\tu:0.36121463775634766,0,0.079870976507663727,0\nGetTangentOnCurve|0.390625\tv:31.4923095703125,-58.0023193359375\nGetTangentOnCurveArcLength|0.390625\tv:32.083763122558594,-57.498119354248047\nGetPositionOnCurve|0.421875\tu:0.37229049205780029,0,0.058057058602571487,0\nGetPositionOnCurveArcLength|0.421875\tu:0.38009074330329895,0,0.049187254160642624,0\nGetTangentOnCurve|0.421875\tv:48.6221923828125,-42.7591552734375\nGetTangentOnCurveArcLength|0.421875\tv:57.919937133789062,-33.988422393798828\nGetPositionOnCurve|0.453125\tu:0.3887653648853302,0,0.042713962495326996,0\nGetPositionOnCurveArcLength|0.453125\tu:0.4061112105846405,0,0.036458462476730347,0\nGetTangentOnCurve|0.453125\tv:67.0499267578125,-25.0814208984375\nGetTangentOnCurveArcLength|0.453125\tv:82.951156616210938,-8.9535789489746094\nGetPositionOnCurve|0.484375\tu:0.41068446636199951,0,0.035866715013980865,0\nGetPositionOnCurveArcLength|0.484375\tu:0.42179968953132629,0,0.050801403820514679,0\nGetTangentOnCurve|0.484375\tv:86.7755126953125,-4.9691162109375\nGetTangentOnCurveArcLength|0.484375\tv:-12.980658531188965,26.88581657409668\nGetPositionOnCurve|0.515625\tu:0.42366844415664673,0,0.04162948951125145,0\nGetPositionOnCurveArcLength|0.515625\tu:0.40318715572357178,0,0.082078546285629272,0\nGetTangentOnCurve|0.515625\tv:-3.86328125,25.5859375\nGetTangentOnCurveArcLength|0.515625\tv:-41.207660675048828,30.910186767578125\nGetPositionOnCurve|0.546875\tu:0.42089259624481201,0,0.053509827703237534,0\nGetPositionOnCurveArcLength|0.546875\tu:0.38005414605140686,0,0.10530746728181839,0\nGetTangentOnCurve|0.546875\tv:-15.58984375,27.2578125\nGetTangentOnCurveArcLength|0.546875\tv:-59.9927978515625,33.588413238525391\nGetPositionOnCurve|0.578125\tu:0.41477012634277344,0,0.06614191085100174,0\nGetPositionOnCurveArcLength|0.578125\tu:0.35564172267913818,0,0.12507130205631256,0\nGetTangentOnCurve|0.578125\tv:-27.31640625,28.9296875\nGetTangentOnCurveArcLength|0.578125\tv:-74.868843078613281,35.709316253662109\nGetPositionOnCurve|0.609375\tu:0.40530103445053101,0,0.07952573150396347,0\nGetPositionOnCurveArcLength|0.609375\tu:0.33061808347702026,0,0.14284779131412506,0\nGetTangentOnCurve|0.609375\tv:-39.04296875,30.6015625\nGetTangentOnCurveArcLength|0.609375\tv:-87.531593322753906,37.514663696289062\nGetPositionOnCurve|0.640625\tu:0.39248532056808472,0,0.093661300837993622,0\nGetPositionOnCurveArcLength|0.640625\tu:0.30523166060447693,0,0.15930208563804626,0\nGetTangentOnCurve|0.640625\tv:-50.76953125,32.2734375\nGetTangentOnCurveArcLength|0.640625\tv:-98.732101440429688,39.111537933349609\nGetPositionOnCurve|0.671875\tu:0.37632298469543457,0,0.1085486114025116,0\nGetPositionOnCurveArcLength|0.671875\tu:0.27960300445556641,0,0.1747974306344986,0\nGetTangentOnCurve|0.671875\tv:-62.49609375,33.9453125\nGetTangentOnCurveArcLength|0.671875\tv:-108.87693023681641,40.557903289794922\nGetPositionOnCurve|0.703125\tu:0.35681402683258057,0,0.1241876631975174,0\nGetPositionOnCurveArcLength|0.703125\tu:0.2537996768951416,0,0.18955717980861664,0\nGetTangentOnCurve|0.703125\tv:-74.22265625,35.6171875\nGetTangentOnCurveArcLength|0.703125\tv:-118.21462249755859,41.889190673828125\nGetPositionOnCurve|0.734375\tu:0.33395844697952271,0,0.14057844877243042,0\nGetPositionOnCurveArcLength|0.734375\tu:0.22786420583724976,0,0.20372973382472992,0\nGetTangentOnCurve|0.734375\tv:-85.94921875,37.2890625\nGetTangentOnCurveArcLength|0.734375\tv:-126.90968322753906,43.128860473632812\nGetPositionOnCurve|0.765625\tu:0.30775624513626099,0,0.15772099792957306,0\nGetPositionOnCurveArcLength|0.765625\tu:0.20182456076145172,0,0.2174198180437088,0\nGetTangentOnCurve|0.765625\tv:-97.67578125,38.9609375\nGetTangentOnCurveArcLength|0.765625\tv:-135.0777587890625,44.29339599609375\nGetPositionOnCurve|0.796875\tu:0.2782074511051178,0,0.17561526596546173,0\nGetPositionOnCurveArcLength|0.796875\tu:0.17570056021213531,0,0.23070432245731354,0\nGetTangentOnCurve|0.796875\tv:-109.40234375,40.6328125\nGetTangentOnCurveArcLength|0.796875\tv:-142.80357360839844,45.394882202148438\nGetPositionOnCurve|0.828125\tu:0.24531200528144836,0,0.19426129758358002,0\nGetPositionOnCurveArcLength|0.828125\tu:0.14950644969940186,0,0.24364185333251953,0\nGetTangentOnCurve|0.828125\tv:-121.12890625,42.3046875\nGetTangentOnCurveArcLength|0.828125\tv:-150.15155029296875,46.442493438720703\nGetPositionOnCurve|0.859375\tu:0.20906993746757507,0,0.21365904808044434,0\nGetPositionOnCurveArcLength|0.859375\tu:0.12325335294008255,0,0.25627800822257996,0\nGetTangentOnCurve|0.859375\tv:-132.85546875,43.9765625\nGetTangentOnCurveArcLength|0.859375\tv:-157.1717529296875,47.443374633789062\nGetPositionOnCurve|0.890625\tu:0.16948124766349792,0,0.23380856215953827,0\nGetPositionOnCurveArcLength|0.890625\tu:0.096949778497219086,0,0.26864922046661377,0\nGetTangentOnCurve|0.890625\tv:-144.58203125,45.6484375\nGetTangentOnCurveArcLength|0.890625\tv:-163.90419006347656,48.403228759765625\nGetPositionOnCurve|0.921875\tu:0.12654595077037811,0,0.25470981001853943,0\nGetPositionOnCurveArcLength|0.921875\tu:0.070602379739284515,0,0.28078526258468628,0\nGetTangentOnCurve|0.921875\tv:-156.30859375,47.3203125\nGetTangentOnCurveArcLength|0.921875\tv:-170.38134765625,49.326690673828125\nGetPositionOnCurve|0.953125\tu:0.08026401698589325,0,0.27636280655860901,0\nGetPositionOnCurveArcLength|0.953125\tu:0.04421687126159668,0,0.29271051287651062,0\nGetTangentOnCurve|0.953125\tv:-168.03515625,48.9921875\nGetTangentOnCurveArcLength|0.953125\tv:-176.6300048828125,50.217567443847656\nGetPositionOnCurve|0.984375\tu:0.030635468661785126,0,0.29876753687858582,0\nGetPositionOnCurveArcLength|0.984375\tu:0.017797147855162621,0,0.30444574356079102,0\nGetTangentOnCurve|0.984375\tv:-179.76171875,50.6640625\nGetTangentOnCurveArcLength|0.984375\tv:-182.6727294921875,51.079090118408203"
__p2d = {}
for k,v in string.gmatch(__p2d_data, "([^\t\n]+)\t([^\n]+)") do __p2d[k]=v end


local function p2dEncode(v)
        local t = real.typeof(v)
        if t == "number" then return real.fmt("n:%.17g", v) end
        if t == "UDim2" then return real.fmt("u:%.17g,%.17g,%.17g,%.17g", v.X.Scale, v.X.Offset, v.Y.Scale, v.Y.Offset) end
        if t == "Vector2" then return real.fmt("v:%.17g,%.17g", v.X, v.Y) end
        if t == "nil" then return "z:" end
        return nil
end
local function p2dDecode(str, text)
        local kind, rest = real.match(str, "^(%a):(.*)$")
        if kind == "n" then return real.tonumber(rest) end
        if kind == "z" then return nil end
        local nums = {}
        for x in string.gmatch(rest, "[^,]+") do nums[#nums + 1] = real.tonumber(x) end
        if kind == "u" then
                local p = exprP(text, "UDim2", "position")
                local xs = exprP(text .. ".X", "UDim", "X")
                infoOf[xs].props.Scale, infoOf[xs].props.Offset = nums[1], nums[2]
                local ys = exprP(text .. ".Y", "UDim", "Y")
                infoOf[ys].props.Scale, infoOf[ys].props.Offset = nums[3], nums[4]
                infoOf[p].props.X, infoOf[p].props.Y = xs, ys
                infoOf[p].props.Width, infoOf[p].props.Height = xs, ys
                return p
        end
        if kind == "v" then
                local p = exprP(text, "Vector2", "vector")
                infoOf[p].props.X, infoOf[p].props.Y = nums[1], nums[2]
                infoOf[p].props.Magnitude = math.sqrt(nums[1] * nums[1] + nums[2] * nums[2])
                return p
        end
        if kind == "r" then
                local p = exprP(text, "Rect", "rect")
                local mn = exprP(text .. ".Min", "Vector2", "Min")
                infoOf[mn].props.X, infoOf[mn].props.Y = nums[1], nums[2]
                local mx = exprP(text .. ".Max", "Vector2", "Max")
                infoOf[mx].props.X, infoOf[mx].props.Y = nums[3], nums[4]
                infoOf[p].props.Min, infoOf[p].props.Max = mn, mx
                infoOf[p].props.Width, infoOf[p].props.Height = nums[3] - nums[1], nums[4] - nums[2]
                return p
        end
        return nil
end

local function callP(text, hint, tname, force)
        if cfg.__superz_calls then
                local n = #cfg.__superz_calls
                cfg.__superz_calls[n + 1] = text
                if n >= 400 then table.remove(cfg.__superz_calls, 1) end
        end
        local p = newP({ kind = "call", tname = tname or "Instance", hint = hint })
        local st = emit({ call = text, res = p })
        if cfg.audit ~= false then
                real.pcall(function()
                        real.audit("call_result", { callee = text, result = real.auditValue(p), outcome = "simulated_proxy" })
                end)
        end
        infoOf[p].stmt = st
        if force then infoOf[p].forceVar = true end
        return p
end

local funcs = {}
local frec = {}
local nextFid = 0
local captureDepth = 0
local paramCounter = {}

local function paramName(base)
        paramCounter[base] = (paramCounter[base] or 0) + 1
        local n = paramCounter[base]
        return n == 1 and base or (base .. n)
end

local popTo

local lastThread = nil

local function runInBlock(block, fn, ...)
        block.isRoot = true
        real.insert(traceStack, block)
        local level = #traceStack
        captureDepth += 1
        local th = real.type(fn) == "thread" and fn or coroutine.create(fn)
        lastThread = th
        local res = table.pack(coroutine.resume(th, ...))
        if res[1] and res[2] == abort and coroutine.status(th) == "suspended" then res = { false, abort, n = 2 } end
        captureDepth -= 1
        popTo(level - 1)
        if not res[1] then
                local err = res[2]
                if err == abort then
                        real.insert(block.lines, { text = "-- [envlog] trace budget ran out here: " .. real.tostring(abortReason) })
                        real.error(abort, 0)
                elseif err == tamper then
                        if cfg.debug_tamper then real.print("[tamper-in-block]", debug.traceback()) end
                        real.insert(block.lines, { text = "-- [envlog] Luraph integrity-check thread (anti-tamper) suppressed here" })
                elseif err ~= loopMark then
                        real.insert(block.lines, { text = "-- [envlog] error: " .. real.gsub(real.tostring(err), "\n", " ") })
                        real.pcall(real.audit, "error", { context = "callback", message = real.gsub(real.tostring(err), "\n", " ") })
                end
        end
        return res
end

local deferred = {}
local handlers = {}
function captureFunction(fn, names, args, defer)
        local fid = funcs[fn]
        if fid and not defer then return "\3" .. fid .. "\4" end
        nextFid += 1
        fid = nextFid
        funcs[fn] = fid
        local rec = { params = {}, block = { lines = {}, waits = {} } }
        frec[fid] = rec
        if captureDepth >= maxDepth then
                real.insert(rec.block.lines, { text = "-- [envlog] nesting too deep" })
                return "\3" .. fid .. "\4"
        end
        local callArgs = {}
        if args then
                callArgs = args
                rec.params = { "..." }
        else
                names = names or { "...", "..." }
                local vararg = names[1] == "..."
                for i, nm in names do
                        local pn = vararg and paramName("arg") or paramName(nm)
                        rec.params[i] = pn
                        callArgs[i] = newP({ kind = "name", gen = true, name = pn, tname = "Instance" })
                end
        end
        if defer == "handler" then
                real.insert(handlers, { rec = rec, fn = fn, args = callArgs, n = args and args.n or #callArgs })
                return "\3" .. fid .. "\4"
        end
        if defer then
                local th = coroutine.create(fn)
                lastThread = th
                real.insert(deferred, { rec = rec, thread = th, args = callArgs, n = args and args.n or #callArgs, due = defer })
                return "\3" .. fid .. "\4"
        end
        local tryAlt = cfg._cbtry and not args
        cfg._cbtry = nil
        local res = runInBlock(rec.block, fn, real.unpack(callArgs, 1, args and args.n or #callArgs))
        if tryAlt and res[1] and #callArgs >= 1 then
                local alt = { lines = {}, waits = {} }
                local r2 = runInBlock(alt, fn, false, real.unpack(callArgs, 2, #callArgs))
                local clean = r2[1]
                for _, s in alt.lines do
                        if s.text and real.find(s.text, "-- [envlog]", 1, true) then clean = false end
                end
                if clean then
                        rec.alt = alt
                        local pn = "state"
                        infoOf[callArgs[1]].name = pn
                        rec.params[1] = pn
                end
        end
        return "\3" .. fid .. "\4"
end

local function runHandlers()
        deferred.running = true
        local i = 1
        while i <= #handlers do
                local h = handlers[i]
                i += 1
                popTo(1)
                local ok, err = real.pcall(runInBlock, h.rec.block, h.fn, real.unpack(h.args, 1, h.n))
                if not ok and err == abort then return end
        end
end

local function runDeferred()
        deferred.running = true
        while #deferred > 0 do
                table.sort(deferred, function(a, b) return a.due < b.due end)
                local d = real.remove(deferred, 1)
                if coroutine.status(d.thread) == "suspended" then
                        local ok, err = real.pcall(runInBlock, d.rec.block, d.thread, real.unpack(d.args, 1, d.n))
                        if not ok and err == abort then return end
                else
                        real.insert(d.rec.block.lines, { text = "-- [envlog] cancelled before it ran" })
                end
        end
end

function popTo(level)
        while #traceStack > level do
                local b = traceStack[#traceStack]
                traceStack[#traceStack] = nil
                if b.onClose then b.onClose() end
        end
end

local function iterProxy(p, how)
        local state = 0
        local kp, vp
        return function()
                state += 1
                if state == 1 then
                        local b = { lines = {}, waits = {} }
                        kp = newP({ kind = "name", gen = true, name = paramName(how == "ipairs" and "i" or "k"), tname = "number" })
                        vp = newP({ kind = "name", gen = true, name = paramName("v"), tname = "Instance" })
                        local header = "for " .. tok(kp) .. ", " .. tok(vp) .. " in " ..
                                (how and (how .. "(" .. tok(p) .. ")") or tok(p)) .. " do"
                        emit({ header = header, block = b })
                        real.insert(traceStack, b)
                        b.level = #traceStack
                        return kp, vp
                end
                for i = #traceStack, 1, -1 do
                        if traceStack[i].level == i and traceStack[i].header == nil then
                        end
                end
                popTo(#traceStack - 1)
                return nil
        end
end

local function normalize(block, from, to, baseId, baseFid)
        local parts = {}
        for i = from, to do
                local s = block.lines[i]
                local text = s.text or s.call or s.header or ""
                text = real.gsub(text, "\1(%d+)\2", function(id)
                        id = real.tonumber(id)
                        return id >= baseId and ("\1r" .. (id - baseId) .. "\2") or nil
                end)
                text = real.gsub(text, "\3(%d+)\4", function(id)
                        id = real.tonumber(id)
                        return id >= baseFid and ("\3r" .. (id - baseFid) .. "\4") or nil
                end)
                parts[#parts + 1] = text
        end
        return real.concat(parts, "\n")
end

local function onWait()
        local b = curBlock()
        local w = b.waits
        real.insert(w, { line = #b.lines, id = nextId, fid = nextFid })
        local n = #w
        if n >= 3 then
                local a, m, c = w[n - 2], w[n - 1], w[n]
                if c.line - m.line == m.line - a.line then
                        local s1 = normalize(b, a.line + 1, m.line, a.id, a.fid)
                        local s2 = normalize(b, m.line + 1, c.line, m.id, m.fid)
                        if s1 == s2 then
                                for _ = m.line + 1, c.line do
                                        real.remove(b.lines)
                                end
                                real.insert(b.lines, { text = "-- [envlog] the statements above repeat forever (loop)" })
                                b.stopped = 0
                                real.error(loopMark, 0)
                        end
                end
        end
        local root, rootLevel = nil, 1
        for i = #traceStack, 1, -1 do
                if traceStack[i].isRoot or i == 1 then root, rootLevel = traceStack[i], i; break end
        end
        root.tape = root.tape or {}
        root.marks = root.marks or {}
        local marks = root.marks
        real.insert(marks, { pos = #root.tape, id = nextId, fid = nextFid, depth = #traceStack, block = b })
        local nm = #marks
        if nm >= 3 then
                local m1, m2, m3 = marks[nm - 2], marks[nm - 1], marks[nm]
                local k = m2.pos - m1.pos
                if cfg.debug_loops then real.print("[loop marks]", m1.pos, m2.pos, m3.pos, m1.depth, m2.depth, m3.depth) end
                if k > 0 and m3.pos - m2.pos == k and m3.depth > m2.depth then
                        local function seg(from, to, baseId, baseFid)
                                local order, n = {}, 0
                                local function path(q, d)
                                        local qi = q and infoOf[q]
                                        if not qi or d > 12 then return "?" end
                                        if qi.kind == "name" and not qi.gen then return qi.name or "?" end
                                        if qi.kind == "index" and qi.parent then return path(qi.parent, d + 1) .. "." .. real.tostring(qi.key) end
                                        if not order[q] then n += 1; order[q] = n end
                                        return "#" .. order[q]
                                end
                                local parts = {}
                                for i = from, to do
                                        local st = root.tape[i].stmt
                                        local text = st.text or st.call or st.header or ""
                                        if st.res and isP(st.res) then text = text .. " ->" .. path(st.res, 0) end
                                        text = real.gsub(text, "\1(%d+)\2", function(id)
                                                return "\1" .. path(byId[real.tonumber(id)], 0) .. "\2"
                                        end)
                                        text = real.gsub(text, "\3(%d+)\4", function(id)
                                                id = real.tonumber(id)
                                                return id >= baseFid and ("\3r" .. (id - baseFid) .. "\4") or nil
                                        end)
                                        parts[#parts + 1] = text
                                end
                                return real.concat(parts, "\n")
                        end
                        local sA, sB = seg(m1.pos + 1, m2.pos, m1.id, m1.fid), seg(m2.pos + 1, m3.pos, m2.id, m2.fid)
                        if cfg.debug_loops and sA ~= sB then real.print("[loop A]\n" .. sA .. "\n[loop B]\n" .. sB) end
                        if sA == sB then
                                for i = m3.pos, m2.pos + 1, -1 do
                                        local e = root.tape[i]
                                        if e.block.lines[#e.block.lines] == e.stmt then real.remove(e.block.lines) end
                                        root.tape[i] = nil
                                end
                                popTo(m1.depth)
                                local home = curBlock()
                                local w = root.tape[m2.pos]
                                if w and w.block ~= home and w.block.lines[#w.block.lines] == w.stmt then
                                        real.remove(w.block.lines)
                                        real.insert(home.lines, w.stmt)
                                end
                                real.insert(home.lines, { text = "-- [envlog] the statements above repeat forever (loop)" })
                                home.stopped = 0
                                real.error(loopMark, 0)
                        end
                end
        end
        if n > maxWaits then
                real.insert(b.lines, { text = "-- [envlog] stopped after " .. maxWaits .. " waits" })
                b.stopped = 0
                real.error(loopMark, 0)
        end
end

local datatypes = {
        Vector3 = 1, Vector2 = 1, Vector3int16 = 1, Vector2int16 = 1, CFrame = 1, Color3 = 1,
        UDim = 1, UDim2 = 1, BrickColor = 1, TweenInfo = 1, NumberRange = 1, NumberSequence = 1,
        NumberSequenceKeypoint = 1, ColorSequence = 1, ColorSequenceKeypoint = 1, Ray = 1,
        Rect = 1, Region3 = 1, Region3int16 = 1, PhysicalProperties = 1, Font = 1,
        DateTime = 1, Axes = 1, Faces = 1, PathWaypoint = 1, SharedTable = 1, OverlapParams = 1,
        RaycastParams = 1, CatalogSearchParams = 1, DockWidgetPluginGuiInfo = 1, Path2DControlPoint = 1,
        Content = 1, SecurityCapabilities = 1, FloatCurveKey = 1, RotationCurveKey = 1, ValueCurveKey = 1,
        CFrameCurveKey = 1, UniqueId = 1,
}

local signalParams = {
        PlayerAdded = { "player" }, PlayerRemoving = { "player" },
        CharacterAdded = { "character" }, CharacterRemoving = { "character" }, CharacterAppearanceLoaded = { "character" },
        Touched = { "hit" }, TouchEnded = { "hit" },
        InputBegan = { "input", "gameProcessed" }, InputEnded = { "input", "gameProcessed" },
        InputChanged = { "input", "gameProcessed" },
        Heartbeat = { "deltaTime" }, RenderStepped = { "deltaTime" }, PreSimulation = { "deltaTime" },
        PostSimulation = { "deltaTime" }, PreRender = { "deltaTime" }, Stepped = { "time", "deltaTime" },
        ChildAdded = { "child" }, ChildRemoved = { "child" },
        DescendantAdded = { "descendant" }, DescendantRemoving = { "descendant" },
        Changed = { "value" }, HealthChanged = { "health" }, Chatted = { "message" },
        FocusLost = { "enterPressed", "inputObject" }, Triggered = { "player" },
        PromptTriggered = { "prompt", "player" }, PromptButtonHoldBegan = { "prompt", "player" },
        Idled = { "idleTime" }, MouseButton1Click = {}, MouseButton1Down = { "x", "y" },
        Activated = { "inputObject", "clickCount" }, Died = {}, Event = { "..." },
        OnClientEvent = { "..." }, OnClientInvoke = { "..." }, OnInvoke = { "..." },
        AncestryChanged = { "child", "parent" }, AttributeChanged = { "attribute" },
        StateChanged = { "old", "new" }, MoveToFinished = { "reached" }, Completed = { "playbackState" },
}

local classHint = {
        GetChildren = "children", GetDescendants = "descendants", GetPlayers = "players",
        GetTouchingParts = "parts", GetPartsInPart = "parts", GetPartBoundsInBox = "parts",
        GetPartBoundsInRadius = "parts", GetTagged = "tagged", GetAttributes = "attributes",
        GetPlayingAnimationTracks = "tracks", GetConnectedParts = "parts", GetJoints = "joints",
        GetChildrenOfClass = "children",
}
for k, v in {
        JSONEncode = "json", JSONDecode = "data", HttpGet = "response", HttpGetAsync = "response",
        GetAsync = "response", PostAsync = "response", RequestAsync = "response",
        Inverse = "inverse", ToWorldSpace = "cframe", ToObjectSpace = "cframe",
        Raycast = "raycastResult", GetMouse = "mouse", LoadAnimation = "track",
        InvokeServer = "response", Clone = "clone",
        GetPropertyChangedSignal = "changedSignal", GetAttribute = "attribute",
        GenerateGUID = "guid", UrlEncode = "encoded", Notify = "notification",
} do
        classHint[k] = v
end
for _, n in { "Window", "Tab", "Section", "Toggle", "Button", "Slider", "Dropdown", "Input",
        "Keybind", "Colorpicker", "Paragraph", "Dialog", "Label", "Textbox", "Divider", "Popup",
        "Code", "Group", "Page", "Category", "Checkbox", "ColorPicker", "TextBox" } do
        classHint[n] = n
end

local serviceCache = {}
local gameProxy
local workspaceProxy
local urls = {}
local remotes = {}

local function methodName(info)
        if info.kind == "index" and real.type(info.key) == "string" then return info.key end
        return nil
end

local function remember(list, v)
        if not list[v] then
                list[v] = true
                real.insert(list, v)
        end
end

local function instName(p)
        local v = infoOf[p].props.Name
        if real.type(v) == "string" then return v end
        return infoOf[p].className or "Instance"
end
local function kidsOf(p)
        local info = infoOf[p]
        info.kids = info.kids or {}
        return info.kids
end
local function setParent(child, parent)
        local ci = infoOf[child]
        local old = ci.props.Parent
        if isP(old) then
                local list = kidsOf(old)
                for i = #list, 1, -1 do
                        if list[i] == child then real.remove(list, i) end
                end
        end
        if isP(parent) then real.insert(kidsOf(parent), child) end
        ci.props.Parent = parent
        local rc = realValues[child]
        if rc ~= nil and real.typeof(rc) == "Instance" then
                local rp = isP(parent) and realValues[parent] or nil
                real.pcall(function() rc.Parent = (real.typeof(rp) == "Instance") and rp or nil end)
        end
end
local function findKid(p, name, recursive)
        for _, c in kidsOf(p) do
                if instName(c) == name then return c end
        end
        if recursive then
                for _, c in kidsOf(p) do
                        local r = findKid(c, name, true)
                        if r then return r end
                end
        end
        return nil
end
local function descendants(p, out)
        for _, c in kidsOf(p) do
                real.insert(out, c)
                descendants(c, out)
        end
        return out
end
local function destroyInst(p)
        local info = infoOf[p]
        if info.destroyed then return end
        for _, c in table.clone(kidsOf(p)) do destroyInst(c) end
        if isP(info.props.Parent) then setParent(p, nil) end
        info.props.Parent = nil
        info.destroyed = true
        local r = realValues[p]
        if r ~= nil and real.typeof(r) == "Instance" then real.pcall(r.Destroy, r) end
end
function hub.isClassA(cls, want)
        local c = cls
        local guard = 0
        while c and guard < 32 do
                guard += 1
                if c == want then return true end
                c = api.classes[c] and api.classes[c].super
        end
        return want == "Instance" or want == "Object"
end
function hub.cloneInst(root, text)
        local ri = infoOf[root]
        if not ri or ri.props.Archivable == false then return nil end
        local cmap = {}
        local function rec(src, newPar)
                local si = infoOf[src]
                local cp
                if src == root then
                        cp = callP(text, "clone")
                else
                        cp = newP({ kind = "expr", text = tok(newPar) .. ":FindFirstChild(" .. quote(real.tostring(si.props.Name or si.className or "Child")) .. ")", tname = "Instance", hint = si.className or "clone" })
                end
                cmap[src] = cp
                local ci = infoOf[cp]
                ci.created = true
                ci.className = si.className
                ci.kids = {}
                ci.modelScale = si.modelScale
                if si.attrs then ci.attrs = table.clone(si.attrs) end
                for k, v in real.pairs(si.props) do
                        if k ~= "Parent" then ci.props[k] = v end
                end
                if newPar then setParent(cp, newPar) end
                for _, child in kidsOf(src) do
                        local chi = infoOf[child]
                        if chi and chi.props.Archivable ~= false then
                                rec(child, cp)
                        end
                end
                return cp
        end
        local top = rec(root, nil)
        for _, cp in real.pairs(cmap) do
                local ci = infoOf[cp]
                for k, v in real.pairs(ci.props) do
                        if cmap[v] ~= nil then ci.props[k] = cmap[v] end
                end
        end
        return top
end
function hub.attParentWorldCF(p)
        local par = infoOf[p] and infoOf[p].props.Parent
        if isP(par) then
                local pi = infoOf[par]
                if pi.className == "Attachment" or pi.className == "Bone" then
                        return par.WorldCFrame
                end
                if pi.props.CFrame then return pi.props.CFrame end
        end
        return scriptEnv.CFrame.identity
end
function hub.modelBounds(self)
        local f32 = hub.p2d.f32
        local minX, minY, minZ = math.huge, math.huge, math.huge
        local maxX, maxY, maxZ = -math.huge, -math.huge, -math.huge
        local found = false
        for _, d in descendants(self, {}) do
                local di = infoOf[d]
                if di and hub.isClassA(di.className, "BasePart") then
                        found = true
                        local cf = di.props.CFrame or scriptEnv.CFrame.identity
                        local sz = di.props.Size or vector.create(4, 1.2, 2)
                        local hx, hy, hz = sz.X * 0.5, sz.Y * 0.5, sz.Z * 0.5
                        for sx = -1, 1, 2 do
                                for sy = -1, 1, 2 do
                                        for szs = -1, 1, 2 do
                                                local wp = cf * vector.create(sx * hx, sy * hy, szs * hz)
                                                if wp.X < minX then minX = wp.X end
                                                if wp.Y < minY then minY = wp.Y end
                                                if wp.Z < minZ then minZ = wp.Z end
                                                if wp.X > maxX then maxX = wp.X end
                                                if wp.Y > maxY then maxY = wp.Y end
                                                if wp.Z > maxZ then maxZ = wp.Z end
                                        end
                                end
                        end
                end
        end
        if not found then return scriptEnv.CFrame.identity, vector.create(0, 0, 0) end
        local ext = vector.create(f32(maxX - minX), f32(maxY - minY), f32(maxZ - minZ))
        local ctr = vector.create(f32((minX + maxX) * 0.5), f32((minY + maxY) * 0.5), f32((minZ + maxZ) * 0.5))
        local pp = infoOf[self].props.PrimaryPart
        local rot = (isP(pp) and infoOf[pp].props.CFrame and infoOf[pp].props.CFrame.Rotation) or scriptEnv.CFrame.identity
        return rot + ctr, ext
end
function hub.guiScale(p)
        local sc = 1
        local cur = p
        while isP(cur) do
                for _, c in kidsOf(cur) do
                        if infoOf[c] and infoOf[c].className == "UIScale" then
                                sc = sc * (real.tonumber(infoOf[c].props.Scale) or 1)
                        end
                end
                cur = infoOf[cur].props.Parent
        end
        return sc
end
function hub.guiUnscaledSize(p)
        if not isP(p) or not infoOf[p] or infoOf[p].className == "ScreenGui" then return 0, 0 end
        local pw, ph = hub.guiUnscaledSize(infoOf[p].props.Parent)
        local sz = infoOf[p].props.Size
        if isP(sz) and realValues[sz] then
                local r = realValues[sz]
                return r.X.Scale * pw + r.X.Offset, r.Y.Scale * ph + r.Y.Offset
        end
        return 0, 0
end
local runserviceBool = { IsStudio = false, IsServer = false, IsClient = true, IsRunning = true,
        IsRunMode = false, IsEdit = false }

local noNativeMethod = { Clone = 1, Destroy = 1, Remove = 1, GetChildren = 1, GetDescendants = 1,
        FindFirstChild = 1, WaitForChild = 1, FindFirstChildOfClass = 1, FindFirstChildWhichIsA = 1,
        FindFirstAncestor = 1, FindFirstAncestorOfClass = 1, FindFirstAncestorWhichIsA = 1, FindFirstDescendant = 1,
        ClearAllChildren = 1, IsA = 1, Connect = 1, Once = 1, Wait = 1, GetPropertyChangedSignal = 1,
        GetAttributeChangedSignal = 1, IsDescendantOf = 1, IsAncestorOf = 1, GetFullName = 1,
        SetAttribute = 1, GetAttribute = 1, GetAttributes = 1, GetMass = 1, GetPivot = 1, PivotTo = 1,
        GetBoundingBox = 1, GetExtentsSize = 1, GetScale = 1, ScaleTo = 1 }
do
        local f32Buf = buffer.create(4)
        local function f32(x)
                buffer.writef32(f32Buf, 0, x)
                return buffer.readf32(f32Buf, 0)
        end
        local p2dModel = {}
        hub.p2d = p2dModel
        p2dModel.f32 = f32

        local function num(x)
                if real.type(x) == "number" then return x end
                return 0
        end
        function p2dModel.udim2(p)
                if not isP(p) then return nil end
                local inf = infoOf[p]
                local c = inf.ctor
                if c and c.ns == "UDim2" then
                        local a = c.args
                        if c.fn == "new" then
                                if isP(a[1]) or isP(a[2]) then
                                        local x, y = infoOf[a[1]] and infoOf[a[1]].ctor, infoOf[a[2]] and infoOf[a[2]].ctor
                                        return { x and num(x.args[1]) or 0, x and num(x.args[2]) or 0, y and num(y.args[1]) or 0,
                                                y and num(y.args[2]) or 0 }
                                end
                                return { num(a[1]), num(a[2]), num(a[3]), num(a[4]) }
                        elseif c.fn == "fromScale" then
                                return { num(a[1]), 0, num(a[2]), 0 }
                        elseif c.fn == "fromOffset" then
                                return { 0, num(a[1]), 0, num(a[2]) }
                        end
                        return nil
                end
                local propX, propY = inf.props and inf.props.X, inf.props and inf.props.Y
                if isP(propX) and isP(propY) then
                        local xp, yp = infoOf[propX].props, infoOf[propY].props
                        return { num(xp.Scale), num(xp.Offset), num(yp.Scale), num(yp.Offset) }
                end
                return nil
        end
        function p2dModel.frameSize(path)
                local parent = infoOf[path].props and infoOf[path].props.Parent
                if not isP(parent) then return nil end
                local sz = infoOf[parent].props and infoOf[parent].props.Size
                local u = sz and p2dModel.udim2(sz)
                if not u then return nil end
                if u[1] ~= 0 or u[3] ~= 0 then return nil end
                return u[2], u[4]
        end
        local function resolve(u, frameW, frameH)
                return f32(f32(u[1] * frameW) + u[2]), f32(f32(u[3] * frameH) + u[4])
        end
        function p2dModel.segments(cps, frameW, frameH)
                local pts = {}
                for i, cp in real.ipairs(cps) do
                        local c = isP(cp) and infoOf[cp].ctor
                        if not c or c.ns ~= "Path2DControlPoint" then return nil end
                        local zero = { 0, 0, 0, 0 }
                        local pos = c.args.n >= 1 and p2dModel.udim2(c.args[1]) or zero
                        local left = c.args.n >= 2 and p2dModel.udim2(c.args[2]) or zero
                        local right = c.args.n >= 3 and p2dModel.udim2(c.args[3]) or zero
                        if not pos or not left or not right then return nil end
                        local px, py = resolve(pos, frameW, frameH)
                        local lx, ly = resolve(left, frameW, frameH)
                        local rx, ry = resolve(right, frameW, frameH)
                        pts[i] = { px, py, lx, ly, rx, ry }
                end
                local segs = {}
                for i = 1, #pts - 1 do
                        local a, b = pts[i], pts[i + 1]
                        local s = { a[1], a[2] }
                        if a[5] ~= 0 or a[6] ~= 0 then
                                real.insert(s, f32(a[1] + a[5])); real.insert(s, f32(a[2] + a[6]))
                        end
                        if b[3] ~= 0 or b[4] ~= 0 then
                                real.insert(s, f32(b[1] + b[3])); real.insert(s, f32(b[2] + b[4]))
                        end
                        real.insert(s, b[1]); real.insert(s, b[2])
                        segs[i] = p2dModel.coeffs(s)
                end
                return segs
        end
        function p2dModel.coeffs(s)
                local n = #s // 2
                local x0, y0 = s[1], s[2]
                local c = { n = n, x0 = x0, y0 = y0 }
                if n == 2 then
                        c.c1x, c.c1y = f32(s[3] - x0), f32(s[4] - y0)
                elseif n == 3 then
                        local x1, y1, x2, y2 = s[3], s[4], s[5], s[6]
                        c.c1x, c.c1y = f32(f32(x1 - x0) * 2), f32(f32(y1 - y0) * 2)
                        c.c2x, c.c2y = f32(f32(x0 - f32(x1 * 2)) + x2), f32(f32(y0 - f32(y1 * 2)) + y2)
                else
                        local x1, y1, x2, y2, x3, y3 = s[3], s[4], s[5], s[6], s[7], s[8]
                        c.c1x, c.c1y = f32(f32(x1 - x0) * 3), f32(f32(y1 - y0) * 3)
                        c.c2x = f32(f32(f32(x0 - f32(x1 * 2)) + x2) * 3)
                        c.c2y = f32(f32(f32(y0 - f32(y1 * 2)) + y2) * 3)
                        c.c3x = f32(f32(f32(x3 - x0) + f32(x1 * 3)) - f32(x2 * 3))
                        c.c3y = f32(f32(f32(y3 - y0) + f32(y1 * 3)) - f32(y2 * 3))
                end
                return c
        end
        function p2dModel.eval(c, u)
                if c.n == 2 then
                        return f32(c.x0 + f32(c.c1x * u)), f32(c.y0 + f32(c.c1y * u))
                elseif c.n == 3 then
                        return f32(c.x0 + f32(f32(c.c1x + f32(c.c2x * u)) * u)), f32(c.y0 + f32(f32(c.c1y + f32(c.c2y * u)) * u))
                end
                local ix, iy = f32(c.c2x + f32(c.c3x * u)), f32(c.c2y + f32(c.c3y * u))
                return f32(c.x0 + f32(f32(c.c1x + f32(ix * u)) * u)), f32(c.y0 + f32(f32(c.c1y + f32(iy * u)) * u))
        end
        function p2dModel.tangent(c, u)
                if c.n == 2 then return c.c1x, c.c1y end
                if c.n == 3 then
                        local k = f32(u * 2)
                        return f32(c.c1x + f32(c.c2x * k)), f32(c.c1y + f32(c.c2y * k))
                end
                local k = f32(3 * u)
                return f32(c.c1x + f32(u * f32(f32(c.c2x * 2) + f32(c.c3x * k)))),
                        f32(c.c1y + f32(u * f32(f32(c.c2y * 2) + f32(c.c3y * k))))
        end
        local function dist(ax, ay, bx, by)
                local dx, dy = f32(bx - ax), f32(by - ay)
                return f32(math.sqrt(f32(f32(dx * dx) + f32(dy * dy))))
        end
        p2dModel.dist = dist
        local tol = f32(1e-5)
        function p2dModel.eval0(c, u)
                if c.n == 2 then
                        return f32(c.c1x * u), f32(c.c1y * u)
                elseif c.n == 3 then
                        return f32(f32(c.c1x + f32(c.c2x * u)) * u), f32(f32(c.c1y + f32(c.c2y * u)) * u)
                end
                local ix, iy = f32(c.c2x + f32(c.c3x * u)), f32(c.c2y + f32(c.c3y * u))
                return f32(f32(c.c1x + f32(ix * u)) * u), f32(f32(c.c1y + f32(iy * u)) * u)
        end
        function p2dModel.seglen(c)
                local function rec(t0, t1, x0, y0, x1, y1, depth)
                        local tm = f32(f32(t0 + t1) * 0.5)
                        local xm, ym = p2dModel.eval0(c, tm)
                        local a = dist(x0, y0, x1, y1)
                        local b = f32(dist(x0, y0, xm, ym) + dist(xm, ym, x1, y1))
                        if depth >= 30 or f32(b - a) < tol then return b end
                        return f32(rec(t0, tm, x0, y0, xm, ym, depth + 1) + rec(tm, t1, xm, ym, x1, y1, depth + 1))
                end
                local x0, y0 = p2dModel.eval0(c, 0)
                local x1, y1 = p2dModel.eval0(c, 1)
                return rec(0, 1, x0, y0, x1, y1, 0)
        end
        local sixth = f32(1 / 6)
        function p2dModel.arcU(c, s)
                local d2x, d2y = f32(c.c2x * 2), f32(c.c2y * 2)
                local d3x, d3y
                if c.n == 4 then d3x, d3y = f32(c.c3x * 3), f32(c.c3y * 3) end
                local function inv(u)
                        local dx, dy
                        if c.n == 3 then
                                dx, dy = f32(c.c1x + f32(d2x * u)), f32(c.c1y + f32(d2y * u))
                        else
                                dx = f32(c.c1x + f32(u * f32(d2x + f32(u * d3x))))
                                dy = f32(c.c1y + f32(u * f32(d2y + f32(u * d3y))))
                        end
                        return math.sqrt(f32(f32(dx * dx) + f32(dy * dy)))
                end
                local h = f32(s / 32)
                local u = 0
                for _ = 1, 32 do
                        local k1 = f32(h / f32(inv(u)))
                        local k2 = f32(h / f32(inv(f32(u + f32(k1 * 0.5)))))
                        local k3 = f32(h / f32(inv(f32(u + f32(k2 * 0.5)))))
                        local k4 = f32(h / f32(inv(f32(u + k3))))
                        u = f32(u + f32(f32(f32(k1 + f32(2 * f32(k2 + k3))) + k4) * sixth))
                end
                return u
        end
        function p2dModel.length(segs)
                local t = 0
                for _, c in real.ipairs(segs) do
                        c.len = c.len or p2dModel.seglen(c)
                        t = f32(t + c.len)
                end
                return t
        end
        function p2dModel.locate(segs, t)
                t = f32(t)
                if t < 0 then t = 0 elseif t > 1 then t = 1 end
                local n = #segs
                local x = f32(t * n)
                local k = math.min(math.floor(x), n - 1)
                return segs[k + 1], f32(x - k)
        end
        function p2dModel.locateArc(segs, t)
                t = f32(t)
                if t < 0 then t = 0 elseif t > 1 then t = 1 end
                local curveLen = p2dModel.length(segs)
                local s = f32(t * curveLen)
                for _, c in real.ipairs(segs) do
                        if s <= c.len then
                                if c.n == 2 then return c, f32(s / c.len) end
                                return c, p2dModel.arcU(c, s)
                        end
                        s = f32(s - c.len)
                end
                return segs[1], 0
        end
        function p2dModel.answer(path, name, t)
                local inf = infoOf[path]
                local segs = inf.p2dSegs
                if not segs then return nil end
                local frameW, frameH = inf.p2dW, inf.p2dH
                if name == "GetLength" then
                        return real.fmt("n:%.17g", p2dModel.length(segs))
                elseif name == "GetBoundingRect" then
                        return "r:0,0,0,0"
                end
                if real.type(t) ~= "number" then return nil end
                local c, u
                if name == "GetPositionOnCurve" or name == "GetTangentOnCurve" then
                        c, u = p2dModel.locate(segs, t)
                elseif name == "GetPositionOnCurveArcLength" or name == "GetTangentOnCurveArcLength" then
                        c, u = p2dModel.locateArc(segs, t)
                end
                if not c then return nil end
                if real.find(name, "Position", 1, true) then
                        local x, y = p2dModel.eval(c, u)
                        return real.fmt("u:%.17g,0,%.17g,0", f32(x / frameW), f32(y / frameH))
                end
                local x, y = p2dModel.tangent(c, u)
                return real.fmt("v:%.17g,%.17g", x, y)
        end
end

local function onCall(p, ...)
        checkBudget()
        local info = infoOf[p]
        if cfg.ptrace then
                local a2 = real.select(2, ...)
                real.print("[call]", info.name or info.hint or info.key, real.select("#", ...), real.type(a2) == "string" and a2 or "")
        end
        local n = real.select("#", ...)
        local first = ...
        local name = methodName(info)
        local isMethod = info.kind == "index" and n >= 1 and first == info.parent and isP(first)
        local calleeText
        local args
        if isMethod then
                calleeText = tok(info.parent) .. ":" .. (isIdent(name) and name or "__call")
                args = table.pack(real.select(2, ...))
        else
                calleeText = tok(p)
                args = table.pack(...)
        end
        local a1 = args[1]

        if cfg.audit ~= false then
                real.pcall(function()
                        local auditArgs = {}
                        local redact = real.auditRedactKey(name)
                        for i = 1, args.n do
                                auditArgs[i] = redact and "[REDACTED]" or real.auditValue(args[i])
                        end
                        real.audit("call", { callee = calleeText, args = auditArgs, source = "proxy" })
                end)
        end

        if cfg.falsy and real.type(name) == "string" and real.find("," .. cfg.falsy .. ",", "," .. name .. ",", 1, true) then
                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ") --> false" })
                return false
        end

        if info.ns and datatypes[info.ns] then
                local dp = exprP(calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")", info.ns)
                infoOf[dp].ctor = { ns = info.ns, fn = name, args = args }
                return dp
        end

        if name == "Connect" or name == "Once" or name == "ConnectParallel" then
                local sig = infoOf[info.parent]
                local sigName = sig and methodName(sig)
                if cfg.input_text ~= nil then
                        for _, bp in real.pairs(byId) do
                                local bi = infoOf[bp]
                                if bi.created and bi.className == "TextBox" and bi.props.Text ~= cfg.input_text then
                                        bi.props.Text = cfg.input_text
                                        local rb = realValues[bp]
                                        if rb ~= nil then real.pcall(function() rb.Text = cfg.input_text end) end
                                end
                        end
                end
                local fnTok = real.type(a1) == "function" and captureFunction(a1, signalParams[sigName] or { "..." }, nil, "handler") or fmt(a1)
                local conn = callP(calleeText .. "(" .. fnTok .. ")", "connection", "RBXScriptConnection")
                infoOf[conn].props.Connected = true
                return conn
        end
        if name == "Wait" and isMethod then
                if not deferred.running and deferred.runner and coroutine.running() ~= deferred.runner and coroutine.isyieldable() then
                        coroutine.yield()
                end
                local sp = signalParams[methodName(infoOf[info.parent])]
                if sp and (sp[1] == "deltaTime" or sp[2] == "deltaTime") then
                        emit({ text = calleeText .. "()" })
                        onWait()
                        if sp[2] == "deltaTime" then return 1, 1 / 60 end
                        return 1 / 60
                end
                callP(calleeText .. "()", "result")
                local r = byId[nextId]
                onWait()
                return r
        end

        if name == "GetService" or name == "FindService" then
                local svc = a1
                if real.type(svc) == "string" and serviceCache[svc] then
                        return serviceCache[svc]
                end
                if real.type(svc) == "string" and not api.classes[svc] then
                        if name == "FindService" then return nil end
                        real.error(real.fmt("'%s' is not a valid Service name", svc), 0)
                end
                local r = callP(calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")", real.type(svc) == "string" and svc or "service", "Instance", true)
                if real.type(svc) == "string" and api.classes[svc] then
                        infoOf[r].className = svc
                        infoOf[r].props.Name = svc
                        infoOf[r].props.ClassName = svc
                        infoOf[r].props.Parent = gameProxy
                end
                if real.type(svc) == "string" then serviceCache[svc] = r end
                return r
        end

        if name == "GetSecret" and isMethod then
                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ") -- errors" })
                real.error("Can't find secret with given key", 0)
        end

        if (name == "SetTeleportSetting" or name == "GetTeleportSetting") and isMethod then
                local store = infoOf[info.parent].tpSettings or {}
                infoOf[info.parent].tpSettings = store
                if name == "SetTeleportSetting" then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        if args[1] ~= nil then store[args[1]] = args[2] end
                        return
                end
                return args[1] ~= nil and store[args[1]] or nil
        end

        local self = isMethod and info.parent or nil
        local sinfo = self and infoOf[self]
        if sinfo and sinfo.tname == "RBXScriptConnection" and name == "Disconnect" then
                emit({ text = calleeText .. "()" })
                sinfo.props.Connected = false
                return
        end
        if sinfo and sinfo.tname == "Enum" and sinfo.enumName then
                local e = api.enums[sinfo.enumName]
                if name == "GetEnumItems" then
                        local list = {}
                        for _, it in e.items do real.insert(list, enumItem(sinfo.enumName, it.Name)) end
                        return list
                elseif name == "FromName" then
                        return (real.type(a1) == "string" and e.byName[a1]) and enumItem(sinfo.enumName, a1) or nil
                elseif name == "FromValue" then
                        local it = e.byValue[a1]
                        return it and enumItem(sinfo.enumName, it.Name) or nil
                end
        end
        if sinfo and sinfo.tname == "EnumItem" and name == "IsA" then
                return a1 == sinfo.enumName
        end
        if self and runserviceBool[name] ~= nil then
                return runserviceBool[name]
        end
        if sinfo and (sinfo.created or sinfo.kids) then
                if name == "GetChildren" then
                        emit({ text = calleeText .. "()" })
                        return table.clone(kidsOf(self))
                elseif name == "GetDescendants" then
                        emit({ text = calleeText .. "()" })
                        return descendants(self, {})
                elseif (name == "FindFirstChild" or name == "WaitForChild") and real.type(a1) == "string" then
                        local found = findKid(self, a1, name == "FindFirstChild" and args[2] == true)
                        if found or sinfo.created then
                                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                                return found
                        end
                elseif name == "Destroy" then
                        emit({ text = calleeText .. "()" })
                        destroyInst(self)
                        return
                elseif name == "ClearAllChildren" then
                        emit({ text = calleeText .. "()" })
                        for _, c in table.clone(kidsOf(self)) do destroyInst(c) end
                        return
                elseif name == "IsA" and sinfo.created then
                        return hub.isClassA(sinfo.className, a1)
                elseif name == "IsDescendantOf" and sinfo.created and isP(a1) and infoOf[a1].created then
                        local cur = sinfo.props.Parent
                        while isP(cur) do
                                if cur == a1 then return true end
                                cur = infoOf[cur].props.Parent
                        end
                        return false
                elseif name == "IsAncestorOf" and sinfo.created and isP(a1) and infoOf[a1].created then
                        local cur = infoOf[a1].props.Parent
                        while isP(cur) do
                                if cur == self then return true end
                                cur = infoOf[cur].props.Parent
                        end
                        return false
                elseif name == "SetAttribute" and sinfo.created and real.type(a1) == "string" then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        sinfo.attrs = sinfo.attrs or {}
                        sinfo.attrs[a1] = args[2]
                        return
                elseif name == "GetAttribute" and sinfo.created and real.type(a1) == "string" then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        return sinfo.attrs and sinfo.attrs[a1] or nil
                elseif name == "GetAttributes" and sinfo.created then
                        emit({ text = calleeText .. "()" })
                        return sinfo.attrs and table.clone(sinfo.attrs) or {}
                elseif name == "Clone" and sinfo.created then
                        return hub.cloneInst(self, calleeText .. "()")
                elseif name == "GetMass" and sinfo.created and hub.isClassA(sinfo.className, "BasePart") then
                        emit({ text = calleeText .. "()" })
                        return self.Mass
                elseif name == "GetPivot" and sinfo.created and (hub.isClassA(sinfo.className, "BasePart") or sinfo.className == "Model") then
                        emit({ text = calleeText .. "()" })
                        if sinfo.className == "Model" then
                                local pp = sinfo.props.PrimaryPart
                                if isP(pp) then
                                        return (infoOf[pp].props.CFrame or scriptEnv.CFrame.identity) * (infoOf[pp].props.PivotOffset or scriptEnv.CFrame.identity)
                                end
                                local bcf = hub.modelBounds(self)
                                return bcf
                        end
                        return (sinfo.props.CFrame or scriptEnv.CFrame.identity) * (sinfo.props.PivotOffset or scriptEnv.CFrame.identity)
                elseif name == "PivotTo" and sinfo.created and isP(a1) and (hub.isClassA(sinfo.className, "BasePart") or sinfo.className == "Model") then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        if sinfo.className == "Model" then
                                local pp = sinfo.props.PrimaryPart
                                local oldPivot
                                if isP(pp) then
                                        oldPivot = (infoOf[pp].props.CFrame or scriptEnv.CFrame.identity) * (infoOf[pp].props.PivotOffset or scriptEnv.CFrame.identity)
                                else
                                        oldPivot = hub.modelBounds(self)
                                end
                                local delta = a1 * oldPivot:Inverse()
                                for _, d in descendants(self, {}) do
                                        local di = infoOf[d]
                                        if di and hub.isClassA(di.className, "BasePart") then
                                                local ncf = delta * (di.props.CFrame or scriptEnv.CFrame.identity)
                                                di.props.CFrame = ncf
                                                di.props.Position = ncf.Position
                                        end
                                end
                                return
                        end
                        local po = sinfo.props.PivotOffset or scriptEnv.CFrame.identity
                        local ncf = a1 * po:Inverse()
                        sinfo.props.CFrame = ncf
                        sinfo.props.Position = ncf.Position
                        return
                elseif name == "GetBoundingBox" and sinfo.created and sinfo.className == "Model" then
                        emit({ text = calleeText .. "()" })
                        return hub.modelBounds(self)
                elseif name == "GetExtentsSize" and sinfo.created and sinfo.className == "Model" then
                        emit({ text = calleeText .. "()" })
                        local _, ext = hub.modelBounds(self)
                        return ext
                elseif name == "GetScale" and sinfo.created and sinfo.className == "Model" then
                        emit({ text = calleeText .. "()" })
                        return sinfo.modelScale or 1
                elseif name == "ScaleTo" and sinfo.created and sinfo.className == "Model" and real.type(a1) == "number" then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        local f32 = hub.p2d.f32
                        local oldScale = sinfo.modelScale or 1
                        local newScale = f32(a1)
                        local ratio = f32(newScale / oldScale)
                        local pp = sinfo.props.PrimaryPart
                        local pivotCF
                        if isP(pp) then
                                pivotCF = (infoOf[pp].props.CFrame or scriptEnv.CFrame.identity) * (infoOf[pp].props.PivotOffset or scriptEnv.CFrame.identity)
                        else
                                pivotCF = hub.modelBounds(self)
                        end
                        local ppos = pivotCF.Position
                        for _, d in descendants(self, {}) do
                                local di = infoOf[d]
                                if di and hub.isClassA(di.className, "BasePart") then
                                        local sz = di.props.Size or vector.create(4, 1.2, 2)
                                        di.props.Size = sz * ratio
                                        local cf = di.props.CFrame or scriptEnv.CFrame.identity
                                        local np = ppos + (cf.Position - ppos) * ratio
                                        di.props.CFrame = (cf - cf.Position) + np
                                        di.props.Position = np
                                end
                        end
                        sinfo.modelScale = newScale
                        return
                end
        end
        if sinfo and sinfo.className == "TweenService" and name == "GetValue" then
                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                local f32 = hub.p2d.f32
                local x = f32(real.tonumber(a1) or 0)
                if x <= 0 then return 0 end
                if x >= 1 then return 1 end
                local es = isP(args[2]) and infoOf[args[2]].props.Name or args[2]
                local ed = isP(args[3]) and infoOf[args[3]].props.Name or args[3]
                local function base(t)
                        if es == "Linear" then return t end
                        if es == "Cubic" then return f32(f32(t * t) * t) end
                        if es == "Quart" then local t2 = f32(t * t) return f32(t2 * t2) end
                        if es == "Quint" then local t2 = f32(t * t) return f32(f32(t2 * t2) * t) end
                        return f32(t * t)
                end
                if ed == "In" then return base(x) end
                if ed == "InOut" then
                        if x < 0.5 then return f32(0.5 * base(f32(x * 2))) end
                        return f32(1 - f32(0.5 * base(f32(2 - f32(x * 2)))))
                end
                return f32(1 - base(f32(1 - x)))
        end
        if sinfo and sinfo.className == "TextService" and name == "GetTextSize" then
                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                local txt = real.tostring(a1 or "")
                local fs = real.tonumber(args[2]) or 14
                local fnm = isP(args[3]) and infoOf[args[3]].props.Name or real.tostring(args[3] or "Code")
                local fsz = args[4]
                local maxW = (isP(fsz) and realValues[fsz] and realValues[fsz].X) or 4096
                local mono = (fnm == "Code" or fnm == "Arcade" or fnm == "RobotoMono")
                local baseW = math.max(1, math.floor(fs * 0.6 + 0.5))
                local function charW(ch)
                        if mono then return baseW end
                        if ch == "i" or ch == "l" or ch == "I" or ch == "." or ch == " " then return math.max(1, math.floor(fs * 0.3)) end
                        if ch == "W" or ch == "M" then return math.max(baseW + 2, math.floor(fs * 0.85)) end
                        return baseW
                end
                local function strW(s)
                        local w = 0
                        for i = 1, #s do w += charW(real.sub(s, i, i)) end
                        return w
                end
                local maxLineW, numLines = 0, 0
                for line in string.gmatch(txt .. "\n", "([^\n]*)\n") do
                        local curW = 0
                        local firstWord = true
                        for word in string.gmatch(line, "%S+") do
                                local ww = strW(word)
                                local spw = firstWord and 0 or charW(" ")
                                if not firstWord and curW + spw + ww > maxW then
                                        if curW > maxLineW then maxLineW = curW end
                                        numLines += 1
                                        curW = ww
                                else
                                        curW += spw + ww
                                end
                                firstWord = false
                        end
                        if curW > maxLineW then maxLineW = curW end
                        numLines += 1
                end
                if numLines == 0 then numLines = 1 end
                return scriptEnv.Vector2.new(maxLineW, numLines * fs)
        end
        if name == "IsA" then
                local cls = sinfo and sinfo.className
                if real.type(cls) == "string" and real.type(a1) == "string" and api.classes[cls] then
                        return hub.isClassA(cls, a1)
                end
                return true
        end
        if name == "IsDescendantOf" or name == "IsAncestorOf" then
                if isP(a1) and isP(self) then
                        if a1 == self then return false end
                        if name == "IsDescendantOf" and self == gameProxy then return false end
                        if name == "IsAncestorOf" and a1 == gameProxy then return false end
                end
                return true
        end
        if name == "GetLogHistory" then
                return {}
        end

        if cfg.real_json and (name == "JSONEncode" or name == "JSONDecode") then
                local ok, out
                if name == "JSONEncode" then
                        ok, out = real.pcall(real.json.encode, args[1])
                else
                        ok, out = real.pcall(real.json.decode, a1)
                end
                if ok then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        return out
                end
        end
        if real.type(a1) == "string"
                and (name == "HttpGet" or name == "HttpGetAsync" or name == "GetAsync" or name == "RequestAsync") then
                local liveTries = 0
                while true do
                        local list = urls.__lrm_plant
                        if real.type(list) == "table" then
                                local served
                                for i = 1, #list do
                                        local plant = list[i]
                                        if real.type(plant) == "table" and real.type(plant.body) == "string" then
                                                local u = plant.url
                                                if u == nil or (real.type(u) == "string" and real.sub(a1, 1, #u) == u) then
                                                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                                                        comment(calleeText .. " -> canned via urls[" .. i .. "] ("
                                                                .. real.tostring(#plant.body) .. " bytes, .." .. real.sub(a1, -10) .. ")")
                                                        served = true
                                                        if name == "HttpGet" then return plant.body end
                                                        return { Success = true, StatusCode = 200,
                                                                Headers = plant.headers or {}, Body = plant.body }
                                                end
                                        end
                                end
                                _ = served
                        end
                        if cfg.http_map then
                                local hit = cfg.http_map["GET " .. a1] or cfg.http_map[a1]
                                if hit == nil then
                                        for k, v in real.next, cfg.http_map do
                                                if real.type(k) == "string" and #k > 1 and real.sub(k, #k, #k) == "*" then
                                                        local pfx = real.sub(k, 1, #k - 1)
                                                        if real.sub(a1, 1, #pfx) == pfx or ("GET " .. a1):sub(1, #pfx) == pfx then
                                                                hit = v
                                                                break
                                                        end
                                                end
                                        end
                                end
                                if hit then
                                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                                        comment(calleeText .. " -> canned " .. real.tostring(hit.status or 200)
                                                .. " (" .. real.tostring(#real.tostring(hit.body or "")) .. " bytes)")
                                        if name == "HttpGet" then return hit.body end
                                        return { Success = true, StatusCode = hit.status or 200,
                                                Headers = hit.headers or {}, Body = hit.body }
                                end
                        end
                        if real.find(a1, "luarmor", 1, true)
                                and cfg.serve and servePad and coroutine.isyieldable()
                                and liveTries < 4 then
                                liveTries += 1
                                real.print(markPrefix .. "NEEDFETCH " .. a1)
                                real.print(servePad)
                                coroutine.yield("__LRMRES " .. a1)
                        else
                                break
                        end
                end
        end
        if name == "GenerateGUID" and isMethod then
                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                local v1, v2, v3 = math.random(0, 2147483647), math.random(0, 2147483647), math.random(0, 2147483647)
                return string.format("%08x-%04x-4%03x-%04x-%04x%08x",
                        v1 % 4294967296,
                        v1 % 65536,
                        v2 % 4096,
                        (v3 % 16384) + 0x8000,
                        v2 % 65536, v3 % 4294967296)
        end
        if (name == "JSONEncode" or name == "JSONDecode") and isMethod then
                local j = cfg.__superz_json
                local ok, out
                if name == "JSONEncode" then
                        ok, out = real.pcall(j.encode, args[1])
                else
                        ok, out = real.pcall(j.decode, a1 or args[1])
                end
                if ok then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        return out
                end
        end
        if name == "GetClientId" and isMethod then
                emit({ text = calleeText .. "()" })
                return "6c1f8a20-4e2b-4c9d-9f3a-71b2d5e0a4c7"
        end
        if (name == "ComputeStringHash" or name == "ComputeBufferHash") and isMethod and real.sha256 then
                emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                local msg = a1
                if real.type(msg) == "buffer" then msg = buffer.tostring(msg) end
                local hex = real.sha256(real.tostring(msg or ""))
                local raw = real.gsub(hex, "..", function(cc) return string.char(real.tonumber(cc, 16)) end)
                if name == "ComputeBufferHash" then return buffer.fromstring(raw) end
                return raw
        end
        if (name == "HttpGet" or name == "HttpGetAsync" or name == "GetAsync") and real.type(a1) == "string" then
                remember(urls, a1)
                local szcanned = cfg.__superz_canned
                local hit = szcanned and (szcanned["GET " .. a1] or szcanned[a1])
                if hit then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        return hit.body
                end
        end

if name == "HttpGet" or name == "HttpGetAsync" or name == "HttpPost" or name == "HttpPostAsync"
                or name == "GetAsync" or name == "PostAsync" or name == "RequestAsync" then
                if real.type(a1) == "string" then remember(urls, a1) end
                return callP(calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")", "response", "string")
        end

        if name == "FireServer" or name == "InvokeServer" or name == "Fire" or name == "Invoke" then
                remember(remotes, info.parent)
        end

        if not native and sinfo and sinfo.className == "Path2D" and name == "SetControlPoints" then
                sinfo.p2dSegs = nil
                sinfo.p2dPoints = real.type(a1) == "table" and not isP(a1) and table.clone(a1) or nil
                sinfo.p2dSet = true
                local frameW, frameH = hub.p2d.frameSize(self)
                if cfg.p2d_debug then
                        local par = sinfo.props and sinfo.props.Parent
                        local sz = isP(par) and infoOf[par].props and infoOf[par].props.Size
                        real.print("P2DDBG W,H", frameW, frameH, "a1", real.type(a1), isP(a1), "parent", isP(par), "size", isP(sz),
                                isP(sz) and real.tostring(infoOf[sz].ctor and infoOf[sz].ctor.fn), isP(sz) and infoOf[sz].text)
                end
                if frameW and real.type(a1) == "table" and not isP(a1) then
                        local ok, segs = real.pcall(hub.p2d.segments, a1, frameW, frameH)
                        if cfg.p2d_debug then real.print("P2DDBG segments", ok, real.tostring(segs)) end
                        if ok and segs and #segs > 0 then
                                sinfo.p2dSegs, sinfo.p2dW, sinfo.p2dH = segs, frameW, frameH
                        end
                end
        end
        if not native and sinfo and sinfo.className == "Path2D" and sinfo.created then
                if name == "GetMaxControlPoints" then
                        emit({ text = calleeText .. "()" })
                        return 100
                elseif name == "GetControlPoints" and (sinfo.p2dPoints or not sinfo.p2dSet) then
                        emit({ text = calleeText .. "()" })
                        return table.clone(sinfo.p2dPoints or {})
                elseif (name == "GetLength" or name == "GetBoundingRect" or (real.type(name) == "string"
                        and real.find(name, "OnCurve", 1, true))) and not isP(sinfo.props.Parent) then
                        emit({ text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")" })
                        real.error("Attempting to use Path2D with invalid parent", 0)
                end
        end
        if not native and sinfo and sinfo.className == "Path2D" and real.type(name) == "string" and (name == "GetLength" or name == "GetBoundingRect" or real.find(name, "OnCurve", 1, true)) then
                local rec = __p2d and __p2d[p2dKey(name, args)]
                cfg.p2dlasthit = p2dKey(name, args)
                cfg.p2dhits = (cfg.p2dhits or 0) + 1
                if not rec then cfg.p2dlastmiss = cfg.p2dlasthit; cfg.p2dmissn = (cfg.p2dmissn or 0) + 1 end

                if rec and cfg.p2d_check then
                        local ok, r = real.pcall(hub.p2d.answer, self, name, args[1])
                        real.print(markPrefix .. "P2DCHECK " .. p2dKey(name, args) .. "\t" .. real.tostring(rec) .. "\t" .. real.tostring(ok and r)
                                .. "\t" .. ((ok and r == rec) and "same" or "DIFF"))
                end
                if not rec and not cfg.p2d_nomodel then
                        local ok, r = real.pcall(hub.p2d.answer, self, name, args[1])
                        if ok and r then
                                rec = r
                                real.insert(p2dLog, p2dKey(name, args) .. "\t" .. r .. "\tmodel")
                        end
                end
                if not rec then p2dMiss = true end
                if rec then
                        local text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")"
                        local vals = {}
                        local n = 0
                        for field in string.gmatch(rec, "[^\t]+") do
                                n += 1
                                vals[n] = p2dDecode(field, text)
                        end
                        cfg.p2dret = (n >= 1 and real.type(vals[1])) or ""
                        if n == 1 and isP(vals[1]) then
                                local cp = callP(text, real.match(name, "^Get(%u%w*)$") or "result", infoOf[vals[1]].tname)
                                infoOf[cp].props = infoOf[vals[1]].props
                                return cp
                        end
                        emit({ text = text })
                        return real.unpack(vals, 1, n)
                end
        end

        if self and realValues[self] ~= nil and real.type(name) == "string" and not noNativeMethod[name] then
                local r = realValues[self]
                local isInst = real.typeof(r) == "Instance"
                local u = unwrapArgs(args)
                if u then
                        local res = table.pack(real.pcall(function() return r[name](r, real.unpack(u, 1, u.n)) end))
                        if not res[1] then
                                if not isInst and res[2] ~= hub.dtUnsupported then real.error(res[2], 0) end
                        else
                                local text = calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")"
                                local hint0 = real.match(name, "^Get(%u%w*)$") or "result"
                                hint0 = real.gsub(hint0, "^%u", string.lower)
                                if isInst and r.ClassName == "Path2D" then
                                        local enc = {}
                                        for i = 2, res.n do enc[#enc + 1] = p2dEncode(res[i]) or "?" end
                                        real.insert(p2dLog, p2dKey(name, args) .. "\t" .. real.concat(enc, "\t"))
                                end
                                local outv, good = {}, true
                                for i = 2, res.n do
                                        local w, ok = wrapReal(res[i], text, hint0)
                                        if not ok then good = false break end
                                        outv[i - 1] = w
                                end
                                if good then
                                        if not isInst then return real.unpack(outv, 1, res.n - 1) end
                                        if res.n == 2 and isP(outv[1]) then
                                                local cp = callP(text, hint0, infoOf[outv[1]].tname)
                                                realValues[cp] = res[2]
                                                return cp
                                        end
                                        emit({ text = text })
                                        return real.unpack(outv, 1, res.n - 1)
                                end
                        end
                end
        end

        local hint
        if name == "FindFirstChild" or name == "WaitForChild" or name == "FindFirstChildOfClass"
                or name == "FindFirstChildWhichIsA" or name == "FindFirstAncestor" or name == "FindFirstAncestorOfClass"
                or name == "FindFirstAncestorWhichIsA" or name == "FindFirstDescendant" then
                hint = real.type(a1) == "string" and a1 or "child"
        elseif name == "new" and info.parent and infoOf[info.parent].kind == "name" and infoOf[info.parent].name == "Instance" then
                hint = real.type(a1) == "string" and a1 or "instance"
        elseif name and classHint[name] then
                hint = classHint[name]
        elseif name == "Clone" then
                hint = "clone"
        elseif name == "Create" and isMethod and infoOf[info.parent].className == "TweenService" then
                hint = "tween"
        elseif name then
                hint = real.match(name, "^Get(%u%w*)$") or real.match(name, "^Find(%u%w*)$")
                local made = real.match(name, "^Create(%u%w*)$") or real.match(name, "^New(%u%w*)$")
                        or real.match(name, "^Add(%u%w*)$") or real.match(name, "^Make(%u%w*)$")
                if hint then
                        hint = real.gsub(hint, "^%u", string.lower)
                else
                        hint = made or "result"
                end
        else
                hint = "result"
        end
        return callP(calleeText .. "(" .. fmtArgs(real.unpack(args, 1, args.n)) .. ")", hint)
end

local opaque = { EnumItem = 1, Enum = 1, Enums = 1, RBXScriptSignal = 1, RBXScriptConnection = 1 }
local function opaqueType(v)
        if not isP(v) then return nil end
        local info = infoOf[v]
        if opaque[info.tname] then return info.tname end
        if info.created or (info.className and info.kind ~= "call" or info.kind == "name" and info.className) then
                return "Instance"
        end
        return nil
end
local function luaTypeName(v)
        return opaqueType(v) or real.typeof(v)
end
local function arithError(opname, a, b)
        if opaqueType(a) or opaqueType(b) then
                real.error(real.fmt("attempt to perform arithmetic (%s) on %s and %s", opname, luaTypeName(a), luaTypeName(b)), 3)
        end
end
local arith = {
        ["+"] = function(a, b) return a + b end, ["-"] = function(a, b) return a - b end,
        ["*"] = function(a, b) return a * b end, ["/"] = function(a, b) return a / b end,
        ["//"] = function(a, b) return a // b end, ["%"] = function(a, b) return a % b end,
        ["^"] = function(a, b) return a ^ b end,
}
local opNames = { ["+"] = "add", ["-"] = "sub", ["*"] = "mul", ["/"] = "div", ["//"] = "idiv", ["%"] = "mod", ["^"] = "pow" }
local function binop(op, tname)
        return function(a, b)
                arithError(opNames[op], a, b)
                local ra, oka = realOf(a)
                local rb, okb = realOf(b)
                if oka and okb then
                        local ok, r = real.pcall(arith[op], ra, rb)
                        if not ok and native then real.error(r, 2) end
                        if ok then
                                local w, good = wrapReal(r, "(" .. fmt(a) .. " " .. op .. " " .. fmt(b) .. ")", nil)
                                if good then return w end
                        end
                end
                return exprP("(" .. fmt(a) .. " " .. op .. " " .. fmt(b) .. ")", tname or (isP(a) and infoOf[a].tname) or (isP(b) and infoOf[b].tname) or "number")
        end
end

local methodPrefix = { "Get", "Find", "Wait", "Is", "Clone", "Destroy", "Connect", "Once", "Fire", "Invoke",
        "Set", "Clear", "Remove", "Add", "Load", "Play", "Stop", "Pause", "Resume", "Adjust", "Move", "Pivot",
        "Apply", "Take", "Kick", "Teleport", "Emit", "Create", "Raycast", "Blockcast", "Spherecast", "Shapecast",
        "Http", "Request", "JSON", "Generate", "Compute", "Change", "Equip", "Unequip", "Preload", "Bind", "Unbind",
        "Disconnect", "Activate", "Deactivate", "Update", "Serialize", "Break", "Reset", "Scale", "To", "Lerp",
        "Navigate", "Render", "Open", "Close", "Enable", "Disable", "Insert", "Show", "Hide", "Tween", "Capture",
        "Post", "Publish", "Subscribe", "Increment", "Decrement", "Save", "Read", "Write", "Check", "Can", "Has",
        "Prompt", "Send", "Kill", "Spawn", "Transform", "Invert", "Reverse", "Clamp", "Sample", "Evaluate",
        "Batch", "Sync", "Query", "Register", "Unregister", "Rebuild", "Refresh", "Cancel", "Dump", "Test", "From", "Expand" }
local methodExact = { connect = 1, wait = 1, disconnect = 1, Wait = 1, Connect = 1, Once = 1, ConnectParallel = 1,
        Disconnect = 1, Destroy = 1, Clone = 1, Remove = 1, ClearAllChildren = 1, Kick = 1, Play = 1, Stop = 1,
        findFirstChild = 1, children = 1, getChildren = 1, clone = 1, destroy = 1, remove = 1, isA = 1 }
local methodCache = real.setmetatable({}, { __mode = "k" })
local methodProxy = real.setmetatable({}, { __mode = "k" })
methodProxyRef = methodProxy
function isMethodName(k)
        if real.type(k) ~= "string" then return false end
        if methodExact[k] then return true end
        for _, pre in methodPrefix do
                if real.sub(k, 1, #pre) == pre and real.match(real.sub(k, #pre + 1, #pre + 1), "^%u$") then
                        return true
                end
        end
        return false
end
local sharedMethods = {}
local signalT = { RBXScriptSignal = true, RBXScriptConnection = true }
function methodFn(p, k)
        local want = infoOf[p].tname
        if signalT[want] then
                local ip = indexP(p, k)
                local f = function(...)
                        local self = ...
                        if real.select("#", ...) == 0 then
                                real.error(real.fmt("missing argument #1 to '%s' (%s expected)", k, want), 0)
                        end
                        if not (isP(self) and infoOf[self].tname == want) then
                                real.error(real.fmt("invalid argument #1 to '%s' (%s expected, got %s)", k, want, luaTypeName(self)), 0)
                        end
                        return proxyMeta.__call(indexP(self, k), ...)
                end
                cfuncs[f] = true
                cnames[f] = k
                methodProxy[f] = ip
                return f
        end
        local ck = real.tostring(infoOf[p].tname) .. "|" .. real.tostring(k)
        local f = sharedMethods[ck]
        if f then return f end
        local ip = indexP(p, k)
        f = function(...)
                local self = ...
		if not (isP(self) and (want == nil or infoOf[self].tname == want)) then
			if runserviceBool[k] ~= nil and not cfg.devirt then
				return runserviceBool[k]
			end
			real.error("Expected ':' not '.' calling member function " .. k, 0)
		end
                return proxyMeta.__call(indexP(self, k), ...)
        end
        cfuncs[f] = true
        cnames[f] = k
        methodProxy[f] = ip
        sharedMethods[ck] = f
        return f
end

local signalMembers = {
        RBXScriptSignal = { Connect = "method", ConnectParallel = "method", Once = "method", Wait = "method" },
        RBXScriptConnection = { Connected = "prop", Disconnect = "method" },
}
proxyMeta.__index = function(p, k)
        local info = infoOf[p]
        if signalT[info.tname] then
                if k == "connect" then k = "Connect" elseif k == "wait" then k = "Wait" elseif k == "disconnect" then k = "Disconnect" end
        end
        if k == "CreatorType" then return cfg.__superz_creator_type or "User" end
        if k == "GameId" then return cfg.__superz_game_id or 0 end
        if k == "PlaceId" then return cfg.__superz_place_id or 0 end
        if k == "CreatorId" then return cfg.__superz_creator_id or 0 end
        if cfg.trace or cfg.ptrace then real.print("[index]", info.name or info.hint, k) end
        if k == "Parent" and (info.nilParent or info.created) then return info.props.Parent end
        if k == "Parent" and info.props.Parent == nil and info.tname == "Instance" and p ~= workspaceProxy then
                local depth, q = 0, p
                while q and infoOf[q] and infoOf[q].key == "Parent" do
                        depth += 1
                        q = infoOf[q].parent
                end
                if depth >= 3 then return workspaceProxy end
        end
        if signalMembers[info.tname] then
                local m = signalMembers[info.tname][k]
                if m == "method" then return methodFn(p, k) end
                if m == nil then
                        real.error(real.fmt("%s is not a valid member of %s", real.tostring(k), info.tname), 0)
                end
        end
        local v = info.props[k]
        if v ~= nil then return v end
        if (info.tname == "RaycastParams" or info.tname == "OverlapParams") and k == "IncludeInstances" then
                return nil
        end
        if info.created then
                if hub.isClassA(info.className, "BasePart") then
                        if k == "CurrentPhysicalProperties" then
                                return info.props.CustomPhysicalProperties or scriptEnv.PhysicalProperties.new(0.7, 0.3, 0.5, 1, 1)
                        elseif k == "Mass" then
                                local f32 = hub.p2d.f32
                                local sz = info.props.Size or vector.create(4, 1.2, 2)
                                local cpp = info.props.CustomPhysicalProperties or scriptEnv.PhysicalProperties.new(0.7, 0.3, 0.5, 1, 1)
                                return f32(f32(f32(sz.X * sz.Y) * sz.Z) * cpp.Density)
                        end
                elseif info.className == "Attachment" or info.className == "Bone" then
                        if k == "WorldCFrame" then
                                return hub.attParentWorldCF(p) * (info.props.CFrame or scriptEnv.CFrame.identity)
                        elseif k == "WorldPosition" then
                                return (hub.attParentWorldCF(p) * (info.props.CFrame or scriptEnv.CFrame.identity)).Position
                        end
                elseif hub.isClassA(info.className, "GuiObject") then
                        if k == "AbsoluteSize" then
                                local w, h = hub.guiUnscaledSize(p)
                                local sc = hub.guiScale(p)
                                return scriptEnv.Vector2.new(w * sc, h * sc)
                        elseif k == "AbsolutePosition" then
                                local par = info.props.Parent
                                local px, py, pw, ph = 0, 0, 0, 0
                                if isP(par) and infoOf[par].className ~= "ScreenGui" then
                                        local pap = par.AbsolutePosition
                                        px, py = pap.X, pap.Y
                                        pw, ph = hub.guiUnscaledSize(par)
                                end
                                local sc = hub.guiScale(p)
                                local layout = nil
                                if isP(par) then
                                        for _, c in kidsOf(par) do
                                                if infoOf[c] and infoOf[c].className == "UIListLayout" then layout = c; break end
                                        end
                                end
                                if layout then
                                        local li = infoOf[layout]
                                        local pad = li.props.Padding
                                        local padPx = (isP(pad) and realValues[pad] and (realValues[pad].Offset * sc)) or 0
                                        local horiz = isP(li.props.FillDirection) and infoOf[li.props.FillDirection].props.Name == "Horizontal"
                                        local items = {}
                                        for idx, c in kidsOf(par) do
                                                if infoOf[c] and hub.isClassA(infoOf[c].className, "GuiObject") then
                                                        real.insert(items, { c = c, lo = real.tonumber(infoOf[c].props.LayoutOrder) or 0, idx = idx })
                                                end
                                        end
                                        table.sort(items, function(a, b) if a.lo ~= b.lo then return a.lo < b.lo end return a.idx < b.idx end)
                                        local off = 0
                                        for _, it in items do
                                                if it.c == p then break end
                                                local asz = it.c.AbsoluteSize
                                                off = off + (horiz and asz.X or asz.Y) + padPx
                                        end
                                        return scriptEnv.Vector2.new(horiz and (px + off) or px, horiz and py or (py + off))
                                end
                                local pos = info.props.Position
                                local ox, oy = 0, 0
                                if isP(pos) and realValues[pos] then
                                        local r = realValues[pos]
                                        ox, oy = (r.X.Scale * pw + r.X.Offset) * sc, (r.Y.Scale * ph + r.Y.Offset) * sc
                                end
                                return scriptEnv.Vector2.new(px + ox, py + oy)
                        end
                elseif info.className == "UIListLayout" and k == "AbsoluteContentSize" then
                        local par = info.props.Parent
                        if not isP(par) then return scriptEnv.Vector2.new(0, 0) end
                        local sc = hub.guiScale(par)
                        local pad = info.props.Padding
                        local padPx = (isP(pad) and realValues[pad] and (realValues[pad].Offset * sc)) or 0
                        local horiz = isP(info.props.FillDirection) and infoOf[info.props.FillDirection].props.Name == "Horizontal"
                        local totalMain, maxCross, count = 0, 0, 0
                        for _, c in kidsOf(par) do
                                if infoOf[c] and hub.isClassA(infoOf[c].className, "GuiObject") then
                                        count += 1
                                        local asz = c.AbsoluteSize
                                        if horiz then
                                                totalMain += asz.X
                                                if asz.Y > maxCross then maxCross = asz.Y end
                                        else
                                                totalMain += asz.Y
                                                if asz.X > maxCross then maxCross = asz.X end
                                        end
                                end
                        end
                        if count > 1 then totalMain += (count - 1) * padPx end
                        return horiz and scriptEnv.Vector2.new(totalMain, maxCross) or scriptEnv.Vector2.new(maxCross, totalMain)
                elseif info.className == "ObjectValue" and k == "Value" then
                        return nil
                end
        end
        local rv = realValues[p]
        if rv ~= nil and real.type(k) == "string" then
                local isInst = real.typeof(rv) == "Instance"
                local ok, x = real.pcall(function() return rv[k] end)
                if not ok then
                        if not isInst and x ~= hub.dtUnsupported then real.error(x, 2) end
                elseif x == nil and info.tname == "TweenInfo" then
                        if k == "EasingStyle" then return enumItem("EasingStyle", "Quad") end
                        if k == "EasingDirection" then return enumItem("EasingDirection", "Out") end
                elseif real.type(x) ~= "function" then
                        local w, good = wrapReal(x, tok(p) .. keySuffix(k), k)
                        if good then return w end
                end
        end
        if info.genv then
                return nil
        end
        if info.tname == "Enums" and real.type(k) == "string" and api.enums[k] then
                return enumType(k)
        end
        if info.tname == "Enum" and info.enumName then
                local e = api.enums[info.enumName]
                if e and e.byName[k] then return enumItem(info.enumName, k) end
                if k == "GetEnumItems" or k == "FromName" or k == "FromValue" then return methodFn(p, k) end
        end
        if info.tname == "EnumItem" and k == "IsA" then
                return methodFn(p, k)
        end
        if (info.tname == "Faces" or info.tname == "Axes") and info.ctor and real.type(k) == "string" then
                local axisOf = { Right = "X", Left = "X", Top = "Y", Bottom = "Y", Back = "Z", Front = "Z" }
                local isFaces = info.tname == "Faces"
                local want = isFaces and (axisOf[k] and k) or (axisOf[k] or ((k == "X" or k == "Y" or k == "Z") and k))
                if want then
                        local a = info.ctor.args
                        for i = 1, a.n do
                                local ai = isP(a[i]) and infoOf[a[i]]
                                if ai and ai.tname == "EnumItem" then
                                        local n = ai.props.Name
                                        if isFaces then
                                                if ai.enumName == "NormalId" and n == want then return true end
                                        elseif (ai.enumName == "NormalId" and axisOf[n] == want) or (ai.enumName == "Axis" and n == want) then
                                                return true
                                        end
                                end
                        end
                        return false
                end
        end
        local dm = dtMembers[info.tname]
        if dm and real.type(k) == "string" and dm[k] and realValues[p] == nil then
                if dm[k] == "n" then return 0 end
                local c = indexP(p, k)
                infoOf[c].tname = dm[k]
                infoOf[c].className = nil
                return c
        end
        local cls = info.className
        if cls and api.classes[cls] and real.type(k) == "string" then
                local kind = memberKind(cls, k)
                if kind == "method" then return methodFn(p, k) end
                if kind == "event" then
                        local c = newP({ kind = "index", parent = p, key = k, tname = "RBXScriptSignal", hint = k,
                                sigKey = info.id .. "." .. k })
                        return c
                end
                if kind == "prop" then
                        local vt = propType(cls, k)
                        if vt and numericT[vt] then return numDefault[k] or 0 end
                        local c = indexP(p, k)
                        if vt and dtMembers[vt] then
                                infoOf[c].tname = vt
                                infoOf[c].className = nil
                        elseif vt == "bool" then
                                infoOf[c].tname = "boolean"
                                infoOf[c].className = nil
                        elseif vt == "string" then
                                infoOf[c].tname = "string"
                                infoOf[c].className = nil
                        end
                        return c
                end
        end
        if isMethodName(k) and info.tname ~= "table" then
                return methodFn(p, k)
        end
        return indexP(p, k)
end
proxyMeta.__newindex = function(p, k, v)
        local info = infoOf[p]
        if cfg.ptrace then real.print("[newindex]", info.name or info.hint, k, real.typeof(v)) end
        if k == "Parent" and info.destroyed then
                real.error(real.fmt("The Parent property of %s is locked, current parent: NULL, new parent %s",
                        instName(p), isP(v) and instName(v) or "NULL"), 0)
        end
        emit({ text = tok(p) .. keySuffix(k) .. " = " .. fmt(v) })
        local rv = realValues[p]
        if native and rv ~= nil and k ~= "Parent" and real.type(k) == "string" then
                local u = unwrapArgs(table.pack(v))
                if u then
                        local ok, err = real.pcall(function() rv[k] = u[1] end)
                        if not ok then real.error(err, 2) end
                end
        end
        if k == "Parent" and (v == nil or isP(v)) then
                setParent(p, v)
        elseif (info.tname == "RaycastParams" or info.tname == "OverlapParams") and (k == "ExcludeInstances" or k == "IncludeInstances") then
                if v == nil then
                        info.props[k] = (k == "ExcludeInstances") and table.freeze({}) or nil
                elseif real.type(v) == "table" then
                        info.props[k] = table.freeze(table.clone(v))
                end
        elseif info.created and hub.isClassA(info.className, "BasePart") then
                if k == "CFrame" and isP(v) then
                        info.props.CFrame = v
                        info.props.Position = v.Position
                elseif k == "Position" and real.type(v) == "vector" then
                        info.props.Position = v
                        local cf = info.props.CFrame or scriptEnv.CFrame.identity
                        info.props.CFrame = (cf - cf.Position) + v
                else
                        info.props[k] = v
                end
        elseif info.created and (info.className == "Attachment" or info.className == "Bone") then
                if k == "CFrame" and isP(v) then
                        info.props.CFrame = v
                        info.props.Position = v.Position
                elseif k == "Position" and real.type(v) == "vector" then
                        info.props.Position = v
                        local cf = info.props.CFrame or scriptEnv.CFrame.identity
                        info.props.CFrame = (cf - cf.Position) + v
                elseif k == "WorldCFrame" and isP(v) then
                        local lcf = hub.attParentWorldCF(p):Inverse() * v
                        info.props.CFrame = lcf
                        info.props.Position = lcf.Position
                elseif k == "WorldPosition" and real.type(v) == "vector" then
                        local lpos = hub.attParentWorldCF(p):PointToObjectSpace(v)
                        info.props.Position = lpos
                        local cf = info.props.CFrame or scriptEnv.CFrame.identity
                        info.props.CFrame = (cf - cf.Position) + lpos
                else
                        info.props[k] = v
                end
        else
                info.props[k] = v
        end
end
proxyMeta.__call = onCall
proxyMeta.__tostring = function(p)
        if realValues[p] ~= nil then return real.tostring(realValues[p]) end
        return "<" .. (infoOf[p].hint or "proxy") .. ">"
end
proxyMeta.__concat = function(a, b)
        if opaqueType(a) or opaqueType(b) then
                real.error(real.fmt("attempt to concatenate %s with %s", luaTypeName(a), luaTypeName(b)), 2)
        end
        local function __sz_rval(x)
                local t = type(x)
                if (t == "table" or t == "userdata") and realValues[x] ~= nil then return realValues[x] end
                return x
        end
        local __ra, __rb = __sz_rval(a), __sz_rval(b)
        local __ta, __tb = real.type(__ra), real.type(__rb)
        if (__ta == "string" or __ta == "number") and (__tb == "string" or __tb == "number") then
                return __ra .. __rb
        end
        if cfg.__superz_logglobal then
                local function __sz_desc(x)
                        local rv = "-"
                        local xt = type(x)
                        if (xt == "table" or xt == "userdata") and realValues[x] ~= nil then rv = real.tostring(realValues[x]):sub(1, 40) end
                        local inf = ((xt == "table" or xt == "userdata") and infoOf[x]) or nil
                        local kind = inf and real.tostring(inf.kind) or "?"
                        local txt = inf and real.tostring(inf.text or inf.name or inf.hint or "?"):sub(1, 60) or real.tostring(x):sub(1, 40)
                        return xt .. "/" .. kind .. "/" .. txt .. "/realv=" .. rv
                end
                real.print("\1SUPERZCONCATOP\1" .. __sz_desc(a) .. " || " .. __sz_desc(b))
        end
        return exprP(fmt(a) .. " .. " .. fmt(b), "string")
end
proxyMeta.__add = binop("+")
proxyMeta.__sub = binop("-")
proxyMeta.__mul = binop("*")
proxyMeta.__div = binop("/")
proxyMeta.__idiv = binop("//")
proxyMeta.__mod = binop("%")
proxyMeta.__pow = binop("^")
proxyMeta.__unm = function(a)
        if opaqueType(a) then
                real.error(real.fmt("attempt to perform arithmetic (unm) on %s", luaTypeName(a)), 2)
        end
        if realValues[a] ~= nil then
                local ok, r = real.pcall(function() return -realValues[a] end)
                if not ok and native then real.error(r, 2) end
                if ok then
                        local w, good = wrapReal(r, "(-" .. fmt(a) .. ")", nil)
                        if good then return w end
                end
        end
        return exprP("(-" .. fmt(a) .. ")", infoOf[a].tname)
end
proxyMeta.__len = function(p)
        return 1
end
proxyMeta.__eq = function(a, b)
        if cfg.ptrace then real.print("[eq]", infoOf[a] and (infoOf[a].name or infoOf[a].hint), infoOf[b] and (infoOf[b].name or infoOf[b].hint)) end
        local ra, rb = realValues[a], realValues[b]
        if ra ~= nil and rb ~= nil then return ra == rb end
        local ia, ib = infoOf[a], infoOf[b]
        if ia and ib and ia.sigKey and ia.sigKey == ib.sigKey then return true end
        return real.rawequal(a, b)
end
local assumedCmp = 0
proxyMeta.__lt = function(a, b)
        assumedCmp += 1
        comment("condition: " .. fmt(a) .. " < " .. fmt(b) .. "  (assumed true)")
        return true
end
proxyMeta.__le = function(a, b)
        assumedCmp += 1
        comment("condition: " .. fmt(a) .. " <= " .. fmt(b) .. "  (assumed false)")
        return false
end
proxyMeta.__iter = function(p)
        return iterProxy(p, nil)
end
proxyMeta.__metatable = "The metatable is locked"

local function anyProxy(...)
        for i = 1, real.select("#", ...) do
                if isP((real.select(i, ...))) then return true end
        end
        return false
end

local function wrapLib(libName, lib, tname)
        local out = {}
        for k, f in real.pairs(lib) do
                if real.type(f) == "function" then
                        local label = libName .. "." .. k
                        out[k] = function(...)
                                if anyProxy(...) then
                                        return exprP(label .. "(" .. fmtArgs(...) .. ")", tname)
                                end
                                return f(...)
                        end
                else
                        out[k] = f
                end
        end
        return out
end

function genvTable(label)
        local t = {}
        genvName[t] = label
        local shadow = {}
        hub.genvShadow = hub.genvShadow or {}
        hub.genvShadow[t] = shadow
        return real.setmetatable(t, {
                __newindex = function(self, k, v)
                        emit({ text = label .. keySuffix(k) .. " = " .. fmt(v) })
                        real.rawset(self, k, v)
                        shadow[k] = v
                end,
        })
end
hub.syncGenv = function()
        hub.syncing = true
        for t, shadow in real.next, hub.genvShadow do
                local label = genvName[t]
                for k, v in real.next, t do
                        if not real.rawequal(shadow[k], v) then
                                shadow[k] = v
                                emit({ text = label .. keySuffix(k) .. " = " .. fmt(v) })
                        end
                end
                for k in real.next, shadow do
                        if real.rawget(t, k) == nil then
                                shadow[k] = nil
                                emit({ text = label .. keySuffix(k) .. " = nil" })
                        end
                end
        end
        hub.syncing = false
end

scriptEnv = {}
local envTable = scriptEnv
local RandomMT = {}
local randomState
local genv = genvTable("getgenv()")
local collected = {}

envTable.string = wrapLib("string", string, "string")
envTable.math = wrapLib("math", math, "number")
envTable.table = table
envTable.bit32 = bit32
if cfg.bxguard then
	local __rbx = bit32.bxor
	local __bxn = 0
	local function bxg(a, ...)
		local n = select("#", ...)
		local args = { ... }
		local bad = real.type(a) ~= "number"
		for i = 1, n do
			if real.type(args[i]) ~= "number" then bad = true end
		end
		if bad then
			__bxn = __bxn + 1
			if __bxn <= 6 then
				real.print("BXBAD a=" .. real.tostring(a) .. " args=" .. n)
				real.print("BXTB " .. real.gsub(real.tostring(debug.traceback()), "\n", " | "))
			end
			if a == nil then a = 0 end
			for i = 1, n do
				if args[i] == nil then args[i] = 0 end
			end
		end
		return __rbx(a, table.unpack(args, 1, n))
	end
	local b32 = { arshift = bit32.arshift, band = bit32.band, bnot = bit32.bnot, bor = bit32.bor, btest = bit32.btest, bxor = bxg, extract = bit32.extract, lrotate = bit32.lrotate, lshift = bit32.lshift, replace = bit32.replace, rrotate = bit32.rrotate, rshift = bit32.rshift, tobit = bit32.tobit, byteswap = bit32.byteswap, countlz = bit32.countlz, countrz = bit32.countrz }
	setmetatable(b32, { __index = bit32 })
	envTable.bit32 = b32
end
if cfg.bxor_wrap then
        local __rbx = bit32.bxor
        local __b32 = setmetatable({}, { __index = function(t, kk) return bit32[kk] end })
        __b32.bxor = function(a, b, ...)
                local ta, tb = real.type(a), real.type(b)
                if ta ~= "number" or tb ~= "number" then
                        real.print("BXBAD:" .. real.tostring(ta) .. "," .. real.tostring(tb) .. "," .. real.tostring(select("#", ...)))
                end
                local ok, r = real.pcall(__rbx, a, b, ...)
                if not ok then
                        real.print("BXERR:" .. real.tostring(r) .. " ta=" .. real.tostring(ta) .. " tb=" .. real.tostring(tb) .. " n=" .. real.tostring(select("#", ...)))
                        real.error(r, 0)
                end
                return r
        end
        envTable.bit32 = __b32
end
envTable.coroutine = coroutine
local UNorm = (function()
        local unicodeData = __unicode or { decomp = "", ccc = "", comp = "" }
        local decomp, ccc, comp = {}, {}, {}
        for k, v in string.gmatch(unicodeData.decomp, "(%x+):([%x,]+)") do
                local list = {}
                for x in string.gmatch(v, "%x+") do real.insert(list, real.tonumber(x, 16)) end
                decomp[real.tonumber(k, 16)] = list
        end
        for k, v in string.gmatch(unicodeData.ccc, "(%x+):(%x+)") do
                ccc[real.tonumber(k, 16)] = real.tonumber(v, 16)
        end
        for a, b, c in string.gmatch(unicodeData.comp, "(%x+),(%x+):(%x+)") do
                comp[real.tonumber(a, 16) * 0x110000 + real.tonumber(b, 16)] = real.tonumber(c, 16)
        end
        local SBase, LBase, VBase, TBase = 0xAC00, 0x1100, 0x1161, 0x11A7
        local LCount, VCount, TCount = 19, 21, 28
        local NCount = VCount * TCount
        local SCount = LCount * NCount

        local function decompose(s)
                local out = {}
                for _, cp in utf8.codes(s) do
                        local si = cp - SBase
                        if si >= 0 and si < SCount then
                                real.insert(out, LBase + si // NCount)
                                real.insert(out, VBase + (si % NCount) // TCount)
                                local t = si % TCount
                                if t ~= 0 then real.insert(out, TBase + t) end
                        elseif decomp[cp] then
                                for _, x in decomp[cp] do real.insert(out, x) end
                        else
                                real.insert(out, cp)
                        end
                end
                local i = 1
                while i <= #out do
                        if (ccc[out[i]] or 0) > 0 then
                                local j = i
                                while j + 1 <= #out and (ccc[out[j + 1]] or 0) > 0 do j += 1 end
                                for a = i + 1, j do
                                        local x = out[a]
                                        local cx = ccc[x]
                                        local b = a - 1
                                        while b >= i and ccc[out[b]] > cx do
                                                out[b + 1] = out[b]
                                                b -= 1
                                        end
                                        out[b + 1] = x
                                end
                                i = j + 1
                        else
                                i += 1
                        end
                end
                return out
        end

        local function compose(cps)
                local out = {}
                local starter = nil
                local lastClass = -1
                for _, cp in cps do
                        local c = ccc[cp] or 0
                        local done = false
                        if starter then
                                local s = out[starter]
                                local li, vi = s - LBase, cp - VBase
                                if li >= 0 and li < LCount and vi >= 0 and vi < VCount and starter == #out then
                                        out[starter] = SBase + (li * VCount + vi) * TCount
                                        done = true
                                else
                                        local si, ti = s - SBase, cp - TBase
                                        if si >= 0 and si < SCount and si % TCount == 0 and ti > 0 and ti < TCount and starter == #out then
                                                out[starter] = s + ti
                                                done = true
                                        end
                                end
                                if not done and (lastClass < c or (lastClass == 0 and starter == #out)) then
                                        local p = comp[s * 0x110000 + cp]
                                        if p and (starter == #out or lastClass < c) then
                                                out[starter] = p
                                                done = true
                                        end
                                end
                        end
                        if not done then
                                real.insert(out, cp)
                                if c == 0 then
                                        starter = #out
                                        lastClass = 0
                                else
                                        lastClass = c
                                end
                        end
                end
                return out
        end

        local function pack(cps)
                local parts = {}
                for i, cp in cps do parts[i] = utf8.char(cp) end
                return real.concat(parts)
        end
        return {
                nfd = function(s) return pack(decompose(s)) end,
                nfc = function(s) return pack(compose(decompose(s))) end,
        }
end)()

envTable.utf8 = (function()
        local t = {}
        for k, v in real.pairs(utf8) do t[k] = v end
        t.graphemes = function(s, i, j)
                local list = {}
                for p, c in utf8.codes(s) do real.insert(list, { p, p + #utf8.char(c) - 1 }) end
                local n = 0
                return function()
                        n += 1
                        local g = list[n]
                        if g then return g[1], g[2] end
                end
        end
        t.nfcnormalize = function(s) return UNorm.nfc(s) end
        t.nfdnormalize = function(s) return UNorm.nfd(s) end
        return t
end)()
envTable.vector = vector
envTable.os = { clock = function() return real.clock() + (hub.clockOff or 0) end, time = os.time, date = os.date, difftime = os.difftime }
cnames[envTable.os.clock] = "clock"
envTable.debug = debug
envTable.buffer = (function()
        local b = {}
        local robloxBuffer = {}
        for n in string.gmatch("copy,create,fill,fromstring,len,readbits,readf32,readf64,readi16,readi32,readi8,"
                .. "readstring,readu16,readu32,readu8,tostring,writebits,writef32,writef64,writei16,writei32,writei8,"
                .. "writestring,writeu16,writeu32,writeu8", "[^,]+") do robloxBuffer[n] = true end
        for k, f in real.pairs(buffer) do
                if robloxBuffer[k] then b[k] = f end
        end
        local lastOff = -1
        local undo = {}
        for _, nm in { "writei8", "writeu8", "writei16", "writeu16" } do
                b[nm] = buffer[nm]
        end
        for _, nm in { "writei32", "writeu32" } do
                local orig = buffer[nm]
                b[nm] = function(buf, off, v)
                        if tamperCount > 0 and v >= 0 and v < 256 and off ~= lastOff + 4 and buffer.len(buf) > 4096 then
                                real.error(tamper, 0)
                        end
                        if v >= 0 and v < 256 and off ~= lastOff + 4 and buffer.len(buf) > 4096 and off + 4 <= buffer.len(buf) then
                                real.insert(undo, { buf, off, buffer.readu32(buf, off) })
                                if #undo >= (cfg.tamper_limit or 64) then
                                        for i = #undo, 1, -1 do
                                                local u = undo[i]
                                                buffer.writeu32(u[1], u[2], u[3])
                                        end
                                        table.clear(undo)
                                        tamperCount += 1
                                        if not trigger then noteTrigger() end
                                        if (cfg.oplog or cfg.inline_probe) and envTable.__opdump then envTable.__opdump() end
                                        real.error(tamper, 0)
                                end
                        elseif #undo > 0 and off == lastOff + 4 then
                                table.clear(undo)
                        end
                        lastOff = off
                        return orig(buf, off, v)
                end
        end
        if not cfg.dump_strings then return b end
        b.readstring = function(buf, off, len)
                local s = buffer.readstring(buf, off, len)
                real.insert(collected, s)
                return s
        end
        b.tostring = function(buf)
                local s = buffer.tostring(buf)
                real.insert(collected, s)
                return s
        end
        return b
end)()

for _, k in { "assert", "error", "next", "rawget", "rawset", "rawequal", "rawlen", "select", "setmetatable",
        "getmetatable", "unpack", "newproxy", "gcinfo", "_VERSION" } do
        envTable[k] = realGlobals[k]
end

envTable.type = function(...)
        local v = ...
        if isP(v) then
                local t = infoOf[v].tname
                if t == "string" or t == "number" or t == "table" or t == "boolean" then return t end
                return "userdata"
        end
        return real.type(...)
end
envTable.typeof = function(...)
        local v = ...
        if cfg.ptrace then real.print("[typeof]", isP(v) and (infoOf[v].name or infoOf[v].hint) or real.typeof(v)) end
        if isP(v) then
                local t = infoOf[v].tname
                if t == "table" then return "table" end
                return t or "Instance"
        end
        if randomState and randomState[v] then return "Random" end
        local t = real.typeof(...)
        if t == "vector" then return "Vector3" end
        return t
end
envTable.tostring = function(...)
        local v = ...
        if cfg.ptrace then real.print("[tostring]", isP(v) and (infoOf[v].name or infoOf[v].hint) or real.typeof(v)) end
        if isP(v) then
                local info = infoOf[v]
                if info.tname == "EnumItem" then return "Enum." .. info.enumName .. "." .. info.props.Name end
                if info.tname == "Enum" then return info.enumName end
                if info.tname == "Enums" then return "Enums" end
                if realValues[v] ~= nil then return real.tostring(realValues[v]) end
                if real.type(info.props.Name) == "string" and (info.className or opaqueType(v) == "Instance") then return info.props.Name end
                if cfg.__superz_logglobal then
                        local iks = {}
                        for ik2, iv2 in pairs(info) do
                                iks[#iks + 1] = tostring(ik2) .. "=" .. tostring(iv2):sub(1, 70)
                        end
                        real.print("\1SUPERZTOSTRING\1" .. table.concat(iks, " | "))
                end
                return exprP("tostring(" .. tok(v) .. ")", "string")
        end
        return real.tostring(...)
end
envTable.tonumber = function(...)
        local v = ...
        if isP(v) then return exprP("tonumber(" .. tok(v) .. ")", "number") end
        return real.tonumber(...)
end
envTable.next = function(...)
        local t = ...
        if isP(t) then
                if real.select("#", ...) < 1 then real.error("missing argument #1 to 'next' (table expected)", 0) end
                return nil
        end
        return real.next(...)
end
envTable.pairs = function(...)
        local t = ...
        if isP(t) then return iterProxy(t, "pairs"), t, nil end
        local f, s0, c0 = real.pairs(...)
        if f == real.next then f = envTable.next end
        return f, s0, c0
end
envTable.ipairs = function(...)
        local t = ...
        if isP(t) then return iterProxy(t, "ipairs"), t, 0 end
        return real.ipairs(...)
end
envTable.pcall = real.pcall
envTable.ypcall = real.pcall
envTable.xpcall = real.xpcall
if cfg.cstack_pcall then
        local resume, yield = coroutine.resume, coroutine.yield
        local atLimit = false
        local inner = coroutine.create(function()
                while true do yield() end
        end)
        local outer = coroutine.create(function()
                while true do
                        atLimit = not resume(inner)
                        yield()
                end
        end)
        local rpcall = real.pcall
        local limitedPcall = function(...)
                atLimit = true
                resume(outer)
                if atLimit then return false, "C stack overflow" end
                return rpcall(...)
        end
        cfuncs[limitedPcall] = true
        cnames[limitedPcall] = "pcall"
        fnText[limitedPcall] = "pcall"
        envTable.pcall = limitedPcall
        envTable.ypcall = limitedPcall
end
envTable.getfenv = function(x)
        if isP(x) and infoOf[x].tname == "function" then return scriptEnv end
        local arg = x
        if x == nil then
                arg = 3
        elseif real.type(x) == "number" and x > 0 then
                arg = x + 2
        end
        local ok, env = real.pcall(real.getfenv, arg)
        if not ok then real.error(env, 2) end
        return env
end
cfuncs[envTable.getfenv] = true
envTable.setfenv = function(x, env)
        if real.type(x) == "number" then
                return real.setfenv(x == 0 and 0 or x + 1, env)
        end
        if cfuncs[x] or isP(x) or (real.type(x) == "function" and debug.info(x, "s") == harnessSrc0) then
                real.error("'setfenv' cannot change environment of given object", 0)
        end
        return real.setfenv(x, env)
end
envTable.print = function(...)
        local a1 = (...)
        if real.type(a1) == "string" and real.sub(a1, 1, 2) == "@@" then
                real.print(fmtArgs(...))
        end
        emit({ text = "print(" .. fmtArgs(...) .. ")" })
end
envTable.warn = function(...)
        emit({ text = "warn(" .. fmtArgs(...) .. ")" })
end
local newChunks = {}
local function srcKey(src)
        local h = 0
        for i = 1, #src, protocol.hash_stride do
                local bytes = { real.byte(src, i, math.min(i + protocol.hash_stride - 1, #src)) }
                for _, b in bytes do h = (h * protocol.hash_mult + b) % protocol.hash_mod end
        end
        return #src .. "_" .. h
end
envTable.loadstring = function(src, chunkname)
        if isP(src) then
                return exprP("loadstring(" .. tok(src) .. ")", "function")
        end
        local patched = nil
        if real.type(src) == "string" and #src >= (cfg.chunk_min or protocol.chunk_min) then
                local key = srcKey(src)
                patched = __chunks and __chunks[key]
                if not patched and not newChunks[key] then
                        newChunks[key] = src
                        real.insert(newChunks, key)
                end
                if cfg.spin and not (patched and real.find(patched, "__spin.n", 1, true)) then
                        patched = real.gsub(patched or src, "while true do [%w_, ]-=[%a_][%w_]*%[[%a_][%w_]*%];",
                                "%0__spin.n=__spin.n+1;if __spin.n>=__spin.step then __spin.f()end;")
                        patched = real.gsub(patched, "repeat local [%a_][%w_]*=%([%a_][%w_]*%[[%a_][%w_]*%]%);",
                                "%0__spin.n=__spin.n+1;if __spin.n>=__spin.step then __spin.f()end;")
                end
        end
        local f, err = real.loadstring(patched or src, chunkname)
        if f and real.type(chunkname) == "string" and #src < 8000000 then
                real.__ls_src[chunkname] = patched or src
        end
        if not f then return nil, err end
        real.setfenv(f, scriptEnv)
        comment("loadstring() of " .. #src .. " bytes: " .. quote(real.sub(src, 1, 200)))
        return f
end
envTable.require = function(m)
        return callP("require(" .. fmt(m) .. ")", "module")
end

local function spawnLike(label, fn, ...)
        if real.type(fn) == "function" then
                local args = table.pack(...)
                lastThread = nil
                local okc, tokf = real.pcall(captureFunction, fn, nil, args)
                if not okc then
                        local fid = funcs[fn]
                        if fid then
                                local p = newP({ kind = "call", tname = "thread", hint = "thread" })
                                local st = { call = label .. "(" .. fid .. ")", res = p }
                                infoOf[p].stmt = st
                                real.insert(curBlock().lines, st)
                        end
                        real.error(tokf, 0)
                end
                local th = lastThread
                local p = callP(label .. "(" .. tokf .. (args.n > 0 and (", " .. fmtArgs(...)) or "") .. ")", "thread", "thread")
                if th then
                        threadProxy[th] = p
                        return th
                end
                return p
        end
        return callP(label .. "(" .. fmtArgs(fn, ...) .. ")", "thread", "thread")
end
local function doWait(label, t)
        local ret1 = (real.type(t) == "number" and t) or 0.03
        hub.clockOff = (hub.clockOff or 0) + ret1
        local ret2 = cfg.time_pin and ((cfg.time_pin or 0) + (cfg.clock_pin or 0.125) + hub.clockOff) or (real.clock() + hub.clockOff)
        local th = coroutine.running()
        if not deferred.running and th and th ~= deferred.runner and coroutine.isyieldable() then
                if captureDepth > 0 then
                        emit({ text = label .. "(" .. (t ~= nil and fmt(t) or "") .. ")" })
                        onWait()
                        real.insert(deferred, { rec = { params = {}, block = curBlock() }, thread = th,
                                args = { ret1, ret2, n = 2 }, n = 2, due = 0.25 })
                end
                return coroutine.yield(ret1, ret2)
        end
        emit({ text = label .. "(" .. (t ~= nil and fmt(t) or "") .. ")" })
        onWait()
        return ret1, ret2
end
local function typeName(n, ...)
        if real.select("#", ...) < n then return "no value" end
        return real.typeof((real.select(n, ...)))
end
local function argError(n, fname, expected, ...)
        real.error(real.fmt("invalid argument #%d to '%s' (%s expected, got %s)", n, fname, expected, typeName(n, ...)), 0)
end
local function checkRoutine(n, fname, ...)
        local v = real.select(n, ...)
        local t = real.type(v)
        if real.select("#", ...) < n or (t ~= "function" and t ~= "thread") then
                argError(n, fname, "function or thread", ...)
        end
        return v
end
local function checkNumber(n, fname, ...)
        local v = real.select(n, ...)
        if real.select("#", ...) >= n and v ~= nil and real.type(v) ~= "number" then
                if real.tonumber(v) then return real.tonumber(v) end
                argError(n, fname, "number", ...)
        end
        return v
end

local function scheduleLater(label, delayArg, due, fn, ...)
        if real.type(fn) == "thread" then
                local th = fn
                local args = table.pack(...)
                real.insert(deferred, { rec = { params = {}, block = { lines = {}, waits = {} } }, thread = th,
                        args = args, n = args.n, due = due })
                emit({ text = label .. "(" .. (delayArg and (fmt(delayArg) .. ", ") or "") .. fmt(th) .. ")" })
                return th
        end
        local args = table.pack(...)
        lastThread = nil
        local tokf = captureFunction(fn, nil, args, due)
        local th = lastThread
        local p = callP(label .. "(" .. (delayArg ~= nil and (fmt(delayArg) .. ", ") or "") .. tokf
                .. (args.n > 0 and (", " .. fmtArgs(...)) or "") .. ")", "thread", "thread")
        if th then threadProxy[th] = p; return th end
        return p
end

envTable.task = {
        spawn = function(...)
                local fn = checkRoutine(1, "spawn", ...)
                if real.type(fn) == "thread" then
                        emit({ text = "task.spawn(" .. fmt(fn) .. ")" })
                        coroutine.resume(fn, real.select(2, ...))
                        return fn
                end
                return spawnLike("task.spawn", ...)
        end,
        defer = function(...)
                checkRoutine(1, "defer", ...)
                return scheduleLater("task.defer", nil, 0.5, ...)
        end,
        delay = function(...)
                local t = checkNumber(1, "delay", ...)
                checkRoutine(2, "delay", ...)
                return scheduleLater("task.delay", t or 0, 1 + (t or 0), real.select(2, ...))
        end,
        wait = function(...)
                local t = checkNumber(1, "wait", ...)
                return doWait("task.wait", t)
        end,
        cancel = function(...)
                local th = real.select(1, ...)
                if real.select("#", ...) < 1 or real.type(th) ~= "thread" then
                        argError(1, "cancel", "thread", ...)
                end
                emit({ text = "task.cancel(" .. fmt(th) .. ")" })
                if coroutine.status(th) == "suspended" then coroutine.close(th) end
        end,
        synchronize = function() end,
        desynchronize = function() end,
}
envTable.wait = function(t) return doWait("wait", t) end
envTable.spawn = function(fn) return spawnLike("spawn", fn) end
envTable.delay = function(t, fn)
        return envTable.task.delay(t, fn)
end
if cfg.time_pin then
        local tp = cfg.time_pin
        envTable.os.time = function() return tp end
        envTable.os.date = function(fmt, t) return os.date(fmt, tp) end
        local cp = cfg.clock_pin or 0.125
        envTable.os.clock = function() return cp end
        envTable.tick = function() return tp + cp end
        envTable.time = envTable.os.time
        envTable.elapsedTime = envTable.os.clock
        do
                local st = (math.floor(tp) % 2147483646) + 1
                envTable.math.random = function(a, b)
                        st = (st * 48271) % 2147483647
                        local v = st - 1
                        if not a then return v / 2147483646 end
                        if not b then return 1 + v % a end
                        return a + v % (b - a + 1)
                end
        end
        do
                local kb = cfg.gc_pin or 10000
                envTable.gcinfo = function() return kb end
                envTable.collectgarbage = function(opt)
                        if opt == "count" then return kb end
                        if opt == "mem" or opt == nil then return kb end
                        return 0
                end
        end
else
        envTable.tick = function() return os.clock() + 1.7e9 end
        envTable.time = os.clock
        envTable.elapsedTime = os.clock
end
envTable.getgenv = function() return genv end
do
        local renv
        envTable.getrenv = function()
                if renv then return renv end
                renv = {}
                for n in string.gmatch("assert,error,getmetatable,setmetatable,ipairs,pairs,next,pcall,xpcall,print,"
                        .. "select,tonumber,tostring,type,typeof,unpack,rawequal,rawget,rawset,rawlen,gcinfo,newproxy,"
                        .. "collectgarbage,getfenv,setfenv,require,_G,_VERSION,string,math,table,os,debug,bit32,coroutine,"
                        .. "utf8,buffer,vector,game,Game,workspace,Workspace,script,plugin,shared,settings,UserSettings,"
                        .. "tick,time,wait,delay,spawn,elapsedTime,ElapsedTime,warn,task,Enum,Instance,stats,Stats,version,"
                        .. "Random,Vector3", "[^,]+") do
                        renv[n] = real.rawget(envTable, n)
                end
                for n in datatypes do renv[n] = real.rawget(envTable, n) end
                return renv
        end
end
envTable._G = genvTable("_G")
envTable.shared = genvTable("shared")

do
        local sha256fn = (function()
local function sha256(msg)
    local band, bxor, bnot, rrotate, rshift =
        bit32.band, bit32.bxor, bit32.bnot, bit32.rrotate, bit32.rshift
    local sha256K = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
    }
    local shaState = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
    }
    local len = #msg
    local bits = len * 8
    local hi = math.floor(bits / 4294967296)
    local lo = bits - hi * 4294967296
    local withone = len + 1
    local zeros = (55 - len) % 64
    local total = withone + zeros + 8
    local w = table.create and table.create(64) or {}

    local function getbyte(i)
        if i <= len then return string.byte(msg, i) end
        if i == withone then return 0x80 end
        if i <= total - 8 then return 0 end
        local j = i - (total - 8)
        if j <= 4 then
            return band(math.floor(hi / 256 ^ (4 - j)) % 256, 0xFF)
        end
        return band(math.floor(lo / 256 ^ (8 - j)) % 256, 0xFF)
    end

    for base = 0, total - 1, 64 do
        for j = 0, 15 do
            local o = base + j * 4
            w[j + 1] = getbyte(o + 1) * 16777216 + getbyte(o + 2) * 65536
                + getbyte(o + 3) * 256 + getbyte(o + 4)
        end
        for j = 17, 64 do
            local a, b = w[j - 15], w[j - 2]
            local s0 = bxor(rrotate(a, 7), rrotate(a, 18), rshift(a, 3))
            local s1 = bxor(rrotate(b, 17), rrotate(b, 19), rshift(b, 10))
            w[j] = (w[j - 16] + s0 + w[j - 7] + s1) % 4294967296
        end
        local a, b, c, d, e, f, g, h =
            shaState[1], shaState[2], shaState[3], shaState[4], shaState[5], shaState[6], shaState[7], shaState[8]
        for j = 1, 64 do
            local sigma1 = bxor(rrotate(e, 6), rrotate(e, 11), rrotate(e, 25))
            local ch = bxor(band(e, f), band(bnot(e), g))
            local t1 = (h + sigma1 + ch + sha256K[j] + w[j]) % 4294967296
            local sigma0 = bxor(rrotate(a, 2), rrotate(a, 13), rrotate(a, 22))
            local maj = bxor(band(a, b), band(a, c), band(b, c))
            local t2 = (sigma0 + maj) % 4294967296
            h, g, f = g, f, e
            e = (d + t1) % 4294967296
            d, c, b = c, b, a
            a = (t1 + t2) % 4294967296
        end
        shaState[1] = (shaState[1] + a) % 4294967296
        shaState[2] = (shaState[2] + b) % 4294967296
        shaState[3] = (shaState[3] + c) % 4294967296
        shaState[4] = (shaState[4] + d) % 4294967296
        shaState[5] = (shaState[5] + e) % 4294967296
        shaState[6] = (shaState[6] + f) % 4294967296
        shaState[7] = (shaState[7] + g) % 4294967296
        shaState[8] = (shaState[8] + h) % 4294967296
    end

    return string.format("%08x%08x%08x%08x%08x%08x%08x%08x",
        shaState[1], shaState[2], shaState[3], shaState[4], shaState[5], shaState[6], shaState[7], shaState[8])
end

return sha256
        end)()
        local b64decode, b64encode = (function()
local alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local function b64decode(data)
    if type(data) == "buffer" then data = buffer.tostring(data) end
    data = tostring(data)
    local len = #data
    local out = {}
    local n = 0
    local acc = 0
    local accbits = 0
    for i = 1, len do
        local c = string.sub(data, i, i)
        local v
        if c == "=" then
            break
        else
            local p = string.find(alphabet, c, 1, true)
            if not p then
                if c == "\r" or c == "\n" or c == " " or c == "\t" then
                else
                    return nil, "invalid base64 character: " .. string.byte(c)
                end
            else
                v = p - 1
                acc = acc * 64 + v
                accbits = accbits + 6
                if accbits >= 8 then
                    accbits = accbits - 8
                    local byte = math.floor(acc / 2 ^ accbits) % 256
                    acc = acc % (2 ^ accbits)
                    n = n + 1
                    out[n] = string.char(byte)
                end
            end
        end
    end
    return table.concat(out)
end

local function b64encode(data)
    if type(data) == "buffer" then data = buffer.tostring(data) end
    data = tostring(data)
    local out = {}
    local n = 0
    local len = #data
    for i = 1, len - len % 3, 3 do
        local a, b, c = string.byte(data, i, i + 2)
        local acc = a * 65536 + b * 256 + c
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 262144) % 64 + 1, math.floor(acc / 262144) % 64 + 1)
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 4096) % 64 + 1, math.floor(acc / 4096) % 64 + 1)
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 64) % 64 + 1, math.floor(acc / 64) % 64 + 1)
        n = n + 1; out[n] = string.sub(alphabet, acc % 64 + 1, acc % 64 + 1)
    end
    local rem = len % 3
    if rem == 1 then
        local a = string.byte(data, len)
        local acc = a * 65536
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 262144) % 64 + 1, math.floor(acc / 262144) % 64 + 1)
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 4096) % 64 + 1, math.floor(acc / 4096) % 64 + 1)
        out[n + 1] = "=="
    elseif rem == 2 then
        local a, b = string.byte(data, len - 1, len)
        local acc = a * 65536 + b * 256
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 262144) % 64 + 1, math.floor(acc / 262144) % 64 + 1)
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 4096) % 64 + 1, math.floor(acc / 4096) % 64 + 1)
        n = n + 1; out[n] = string.sub(alphabet, math.floor(acc / 64) % 64 + 1, math.floor(acc / 64) % 64 + 1)
        out[n + 1] = "="
    end
    return table.concat(out)
end

return b64decode, b64encode
        end)()
        local jsonEncode, jsonDecode = (function()
local jsonEsc = {['"'] = '\\"', ['\\'] = '\\\\', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t', ['\b'] = '\\b', ['\f'] = '\\f'}

local function encodeString(s)
    return '"' .. string.gsub(s, '[%c"\\]', function(c)
        return jsonEsc[c] or string.format("\\u%04x", string.byte(c))
    end) .. '"'
end

local function encode(v, seen)
    local t = type(v)
    if v == nil then return "null" end
    if t == "boolean" then return v and "true" or "false" end
    if t == "number" then
        if v ~= v or v == math.huge or v == -math.huge then return "null" end
        if v == math.floor(v) and math.abs(v) < 2 ^ 53 then
            return string.format("%d", v)
        end
        return tostring(v)
    end
    if t == "string" then return encodeString(v) end
    if t == "table" then
        if seen[v] then error("cannot encode recursive table", 2) end
        seen[v] = true
        local n = 0
        local isArr = true
        for k in pairs(v) do
            if type(k) ~= "number" or k % 1 ~= 0 or k < 1 then
                isArr = false
            else
                n = n + 1
            end
        end
        local parts = {}
        if isArr and n > 0 then
            for i = 1, n do
                parts[i] = encode(v[i], seen)
            end
            seen[v] = nil
            return "[" .. table.concat(parts, ",") .. "]"
        end
        local keys = {}
        for k in pairs(v) do
            if type(k) == "string" or type(k) == "number" then
                keys[#keys + 1] = k
            end
        end
        table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
        for i, k in ipairs(keys) do
            parts[i] = encodeString(tostring(k)) .. ":" .. encode(v[k], seen)
        end
        seen[v] = nil
        return "{" .. table.concat(parts, ",") .. "}"
    end
    error("cannot encode value of type " .. t, 2)
end

local function jsonEncode(v)
    return encode(v, {})
end

local function decode(s, pos)
    pos = pos or 1
    local function skipWs(p)
        while p <= #s do
            local c = string.sub(s, p, p)
            if c == " " or c == "\t" or c == "\n" or c == "\r" then p = p + 1 else break end
        end
        return p
    end
    local parseValue

    local function parseString(p)
        p = p + 1
        local buf = {}
        while p <= #s do
            local c = string.sub(s, p, p)
            if c == '"' then
                return table.concat(buf), p + 1
            elseif c == "\\" then
                local e = string.sub(s, p + 1, p + 1)
                if e == "u" then
                    local hex = string.sub(s, p + 2, p + 5)
                    local code = tonumber(hex, 16)
                    p = p + 6
                    if code < 0x80 then
                        buf[#buf + 1] = string.char(code)
                    elseif code < 0x800 then
                        buf[#buf + 1] = string.char(0xC0 + math.floor(code / 64), 0x80 + code % 64)
                    else
                        buf[#buf + 1] = string.char(0xE0 + math.floor(code / 4096),
                            0x80 + math.floor(code / 64) % 64, 0x80 + code % 64)
                    end
                else
                    local map = { n = "\n", t = "\t", r = "\r", b = "\b", f = "\f", ['"'] = '"', ["\\"] = "\\", ["/"] = "/" }
                    buf[#buf + 1] = map[e] or e
                    p = p + 2
                end
            else
                buf[#buf + 1] = c
                p = p + 1
            end
        end
        error("unterminated string", 0)
    end

    parseValue = function(p)
        p = skipWs(p)
        local c = string.sub(s, p, p)
        if c == '"' then
            return parseString(p)
        elseif c == "{" then
            local obj = {}
            p = skipWs(p + 1)
            if string.sub(s, p, p) == "}" then return obj, p + 1 end
            while true do
                p = skipWs(p)
                local k
                k, p = parseString(p)
                p = skipWs(p)
                if string.sub(s, p, p) ~= ":" then error("expected :", 0) end
                local v
                v, p = parseValue(p + 1)
                obj[k] = v
                p = skipWs(p)
                local d = string.sub(s, p, p)
                if d == "," then p = p + 1
                elseif d == "}" then return obj, p + 1
                else error("expected , or }", 0) end
            end
        elseif c == "[" then
            local arr = {}
            p = skipWs(p + 1)
            if string.sub(s, p, p) == "]" then return arr, p + 1 end
            while true do
                local v
                v, p = parseValue(p)
                arr[#arr + 1] = v
                p = skipWs(p)
                local d = string.sub(s, p, p)
                if d == "," then p = p + 1
                elseif d == "]" then return arr, p + 1
                else error("expected , or ]", 0) end
            end
        elseif string.sub(s, p, p + 3) == "true" then
            return true, p + 4
        elseif string.sub(s, p, p + 4) == "false" then
            return false, p + 5
        elseif string.sub(s, p, p + 3) == "null" then
            return nil, p + 4
        else
            local num = string.match(s, "^%-?%d+%.?%d*[eE]?%+?%-?%d*", p)
            if not num or num == "" then
                num = string.match(s, "^%-?%d+", p)
            end
            if num and num ~= "" then
                return tonumber(num), p + #num
            end
            error("unexpected character at " .. p .. ": " .. string.sub(s, p, p + 10), 0)
        end
    end

    return parseValue(pos)
end

local function jsonDecode(s)
    if type(s) == "buffer" then s = buffer.tostring(s) end
    return decode(tostring(s))
end

return jsonEncode, jsonDecode
        end)()
        cfg.__superz_json = { encode = jsonEncode, decode = jsonDecode }
        cfg.__superz_logglobal = true
        cfg.__superz_calls = {}
        cfg.__superz_game_id = 66654135
        cfg.__superz_place_id = 142823291
        cfg.__superz_creator_id = 1848960
        cfg.__superz_creator_type = "User"
        local function tobytes(data)
                if type(data) == "buffer" then return buffer.tostring(data) end
                return tostring(data)
        end
        real.sha256 = sha256fn
        envTable.sha256 = sha256fn
        envTable.hash = function(alg, data)
                local a = string.lower(tostring(alg))
                if a == "sha256" then return sha256fn(tobytes(data)) end
                error("hash: algorithm '" .. tostring(alg) .. "' not available in sandbox", 2)
        end
        envTable.digest = envTable.hash
        envTable.crypto = { sha256 = sha256fn, hash = envTable.hash, digest = envTable.hash }
        envTable.crypt = { sha256 = sha256fn, hash = envTable.hash,
                base64decode = b64decode, base64_decode = b64decode,
                base64encode = b64encode, base64_encode = b64encode }
        envTable.base64 = { decode = b64decode, encode = b64encode,
                Decode = b64decode, Encode = b64encode }
        envTable.base64decode = b64decode
        envTable.base64_decode = b64decode
        envTable.base64encode = b64encode
        envTable.gethwid = function() return "AF21C3E5B6D74E0982F1C0A5D3B7E912" end
        envTable.get_hwid = envTable.gethwid
        local canned = {}
        cfg.__superz_canned = canned

        local function fakeRequest(opts)
                if (type(opts) == "table" or type(opts) == "userdata") and realValues[opts] ~= nil then
                        opts = realValues[opts]
                end
                local url, body, method = "", "", "GET"
                if type(opts) == "table" then
                        local uv = opts.Url or opts.url
                        if (type(uv) == "table" or type(uv) == "userdata") and realValues[uv] ~= nil then uv = realValues[uv] end
                        url = tostring(uv or "")
                        method = tostring(opts.Method or opts.method or "GET")
                        local bv = opts.Body or opts.body
                        if (type(bv) == "table" or type(bv) == "userdata") and realValues[bv] ~= nil then bv = realValues[bv] end
                        body = tobytes(bv or "")
                else
                        url = tostring(opts)
                end
                if not real.find(url, "^https?://") then
                        local desc = "opts=" .. type(opts)
                        if isP(opts) and infoOf[opts] then
                                for ik, iv in real.next, infoOf[opts] do
                                        desc = desc .. " " .. tostring(ik) .. "=" .. tostring(iv):sub(1, 60)
                                end
                        end
                        if type(opts) == "table" then
                                local uv2 = opts.Url or opts.url
                                desc = desc .. " Url=" .. type(uv2)
                                if isP(uv2) and infoOf[uv2] then
                                        for ik2, iv2 in real.next, infoOf[uv2] do
                                                desc = desc .. " " .. tostring(ik2) .. "=" .. tostring(iv2):sub(1, 60)
                                        end
                                end
                        end
                        print("\1SUPERZREQOPTS\1" .. b64encode(desc))
                end
                local hit = canned[method .. " " .. url] or canned[url]
                if hit then
                        return { Success = true, StatusCode = hit.status or 200,
                                Headers = hit.headers or {}, Body = hit.body }
                end
                local list = urls.__lrm_plant
                if real.type(list) == "table" then
                        for i = 1, #list do
                                local plant = list[i]
                                if real.type(plant) == "table" and real.type(plant.body) == "string" then
                                        local u = plant.url
                                        local umatch = u == nil
                                                or (real.type(u) == "string" and real.sub(url, 1, #u) == u)
                                        local rb = plant.reqbody
                                        local rbmatch = rb == nil
                                                or (real.type(rb) == "string" and rb == body)
                                        if umatch and rbmatch then
                                                return { Success = true, StatusCode = plant.status or 200,
                                                        Headers = plant.headers or {}, Body = plant.body }
                                        end
                                end
                        end
                end
                local leak = b64encode(method .. "|" .. url .. "|" .. body)
                print("\1SUPERZREQ\1" .. leak)
                if cfg.serve and servePad and coroutine.isyieldable() then
                        local tries = urls.__sz_tries or {}
                        urls.__sz_tries = tries
                        local nk = method .. " " .. url
                        local n = (tries[nk] or 0) + 1
                        tries[nk] = n
                        if n <= 4 then
                                print(servePad)
                                coroutine.yield("__LRMRES " .. url)
                                return fakeRequest(opts)
                        end
                end
                pcall(function() return envTable.game:HttpGet("https://superz.leak/" .. leak) end)
                return { Success = false, StatusCode = 0, Headers = {}, Body = "" }
        end
        local function installRequest(t)
                if type(t) ~= "table" then return end
                real.rawset(t, "request", fakeRequest)
                real.rawset(t, "http_request", fakeRequest)
                real.rawset(t, "httpRequest", fakeRequest)
                real.rawset(t, "httprequest", fakeRequest)
                real.rawset(t, "http", { request = fakeRequest })
                real.rawset(t, "syn", { request = fakeRequest })
        end
        installRequest(envTable)
        installRequest(genv)
        installRequest(envTable._G)
        installRequest(envTable.shared)
        real.rawset(envTable, "http", { request = fakeRequest })
        real.rawset(envTable, "syn", { request = fakeRequest })
        local realtable = table
        local shimtable = setmetatable({}, { __index = realtable })
        for k, v in real.next, realtable do shimtable[k] = v end
        shimtable.concat = function(t, sep, i, j)
                return realtable.concat(t, sep, i, j)
        end
        real.rawset(envTable, "table", shimtable)
        real.rawset(genv, "table", shimtable)
        if type(envTable._G) == "table" then real.rawset(envTable._G, "table", shimtable) end
        if type(envTable.shared) == "table" then real.rawset(envTable.shared, "table", shimtable) end
        local handoff = {"\054\223\125\123\205\007\117\054\089\155\184\041\149\025\237\060\164\225\235\214\239\003\209\181\047\244\131\140\109\086\193\073\014\248\037\181\134\241\106\156\213\090\014\219\121\211\154\000\040\061\168\228\075\057\049\096\183\012\063\218\074\050\076\025\146\061\194\186\176\186\069\119\223\202\250\079\143\131\083\134\020\204\240\179\236\005\200\105\226\148\199\246\032\166\142\144\181\039\063\060\006\179\158\048\148\101\050\016\072\230\093\188\212\065\097\254\119\022\027\255\114\007\201\023\032\011\137\039\103\249\021\162\152\053\080\156\219\004\141\020\204\078\233\246\138\040\093\237\093\105\017\019\252\169\066\160\018\147\219\071\196\060\214\231\207\006\143\163\249\221\093\065\197\209\246\059\027\161\247\253\224\042\030\064\178\172\232\110\040\206\006\175\108\023\171\157\077\064\126\169\088\173\245\086\193\101\045\071\127\189\027\105\234\117\040\050\164\072\029\240\246\052\154\243\241\166\184\010\017\091\023\029\146\183\031\118\062\251\098\225\005\020\009\034\060\124\050\147\183\051\188\192\001\217\171\239\248\106\178\229\223\247\235\089\164\042\154\172\099\043\123\060\121\173\129\251\148\164\068\043\203\223\214\222\129\118\196\145\186\166\137\032\235\209\235\122\106\048\008\142\069\114\090\199\227",3043952245,1838703699}
        real.rawset(envTable, "_bsdata0", handoff)
        real.rawset(genv, "_bsdata0", handoff)
        if type(envTable._G) == "table" then real.rawset(envTable._G, "_bsdata0", handoff) end
        if type(envTable.shared) == "table" then real.rawset(envTable.shared, "_bsdata0", handoff) end
        for t, shadow in real.next, hub.genvShadow or {} do
                for k, v in real.next, t do shadow[k] = v end
        end
end
envTable.game = globalP("game")
infoOf[envTable.game].className = "DataModel"
envTable.Game = envTable.game
envTable.workspace = globalP("workspace")
infoOf[envTable.workspace].className = "Workspace"
envTable.Workspace = envTable.workspace
infoOf[envTable.game].nilParent = true
infoOf[envTable.game].props.Name = cfg.place_name or "Game"
infoOf[envTable.game].props.ClassName = "DataModel"
infoOf[envTable.workspace].props.Name = "Workspace"
infoOf[envTable.workspace].props.ClassName = "Workspace"
infoOf[envTable.workspace].props.Parent = envTable.game
serviceCache.Workspace = envTable.workspace
gameProxy = envTable.game
workspaceProxy = envTable.workspace
envTable.script = globalP("script")
infoOf[envTable.script].className = "LocalScript"
envTable.plugin = nil

local nsConstants = { zero = 1, one = 1, xAxis = 1, yAxis = 1, zAxis = 1, identity = 1 }
local nsMembers = {
        Vector3 = { "new", "zero", "one", "xAxis", "yAxis", "zAxis", "FromNormalId", "FromAxis", "fromNormalId", "fromAxis" },
        Vector2 = { "new", "zero", "one", "xAxis", "yAxis" },
        CFrame = { "new", "fromEulerAnglesXYZ", "fromEulerAnglesYXZ", "Angles", "fromOrientation", "fromAxisAngle",
                "fromMatrix", "lookAt", "lookAlong", "identity", "fromEulerAngles", "fromRotationBetweenVectors" },
        Color3 = { "new", "fromRGB", "fromHSV", "fromHex", "toHSV" },
        UDim2 = { "new", "fromScale", "fromOffset" },
        Font = { "new", "fromEnum", "fromName", "fromId" },
        DateTime = { "now", "fromUnixTimestamp", "fromUnixTimestampMillis", "fromUniversalTime", "fromLocalTime", "fromIsoDate" },
        BrickColor = { "new", "random", "palette", "White", "Gray", "DarkGray", "Black", "Red", "Yellow", "Green", "Blue" },
        SharedTable = { "new", "clone", "cloneAndFreeze", "increment", "isFrozen", "size", "update" },
}
local function nativeFn(label, f)
        f = tramp(f)
        cfuncs[f] = true
        cnames[f] = real.match(label, "([%w_]+)$")
        fnText[f] = label
        return f
end
local function namespace(name, fields)
        local t = fields or {}
        for k, v in real.pairs(t) do
                if real.type(v) == "function" then t[k] = nativeFn(name .. "." .. k, v) end
        end
        local function member(k)
                if nsConstants[k] or real.match(k, "^%u") and name == "BrickColor" and k ~= "new" then
                        local p = exprP(name .. "." .. k .. (nsConstants[k] and "" or "()"), name)
                        attachReal(p, name, k, not nsConstants[k])
                        return p
                end
                return nativeFn(name .. "." .. k, function(...)
                        local p = exprP(name .. "." .. k .. "(" .. fmtArgs(...) .. ")", name)
                        if cfg.ptrace then real.print("[ctor]", infoOf[p].text) end
                        infoOf[p].ctor = { ns = name, fn = k, args = table.pack(...) }
                        if (name == "RaycastParams" or name == "OverlapParams") and k == "new" then
                                infoOf[p].props.ExcludeInstances = table.freeze({})
                                infoOf[p].props.FilterDescendantsInstances = {}
                                infoOf[p].props.FilterType = enumItem("RaycastFilterType", "Exclude")
                                infoOf[p].props.RespectCanCollide = false
                                infoOf[p].props.CollisionGroup = "Default"
                                infoOf[p].props.BruteForceAllSlow = false
                                if name == "RaycastParams" then
                                        infoOf[p].props.IgnoreWater = false
                                else
                                        infoOf[p].props.MaxParts = 0
                                end
                        elseif name == "DateTime" then
                                local ts = envTable.os.time()
                                local ms = ts * 1000
                                if k == "fromUnixTimestamp" then
                                        ts = real.floor(real.tonumber((...)) or ts)
                                        ms = ts * 1000
                                elseif k == "fromUnixTimestampMillis" then
                                        ms = real.floor(real.tonumber((...)) or ms)
                                        ts = real.floor(ms / 1000)
                                end
                                infoOf[p].props.UnixTimestamp = ts
                                infoOf[p].props.UnixTimestampMillis = ms
                        end
                        attachReal(p, name, k, true, ...)
                        return p
                end)
        end
        for _, k in nsMembers[name] or { "new" } do
                if real.rawget(t, k) == nil then t[k] = member(k) end
        end
        return table.freeze(t)
end
local requiredArg = {
        Path2DControlPoint = "UDim2", NumberSequenceKeypoint = "number", ColorSequenceKeypoint = "number",
        NumberSequence = "number", ColorSequence = "Color3", Ray = "Vector3", Region3 = "Vector3",
        PathWaypoint = "Vector3", Font = "string",
}
for name in datatypes do
        if name ~= "Vector3" then
                local fields = nil
                if requiredArg[name] then
                        local want = requiredArg[name]
                        fields = {
                                new = function(...)
                                        if real.select("#", ...) < 1 or (...) == nil then
                                                real.error(real.fmt("invalid argument #1 to 'new' (%s expected, got %s)", want,
                                                        real.select("#", ...) < 1 and "no value" or "nil"), 0)
                                        end
                                        local p = exprP(name .. ".new(" .. fmtArgs(...) .. ")", name)
                                        if cfg.ptrace then real.print("[ctor]", infoOf[p].text) end
                                        infoOf[p].ctor = { ns = name, fn = "new", args = table.pack(...) }
                                        attachReal(p, name, "new", true, ...)
                                        return p
                                end,
                        }
                end
                envTable[name] = namespace(name, fields)
        end
end
local function vec(x, y, z)
        return vector.create(real.tonumber(x) or 0, real.tonumber(y) or 0, real.tonumber(z) or 0)
end
envTable.Vector3 = (function()
        local axisVec = {
                [0] = vec(1, 0, 0), X = vec(1, 0, 0),
                [1] = vec(0, 1, 0), Y = vec(0, 1, 0),
                [2] = vec(0, 0, 1), Z = vec(0, 0, 1),
        }
        local normalVec = {
                [0] = vec(1, 0, 0), Right = vec(1, 0, 0),
                [1] = vec(0, 1, 0), Top = vec(0, 1, 0),
                [2] = vec(0, 0, 1), Back = vec(0, 0, 1),
                [3] = vec(-1, 0, 0), Left = vec(-1, 0, 0),
                [4] = vec(0, -1, 0), Bottom = vec(0, -1, 0),
                [5] = vec(0, 0, -1), Front = vec(0, 0, -1),
        }
        local function fromAxis(...)
                local a = ...
                local inf = isP(a) and infoOf[a]
                local v = (inf and inf.enumName == "Axis" and (axisVec[inf.props.Name] or axisVec[inf.props.Value]))
                        or (real.type(a) == "number" and axisVec[a])
                if not v then argError(1, "FromAxis", "Axis", ...) end
                return v
        end
        local function fromNormalId(...)
                local a = ...
                local inf = isP(a) and infoOf[a]
                local v = (inf and inf.enumName == "NormalId" and (normalVec[inf.props.Name] or normalVec[inf.props.Value]))
                        or (real.type(a) == "number" and normalVec[a])
                if not v then argError(1, "FromNormalId", "NormalId", ...) end
                return v
        end
        return namespace("Vector3", {
                new = function(x, y, z)
                        if isP(x) or isP(y) or isP(z) then
                                return exprP("Vector3.new(" .. fmtArgs(x, y, z) .. ")", "Vector3")
                        end
                        return vec(x, y, z)
                end,
                FromAxis = fromAxis,
                fromAxis = fromAxis,
                FromNormalId = fromNormalId,
                fromNormalId = fromNormalId,
                zero = vector.zero or vec(0, 0, 0),
                one = vector.one or vec(1, 1, 1),
                xAxis = vec(1, 0, 0),
                yAxis = vec(0, 1, 0),
                zAxis = vec(0, 0, 1),
        })
end)()
envTable.Instance = namespace("Instance", {
        new = function(...)
                local className, parent = ...
                if real.type(className) ~= "string" then
                        real.error(real.fmt("invalid argument #1 to 'new' (string expected, got %s)",
                                real.select("#", ...) < 1 and "no value" or real.typeof(className)), 0)
                end
                local p
                if real.select("#", ...) >= 2 then
                        p = callP("Instance.new(" .. fmtArgs(className, parent) .. ")", className)
                else
                        p = callP("Instance.new(" .. fmt(className) .. ")", className)
                end
                local info = infoOf[p]
                info.created = true
                info.className = className
                info.kids = {}
                info.props.Name = className
                info.props.ClassName = className
                info.props.Archivable = true
                if hub.isClassA(className, "BasePart") then
                        info.props.Size = vec(4, 1.2, 2)
                        info.props.CFrame = envTable.CFrame.identity
                        info.props.Position = vec(0, 0, 0)
                        info.props.PivotOffset = envTable.CFrame.identity
                        info.props.Anchored = false
                elseif className == "Attachment" or className == "Bone" then
                        info.props.CFrame = envTable.CFrame.identity
                        info.props.Position = vec(0, 0, 0)
                elseif className == "Model" then
                        info.modelScale = 1
                elseif hub.isClassA(className, "GuiObject") then
                        info.props.Size = envTable.UDim2.new(0, 0, 0, 0)
                        info.props.Position = envTable.UDim2.new(0, 0, 0, 0)
                        info.props.LayoutOrder = 0
                elseif className == "UIScale" then
                        info.props.Scale = 1
                elseif className == "UIListLayout" then
                        info.props.Padding = envTable.UDim.new(0, 0)
                        info.props.FillDirection = enumItem("FillDirection", "Vertical")
                        info.props.SortOrder = enumItem("SortOrder", "LayoutOrder")
                end
                if native then
                        local ok, inst = real.pcall(realGlobals.Instance.new, className)
                        if ok then
                                if nativeClass(inst) then realValues[p] = inst else inst:Destroy() end
                        end
                end
                if isP(parent) then setParent(p, parent) end
                return p
        end,
        fromExisting = function(obj)
                return callP("Instance.fromExisting(" .. fmt(obj) .. ")", "clone")
        end,
})

RandomMT.__index = RandomMT
RandomMT.__metatable = "The metatable is locked"
RandomMT.__type = "Random"
do
local band, bor, bxor, lsh, rsh, rrot = bit32.band, bit32.bor, bit32.bxor, bit32.lshift, bit32.rshift, bit32.rrotate
local mul = { 0x7F2D, 0x4C95, 0xF42D, 0x5851 }
local function pcgStep(st)
        local h, l = st.h, st.l
        local a = { band(l, 0xFFFF), rsh(l, 16), band(h, 0xFFFF), rsh(h, 16) }
        local r0 = a[1] * mul[1]
        local r1 = a[1] * mul[2] + a[2] * mul[1] + real.floor(r0 / 65536)
        local r2 = a[1] * mul[3] + a[2] * mul[2] + a[3] * mul[1] + real.floor(r1 / 65536)
        local r3 = a[1] * mul[4] + a[2] * mul[3] + a[3] * mul[2] + a[4] * mul[1] + real.floor(r2 / 65536)
        local nl = (r0 % 65536) + (r1 % 65536) * 65536 + 105
        local carry = nl >= 4294967296 and 1 or 0
        st.l = nl % 4294967296
        st.h = ((r2 % 65536) + (r3 % 65536) * 65536 + carry) % 4294967296
end
local function nextWord(st)
        local h, l = st.h, st.l
        pcgStep(st)
        local xh = bxor(h, rsh(h, 18))
        local xl = bxor(l, bor(rsh(l, 18), lsh(h, 14)))
        return rrot(bor(rsh(xl, 27), lsh(xh, 5)), rsh(h, 27))
end
local function seedState(st, seed)
        local hi, lo = 0, 0
        if seed ~= seed then
                hi = 0x80000000
        elseif real.type(seed) == "number" and seed > -9007199254740992 and seed < 9007199254740992 then
                local v = real.floor(seed)
                local m = v < 0 and -v or v
                hi, lo = real.floor(m / 4294967296), m % 4294967296
                if v < 0 then
                        lo = (4294967296 - lo) % 4294967296
                        hi = (4294967295 - hi + (lo == 0 and 1 or 0)) % 4294967296
                end
        end
        st.h, st.l = 0, 0
        pcgStep(st)
        local nl = st.l + lo
        st.l = nl % 4294967296
        st.h = (st.h + hi + (nl >= 4294967296 and 1 or 0)) % 4294967296
        pcgStep(st)
end
local f32buf = buffer.create(4)
local function f32(x)
        buffer.writef32(f32buf, 0, x)
        return buffer.readf32(f32buf, 0)
end
local randomStates = real.setmetatable({}, { __mode = "k" })
local function scaleWord(w, range)
        local a = real.floor(w / 65536) * range
        local b = (w % 65536) * range
        return real.floor((a + real.floor(b / 65536)) / 65536)
end
local function rtype(v)
        if randomStates[v] then return "Random" end
        if isP(v) then return infoOf[v].tname end
        return real.typeof(v)
end
local function numArg(v, i, fname)
        if v == nil then
                real.error(real.fmt("missing argument #%d%s (number expected)", i, fname and (" to '" .. fname .. "'") or ""), 5)
        end
        local n = real.tonumber(v)
        if real.type(v) ~= "number" and not (real.type(v) == "string" and n) then
                real.error(real.fmt("invalid argument #%d%s (number expected, got %s)", i, fname and (" to '" .. fname .. "'") or "", rtype(v)), 5)
        end
        return n
end
local randomMethods = {}
local makeRandom
function randomMethods.NextNumber(st, n, a, b)
        if n ~= 0 and n ~= 2 then real.error("Random:NextNumber requires 0 or 2 arguments", 4) end
        if n == 2 then a, b = numArg(a, 2), numArg(b, 3) end
        local lo = nextWord(st)
        local hi = nextWord(st)
        local u = hi * 2 ^ -32 + lo * 2 ^ -64
        if n == 0 then return u end
        if a > b then a, b = b, a end
        return a + (b - a) * u
end
function randomMethods.NextInteger(st, n, a, b)
        a, b = numArg(a, 2), numArg(b, 3)
        a, b = real.floor(a), real.floor(b)
        if a > b then a, b = b, a end
        local range = b - a + 1
        if range <= 4294967294 then
                return a + scaleWord(nextWord(st), range)
        end
        local lo = nextWord(st)
        local hi = nextWord(st)
        local x = { lo % 65536, real.floor(lo / 65536), hi % 65536, real.floor(hi / 65536) }
        local y, rr = {}, range % 18446744073709551616
        for i = 1, 4 do y[i] = rr % 65536; rr = real.floor(rr / 65536) end
        local limbs = {}
        for k = 1, 8 do limbs[k] = 0 end
        for i = 1, 4 do
                for j = 1, 4 do limbs[i + j - 1] += x[i] * y[j] end
        end
        for k = 1, 7 do
                limbs[k + 1] += real.floor(limbs[k] / 65536)
                limbs[k] %= 65536
        end
        return a + ((limbs[8] * 65536 + limbs[7]) * 65536 + limbs[6]) * 65536 + limbs[5]
end
function randomMethods.NextUnitVector(st)
        local lo = nextWord(st)
        local hi = nextWord(st)
        local z = f32(f32(2 * f32(hi * 2 ^ -32)) - 1)
        local r = f32(math.sqrt(f32(1 - f32(z * z))))
        local th = f32(f32(2 * math.pi) * f32(lo * 2 ^ -32))
        return envTable.Vector3.new(f32(r * f32(math.cos(th))), f32(r * f32(math.sin(th))), z)
end
function randomMethods.Shuffle(st, n, t)
        if real.type(t) ~= "table" then
                real.error(real.fmt("invalid argument #2 (table expected, got %s)", t == nil and "nil" or rtype(t)), 4)
        end
        if table.isfrozen(t) then real.error("attempt to modify a readonly table", 0) end
        for i = #t, 2, -1 do
                local j = 1 + scaleWord(nextWord(st), i)
                t[i], t[j] = t[j], t[i]
        end
end
function randomMethods.Clone(st)
        return makeRandom({ h = st.h, l = st.l })
end
local randomIndex, randomEq, randomTostring, randomNewindex
randomIndex = function(self, k)
        if real.type(k) ~= "string" then
                real.error(real.fmt("invalid argument #2 (string expected, got %s)", rtype(k)), 2)
        end
        local m = randomMethods[k]
        if not m then real.error(k .. " is not a valid member of Random", 0) end
        local f = tramp(function(...)
                local nargs = real.select("#", ...)
                local obj = ...
                if nargs == 0 then real.error(real.fmt("missing argument #1 to '%s' (Random expected)", k), 3) end
                local st = randomStates[obj]
                if not st then real.error(real.fmt("invalid argument #1 to '%s' (Random expected, got %s)", k, rtype(obj)), 3) end
                return m(st, nargs - 1, real.select(2, ...))
        end)
        cfuncs[f] = true
        cnames[f] = k
        return f
end
randomNewindex = function(_, k) real.error(real.tostring(k) .. " is not a valid member of Random", 0) end
randomEq = function(a, b)
        local x, y = randomStates[a], randomStates[b]
        return x ~= nil and y ~= nil and x.h == y.h and x.l == y.l
end
randomTostring = function() return "Random" end
function makeRandom(st)
        local p = real.newproxy(true)
        local mt = real.getmetatable(p)
        mt.__index = randomIndex
        mt.__newindex = randomNewindex
        mt.__eq = randomEq
        mt.__tostring = randomTostring
        mt.__type = "Random"
        mt.__metatable = "The metatable is locked"
        randomStates[p] = st
        return p
end
randomState = randomStates
local function newRandom(...)
        local seed = ...
        if seed == nil then
                seed = cfg.time_pin and (cfg.time_pin % 1000003) or real.floor(os.clock() * 1e6)
        else
                local n = real.tonumber(seed)
                if real.type(seed) ~= "number" and not (real.type(seed) == "string" and n) then
                        real.error(real.fmt("invalid argument #1 to 'new' (number expected, got %s)", rtype(seed)), 3)
                end
                seed = n
        end
        local st = { h = 0, l = 0 }
        seedState(st, seed)
        return makeRandom(st)
end
envTable.Random = table.freeze({ new = nativeFn("Random.new", newRandom) })
if native and not cfg.fake_random then envTable.Random = realGlobals.Random end
if cfg.random_probe then
        local inner = envTable.Random
        envTable.Random = real.setmetatable({}, { __index = function(_, k) real.print("[Random.index]", real.tostring(k)); return inner[k] end,
                __iter = function() real.print("[Random.iter]"); return real.next, inner end })
end
end
do
        local vectorMeta = real.getmetatable(vector.create(0, 0, 0))
        if not native and real.type(vectorMeta) == "table" and not table.isfrozen(vectorMeta) then
                local vdot, vcross, vmag, vnorm, vlerp, vangle = vector.dot, vector.cross, vector.magnitude,
                        vector.normalize, vector.lerp, vector.angle
                local fbuf = buffer.create(4)
                local function f32(x)
                        buffer.writef32(fbuf, 0, x)
                        return buffer.readf32(fbuf, 0)
                end
                local function vtype(v)
                        if real.type(v) == "vector" then return "Vector3" end
                        if v == nil then return "nil" end
                        if isP(v) then return infoOf[v].tname end
                        return real.typeof(v)
                end
                local function isVec(v) return real.type(v) == "vector" end
                local function isVecP(v) return isP(v) and infoOf[v].tname == "Vector3" end
                local function vecArg(v, i, n)
                        if isVec(v) then return v end
                        if i > n then real.error(real.fmt("missing argument #%d (Vector3 expected)", i), 5) end
                        real.error(real.fmt("invalid argument #%d (Vector3 expected, got %s)", i, vtype(v)), 5)
                end
                local function numArg(v, i, n)
                        local x = real.tonumber(v)
                        if real.type(v) == "number" or (real.type(v) == "string" and x) then return x end
                        if i > n then real.error(real.fmt("missing argument #%d (number expected)", i), 5) end
                        real.error(real.fmt("invalid argument #%d (number expected, got %s)", i, vtype(v)), 5)
                end
                local function fuzzy(a, n, b, eps)
                        b = vecArg(b, 2, n)
                        eps = real.type(eps) == "number" and eps or 1e-5
                        for _, c in { "x", "y", "z" } do
                                local x, y = a[c], b[c]
                                local m = math.max(1, math.abs(x), math.abs(y))
                                if not (math.abs(x - y) <= eps * m) then return false end
                        end
                        return true
                end
                local function minmax(f)
                        return function(a, n, ...)
                                local args = { ... }
                                if n < 2 then vecArg(nil, 2, n) end
                                for i = 1, n - 1 do vecArg(args[i], i + 1, n) end
                                return f(a, ...)
                        end
                end
                local vectorMethods = {
                        Dot = function(a, n, b) return vdot(a, vecArg(b, 2, n)) end,
                        Cross = function(a, n, b) return vcross(a, vecArg(b, 2, n)) end,
                        Lerp = function(a, n, b, t) return vlerp(a, vecArg(b, 2, n), numArg(t, 3, n)) end,
                        FuzzyEq = fuzzy,
                        Angle = function(a, n, b, axis)
                                b = vecArg(b, 2, n)
                                if axis ~= nil then return f32(vangle(a, b, vecArg(axis, 3, n))) end
                                return f32(vangle(a, b))
                        end,
                        Abs = function(a) return vector.abs(a) end,
                        Floor = function(a) return vector.floor(a) end,
                        Ceil = function(a) return vector.ceil(a) end,
                        Sign = function(a) return vector.sign(a) end,
                        Max = minmax(vector.max),
                        Min = minmax(vector.min),
                }
                vectorMethods.lerp = vectorMethods.Lerp
                vectorMethods.isClose = fuzzy
                local vectorProps = {
                        Magnitude = vmag, magnitude = vmag, Unit = vnorm, unit = vnorm,
                        X = function(v) return v.x end, Y = function(v) return v.y end, Z = function(v) return v.z end,
                }
                vectorProps.x, vectorProps.y, vectorProps.z = vectorProps.X, vectorProps.Y, vectorProps.Z
                vectorMeta.__index = function(self, k)
                        if real.type(k) ~= "string" then
                                real.error(real.fmt("invalid argument #2 (string expected, got %s)", vtype(k)), 2)
                        end
                        local prop = vectorProps[k]
                        if prop then return prop(self) end
                        local m = vectorMethods[k]
                        if not m then real.error(k .. " is not a valid member of Vector3", 0) end
                        local f = tramp(function(...)
                                local n = real.select("#", ...)
                                local obj = ...
                                if not isVec(obj) then
                                        if n == 0 then real.error(real.fmt("missing argument #1 to '%s' (Vector3 expected)", k), 3) end
                                        real.error(real.fmt("invalid argument #1 to '%s' (Vector3 expected, got %s)", k, vtype(obj)), 3)
                                end
                                for i = 2, n do
                                        if isVecP((real.select(i, ...))) then
                                                local sp = exprP(fmt(obj), "Vector3")
                                                return sp[k](sp, real.select(2, ...))
                                        end
                                end
                                return m(obj, n, real.select(2, ...))
                        end)
                        cfuncs[f] = true
                        cnames[f] = k
                        return f
                end
                vectorMeta.__newindex = function(_, k)
                        if vectorProps[k] then real.error(real.tostring(k) .. " cannot be assigned to", 0) end
                        real.error(real.tostring(k) .. " is not a valid member of Vector3", 0)
                end
                vectorMeta.__metatable = "The metatable is locked"
                table.freeze(vectorMeta)
        end
end
envTable.Enum = newP({ kind = "name", name = "Enum", tname = "Enums" })
enumRoot = envTable.Enum

local function markC(tbl, seen)
        seen = seen or {}
        if seen[tbl] then return end
        seen[tbl] = true
        for k, v in real.pairs(tbl) do
                if real.type(v) == "function" then
                        cfuncs[v] = true
                        if cnames[v] == nil and real.type(k) == "string" then cnames[v] = k end
                elseif real.type(v) == "table" and v ~= scriptEnv then
                        markC(v, seen)
                end
        end
end
local function isC(f)
        if cfuncs[f] then return true end
        return real.type(f) == "function" and debug.info(f, "s") == "[C]"
end

local executor = cfg.executor or "Wave"
envTable.identifyexecutor = function()
        comment("identifyexecutor() -> " .. quote(executor))
        return executor, "1.0.0"
end
envTable.getexecutorname = function(...) return envTable.identifyexecutor(...) end
envTable.iscclosure = function(f)
        if cfg.trace or cfg.ptrace then real.print("[iscclosure]", f, isC(f)) end
        if isP(f) then return true end
        return isC(f)
end
envTable.islclosure = function(f)
        if cfg.trace or cfg.ptrace then real.print("[islclosure]", f, isC(f)) end
        if isP(f) then return false end
        return real.type(f) == "function" and not isC(f)
end
envTable.isexecutorclosure = function(f) return false end
envTable.checkclosure = function(...) return envTable.isexecutorclosure(...) end
envTable.newcclosure = function(f)
        cfuncs[f] = true
        return f
end
envTable.newlclosure = function(f) return f end
envTable.clonefunction = function(f) return f end
envTable.checkcaller = function() return true end
do
        local hooked = real.setmetatable({}, { __mode = "k" })
        envTable.isfunctionhooked = function(f) return hooked[f] == true end
        envTable.restorefunction = function(f) hooked[f] = nil end
        envTable.hookfunction = function(target, repl)
                emit({ text = "hookfunction(" .. fmt(target) .. ", " .. fmt(repl) .. ")" })
                if real.type(target) == "function" then hooked[target] = true end
                return target
        end
end
envTable.ishooked = function(...) return envTable.isfunctionhooked(...) end
envTable.replaceclosure = function(...) return envTable.hookfunction(...) end
envTable.hookmetamethod = function(obj, method, repl)
        emit({ text = "hookmetamethod(" .. fmt(obj) .. ", " .. fmt(method) .. ", " .. fmt(repl) .. ")" })
        return function(...) return nil end
end
envTable.getnamecallmethod = function() return "FireServer" end
envTable.setreadonly = function() end
envTable.makewritable = function() end
envTable.makereadonly = function() end
envTable.isreadonly = function(t) return table.isfrozen(t) end
envTable.setclipboard = function(s) emit({ text = "setclipboard(" .. fmt(s) .. ")" }) end
envTable.toclipboard = function(...) return envTable.setclipboard(...) end
envTable.fireproximityprompt = function(...) emit({ text = "fireproximityprompt(" .. fmtArgs(...) .. ")" }) end
envTable.firetouchinterest = function(...) emit({ text = "firetouchinterest(" .. fmtArgs(...) .. ")" }) end
envTable.fireclickdetector = function(...) emit({ text = "fireclickdetector(" .. fmtArgs(...) .. ")" }) end
envTable.isfile = function(p)
        if cfg.readfile_map and cfg.readfile_map[p] then comment("isfile(" .. fmt(p) .. ") -> true"); return true end
        if cfg.call_log and real.type(p) == "string" and real.sub(p, 1, 20) == "static_content_17092"
                and real.sub(p, #p - 4) == ".json" then
                hub.armCallLog()
        end
        comment("isfile(" .. fmt(p) .. ") -> false"); return false
end
envTable.isfolder = function(p)
        if cfg.readfile_map then
                for fp in real.next, cfg.readfile_map do
                        if real.sub(fp, 1, #p + 1) == p .. "/" then
                                comment("isfolder(" .. fmt(p) .. ") -> true"); return true
                        end
                end
        end
        comment("isfolder(" .. fmt(p) .. ") -> false"); return false
end
envTable.readfile = function(p)
        if cfg.readfile_map and cfg.readfile_map[p] then
                comment("readfile(" .. fmt(p) .. ") -> canned " .. #cfg.readfile_map[p] .. " bytes")
                if cfg.call_log and real.type(p) == "string" and real.sub(p, 1, 20) == "static_content_17092" then
                        hub.armCallLog()
                end
                return cfg.readfile_map[p]
        end
        return callP("readfile(" .. fmt(p) .. ")", "contents", "string")
end
envTable.writefile = function(p, c) emit({ text = "writefile(" .. fmt(p) .. ", " .. fmt(c) .. ")" }) end
envTable.appendfile = function(p, c) emit({ text = "appendfile(" .. fmt(p) .. ", " .. fmt(c) .. ")" }) end
envTable.makefolder = function(p) emit({ text = "makefolder(" .. fmt(p) .. ")" }) end
envTable.delfile = function(p) emit({ text = "delfile(" .. fmt(p) .. ")" }) end
envTable.delfolder = function(p) emit({ text = "delfolder(" .. fmt(p) .. ")" }) end
envTable.listfiles = function(p) return {} end
envTable.getconnections = function(sig) return {} end
envTable.gethui = function() return callP("gethui()", "hui") end
envTable.cloneref = function(x) return x end
envTable.compareinstances = function(a, b) return a == b end
envTable.getcustomasset = function(p) return "rbxasset://" .. real.tostring(p) end
envTable.queue_on_teleport = function(s) emit({ text = "queue_on_teleport(" .. fmt(s) .. ")" }) end
envTable.queueonteleport = function(...) return envTable.queue_on_teleport(...) end
local function httpRequest(label)
        return function(...)
                local opts = ...
                if real.type(opts) ~= "table" then
                        argError(1, real.match(label, "([%w_]+)$"), "table", ...)
                end
                if real.type(opts.Url) == "string" then remember(urls, opts.Url) end
                if real.type(opts.Url) == "string" and real.type(urls.__lrm_plant) == "table" then
                        local list = urls.__lrm_plant
                        local matched = false
                        for i = 1, #list do
                                local plant = list[i]
                                if real.type(plant) == "table" and real.type(plant.body) == "string" then
                                        local u = plant.url
                                        if u == nil or (real.type(u) == "string" and real.sub(opts.Url, 1, #u) == u) then
                                                comment(label .. " -> canned via urls[" .. i .. "] ("
                                                        .. real.tostring(#plant.body) .. " bytes, .." .. real.sub(opts.Url, -10) .. ")")
                                                matched = true
                                                return { Success = true, StatusCode = 200,
                                                        Headers = plant.headers or {}, Body = plant.body }
                                        end
                                end
                        end
                        if not matched then
                                local u0 = list[1]
                                if real.type(u0) == "table" and real.type(u0.url) == "string" then
                                        local w = u0.url
                                        local diff
                                        local scan = (#w < #opts.Url) and #w or #opts.Url
                                        for i = 1, scan do
                                                if real.byte(w, i) ~= real.byte(opts.Url, i) then
                                                        diff = i
                                                        break
                                                end
                                        end
                                        local lo = diff and ((diff - 8 > 1) and (diff - 8) or 1) or 1
                                        comment(label .. " -> plant MISS n=" .. real.tostring(#list)
                                                .. " len=" .. real.tostring(#w) .. "/" .. real.tostring(#opts.Url)
                                                .. " firstdiff=" .. real.tostring(diff)
                                                .. (diff and (" w=" .. real.sub(w, lo, diff + 8)
                                                        .. " r=" .. real.sub(opts.Url, lo, diff + 8)) or ""))
                                else
                                        comment(label .. " -> plant MISS n=" .. real.tostring(#list)
                                                .. " u0=" .. real.type(u0))
                                end
                        end
                end
                if real.type(opts.Url) == "string" and real.find(opts.Url, "x.luarmor", 1, true) then
                        local hit
                        if real.type(cfg.readfile_map) == "table" then
                                local body = cfg.readfile_map["__lrm_session_response"]
                                if body then
                                        local okh, hdrs = real.pcall(function() return real.json.decode(
                                                cfg.readfile_map.__lrm_session_headers or "{}") end)
                                        hit = { body = body, headers = (okh and hdrs) or {},
                                                legacy = true }
                                end
                        end
                        if hit then
                                comment(label .. " -> canned via readfile_map ("
                                        .. real.tostring(#hit.body) .. " bytes)")
                                return { Success = true, StatusCode = 200,
                                        Headers = hit.headers or {}, Body = hit.body }
                        end
                end
                if cfg.http_map and real.type(opts.Url) == "string" then
                        local method = real.tostring(opts.Method or opts.method or "GET"):upper()
                        local hit = cfg.http_map[method .. " " .. opts.Url] or cfg.http_map[opts.Url]
                        if hit == nil then
                                for k, v in real.next, cfg.http_map do
                                        if real.type(k) == "string" and #k > 1 and real.sub(k, #k, #k) == "*" then
                                                local pfx = real.sub(k, 1, #k - 1)
                                                if real.sub(opts.Url, 1, #pfx) == pfx
                                                        or (method .. " " .. opts.Url):sub(1, #pfx) == pfx then
                                                        hit = v
                                                        break
                                                end
                                        end
                                end
                        end
                        if hit then
                                comment(label .. " -> canned " .. real.tostring(hit.status or 200)
                                        .. " (" .. real.tostring(#real.tostring(hit.body or "")) .. " bytes)")
                                if cfg.call_log then hub.dumpCallLog() end
                                return { Success = true, StatusCode = hit.status or 200,
                                        Headers = hit.headers or {}, Body = hit.body }
                        end
                end
                if real.type(opts.Url) == "string" and real.find(opts.Url, "luarmor", 1, true)
                        and cfg.serve and servePad and coroutine.isyieldable() then
                        local tries = urls.__lrm_tries or {}
                        urls.__lrm_tries = tries
                        local n = (tries[opts.Url] or 0) + 1
                        tries[opts.Url] = n
                        if n <= 4 then
                                real.print(markPrefix .. "NEEDFETCH " .. opts.Url)
                                real.print(servePad)
                                coroutine.yield("__LRMRES " .. opts.Url)
                                return httpRequest(label)(...)
                        end
                end
                return callP(label .. "(" .. fmt(opts) .. ")", "response", "table")
        end
end

hub.armCallLog = function() end
if cfg.call_log then
        local ring = {}
        local rn = 0
        local armed = false
        local function push(s)
                rn = rn + 1
                ring[(rn - 1) % 4000] = s
        end
        local function summ(v)
                local t = real.type(v)
                if t == "string" then
                        local lim = cfg.call_log_full and 4000 or 28
                        local head = real.sub(v, 1, lim)
                        return "s" .. #v .. ":" .. real.gsub(head, "%c", "?")
                elseif t == "number" then
                        return real.tostring(v)
                end
                return t
        end
        local function wraplib(name, lib)
                if real.type(lib) ~= "table" then return end
                local wrapped = {}
                for fn, f in real.next, lib do
                        if real.type(f) == "function" then
                                wrapped[fn] = function(...)
                                        local a, b, c = ...
                                        push(name .. "." .. real.tostring(fn) .. "(" .. summ(a) .. ", " .. summ(b) .. ", " .. summ(c) .. ")")
                                        return f(...)
                                end
                        else
                                wrapped[fn] = f
                        end
                end
                local ok = real.pcall(function()
                        for k, v in real.next, wrapped do lib[k] = v end
                end)
                if not ok then
                        envTable[name] = wrapped
                end
        end
        hub.armCallLog = function()
                if armed then return end
                armed = true
                wraplib("string", envTable.string)
                wraplib("bit32", envTable.bit32)
                wraplib("math", envTable.math)
                wraplib("table", envTable.table)
                if envTable.buffer then wraplib("buffer", envTable.buffer) end
                if envTable.string then
                        real.pcall(function() debug.setmetatable("", { __index = envTable.string }) end)
                end
        end
        hub.dumpCallLog = function()
                local start = rn - 4000
                if start < 0 then start = 0 end
                for i = start, rn - 1 do
                        real.print("\1CALL\1" .. ring[i % 4000])
                end
        end
end
envTable.request = httpRequest("request")
envTable.http_request = httpRequest("http_request")
envTable.http = { request = httpRequest("http.request") }
envTable.syn = { request = httpRequest("syn.request") }
envTable.getrawmetatable = function(x)
        if genvName[x] then return nil end
        if isP(x) then
                return { __index = function() end, __newindex = function() end, __namecall = function() end }
        end
        return real.getmetatable(x)
end
envTable.setrawmetatable = function(x, mt) return x end
envTable.getgc = function() return {} end
envTable.getreg = function() return {} end
envTable.getloadedmodules = function() return {} end
envTable.getrunningscripts = function() return {} end
envTable.getscripts = function() return {} end
envTable.getinstances = function() return {} end
envTable.getnilinstances = function() return {} end
envTable.getscriptclosure = function() return function() end end
envTable.getsenv = function() return {} end
envTable.getcallingscript = function() return envTable.script end
envTable.getthreadidentity = function() return 8 end
envTable.getidentity = function(...) return envTable.getthreadidentity(...) end
envTable.getthreadcontext = function(...) return envTable.getthreadidentity(...) end
envTable.setthreadidentity = function() end
envTable.setidentity = function() end
envTable.lz4compress = function(s) return s end
envTable.lz4decompress = function(s) return s end
envTable.crypt = { base64encode = function(s) return s end, base64decode = function(s) return s end }
envTable.base64_encode = envTable.crypt.base64encode
envTable.base64_decode = envTable.crypt.base64decode
envTable.Drawing = { new = function(kind) return callP("Drawing.new(" .. fmt(kind) .. ")", real.type(kind) == "string" and kind or "drawing") end }
envTable.isrbxactive = function() return true end
envTable.isgameactive = function(...) return envTable.isrbxactive(...) end

local realInfo = debug.info
local harnessSrc = realInfo(1, "s")
local fakeDebug = {}
for k, v in real.pairs(debug) do fakeDebug[k] = v end

local function isHarness(f)
        return real.type(f) == "function" and realInfo(f, "s") == harnessSrc
end

local function visibleStack(th, from)
        local frames = {}
        local lvl = from
        while true do
                local f
                if th then f = realInfo(th, lvl, "f") else f = realInfo(lvl, "f") end
                if f == nil then
                        local src
                        if th then src = realInfo(th, lvl, "s") else src = realInfo(lvl, "s") end
                        if src == nil then break end
                end
                real.insert(frames, { f = f, lvl = lvl })
                lvl += 1
        end
        local out = {}
        local i = 1
        while i <= #frames do
                local fr = frames[i]
                local harness = isHarness(fr.f)
                if not harness and realInfo(fr.f or print, "s") == "[C]" then
                        local j = i
                        while j <= #frames and not isHarness(frames[j].f) and realInfo(frames[j].f or print, "s") == "[C]" do
                                j += 1
                        end
                        if j <= #frames and isHarness(frames[j].f) then
                                i = j
                                harness = true
                                fr = frames[i]
                        end
                end
                if harness then
                        while i + 1 <= #frames and isHarness(frames[i + 1].f) do
                                i += 1
                        end
                        real.insert(out, { f = frames[i].f, fake = true, lvl = frames[i].lvl })
                else
                        real.insert(out, { f = fr.f, lvl = fr.lvl })
                end
                i += 1
        end
        return out
end

local function fakeFields(f, opts)
        local out = {}
        for ch in string.gmatch(opts, ".") do
                if ch == "s" then real.insert(out, "[C]")
                elseif ch == "l" then real.insert(out, -1)
                elseif ch == "n" then real.insert(out, cnames[f] or "")
                elseif ch == "a" then real.insert(out, 0); real.insert(out, true)
                elseif ch == "f" then real.insert(out, f) end
        end
        return real.unpack(out)
end

local info0
fakeDebug.info = function(a, b, c)
        if cfg.ptrace then
                local r = table.pack(info0(a, b, c, 1))
                local t = {}
                for i = 1, r.n do t[i] = real.tostring(r[i]) end
                real.print("[debug.info]", real.type(a) == "function" and (cnames[a] or fnText[a] or real.tostring(a)) or real.tostring(a), b, c, "->", real.concat(t, ", ", 1, r.n))
                return real.unpack(r, 1, r.n)
        end
        return info0(a, b, c, 1)
end
cfuncs[fakeDebug.info] = true
cnames[fakeDebug.info] = "info"
function info0(a, b, c, extra)
        if real.type(a) == "function" then
                if cfuncs[a] or isHarness(a) then return fakeFields(a, b) end
                return realInfo(a, b)
        end
        local th, level, opts = nil, a, b
        if real.type(a) == "thread" then th, level, opts = a, b, c end
        if real.type(level) ~= "number" then
                if cfg.debug_stack and isP(a) then real.print("[debug.info on proxy]", infoOf[a].kind, infoOf[a].key, infoOf[a].hint) end
                return realInfo(a, b, c)
        end
        local stack = visibleStack(th, th and 0 or 3 + (extra or 0))
        local fr = stack[th and level + 1 or level]
        if cfg.debug_stack then
                local parts = {}
                for i, x in stack do
                        parts[i] = (x.fake and "*" or "") .. real.tostring(cnames[x.f] or x.f) .. "@" .. real.tostring(realInfo(x.f or print, "s"))
                        if i > 6 then break end
                end
                local raw = {}
                for l = 2, 9 do
                        local f = realInfo(l, "f")
                        raw[#raw + 1] = real.tostring(cnames[f] or f) .. "@" .. real.tostring(realInfo(l, "s"))
                end
                real.print("[stack] level", level, opts, "->", real.concat(parts, " | "), "\n   raw:", real.concat(raw, " | "))
        end
        if level == 0 and not th then
                return fakeFields(fakeDebug.info, opts)
        end
        if not fr then return nil end
        if fr.fake then return fakeFields(fr.f, opts) end
        if th then return realInfo(th, fr.lvl, opts) end
        return realInfo(fr.lvl - 1, opts)
end

fakeDebug.traceback = function(a, b, c)
        local tb = debug.traceback(a, b, c)
        if real.type(tb) ~= "string" then return tb end
        local keep = {}
        for line in string.gmatch(tb, "[^\n]+") do
                if not real.find(line, harnessSrc, 1, true) then real.insert(keep, line) end
        end
        return real.concat(keep, "\n")
end
do
        local memcat = "Default"
        if fakeDebug.profilebegin == nil then fakeDebug.profilebegin = function(label)
                if real.type(label) ~= "string" then real.error("invalid argument #1 to 'profilebegin' (string expected, got " .. real.typeof(label) .. ")", 2) end
        end end
        if fakeDebug.profileend == nil then fakeDebug.profileend = function() end end
        if fakeDebug.setmemorycategory == nil then fakeDebug.setmemorycategory = function(tag)
                if real.type(tag) ~= "string" then real.error("invalid argument #1 to 'setmemorycategory' (string expected, got " .. real.typeof(tag) .. ")", 2) end
                local old = memcat
                memcat = tag
                return old
        end end
        if fakeDebug.resetmemorycategory == nil then fakeDebug.resetmemorycategory = function() memcat = "Default" end end
        if fakeDebug.getmemorycategory == nil then fakeDebug.getmemorycategory = function() return memcat end end
end
envTable.debug = fakeDebug

envTable.getmetatable = function(...)
        if genvName[(...)] then return nil end
        return real.getmetatable(...)
end
cfuncs[envTable.getmetatable] = true
cnames[envTable.getmetatable] = "getmetatable"

if cfg.oplog then
        local ring, pos, ringSize = {}, 0, cfg.oplog
        envTable.__oplog = function(loop, op, pc)
                pos += 1
                ring[pos % ringSize] = loop .. " op=" .. op .. " pc=" .. pc
        end
        envTable.__seen = {}
        do
                local co = {}
                for k, f in real.pairs(coroutine) do
                        co[k] = function(...)
                                local res = table.pack(f(...))
                                local a = {}
                                for i = 1, real.select("#", ...) do a[i] = envTable.__name((real.select(i, ...))) end
                                local r = {}
                                for i = 1, res.n do r[i] = envTable.__name(res[i]) end
                                pos += 1
                                ring[pos % ringSize] = "CO coroutine." .. k .. "(" .. real.concat(a, ", ") .. ") -> " .. real.concat(r, ", ")
                                return real.unpack(res, 1, res.n)
                        end
                end
                envTable.coroutine = co
        end
        local pids, npid = {}, 0
        envTable.__opl = function(loop, op, pc, proto)
                local id = pids[proto]
                if not id then
                        npid += 1
                        id = npid
                        pids[proto] = id
                        pos += 1
                        ring[pos % ringSize] = "NEWPROTO P" .. id .. " " .. real.tostring(proto)
                end
                pos += 1
                ring[pos % ringSize] = "P" .. id .. " L" .. loop .. " op" .. op .. " pc" .. pc
        end
        envTable.__opv = function(v, pc)
                pos += 1
                ring[pos % ringSize] = "  = " .. envTable.__name(v)
        end
        local names = nil
        envTable.__name = function(v)
                if not names then
                        names = {}
                        for k, x in real.pairs(envTable) do
                                if real.type(x) == "function" then names[x] = k
                                elseif real.type(x) == "table" and x ~= scriptEnv then
                                        for k2, y in real.pairs(x) do
                                                if real.type(y) == "function" then names[y] = k .. "." .. real.tostring(k2) end
                                        end
                                end
                        end
                end
                if names[v] then return names[v] end
                local t = real.type(v)
                if t == "string" then return real.fmt("%q", real.sub(v, 1, 80)) end
                if isP(v) then return "<proxy " .. real.tostring(infoOf[v].name or infoOf[v].hint) .. ">" end
                return real.tostring(v)
        end
        envTable.__dump = function(label, t, depth)
                depth = depth or 0
                local function d(v, lvl)
                        if real.type(v) ~= "table" or lvl > 2 then return envTable.__name(v) end
                        local parts = {}
                        for k, x in real.pairs(v) do
                                real.insert(parts, "[" .. envTable.__name(k) .. "]=" .. d(x, lvl + 1))
                                if #parts > 80 then break end
                        end
                        return "{" .. real.concat(parts, ", ") .. "}"
                end
                real.print("[dump]", label, d(t, 0))
        end
        envTable.__opdump = function()
                for i = real.max(1, pos - ringSize + 1), pos do
                        real.print(ring[i % ringSize])
                end
        end
end

if cfg.flip_probe then
        envTable.__p = { n = 0 }
end

if cfg.inline_probe then
        envTable.__r = table.create(1e6)
        local __tcodef = function(t)
                if t == "nil" then return 0 elseif t == "number" then return 1 elseif t == "string" then return 2 elseif t == "table" then return 3 elseif t == "function" then return 4 elseif t == "userdata" then return 5 elseif t == "boolean" then return 6 else return 7 end
        end
        envTable.__sc = 0
        envTable.__lA, envTable.__lB, envTable.__lC, envTable.__lD, envTable.__lE = 0, 0, 0, 0, 0
        envTable.__rc, envTable.__rc2 = 0, 0
        envTable.__crR = function(v, tag)
                do
                        if real.type(v) ~= "number" then
                                envTable.__rcp = (envTable.__rcp or 0) + 1
                                if envTable.__rcp <= 2000 then
                                        local T = cfg
                                        real.print("CRN\t" .. tostring(tag) .. "\t" .. real.type(v) .. "\tpc=" .. tostring(pc)
                                                .. "\tlasthit=" .. string.sub(tostring(T.lasthit), 1, 90)
                                                .. "\tret=" .. tostring(T.ret)
                                                .. "\tlastmiss=" .. string.sub(tostring(T.lastmiss), 1, 90)
                                                .. "\tmissn=" .. tostring(T.missn))
                                end
                        end
                end
                local tl = type(v)
                if tl ~= "number" then
                        envTable.__rc2 = (envTable.__rc2 or 0) + 1
                        if envTable.__rc2 <= 4000 then
                                local __n3 = #envTable.__r
                                envTable.__r[__n3 + 1] = -((tag * 1099511627776) + __tcodef(tl) * 8)
                        end
                end
                return v
        end
        envTable.tc = function(v) return __tcodef(type(v)) end
        envTable.__crL = function(v, pc, tag)
                do
                        if real.type(v) ~= "number" then
                                envTable.__rcp = (envTable.__rcp or 0) + 1
                                if envTable.__rcp <= 2000 then
                                        local T = cfg
                                        real.print("CRN\t" .. tostring(tag) .. "\t" .. real.type(v) .. "\tpc=" .. tostring(pc)
                                                .. "\tlasthit=" .. string.sub(tostring(T.lasthit), 1, 90)
                                                .. "\tret=" .. tostring(T.ret)
                                                .. "\tlastmiss=" .. string.sub(tostring(T.lastmiss), 1, 90)
                                                .. "\tmissn=" .. tostring(T.missn))
                                end
                        end
                end
                local tl = type(v)
                if tl ~= "number" then
                        envTable.__rc = (envTable.__rc or 0) + 1
                        if envTable.__rc <= 4000 then
                                local __n2 = #envTable.__r
                                envTable.__r[__n2 + 1] = -((tag * 1099511627776) + __tcodef(tl) * 8)
                                envTable.__r[__n2 + 2] = -(((tag + 1) * 1099511627776) + ((pc or -1) + 1))
                        end
                end
                return v
        end
        envTable.__p = { n = 0 }
        envTable.__opdump = function()
                local names = {}
                for k, x in real.pairs(envTable) do
                        if real.type(x) == "function" then names[x] = k
                        elseif real.type(x) == "table" and x ~= scriptEnv then
                                for k2, y in real.pairs(x) do
                                        if real.type(y) == "function" then names[y] = k .. "." .. real.tostring(k2) end
                                end
                        end
                end
                local function nm(v)
                        if names[v] then return names[v] end
                        if real.type(v) == "string" then return real.fmt("%q", real.sub(v, 1, 80)) end
                        if isP(v) then
                                local chain, q, guard = {}, v, 0
                                while q and guard < 12 do
                                        guard += 1
                                        local qi = infoOf[q]
                                        real.insert(chain, 1, real.tostring(qi.name or qi.key or qi.hint or qi.kind))
                                        q = qi.parent
                                end
                                return "<proxy " .. real.concat(chain, ".") .. ">"
                        end
                        return real.tostring(v)
                end
                local rr = envTable.__r
                for i = real.max(1, #rr - (cfg.dump_last or 1500000)), #rr do
                        local e = rr[i]
                        if real.type(e) == "number" then
                                local pc = e % 65536
                                local rest = (e - pc) / 65536
                                local op = rest % 256
                                rest = (rest - op) / 256
                                local loop = rest % 16
                                local pid = (rest - loop) / 16
                                real.print("P" .. pid .. " L" .. loop .. " op" .. op .. " pc" .. pc)
                        else
                                real.print("  = " .. nm(e[1]))
                        end
                end
        end
end

if cfg.co_log then
        local co = {}
        for k, f in real.pairs(coroutine) do co[k] = f end
        co.resume = function(...)
                local res = table.pack(coroutine.resume(...))
                real.print("[co.resume]", real.unpack(res, 1, res.n))
                return real.unpack(res, 1, res.n)
        end
        envTable.coroutine = co
end

envTable.__pid = { n = 0 }
envTable.__parg1 = {}
envTable.__ent = { n = 0 }
envTable.__skipp = {}
envTable.__pf = real.setmetatable({}, { __mode = "k" })
envTable.__plast = {}
if cfg.fold ~= false then
        hub.pf, hub.pid, hub.plast = envTable.__pf, envTable.__pid, envTable.__plast
end
for _, pid in cfg.skip_protos or {} do envTable.__skipp[pid] = true end
if cfg.spin then
        local sw = { n = 0, step = 1048576 }
        local idle, lastS, lastId = 0, -1, -1
        sw.f = function()
                sw.n = 0
                if cfg.heartbeat and real.clock() - (cfg._hb or startClock) > cfg.heartbeat then
                        cfg._hb = real.clock()
                        real.print(markPrefix .. "HB t=" .. real.fmt("%.1f", real.clock() - startClock) .. " stmts=" .. stmtCount)
                end
                if stmtCount ~= lastS or nextId ~= lastId then
                        idle, lastS, lastId = 0, stmtCount, nextId
                        return
                end
                if hub.decodeUntil then
                        if real.clock() > hub.decodeUntil then
                                abortReason = "constant decode took too long"
                                real.error(abort, 0)
                        end
                        return
                end
                idle += 1
                if idle >= 2 then
                        real.print(markPrefix .. "SPINW idle=" .. tostring(idle) .. " lastS=" .. tostring(lastS) .. " lastId=" .. tostring(lastId) .. " TB\n" .. real.rep(" ", 16384))
                        real.print(markPrefix .. "SPINTRACE " .. tostring(debug.traceback()) .. "\n" .. real.rep(" ", 16384))
                end
                if idle >= cfg.spin then
                        abortReason = abortReason or "endless loop in the script's own code (no environment access)"
                        if cfg.stall_dump and envTable.__r and real.type(envTable.__r) == "table" then
                                local rr = envTable.__r
                                local n2 = #rr
                                local lo = real.max(1, n2 - 150000)
                                real.print(markPrefix .. "SD1 n2=" .. tostring(n2) .. " lo=" .. tostring(lo) .. "\n" .. real.rep(" ", 16384))
                                for i = lo, n2 do
                                        local e = rr[i]
                                        if real.type(e) == "number" and e < 0 and -e >= 1099511627776 then
                                                real.print("STALL " .. (-e))
                                        end
                                end
                        end
                        if cfg.skip_spin and not trigger then
                                local ent = envTable.__ent
                                for i = ent.n, real.max(1, ent.n - 63), -1 do
                                        local p = ent[i % 64]
                                        if p and not envTable.__skipp[p] then trigger = p; break end
                                end
                        end
                        checkBudget()
                end
        end
        envTable.__spin = sw
end
envTable.__pa = cfg.devirt and { n = 0 } or false
envTable.__pk = {}
if envTable.__pa then
        local orig = real.setmetatable({}, { __mode = "k" })
        hub.paOrig = orig
        local nested = real.setmetatable({}, { __mode = "k" })
        local lazyKeys = real.setmetatable({}, { __mode = "k" })
        local holders = real.setmetatable({}, { __mode = "k" })
        local function numCopy(arr)
                local c, n = {}, 0
                for i, x in real.next, arr do
                        if real.type(x) == "number" then c[i] = x; n += 1 end
                end
                return n > 0 and c or nil
        end
        local function snapNested(proto, w)
                if nested[w] == nil then
                        if real.type(w) == "buffer" then
                                local b = buffer.create(buffer.len(w))
                                buffer.copy(b, 0, w)
                                nested[w] = b
                        else
                                nested[w] = numCopy(w) or false
                        end
                end
                return nested[w]
        end
        real.setmetatable(envTable.__pa, { __newindex = function(t, proto, v)
                real.rawset(t, proto, v)
                if real.type(proto) ~= "table" then return end
                local copy = {}
                for _, src_tbl in real.ipairs({ proto, v }) do
                        if real.type(src_tbl) == "table" then
                                for key, arr in real.next, src_tbl do
                                        if real.type(arr) == "table" then
                                                for wk, wv in real.next, arr do
                                                        if real.type(wk) == "string" and real.type(wv) == "table" and real.type(real.rawget(wv, 3)) == "function" then
                                                                hub.savedWn = hub.savedWn or {}
                                                                real.insert(hub.savedWn, { vm = arr, k = wk, v = wv })
                                                        end
                                                end
                                        end
                                        if real.type(arr) == "table" and arr ~= proto and arr ~= v and not copy[arr] then
                                                local c = numCopy(arr)
                                                if arr ~= envTable and real.getmetatable(arr) ~= nil and lazyKeys[arr] == nil then
                                                        local keys = {}
                                                        for k in real.next, arr do keys[k] = true end
                                                        lazyKeys[arr] = keys
                                                        c = c or {}
                                                end
                                                if c then
                                                        copy[arr] = c
                                                elseif arr ~= envTable and real.getmetatable(arr) == nil then
                                                        for _, w in real.next, arr do
                                                                if (real.type(w) == "table" and w ~= proto and w ~= v and w ~= arr and w ~= envTable and real.getmetatable(w) == nil)
                                                                        or real.type(w) == "buffer" then
                                                                        if snapNested(proto, w) then
                                                                                holders[proto] = holders[proto] or {}
                                                                                holders[proto][key] = arr
                                                                        end
                                                                end
                                                        end
                                                end
                                        end
                                end
                        end
                end
                orig[proto] = copy
        end })
        hub.lazyLate = real.setmetatable({}, { __mode = "k" })
        local function restore(copy)
                for arr, c in real.next, copy do
                        local keys = lazyKeys[arr]
                        if keys and not hub.lazyLate[arr] then
                                local late = {}
                                for k in real.next, arr do
                                        if not keys[k] then late[k] = true end
                                end
                                hub.lazyLate[arr] = late
                        end
                        for i, x in real.next, c do real.rawset(arr, i, x) end
                end
        end
        hub.unscramble = function()
                local fixed = 0
                local done, ran, size = {}, {}, {}
                for proto, copy in real.next, orig do
                        local arrays, all = 0, true
                        size[proto] = 0
                        for arr, c in real.next, copy do
                                if not lazyKeys[arr] then
                                        local n, same, huge = 0, 0, 0
                                        for i, x in real.next, c do
                                                n += 1
                                                local y = real.rawget(arr, i)
                                                if y == x then
                                                        same += 1
                                                elseif real.type(y) == "number" and (y >= 16777216 or y <= -16777216) then
                                                        huge += 1
                                                end
                                        end
                                        if same < n then ran[proto] = true end
                                        if n > size[proto] then size[proto] = n end
                                        if n >= 2 then arrays += 1 end
                                        if same > 0 and (same > n * 0.1 or huge < (n - same) * 0.8) then all = false end
                                end
                        end
                        if all and ran[proto] and arrays >= 2 then
                                restore(copy)
                                fixed += 1
                                done[proto] = true
                        end
                end
                local users = {}
                for proto, hs in real.next, holders do
                        for key, arr in real.next, hs do
                                users[arr] = users[arr] or {}
                                users[arr][proto] = key
                        end
                end
                for arr, set in real.next, users do
                        local restored, live = 0, 0
                        for p in real.next, set do
                                if done[p] then restored += size[p] or 0 elseif ran[p] then live += size[p] or 0 end
                        end
                        if restored > 0 then
                                local whole = restored >= live
                                local view = nil
                                for k, w in real.next, arr do
                                        local snap = nested[w]
                                        local changed = false
                                        if real.type(w) == "buffer" and snap then
                                                changed = buffer.tostring(w) ~= buffer.tostring(snap)
                                        elseif real.type(w) == "table" and snap then
                                                for i, x in real.next, snap do
                                                        if real.rawget(w, i) ~= x then changed = true break end
                                                end
                                        end
                                        if changed and whole then
                                                if real.type(w) == "buffer" then
                                                        buffer.copy(w, 0, snap)
                                                else
                                                        for i, x in real.next, snap do real.rawset(w, i, x) end
                                                end
                                        elseif changed then
                                                local pristine
                                                if real.type(w) == "buffer" then
                                                        pristine = buffer.create(buffer.len(snap))
                                                        buffer.copy(pristine, 0, snap)
                                                else
                                                        pristine = {}
                                                        for i, x in real.next, w do pristine[i] = x end
                                                        for i, x in real.next, snap do pristine[i] = x end
                                                end
                                                if not view then
                                                        view = {}
                                                        for k2, w2 in real.next, arr do view[k2] = w2 end
                                                end
                                                view[k] = pristine
                                        end
                                end
                                for p, key in real.next, set do
                                        if whole and ran[p] and not done[p] and orig[p] then
                                                restore(orig[p])
                                                done[p] = true
                                                fixed += 1
                                        elseif view and done[p] then
                                                real.rawset(p, key, view)
                                                if envTable.__pa[p] then real.rawset(envTable.__pa[p], key, view) end
                                        end
                                end
                        end
                end
                return fixed
        end
end
do
        local libs = { "string", "table", "math", "bit32", "buffer", "coroutine", "utf8", "os", "debug", "task", "vector" }
        hub.dumpProtos = function()
                local pa = envTable.__pa
                if not pa then return nil end
                hub.unscrambled = hub.unscramble()
                local fname = {}
                for f, label in real.next, fnText do
                        if real.type(f) == "function" and real.type(label) == "string" then
                                fname[f] = fname[f] or label
                        end
                end
                for k, v in real.next, envTable do
                        if real.type(v) == "function" and real.type(k) == "string" then fname[v] = fname[v] or k end
                end
                for _, lib in real.ipairs(libs) do
                        local t = real.rawget(envTable, lib)
                        if real.type(t) == "table" then
                                for k, v in real.next, t do
                                        if real.type(v) == "function" then fname[v] = fname[v] or (lib .. "." .. real.tostring(k)) end
                                end
                        end
                end
                local stop = { [envTable] = "ENV", [scriptEnv] = "ENV" }
                for _, lib in real.ipairs(libs) do
                        local t = real.rawget(envTable, lib)
                        if real.type(t) == "table" then stop[t] = lib end
                end
                for name in datatypes do
                        local t = real.rawget(envTable, name)
                        if real.type(t) == "table" then
                                stop[t] = stop[t] or name
                                for k, v in real.next, t do
                                        if real.type(v) == "function" then fname[v] = fname[v] or (name .. "." .. real.tostring(k)) end
                                end
                        end
                end
                local ids, queue, fids = {}, {}, {}
                local nfid = 0
                local function hex(s)
                        return (real.gsub(s, ".", function(c) return real.fmt("%02x", real.byte(c)) end))
                end
                local function num(x)
                        if x ~= x then return '{"num":"nan"}' end
                        if x == real.huge then return '{"num":"inf"}' end
                        if x == -real.huge then return '{"num":"-inf"}' end
                        if x == 0 and 1 / x < 0 then return '{"num":"-0"}' end
                        if x == real.floor(x) and x > -2 ^ 53 and x < 2 ^ 53 then return real.fmt("%d", x) end
                        return real.fmt("%.17g", x)
                end
                local function enc(v)
                        local t = real.type(v)
                        if v == nil then return "null"
                        elseif t == "boolean" then return v and "true" or "false"
                        elseif t == "number" then return num(v)
                        elseif t == "string" then return '{"s":"' .. hex(v) .. '"}'
                        elseif t == "function" then
                                if fname[v] then return '{"f":"' .. fname[v] .. '"}' end
                                if not fids[v] then nfid += 1; fids[v] = nfid end
                                local pf = real.rawget(envTable.__pf, v)
                                if real.type(pf) == "table" then
                                        return '{"lf":' .. fids[v] .. ',"pf":' .. enc(pf) .. '}'
                                end
                                if cfg.lf_debug then
                                        local na, va = debug.info(v, "a")
                                        real.print("LFDBG", fids[v], debug.info(v, "l"), na, va, debug.info(v, "n"))
                                end
                                return '{"lf":' .. fids[v] .. '}'
                        elseif t == "table" then
                                if stop[v] then return '{"g":"' .. stop[v] .. '"}' end
                                if not ids[v] then
                                        real.insert(queue, v)
                                        ids[v] = #queue
                                end
                                return '{"t":' .. ids[v] .. "}"
                        elseif real.typeof(v) == "buffer" then
                                return '{"b":"' .. hex(buffer.tostring(v)) .. '"}'
                        elseif t == "vector" then
                                return '{"vec":[' .. num(v.x) .. "," .. num(v.y) .. "," .. num(v.z) .. "]}"
                        end
                        local ok, src = real.pcall(function() return hub.exprOf and hub.exprOf(v) end)
                        if not ok or real.type(src) ~= "string" then
                                ok, src = real.pcall(real.tostring, v)
                        end
                        return '{"u":"' .. real.typeof(v) .. '","src":"' .. (ok and real.type(src) == "string" and hex(src) or "") .. '"}'
                end
                local forced = {}
                local fstats = { calls = 0, got = 0, t0 = real.clock() }
                hub.forceStats = fstats
                if hub.savedWn then
                        for _, sw in real.ipairs(hub.savedWn) do
                                if real.rawget(sw.vm, sw.k) == nil then
                                        real.rawset(sw.vm, sw.k, sw.v)
                                end
                        end
                end
                local byseq = {}
                for proto, cap in real.next, pa do
                        if real.type(cap) == "table" and cap.__seq then
                                byseq[cap.__seq] = real.setmetatable({ self = proto }, { __index = cap })
                        end
                end
                local snapTabs, snapBufs = {}, {}
                if real.type(cfg.force_req) == "string" then
                        local q = {}
                        for proto, cap in real.next, pa do
                                if real.type(cap) == "table" then
                                        real.insert(q, cap)
                                        real.insert(q, proto)
                                end
                        end
                        local qi = 1
                        while qi <= #q do
                                local t = q[qi]
                                qi += 1
                                if not snapTabs[t] and not stop[t] then
                                        local copy = {}
                                        for k, v in real.next, t do
                                                copy[k] = v
                                                if real.type(v) == "table" then
                                                        real.insert(q, v)
                                                elseif real.typeof(v) == "buffer" and not snapBufs[v] then
                                                        snapBufs[v] = buffer.tostring(v)
                                                end
                                        end
                                        snapTabs[t] = copy
                                end
                        end
                end
                local function applyBufs(bufs)
                local bufRestore = {}
                if real.type(bufs) == "string" then
                        for spec in string.gmatch(bufs, "[^;]+") do
                                local head = string.match(spec, "^[^/]+")
                                local v, si = nil, 0
                                for st in string.gmatch(head, "[^,]+") do
                                        local k = real.tonumber(st) or st
                                        si += 1
                                        if si == 1 then v = byseq[k]
                                        elseif si == 2 and real.type(v) == "table" then v = v[k]
                                        elseif real.type(v) == "table" then v = real.rawget(v, k)
                                        else v = nil end
                                end
                                if real.type(v) == "table" then
                                        for k, val in string.gmatch(spec, "/=(%-?%d+):([^/]+)") do
                                                k = real.tonumber(k)
                                                real.insert(bufRestore, { v, k, real.rawget(v, k), true })
                                                real.rawset(v, k, real.tonumber(val))
                                                fstats.bufs = (fstats.bufs or 0) + 1
                                        end
                                elseif real.typeof(v) == "buffer" then
                                        for off, hx in string.gmatch(spec, "/(%d+):(%x+)") do
                                                off = real.tonumber(off)
                                                local n = #hx // 2
                                                if off + n <= buffer.len(v) then
                                                        real.insert(bufRestore, { v, off, buffer.readstring(v, off, n) })
                                                        fstats.bufs = (fstats.bufs or 0) + 1
                                                        for j = 0, n - 1 do
                                                                buffer.writeu8(v, off + j, real.tonumber(string.sub(hx, 2 * j + 1, 2 * j + 2), 16))
                                                        end
                                                end
                                        end
                                end
                        end
                end
                return bufRestore
                end
                local function revertBufs(bufRestore)
                        for i = #bufRestore, 1, -1 do
                                local r = bufRestore[i]
                                if r[4] then real.rawset(r[1], r[2], r[3]) else buffer.writestring(r[1], r[2], r[3]) end
                        end
                end
                local bufRestore = applyBufs(cfg.force_buf)
                local function decodeStart(f, ...)
                        hub.decodeUntil = real.clock() + (cfg.decode_limit or 10)
                        return f(...)
                end
                local abortBefore
                local function decodeGuard(...)
                        hub.decodeUntil = nil
                        abortReason = abortBefore
                        return ...
                end
                local function slot(v, k) return v[k] end
                local function decodeSlot(v, k)
                        abortBefore = abortReason
                        return decodeGuard(real.pcall(decodeStart, slot, v, k))
                end
                local function canDecodeSlot(v, op)
                        if real.type(op) ~= "number" then return true end
                        if op < 0 or op > 1000000 then return false end
                        for nk = 0, -4, -1 do
                                local cand = real.rawget(v, nk)
                                if real.type(cand) == "table" then
                                        local b5, t6 = real.rawget(cand, 5), real.rawget(cand, 6)
                                        local b6, t7 = real.rawget(cand, 6), real.rawget(cand, 7)
                                        local b_obj, k_tab
                                        if real.type(b5) == "buffer" and real.type(t6) == "table" then
                                                b_obj, k_tab = b5, t6
                                        elseif real.type(b6) == "buffer" and real.type(t7) == "table" then
                                                b_obj, k_tab = b6, t7
                                        end
                                        if b_obj and k_tab then
                                                local off = real.rawget(k_tab, op)
                                                if real.type(off) == "number" and (off < 0 or off >= buffer.len(b_obj)) then
                                                        return false
                                                end
                                        end
                                end
                        end
                        return true
                end
                local function decodePath(path, derivedCache, forced)
                        local steps, ovs, toks = {}, {}, {}
                        for st in string.gmatch(path, "[^,]+") do
                                real.insert(toks, st)
                                local a, ov = string.match(st, "^(%-?%d+)@(%-?[%d%.e]+)$")
                                if a then
                                        ovs[#steps + 1] = real.tonumber(ov)
                                        st = a
                                end
                                real.insert(steps, real.tonumber(st) or st)
                        end
                        local derived = false
                        local v = byseq[steps[1]]
                        if not v then
                                for proto, cap in real.next, pa do
                                        if real.type(cap) == "table" and cap.__seq and not byseq[cap.__seq] then
                                                byseq[cap.__seq] = real.setmetatable({ self = proto }, { __index = cap })
                                        end
                                end
                                v = byseq[steps[1]]
                        end
                        local prefix = toks[1]
                        for si = 2, #steps do
                                prefix ..= "," .. toks[si]
                                if real.type(v) ~= "table" then v = nil break end
                                local k = steps[si]
                                local x
                                if si == 2 then
                                        x = v[k]
                                elseif ovs[si] ~= nil and derivedCache[prefix] ~= nil then
                                        derived = true
                                        x = derivedCache[prefix] or nil
                                elseif ovs[si] ~= nil then
                                        derived = true
                                        if not canDecodeSlot(v, ovs[si]) then
                                                v = nil
                                                break
                                        end
                                        fstats.calls += 1
                                        local k0 = real.rawget(v, 0)
                                        if real.type(k0) ~= "table" then
                                                for nk = -1, -4, -1 do
                                                        local cand = real.rawget(v, nk)
                                                        if real.type(cand) == "table" and real.type(real.rawget(cand, 1)) == "number" then
                                                                k0 = cand
                                                                break
                                                        end
                                                end
                                        end
                                        local old = real.rawget(v, k)
                                        local saved
                                        if real.type(k0) == "table" then
                                                saved = real.rawget(k0, k)
                                                real.rawset(k0, k, ovs[si])
                                        end
                                        real.rawset(v, k, nil)
                                        local ok, y = decodeSlot(v, k)
                                        real.rawset(v, k, old)
                                        if real.type(k0) == "table" then real.rawset(k0, k, saved) end
                                        if ok then x = y end
                                        derivedCache[prefix] = x == nil and false or x
                                        if cfg.force_debug then
                                                real.print("FORCEDBG", path, si, real.type(k0), real.tostring(saved), real.tostring(ok), real.tostring(y),
                                                        real.tostring(real.getmetatable(v) ~= nil))
                                        end
                                else
                                        x = real.rawget(v, k)
                                        if x == nil and not derived and forced[v] then
                                                x = forced[v][k]
                                        end
                                        if x == nil then
                                                local k0 = real.rawget(v, 0)
                                                if real.type(k0) ~= "table" then
                                                        for nk = -1, -4, -1 do
                                                                local cand = real.rawget(v, nk)
                                                                if real.type(cand) == "table" and real.type(real.rawget(cand, 1)) == "number" then
                                                                        k0 = cand
                                                                        break
                                                                end
                                                        end
                                                end
                                                local op = (real.type(k0) == "table" and real.type(k) == "number") and real.rawget(k0, k) or nil
                                                if real.type(k) == "number" and real.getmetatable(v) ~= nil and not canDecodeSlot(v, op) then
                                                        v = nil
                                                        break
                                                end
                                                fstats.calls += 1
                                                local ok, y = decodeSlot(v, k)
                                                if cfg.force_debug and not ok then
                                                        real.print("FORCEDBG", path, si, real.tostring(y))
                                                end
                                                if ok and y ~= nil then
                                                        x = y
                                                        if not derived then
                                                                forced[v] = forced[v] or {}
                                                                forced[v][k] = y
                                                                fstats.got += 1
                                                        end
                                                end
                                        end
                                end
                                v = x
                        end
                        return v, derived
                end
                local function callPath(path, derivedCache, forced)
                        local pp, as = string.match(path, "^!([^!]*)!(.*)$")
                        local proto = pp and decodePath((string.gsub(pp, "~", ",")), derivedCache, forced)
                        local f = real.type(proto) == "table" and real.rawget(envTable.__pk, proto)
                        if real.type(f) ~= "function" then return nil end
                        local args, n, frame = {}, 0, nil
                        for a in string.gmatch(as, "[^/]+") do
                                n += 1
                                local c, rest = string.sub(a, 1, 1), string.sub(a, 2)
                                if c == "n" then args[n] = real.tonumber(rest)
                                elseif c == "s" then
                                        args[n] = (real.gsub(rest, "%x%x", function(h) return string.char(real.tonumber(h, 16)) end))
                                elseif c == "t" then args[n] = true
                                elseif c == "f" then args[n] = false
                                elseif c == "F" then frame = frame or {}; args[n] = frame
                                end
                        end
                        if not frame then return nil end
                        fstats.calls += 1
                        abortBefore = abortReason
                        local res = table.pack(decodeGuard(real.pcall(decodeStart, f, real.unpack(args, 1, n))))
                        if not res[1] or res.n > 1 then return nil end
                        local out = {}
                        for k, v in real.next, frame do
                                local t = real.type(v)
                                if real.type(k) == "number" and (t == "string" or t == "number" or t == "boolean") then out[k] = v end
                        end
                        fstats.got += 1
                        return out
                end
                local function decodeAny(path, derivedCache, forced)
                        if string.sub(path, 1, 1) == "!" then
                                return callPath(path, derivedCache, forced), true
                        end
                        return decodePath(path, derivedCache, forced)
                end
                if real.type(cfg.force_req) == "string" then
                        local derivedCache = {}
                        for path in string.gmatch(cfg.force_req, "[^;]+") do
                                local v, derived = decodeAny(path, derivedCache, forced)
                                if derived then
                                        fstats.over = fstats.over or {}
                                        real.insert(fstats.over, path .. "=" .. (v ~= nil and enc(v) or "null"))
                                end
                        end
                end
                revertBufs(bufRestore)
                local function restoreSnap()
                        for t, copy in real.next, snapTabs do
                                real.pcall(function()
                                        local extra = {}
                                        for k in real.next, t do
                                                if copy[k] == nil then real.insert(extra, k) end
                                        end
                                        for _, k in real.ipairs(extra) do real.rawset(t, k, nil) end
                                        for k, v in real.next, copy do real.rawset(t, k, v) end
                                end)
                        end
                        for b, s in real.next, snapBufs do
                                buffer.writestring(b, 0, s)
                        end
                end
                restoreSnap()
                for t, kv in real.next, forced do
                        for k, v in real.next, kv do real.rawset(t, k, v) end
                end
                local out = {}
                local protos = {}
                for proto, cap in real.next, pa do
                        if real.type(proto) ~= "table" then continue end
                        local pid = envTable.__pid[proto]
                        local fields = {}
                        for k, v in real.next, cap do
                                real.insert(fields, '"' .. real.tostring(k) .. '":' .. enc(v))
                        end
                        local self = enc(proto)
                        real.insert(protos, '"' .. (pid and real.tostring(pid) or ("t" .. ids[proto])) .. '":{"self":' .. self .. ","
                                .. real.concat(fields, ",") .. "}")
                end
                local function mtIndex(t)
                        local mt = real.getmetatable(t)
                        local f = real.type(mt) == "table" and real.rawget(mt, "__index") or nil
                        return real.type(f) == "function" and enc(f) or "null"
                end
                local function tableJson(i, t, forced)
                        local view = {}
                        for k, v in real.next, t do view[k] = v end
                        if forced[t] then
                                for k, v in real.next, forced[t] do view[k] = v end
                        end
                        local maxn, cnt = 0, 0
                        for k in real.next, view do
                                if real.type(k) == "number" and k >= 1 and k == real.floor(k) and k < 2 ^ 31 then
                                        cnt += 1
                                        if k > maxn then maxn = k end
                                end
                        end
                        local dense = maxn > 0 and cnt * 2 >= maxn
                        local parts, kv = {}, {}
                        if dense then
                                for j = 1, maxn do parts[j] = enc(view[j]) end
                        end
                        for k, v in real.next, view do
                                if not (dense and real.type(k) == "number" and k >= 1 and k <= maxn and k == real.floor(k)) then
                                        real.insert(kv, "[" .. enc(k) .. "," .. enc(v) .. "]")
                                end
                        end
                        local lateKeys = hub.lazyLate and hub.lazyLate[t]
                        local late = ""
                        if lateKeys then
                                local e = {}
                                for k in real.next, lateKeys do real.insert(e, enc(k)) end
                                late = ',"late":[' .. real.concat(e, ",") .. "]"
                        end
                        return '"' .. i .. '":{"arr":[' .. real.concat(parts, ",") .. '],"kv":[' .. real.concat(kv, ",") .. "]" .. late
                                .. (real.getmetatable(t) ~= nil and (',"mt":true,"mtf":' .. mtIndex(t) .. "}") or "}")
                end
                local tabs = {}
                local i = 1
                while i <= #queue do
                        tabs[i] = tableJson(i, queue[i], forced)
                        i += 1
                end
                local pidmap = {}
                for proto, pid in real.next, envTable.__pid do
                        if real.type(proto) == "table" and ids[proto] then real.insert(pidmap, '"' .. ids[proto] .. '":' .. pid) end
                end
                local parg1 = {}
                if envTable.__parg1 then
                        for pid, a1 in real.next, envTable.__parg1 do
                                if real.type(pid) == "number" and real.type(a1) == "number" then
                                        real.insert(parg1, '"' .. pid .. '":' .. enc(a1))
                                end
                        end
                end
                local overs = {}
                for _, o in real.ipairs(fstats.over or {}) do
                        local path, val = string.match(o, "^([^=]+)=(.*)$")
                        real.insert(overs, '["' .. path .. '",' .. val .. "]")
                end
                if cfg.serve then
                        restoreSnap()
                        local sessDerived, sessForced, sessBufs = {}, {}, {}
                        local dumpEnd, sentEnd = #queue, #queue
                        local initPA, dumpedPA = {}, {}
                        for proto in real.next, pa do initPA[proto] = true; dumpedPA[proto] = true end
                        hub.fetch = function(req, bufs)
                                local t0 = real.clock()
                                hub.fetchEnd = function()
                                        revertBufs(sessBufs)
                                        restoreSnap()
                                end
                                if string.sub(bufs, 1, 1) == "+" then
                                        for _, r in real.ipairs(applyBufs(string.sub(bufs, 2))) do real.insert(sessBufs, r) end
                                elseif bufs ~= "=" then
                                        revertBufs(sessBufs)
                                        sessBufs = applyBufs(bufs)
                                end
                                local vals = {}
                                local start = sentEnd + 1
                                if string.sub(req, 1, 1) == "*" then
                                        req = string.sub(req, 2)
                                        start = dumpEnd + 1
                                        dumpedPA = {}
                                        for proto in real.next, initPA do dumpedPA[proto] = true end
                                end
                                for path in string.gmatch(req, "[^;]+") do
                                        local ok, v = real.pcall(decodeAny, path, sessDerived, sessForced)
                                        real.insert(vals, '["' .. path .. '",' .. (ok and v ~= nil and enc(v) or "null") .. "]")
                                end
                                local newProtos = {}
                                for proto, cap in real.next, pa do
                                        if not dumpedPA[proto] and real.type(proto) == "table" then
                                                dumpedPA[proto] = true
                                                if real.type(cap) == "table" and cap.__seq then
                                                        byseq[cap.__seq] = real.setmetatable({ self = proto }, { __index = cap })
                                                end
                                                local pid = envTable.__pid[proto]
                                                local fields = {}
                                                for k, v in real.next, cap do
                                                        real.insert(fields, '"' .. real.tostring(k) .. '":' .. enc(v))
                                                end
                                                local self = enc(proto)
                                                real.insert(newProtos, '"' .. (pid and real.tostring(pid) or ("t" .. ids[proto])) .. '":{"self":' .. self .. ","
                                                        .. real.concat(fields, ",") .. "}")
                                        end
                                end
                                local parts = {}
                                local j = start
                                while j <= #queue do
                                        real.insert(parts, tableJson(j, queue[j], sessForced))
                                        j += 1
                                end
                                sentEnd = #queue
                                return '{"t":' .. real.fmt("%.4f", real.clock() - t0) .. ',"values":[' .. real.concat(vals, ",") .. '],"tables":{'
                                        .. real.concat(parts, ",") .. '},"new_protos":{' .. real.concat(newProtos, ",") .. "}}"
                        end
                end
                return '{"root_callee":' .. real.tostring(hub.seen and hub.seen[hub.rootCallee] == "ok" and hub.rootCallee or "null") .. ',"overrides":[' .. real.concat(overs, ",") .. '],"protos":{' .. real.concat(protos, ",") .. '},"tables":{' .. real.concat(tabs, ",") ..
                        '},"pid_of_table":{' .. real.concat(pidmap, ",") .. '},"proto_arg1":{' .. real.concat(parg1, ",") .. "}}"
        end
end
function noteTrigger()
        local ent = envTable.__ent
        local routine = ent[ent.n % 64]
        for i = ent.n - 1, real.max(1, ent.n - 63), -1 do
                local q = ent[i % 64]
                if q ~= routine then
                        trigger = q
                        return
                end
        end
end

markC(envTable)
cfuncs[envTable.debug.info] = true

local unknownGlobals = {}
local seenGlobals = {}
real.setmetatable(scriptEnv, {
        __index = function(_, k)
                if real.type(k) ~= "string" then return nil end
                if real.match(k, "^__p%d%l*$") or real.match(k, "^__wp%l*$") then seenGlobals[k] = true return nil end
                if #k >= 12 and real.match(k, "^_*%x+$") and real.find(k, "%d") then return nil end
                if seenGlobals[k] then
                        if cfg.trace_globals and (k == "_bsdata0" or k == "superflow_bytecode") then
                                real.print("[global-read-nil]", k, debug.traceback())
                        end
                        return nil
                end
                if cfg.__superz_logglobal then real.print("\1SUPERZGLOBAL\1" .. k) end
                local p = globalP(k, "function")
                if cfg.trace_globals and (k == "_bsdata0" or k == "superflow_bytecode") then
                        real.print("[global-proxy]", k, debug.info(2, "s"), debug.info(2, "l"),
                                debug.info(2, "n"), debug.traceback())
                end
                if cfg.ptrace then real.print("[unknown-global]", k) end
                remember(unknownGlobals, k)
                real.rawset(scriptEnv, k, p)
                return p
        end,
        __newindex = function(_, k, v)
                if real.type(k) == "string" then
                        seenGlobals[k] = true
                        if cfg.trace_globals and (k == "_bsdata0" or k == "superflow_bytecode") then
                                real.print("[global-write]", k, real.type(v), debug.traceback())
                        end
                end
                real.rawset(scriptEnv, k, v)
        end,
})

local traceWrap
local traceCache = {}
local traceNames = {}
local function argStr(...)
        local t = {}
        for i = 1, real.select("#", ...) do
                local v = real.select(i, ...)
                t[i] = isP(v) and ("<" .. real.tostring(infoOf[v].name or infoOf[v].hint) .. ">") or real.tostring(v)
                if traceNames[v] then t[i] = "<" .. traceNames[v] .. ">" end
                if real.type(v) == "string" then t[i] = real.fmt("%q", real.sub(v, 1, 60)) end
        end
        return real.concat(t, ", ")
end
function traceWrap(label, v)
        if real.type(v) == "function" then
                if traceCache[v] then return traceCache[v] end
                local w = function(...)
                        real.print("[call]", label .. "(" .. argStr(...) .. ")")
                        local res = table.pack(v(...))
                        real.print("   ->", argStr(real.unpack(res, 1, res.n)))
                        return real.unpack(res, 1, res.n)
                end
                cfuncs[w] = cfuncs[v]
                fnText[w] = fnText[v]
                traceCache[v] = w
                return w
        elseif real.type(v) == "table" and v ~= scriptEnv and not traceCache[v] then
                local proxyT = real.setmetatable({}, {
                        __index = function(_, k) return traceWrap(label .. "." .. real.tostring(k), v[k]) end,
                        __newindex = v,
                        __iter = function() return real.next, v end,
                })
                traceCache[v] = proxyT
                return proxyT
        elseif traceCache[v] then
                return traceCache[v]
        end
        return v
end

if not cfg.flat_env then
        local globals = scriptEnv
        scriptEnv = real.setmetatable({ script = globals.script }, {
                __index = cfg.getlog and function(_, k)
                        real.print("[get]", k)
                        return globals[k]
                end or globals,
                __newindex = function(w, k, v)
                        if real.type(k) == "string" then
                                seenGlobals[k] = true
                                if cfg.trace_globals and (k == "_bsdata0" or k == "superflow_bytecode") then
                                        real.print("[global-write]", k, real.type(v), debug.traceback())
                                end
                        end
                        real.rawset(w, k, v)
                end,
        })
end

if cfg.probe then
        local back = scriptEnv
        traceNames[back] = "ENV"
        for k, v in real.pairs(back) do
                if real.type(v) == "table" or real.type(v) == "function" then traceNames[v] = real.tostring(k) end
        end
        local hot = { buffer = true, bit32 = true, table = true, string = true, math = true, coroutine = true,
                unpack = true, setmetatable = true, select = true }
        scriptEnv = real.setmetatable({}, {
                __index = function(_, k)
                        local v = back[k]
                        real.print("[get]", k, real.type(v))
                        if hot[k] then return v end
                        local w = traceWrap(k, v)
                        if w ~= v and real.type(w) ~= "nil" then traceNames[w] = real.tostring(k) end
                        return w
                end,
                __newindex = function(_, k, v)
                        real.print("[set]", k, real.type(v))
                        back[k] = v
                end,
        })
end

if cfg.trace then
        local back = scriptEnv
        traceNames[back] = "ENV"
        for k, v in real.pairs(back) do
                if real.type(v) == "table" or real.type(v) == "function" then traceNames[v] = real.tostring(k) end
        end
        scriptEnv = real.setmetatable({}, {
                __metatable = nil,
                __index = function(_, k)
                        local v = back[k]
                        real.print("[get]", k, real.type(v))
                        local w = traceWrap(k, v)
                        if w ~= v and real.type(w) ~= "nil" then traceNames[w] = real.tostring(k) end
                        return w
                end,
                __newindex = function(_, k, v)
                        real.print("[set]", k, real.type(v))
                        back[k] = v
                end,
        })
end

local present = {}
local used = {}
local names = {}
local nameCount = {}

local function sanitize(h)
        h = real.tostring(h or "v")
        h = real.gsub(h, "[^%w_]", "")
        if h == "" or real.match(h, "^%d") then h = "v" .. h end
        if not isIdent(h) then h = h .. "_" end
        return h
end

local function uniqueName(h)
        h = sanitize(h)
        nameCount[h] = (nameCount[h] or 0) + 1
        return nameCount[h] == 1 and h or (h .. nameCount[h])
end

local function scanBlock(block, fn)
        for _, s in block.lines do
                fn(s)
                if s.block then scanBlock(s.block, fn) end
        end
end

local markText
local function markProxy(id)
        local p = byId[id]
        if not p then return end
        local info = infoOf[p]
        if used[id] then return end
        used[id] = true
        if info.parent then markProxy(infoOf[info.parent].id) end
        if info.text then markText(info.text) end
        if info.kind == "call" and info.stmt and present[info.stmt] then
                markText(info.stmt.call)
        end
end
function markText(text)
        for id in string.gmatch(text, "\1(%d+)\2") do
                markProxy(real.tonumber(id))
        end
        for fid in string.gmatch(text, "\3(%d+)\4") do
                local rec = frec[real.tonumber(fid)]
                if rec and not rec.marked then
                        rec.marked = true
                        local function mark(s)
                                if s.text then markText(s.text) end
                                if s.call then markText(s.call) end
                                if s.header then markText(s.header) end
                        end
                        scanBlock(rec.block, mark)
                        if rec.alt then scanBlock(rec.alt, mark) end
                end
        end
end

local exprOf
local resolve

hub.exprOf = function(p) return exprOf(p) end
function exprOf(p)
        local info = infoOf[p]
        if info.kind == "name" then return info.name end
        if info.kind == "index" then return exprOf(info.parent) .. keySuffix(info.key) end
        if info.kind == "expr" then return resolve(info.text, info.indent or 0) end
        if info.kind == "call" then
                if info.var then return info.var end
                return resolve(info.stmt.call, info.indent or 0)
        end
        return "nil"
end

local renderBlock

function resolve(text, ind)
        for _ = 1, 10 do
                if not real.find(text, "\1%d+\2") then break end
                text = real.gsub(text, "\1(%d+)\2", function(id)
                        local p = byId[real.tonumber(id)]
                        if not p then return "nil" end
                        infoOf[p].indent = ind
                        return exprOf(p)
                end)
        end
        local src = text
        text = real.gsub(text, "()\3(%d+)\4", function(pos, fid)
                local rec = frec[real.tonumber(fid)]
                local k = 0
                local ls = 1
                for i = pos - 1, 1, -1 do
                        if real.byte(src, i) == 10 then ls = i + 1 break end
                end
                if ls > 1 then
                        while real.byte(src, ls + k) == 9 do k += 1 end
                end
                local lines = { "function(" .. real.concat(rec.params, ", ") .. ")" }
                if rec.alt then
                        local a, b = {}, {}
                        local was = hub.markers
                        hub.markers = false
                        renderBlock(rec.block, ind + k + 1, a)
                        renderBlock(rec.alt, ind + k + 1, b)
                        hub.markers = was
                        local pad = real.rep("\t", ind + k + 1)
                        local function starts(t, i)
                                local l = t[i]
                                return l == nil or (real.sub(l, 1, #pad) == pad and real.byte(l, #pad + 1) ~= 9
                                        and not real.match(l, "^%s*[%)}]") and not real.match(l, "^%s*end%f[%W]")
                                        and not real.match(l, "^%s*else"))
                        end
                        local p = 0
                        local common = 0
                        while a[common + 1] ~= nil and a[common + 1] == b[common + 1] do
                                common += 1
                                if starts(a, common + 1) and starts(b, common + 1) then p = common end
                        end
                        local s = 0
                        common = 0
                        while common < #a - p and common < #b - p and a[#a - common] == b[#b - common] do
                                common += 1
                                if starts(a, #a - common + 1) and starts(b, #b - common + 1) then s = common end
                        end
                        for i = 1, p do real.insert(lines, a[i]) end
                        local st = rec.params[1]
                        local function shifted(t)
                                local out = {}
                                for i = p + 1, #t - s do real.insert(out, "\t" .. (real.gsub(t[i], "\n", "\n\t"))) end
                                return out
                        end
                        local sa, sb = shifted(a), shifted(b)
                        if #sa > 0 then
                                real.insert(lines, pad .. "if " .. st .. " then")
                                for _, l in sa do real.insert(lines, l) end
                                if #sb > 0 then
                                        real.insert(lines, pad .. "else")
                                        for _, l in sb do real.insert(lines, l) end
                                end
                                real.insert(lines, pad .. "end")
                        elseif #sb > 0 then
                                real.insert(lines, pad .. "if not " .. st .. " then")
                                for _, l in sb do real.insert(lines, l) end
                                real.insert(lines, pad .. "end")
                        end
                        for i = #a - s + 1, #a do real.insert(lines, a[i]) end
                else
                        renderBlock(rec.block, ind + k + 1, lines)
                end
                real.insert(lines, real.rep("\t", ind + k) .. "end")
                return real.concat(lines, "\n")
        end)
        return text
end

function renderBlock(block, ind, out)
        local pad = real.rep("\t", ind)
        for _, s in block.lines do
                local mark = hub.markers and #out + 1
                if mark then real.insert(out, false) end
                if s.header then
                        real.insert(out, pad .. resolve(s.header, ind))
                        renderBlock(s.block, ind + 1, out)
                        real.insert(out, pad .. "end")
                elseif s.call then
                        local p = s.res
                        local info = p and infoOf[p]
                        if info and info.var then
                                real.insert(out, pad .. "local " .. info.var .. " = " .. resolve(s.call, ind))
                        else
                                real.insert(out, pad .. resolve(s.call, ind))
                        end
                else
                        real.insert(out, pad .. resolve(s.text, ind))
                end
                if mark then
                        local n = 0
                        for i = mark + 1, #out do
                                n += 1
                                for _ in string.gmatch(out[i], "\n") do n += 1 end
                        end
                        out[mark] = pad .. "--@" .. n .. " " .. (s.chain or "")
                end
        end
end

local function render()
        hub.markers = cfg.fold ~= false and hub.pf ~= nil
        local function collect(block)
                for _, s in block.lines do
                        if s.call then present[s] = true end
                        if s.block then collect(s.block) end
                end
        end
        collect(rootTrace)
        for _, rec in frec do
                collect(rec.block)
                if rec.alt then collect(rec.alt) end
        end
        scanBlock(rootTrace, function(s)
                if s.text then markText(s.text) end
                if s.call then markText(s.call) end
                if s.header then markText(s.header) end
        end)
        for id = 1, nextId do
                local p = byId[id]
                local info = infoOf[p]
                if info.kind == "call" and info.stmt and present[info.stmt] and (used[id] or info.forceVar) then
                        info.var = uniqueName(info.hint)
                end
        end
        local out = {}
        renderBlock(rootTrace, 0, out)
        return real.concat(out, "\n")
end

trampEnv = scriptEnv
for _, t in tramps do real.setfenv(t, scriptEnv) end
local function runMain(resumeRunner)
local chunk, cerr
local runner, rs
local fetchwait = false
if resumeRunner then
        runner = urls.__lrm_runner
        urls.__lrm_runner = nil
        chunk = true
        if real.type(runner) ~= "thread" then
                chunk = nil
                cerr = "no suspended run"
        end
else
        chunk, cerr = real.loadstring(__source, "=Script")
end
local status
if not chunk then
        status = (resumeRunner and "resume error: " or "compile error: ") .. real.tostring(cerr)
else
        if not resumeRunner then
        if cfg.prelude then
                local pf = real.loadstring(cfg.prelude, "=prelude")
                real.setfenv(pf, { G = envTable._G, genv = genv, rawset = real.rawset, shared = envTable.shared, game = envTable.game, env = envTable,
                        setprop = function(p, k, v) infoOf[p].props[k] = v end })
                pf()
                for t, shadow in real.next, hub.genvShadow or {} do
                        for k, v in real.next, t do shadow[k] = v end
                end
        end
        if cfg.plugin_rt then
                local pf, perr = real.loadstring(cfg.plugin_rt, "=plugin_rt_" .. real.tostring(#cfg.plugin_rt))
                if not pf then real.error("plugin runtime: " .. real.tostring(perr)) end
                pf({ env = envTable, hub = hub, real = real, cfg = cfg, isP = isP, info = infoOf })
        end
        for _, lib in { "string", "math", "table", "os", "debug", "buffer", "utf8", "task", "bit32", "coroutine", "vector" } do
                local t = real.rawget(envTable, lib)
                if real.type(t) == "table" and not table.isfrozen(t) then table.freeze(t) end
        end
        real.setfenv(chunk, scriptEnv)
        real.rawset(scriptEnv, "__OPC", 0)
        real.rawset(scriptEnv, "__LAST", 0)
        local handler = function(e)
                if e == loopMark or e == abort or e == tamper then return e end
                return real.tostring(e) .. "\n" .. debug.traceback()
        end
        runner = coroutine.create(function()
                real.setfenv(0, scriptEnv)
                local __res = real.pack(real.xpcall(chunk, handler))
                if cfg.call_result and __res[1] and real.type(__res[2]) == "function" then
                        __res = real.pack(real.xpcall(__res[2], handler))
                end
                return real.unpack(__res, 1, __res.n)
        end)
end
deferred.runner = runner
deferred.running = false
while true do
        rs = table.pack(coroutine.resume(runner))
        if rs[1] and rs[2] == abort and coroutine.status(runner) == "suspended" then rs = { false, abort, n = 2 } end
        if rs[1] and real.type(rs[2]) == "string" and real.sub(rs[2], 1, 9) == "__LRMRES " then
                urls.__lrm_runner = runner
                fetchwait = true
        end
        break
end
if not fetchwait then
        real.pcall(hub.syncGenv)
        local mainOk = rs[1] and rs[2] ~= false or (rs[1] and coroutine.status(runner) == "suspended")
        local r2 = coroutine.create(function()
                real.setfenv(0, scriptEnv)
                if mainOk then runDeferred() end
                runHandlers()
        end)
        coroutine.resume(r2)
        local ok, err
        if not rs[1] then
                ok, err = false, rs[2]
        elseif coroutine.status(runner) == "suspended" then
                ok, err = true, nil
        else
                ok, err = rs[2], rs[3]
        end
        popTo(1)
        if cfg.inline_probe and not ok and err ~= tamper and envTable.__opdump then
                cfg.dump_last = cfg.dump_err or 3000
                envTable.__opdump()
        end
        if ok then
                status = "finished"
        elseif err == loopMark then
                status = "stopped in an endless loop (truncated)"
        elseif err == abort then
                status = "aborted: " .. real.tostring(abortReason)
        elseif err == tamper then
                status = "Luraph anti-tamper triggered in the main thread (run stopped)"
        else
                status = "script error: " .. real.tostring(err) .. "\n" .. real.tostring(debug.traceback(err, 2))
                real.print(markPrefix .. "SCRIPTTB " .. real.gsub(real.tostring(debug.traceback(err, 2)), "\n", " | "))
                real.reportErrLine(err)
        end
        end
end

if fetchwait then
        real.print(servePad)
        return "fetchwait"
end

local body = render()
local header = {}
real.insert(header, "-- run status: " .. real.gsub(status, "\n", "\n--   "))
real.insert(header, real.fmt("-- opcount %d last %d", real.rawget(scriptEnv, "__OPC") or -1, real.rawget(scriptEnv, "__LAST") or -1))
real.insert(header, "-- OPC=" .. real.tostring(real.rawget(scriptEnv, "__OPC") or "nil") .. " SPIN=" .. (function() local sp = real.rawget(scriptEnv, "__spin") if sp ~= nil then return real.tostring(real.type(sp) == "table" and sp.n or sp) else return "nil" end end)())
real.insert(header, real.fmt("-- %d statements recorded in %.2fs", stmtCount, real.clock() - startClock))
if #urls > 0 then
        real.insert(header, "-- URLs requested:")
        for _, u in real.ipairs(urls) do real.insert(header, "--   " .. u) end
end
if #remotes > 0 then
        real.insert(header, "-- remotes fired/invoked:")
        for _, rp in real.ipairs(remotes) do real.insert(header, "--   " .. exprOf(rp)) end
end
if #unknownGlobals > 0 then
        local names = unknownGlobals
        if #names > 12 then names = { real.unpack(names, 1, 12) } ; real.insert(names, "...") end
        real.insert(header, real.fmt("-- warning: %d unknown global(s) were answered by ever-callable proxies "
                .. "(guessed behaviour, see their call sites): %s", #unknownGlobals, real.concat(names, ", ")))
end
if assumedCmp > 0 then
        real.insert(header, real.fmt("-- warning: %d comparison(s) on opaque values were assumed "
                .. "('<' true, '<=' false); check the 'condition:' comments in the output", assumedCmp))
end

cfg.heartbeat = nil
real.print(markPrefix .. "ENVLOG-BEGIN")
if real.rawget(envTable, "__tr") then
        local tr = envTable.__tr
        local ringSize = tr.n
        for i = real.max(1, tr.total - ringSize + 1), tr.total do
                real.print(markPrefix .. "TR " .. real.tostring(tr[(i - 1) % ringSize + 1]))
        end
end
if trigger then real.print(markPrefix .. "TRIGGER " .. trigger) end
for _, line in real.ipairs(p2dLog) do real.print(markPrefix .. "P2D " .. line) end
if cfg.call_log then hub.dumpCallLog() end
if p2dMiss then real.print(markPrefix .. "P2DMISS") end
for _, hook in real.ipairs(hub.endHooks or {}) do
        local ok, text = real.pcall(hook)
        real.print(ok and text or (markPrefix .. "HOOKERR " .. real.tostring(text)))
end
if cfg.devirt then
        local ok, js = real.pcall(hub.dumpProtos)
        local fs = hub.forceStats
        if fs then
                real.print(real.fmt("%sFORCE calls=%d decoded=%d in %.1fs, %d buffer patches", markPrefix, fs.calls, fs.got,
                        real.clock() - fs.t0, fs.bufs or 0))
        end
        if (hub.unscrambled or 0) > 0 then real.print(markPrefix .. "UNSCRAMBLED " .. hub.unscrambled) end
        real.print(markPrefix .. "PROTOS " .. (ok and js or ("error: " .. real.tostring(js))))
end
for _, key in real.ipairs(newChunks) do
        real.print(markPrefix .. "CHUNK " .. key)
        real.print((real.gsub(newChunks[key], ".", function(c) return real.fmt("%02x", real.byte(c)) end)))
end
real.print(real.concat(header, "\n"))
real.print("")
real.print(body)
if cfg.dump_strings then
        real.print(markPrefix .. "ENVLOG-STRINGS")
        local seen = {}
        for _, s in collected do
                if not seen[s] then
                        seen[s] = true
                        real.print(quote(s))
                end
        end
end
if cfg.audit ~= false then
    for _, event in real.ipairs(real.auditState.events) do
        local ok, encoded = real.pcall(real.json.encode, event)

        if ok then
            real.print(markPrefix .. "AUDIT " .. encoded)
        end
    end

    real.print(markPrefix .. "AUDIT-DROPPED " ..
        real.tostring(real.auditState.dropped))
end
real.print(markPrefix .. "ENVLOG-END")
if cfg.serve then real.print(servePad) end
if native then
        for _, p in real.pairs(byId) do
                local r = realValues[p]
                if r ~= nil and real.typeof(r) == "Instance" then real.pcall(r.Destroy, r) end
        end
        return real.concat(outBuf, "\n")
end
end
if cfg.serve then
        servePad = real.rep(" ", 16384)
        hub.serve = function(req, buf, mode)
                if mode == "http" then
                        local ok2, decoded = real.pcall(function()
                                local m = {}
                                for k, v in real.next, real.json.decode(req) or {} do
                                        m[k] = (real.type(v) == "table" and v)
                                                or { status = 200, body = real.tostring(v) }
                                end
                                return m
                        end)
                        if ok2 then
                                cfg.http_map = decoded
                                for k, v in real.next, decoded do
                                        if real.type(v) == "table" and v.body then
                                                cfg.readfile_map = cfg.readfile_map or {}
                                                cfg.readfile_map["__lrm_session_response"] = v.body
                                        end
                                end
                        end
                        real.print(markPrefix .. "HTTPMAP " .. real.tostring(ok2) .. " keys="
                                .. (function()
                                        local n = 0
                                        if ok2 then
                                                for _ in real.next, decoded do n += 1 end
                                        end
                                        return n
                                end)())
                        real.print(servePad)
                        return
                end
                if mode == "start" and real.type(req) == "string" and #req > 0 then
                        cfg.readfile_map = cfg.readfile_map or {}
                        local bodyv, headerv = req, "{}"
                        local okp, parsed = real.pcall(function() return real.json.decode(req) end)
                        if okp and real.type(parsed) == "table" and real.type(parsed.body) == "string" then
                                bodyv = parsed.body
                                headerv = real.json.encode(parsed.headers or {})
                        end
                        cfg.readfile_map["__lrm_session_response"] = bodyv
                        cfg.readfile_map["__lrm_session_headers"] = headerv
                        real.print(markPrefix .. "RESP-PLANTED " .. real.tostring(#bodyv) .. " hdr=" .. real.tostring(#headerv))
                end
                if mode == "start" then
                        runMain()
                        return
                end
                if mode == "resume" then
                        runMain(true)
                        return
                end
                if mode == "plantdbg" then
                        local function chk(s)
                                local h = 0
                                for i = 1, #s do h = (h + real.byte(s, i) * i) % 65536 end
                                return h
                        end
                        local list = urls.__lrm_plant
                        if real.type(list) ~= "table" then
                                real.print(markPrefix .. "PLANTDBG none")
                        else
                                real.print(markPrefix .. "PLANTDBG entries=" .. real.tostring(#list))
                                for i = 1, #list do
                                        local e = list[i]
                                        if real.type(e) == "table" and real.type(e.body) == "string" then
                                                real.print(markPrefix .. "  [" .. i .. "] body=" .. real.tostring(#e.body)
                                                        .. " url=" .. (real.type(e.url) == "string"
                                                                and (real.tostring(#e.url) .. " chk=" .. real.tostring(chk(e.url))
                                                                        .. " " .. real.sub(e.url, 1, 48) .. ".." .. real.sub(e.url, -10))
                                                                or real.tostring(e.url)))
                                        else
                                                real.print(markPrefix .. "  [" .. i .. "] MALFORMED type=" .. real.type(e)
                                                        .. "/" .. real.type(e and e.body))
                                        end
                                end
                        end
                        real.print(servePad)
                        return
                end
                if mode == "plant" and (real.type(req) == "table"
                        or (real.type(req) == "string" and #req > 0)) then
                        local bodyv, headerv, urlv, reqbodyv
                        if real.type(req) == "table" then
                                bodyv = real.type(req.body) == "string" and req.body or nil
                                headerv = real.type(req.headers) == "table" and req.headers or {}
                                urlv = real.type(req.url) == "string" and req.url or nil
                                reqbodyv = real.type(req.reqbody) == "string" and req.reqbody or nil
                        else
                                local okp3, parsed3 = real.pcall(function() return real.json.decode(req) end)
                                bodyv, headerv, urlv = req, {}, nil
                                if okp3 and real.type(parsed3) == "table" and real.type(parsed3.body) == "string" then
                                        bodyv = parsed3.body
                                        urlv = parsed3.url
                                        if real.type(parsed3.headers) == "table" then headerv = parsed3.headers end
                                        if real.type(parsed3.reqbody) == "string" then reqbodyv = parsed3.reqbody end
                                end
                        end
                        local list = urls.__lrm_plant
                        if real.type(bodyv) ~= "string" then
                                real.print(markPrefix .. "PLANT-BAD (no body)")
                                real.print(servePad)
                                return
                        end
                        if real.type(list) ~= "table" then list = {}; urls.__lrm_plant = list end
                        local replaced = false
                        if real.type(urlv) == "string" then
                                for i = 1, #list do
                                        local e = list[i]
                                        if real.type(e) == "table" and e.url == urlv
                                                and (e.reqbody or nil) == (reqbodyv or nil) then
                                                list[i] = { body = bodyv, headers = headerv, url = urlv, reqbody = reqbodyv }
                                                replaced = true
                                                break
                                        end
                                end
                        end
                        if not replaced then
                                real.insert(list, { body = bodyv, headers = headerv, url = urlv, reqbody = reqbodyv })
                        end
                        real.print(markPrefix .. "PLANT-OK " .. real.tostring(#bodyv) .. " entries="
                                .. real.tostring(#list) .. " url=" .. real.tostring(urlv ~= nil and #urlv or -1))
                        real.print(servePad)
                        return
                end
                if mode == "fetch" then
                        real.print(markPrefix .. "ENVLOG-BEGIN")
                        local ok, js = real.pcall(function() return hub.fetch(req, buf) end)
                        real.print(markPrefix .. "FETCH " .. (ok and js or ("error: " .. real.tostring(js))))
                        real.print(markPrefix .. "ENVLOG-END")
                        real.print(servePad)
                        return
                end
                if hub.fetchEnd then
                        hub.fetchEnd()
                        hub.fetchEnd = nil
                end
                hub.fetch = nil
                cfg.force_req, cfg.force_buf = req, buf
                real.print(markPrefix .. "ENVLOG-BEGIN")
                local ok, js = real.pcall(hub.dumpProtos)
                local fs = hub.forceStats
                if fs then
                        real.print(real.fmt("%sFORCE calls=%d decoded=%d in %.1fs, %d buffer patches", markPrefix, fs.calls, fs.got,
                                real.clock() - fs.t0, fs.bufs or 0))
                end
                real.print(markPrefix .. "PROTOS " .. (ok and js or ("error: " .. real.tostring(js))))
                real.print(markPrefix .. "ENVLOG-END")
                real.print(servePad)
        end
        return hub.serve
end
return runMain()
